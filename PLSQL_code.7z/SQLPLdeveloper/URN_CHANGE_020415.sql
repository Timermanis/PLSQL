--RUN these 2 queries!@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
502963007440800
503103118612300
select * from customers a where CUS_ACCOUNT_NUMBER  in (
503103143706547,
503103143706548,
503103143706552,
503103143706553,
503103143706554,
503103143706559,
503103143698304,
503103143698305,
503103143698306,
503103143711920,
502963003090900,
503103144633300,
503103136363000,
503103144640100,
503103144681400,
503103136431600,
502963019906451 

) and CUS_TO_DATE = '31/DEC/4000'

select unique CUS_ACCOUNT_NUMBER from customers a where CUS_ACCOUNT_NUMBER  in (

503103143706547,
503103143706548,
503103143706552,
503103143706553,
503103143706554,
503103143706559,
503103143698304,
503103143698305,
503103143698306,
503103143711920,
502963003090900,
503103144633300,
503103136363000,
503103144640100,
503103144681400,
503103136431600,
502963019906451
) 
group by CUS_ACCOUNT_NUMBER having CUS_TO_DATE = (select max(CUS_TO_DATE) from customers where CUS_ACCOUNT_NUMBER = a.CUS_ACCOUNT_NUMBER)
minus
select distinct(CUS_ACCOUNT_NUMBER) from customers a where CUS_ACCOUNT_NUMBER  in (
502963061714852
) and cus_to_date > sysdate and CUS_BRANCH_CODE = 'BRA740' --for update--order by  CUS_ACCOUNT_NUMBER,CUS_TO_DATE

select * from customer_x_ref x where x.ccr_cust_urn in (
503103143706547,
503103143706548,
503103143706552,
503103143706553,
503103143706554,
503103143706559,
503103143698304,
503103143698305,
503103143698306,
503103143711920,
502963003090900,
503103144633300,
503103136363000,
503103144640100,
503103144681400,
503103136431600,
502963019906451

)--New URN

select * from customers where CUS_ACCOUNT_NUMBER in (
503103143329600,
502963011996351,
502963047265500,
502963080206300,
502963002108889,
503103143415600,
503103143416300,
503103143417000,
503103143418700,
503103143419400,
503103143420000,
503103137791000,
503103113938900,
502963096424207,
503103143430900,
503103136132202,

503103126655951,
503103142787500,
503103120296051


) and cus_to_date = to_date('31/12/4000','dd/mm/yyyy')

select * from customer_x_ref where CCR_BUS_PARTNER_ID in (156360,156357)
503103126655900	503103126655951
503103142788200	503103142787500
503103120296000	503103120296051


-------------------------------------------------------------------------------
select * from dc_ans d where d.net_issue_year > 2014

truncate table dc_ans;
insert into dc_ans
select *
  from agent_net_sales d
 where d.net_agent_account_number in 
 (
502963088406979,
502963088406982,
502963088406984,
502963088406965,
502963088406966,
502963088407079,
502963088407057,
502963088406973,
502963088406952,
550163950000800,
740164484000800,
740164491000800,
740164479000600,
740164542000100,
220164523000700,
220164522000800,
502963019906400

)
   and not exists (SELECT 1
                     FROM title_history_2, titles, branch_issues, customers
                    WHERE cus_branch_code = bris_branch_code
                      AND bris_invoice_date BETWEEN cus_from_date AND cus_to_date
                      AND titl_code = bris_title_code
                      AND th_code(+) = bris_title_code
                      AND bris_invoice_date BETWEEN th_from_date(+) AND th_to_date(+)
                      AND bris_ean = d.net_issue_ean
                      AND bris_issue_year = d.net_issue_year
                      AND cus_account_number = d.net_agent_account_number
                      AND d.net_issue_year > to_char(sysdate, 'YYYY')-3 );


delete from agent_net_sales s
 where (s.net_agent_account_number, s.net_issue_ean, s.net_issue_year) in (select s1.net_agent_account_number, s1.net_issue_ean, s1.net_issue_year
                                                                             from dc_ans s1);

commit;


select LPAD(555,5, 0) from dual

-----------------------------------------------------
select * from agent_net_sales s
 where (s.net_agent_account_number, s.net_issue_ean, s.net_issue_year) in (select s1.net_agent_account_number, s1.net_issue_ean, s1.net_issue_year
                                                                             from dc_ans s1);

select distinct d.net_agent_account_number from dc_ans d where d.net_issue_year >2014 502963031593800
select * from dc_ans d where d.net_agent_account_number = 502963031593800



insert into agent_net_sales s
select &new_urn,
       NET_ISSUE_EAN,
       NET_ISSUE_YEAR,
       NET_BOX_OUT_QUANTITY,
       NET_CREDIT_QUANTITY,
       NET_OTHER_SALES_QUANTITY,
       NET_COMMITED_QUANTITY,
       NET_CASUAL_QUANTITY,
       NET_RETURN_QUANTITY,
       NET_NOTE_KEYED_FLAG,
       NET_CTB_FLAG,
       NET_BRANCH_CODE,
       NET_BOX_NUMBER,
       NET_MULTIPLE_CODE,
       NET_MULTIPLE_GRADE_CODE,
       NET_ANMW_CODE,
       NET_RETAILER_BAND,
       NET_POSTCODE_OUTER,
       NET_PUBLISHER_CODE,
       NET_TITLE_CODE
  from dc_ans
where NET_AGENT_ACCOUNT_NUMBER = &old_urn and NET_ISSUE_YEAR >= 2013;

503103108773451	503103108773400
503103116492300	503103116492351

------------------------------------------
create table dc_ans1 as select * from dc_ans where 1=2
truncate table dc_ans1
insert into dc_ans1
select *
  from agent_net_sales d
 where d.net_agent_account_number in 
 (
502963080206300 

)
   and not exists (SELECT 1
                     FROM title_history_2, titles, branch_issues, customers
                    WHERE cus_branch_code = bris_branch_code
                      AND bris_invoice_date BETWEEN cus_from_date AND cus_to_date
                      AND titl_code = bris_title_code
                      AND th_code(+) = bris_title_code
                      AND bris_invoice_date BETWEEN th_from_date(+) AND th_to_date(+)
                      AND bris_ean = d.net_issue_ean
                      AND bris_issue_year = d.net_issue_year
                      AND cus_account_number = d.net_agent_account_number);


delete from agent_net_sales s
 where (s.net_agent_account_number, s.net_issue_ean, s.net_issue_year) in (select s1.net_agent_account_number, s1.net_issue_ean, s1.net_issue_year
                                                                             from dc_ans1 s1);

commit;
--------------------------------------
insert into agent_net_sales s
select &new_urn,
       NET_ISSUE_EAN,
       NET_ISSUE_YEAR,
       NET_BOX_OUT_QUANTITY,
       NET_CREDIT_QUANTITY,
       NET_OTHER_SALES_QUANTITY,
       NET_COMMITED_QUANTITY,
       NET_CASUAL_QUANTITY,
       NET_RETURN_QUANTITY,
       NET_NOTE_KEYED_FLAG,
       NET_CTB_FLAG,
       NET_BRANCH_CODE,
       NET_BOX_NUMBER,
       NET_MULTIPLE_CODE,
       NET_MULTIPLE_GRADE_CODE,
       NET_ANMW_CODE,
       NET_RETAILER_BAND,
       NET_POSTCODE_OUTER,
       NET_PUBLISHER_CODE,
       NET_TITLE_CODE
  from dc_ans
 where NET_AGENT_ACCOUNT_NUMBER = &old_urn and NET_ISSUE_YEAR > 2014;
 ----------------
 790138303000000	503103143597900
790553110307300	503103126994900
791128110105400	503103126515600

 
 select distinct m.net_agent_account_number from dc_ans m where m.net_issue_year >= 2015
791010110504300	502963047265500


select * from customer_x_ref x where x.ccr_cust_urn = 502963002108889

select * from agent_net_sales a where a.net_agent_account_number = 502963002108889
select * from dc_ans d where d.net_issue_year > 2014 d.net_issue_ean = 220163527000600
select to_number(to_char(to_date(trim(sysdate))-1,'WW')) from dual


select * from customers h where h.cus_account_number = 220163622000000
