insert into HK_BRANCH_EAN_YR (HK_BRANCH_CODE,HK_EAN,HK_ISSUE_YEAR)
select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from cas_branch_issues c where  bris_link_issue_year = 2013 and c.bris_title_code not in (select f.titl_code from four_year_titles f) 
union 
select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from branch_issues b where  bris_link_issue_year = 2013 and b.bris_title_code not in (select f.titl_code from four_year_titles f) 

insert into HK_BRANCH_EAN_YR (HK_BRANCH_CODE,HK_EAN,HK_ISSUE_YEAR)
select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from cas_branch_issues c where  c.bris_link_issue_year = 2011 
union 
select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from branch_issues b where  bris_link_issue_year = 2011

select count(*) from HK_BRANCH_EAN_YR t where t.hk_issue_year = 2013 and t.HK_AGNS_IND is  null 



delete from HK_BRANCH_EAN_YR where HK_AGNS_IND is  null

--select count(*) from agent_net_sales a where a.net_issue_year = 2010

--ip_housekeeping
-- hk_agns_delete_year
