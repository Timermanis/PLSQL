create table jt_T_T_staging as
select 
PLANT,
YEAR_WEEK,
ROUTE,
case when EXCL_SUN = '2R' then SUNDAY||' ' when EXCL_SUN = '3C' then SUNDAY||'  ' when EXCL_SUN = '1P' then SUNDAY||'   '   else to_char(SUNDAY)  end SUNDAY,
  case when EXCL_SUN = '2R' then MONDAY||' ' when EXCL_SUN = '3C' then MONDAY||'  ' when EXCL_SUN = '1P' then MONDAY||'   '   else to_char(MONDAY)  end MONDAY,
    case when EXCL_SUN = '2R' then TUESDAY||' ' when EXCL_SUN = '3C' then TUESDAY||'  ' when EXCL_SUN = '1P' then TUESDAY||'   '   else to_char(TUESDAY)  end TUESDAY,
      case when EXCL_SUN = '2R' then WEDNESDAY||' ' when EXCL_SUN = '3C' then WEDNESDAY||'  ' when EXCL_SUN = '1P' then WEDNESDAY||'   '   else to_char(WEDNESDAY)  end WEDNESDAY,
        case when EXCL_SUN = '2R' then THURSDAY||' ' when EXCL_SUN = '3C' then THURSDAY||'  ' when EXCL_SUN = '1P' then THURSDAY||'   '   else to_char(THURSDAY)  end THURSDAY,
          case when EXCL_SUN = '2R' then FRIDAY||' ' when EXCL_SUN = '3C' then FRIDAY||'  ' when EXCL_SUN = '1P' then FRIDAY||'   '   else to_char(FRIDAY)  end FRIDAY,
            case when EXCL_SUN = '2R' then SATURDAY||' ' when EXCL_SUN = '3C' then SATURDAY||'  ' when EXCL_SUN = '1P' then SATURDAY||'   '   else to_char(SATURDAY)  end SATURDAY,

TOTAL_FAILURES,
SUN_RDT,
MON_RDT,
TUE_RDT,
WED_RDT,
THU_RDT,
FRI_RDT,
SAT_RDT
 from SUPPORT.JT_T_AND_T_COMPLIANCE_V2
 
 
 create table jt_T_T_staging as
select 
PLANT,
YEAR_WEEK,
ROUTE,
case when EXCL_SUN = '2R' then SUNDAY*100||' ' when EXCL_SUN = '3C' then SUNDAY*100||'  ' when EXCL_SUN = '1P' then SUNDAY*100||'   '   else to_char(SUNDAY)  end SUNDAY,
  case when EXCL_SUN = '2R' then MONDAY*100||' ' when EXCL_SUN = '3C' then MONDAY*100||'  ' when EXCL_SUN = '1P' then MONDAY*100||'   '   else to_char(MONDAY)  end MONDAY,
    case when EXCL_SUN = '2R' then TUESDAY*100||' ' when EXCL_SUN = '3C' then TUESDAY*100||'  ' when EXCL_SUN = '1P' then TUESDAY*100||'   '   else to_char(TUESDAY)  end TUESDAY,
      case when EXCL_SUN = '2R' then WEDNESDAY*100||' ' when EXCL_SUN = '3C' then WEDNESDAY*100||'  ' when EXCL_SUN = '1P' then WEDNESDAY*100||'   '   else to_char(WEDNESDAY)  end WEDNESDAY,
        case when EXCL_SUN = '2R' then THURSDAY*100||' ' when EXCL_SUN = '3C' then THURSDAY*100||'  ' when EXCL_SUN = '1P' then THURSDAY*100||'   '   else to_char(THURSDAY)  end THURSDAY,
          case when EXCL_SUN = '2R' then FRIDAY*100||' ' when EXCL_SUN = '3C' then FRIDAY*100||'  ' when EXCL_SUN = '1P' then FRIDAY*100||'   '   else to_char(FRIDAY)  end FRIDAY,
            case when EXCL_SUN = '2R' then SATURDAY*100||' ' when EXCL_SUN = '3C' then SATURDAY*100||'  ' when EXCL_SUN = '1P' then SATURDAY*100||'   '   else to_char(SATURDAY)  end SATURDAY,

TOTAL_FAILURES,
SUN_RDT,
MON_RDT,
TUE_RDT,
WED_RDT,
THU_RDT,
FRI_RDT,
SAT_RDT
 from SUPPORT.jt_T_T_staging
