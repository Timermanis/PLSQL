create table T_T_base as
select PLANT,
YEAR_WEEK,
ROUTE,
SUNDAY,
EXCL_SUN,
MONDAY,
EXCL_MON,
TUESDAY,
EXCL_TUE,
WEDNESDAY,
EXCL_WED,
THURSDAY,
EXCL_THU,
FRIDAY,
EXCL_FRI,
SATURDAY,
EXCL_SAT,
TOTAL_FAILURES,
SUN_RDT,
MON_RDT,
TUE_RDT,
WED_RDT,
THU_RDT,
FRI_RDT,
SAT_RDT
 from support.JT_T_AND_T_COMPLIANCE_V1 t 
 
 where t.plant in () and
 t.year_week in () and

---------------------------------------------------------------------
create table T_T_base_v4 as
select 
PLANT,
YEAR_WEEK,
ROUTE,
case when EXCL_SUN = '2R' then SUNDAY*100||' ' when EXCL_SUN = '3C' then SUNDAY*100||'  ' when EXCL_SUN = '1P' then SUNDAY*100||'   '   else to_char(SUNDAY*100)  end SUNDAY,
  case when EXCL_SUN = '2R' then MONDAY*100||' ' when EXCL_SUN = '3C' then MONDAY*100||'  ' when EXCL_SUN = '1P' then MONDAY*100||'   '   else to_char(MONDAY*100)  end MONDAY,
    case when EXCL_SUN = '2R' then TUESDAY*100||' ' when EXCL_SUN = '3C' then TUESDAY*100||'  ' when EXCL_SUN = '1P' then TUESDAY*100||'   '   else to_char(TUESDAY*100)  end TUESDAY,
      case when EXCL_SUN = '2R' then WEDNESDAY*100||' ' when EXCL_SUN = '3C' then WEDNESDAY*100||'  ' when EXCL_SUN = '1P' then WEDNESDAY*100||'   '   else to_char(WEDNESDAY*100)  end WEDNESDAY,
        case when EXCL_SUN = '2R' then THURSDAY*100||' ' when EXCL_SUN = '3C' then THURSDAY*100||'  ' when EXCL_SUN = '1P' then THURSDAY*100||'   '   else to_char(THURSDAY*100)  end THURSDAY,
          case when EXCL_SUN = '2R' then FRIDAY*100||' ' when EXCL_SUN = '3C' then FRIDAY*100||'  ' when EXCL_SUN = '1P' then FRIDAY*100||'   '   else to_char(FRIDAY*100)  end FRIDAY,
            case when EXCL_SUN = '2R' then SATURDAY*100||' ' when EXCL_SUN = '3C' then SATURDAY*100||'  ' when EXCL_SUN = '1P' then SATURDAY*100||'   '   else to_char(SATURDAY*100)  end SATURDAY,

TOTAL_FAILURES,
SUN_RDT,
MON_RDT,
TUE_RDT,
WED_RDT,
THU_RDT,
FRI_RDT,
SAT_RDT
 from jt_t_and_t_compliance_v2 t 

drop table T_T_base_v4
select * from support.T_T_base_v4 c where c.plant = 'SHEFFIELD' and year_week = 201617 for update
