--create table   jt_ctl_files_070515_BRA560 as
select * from ctl_files where CTL_COUNTERPARTY in ('BRA550');-- for update;--14789
select * from SAP_BRANCHES where BRANCH_ID in (550)
create table jt_msg_files_260217_BRA550 as
select * from msg_files where msg_COUNTERPARTY = 'BRA550'and MSG_SEQ_NO > 14780 order by MSG_TIMESTAMP desc for update;
create table jt_SAP_BRANCHES_260217 as
select * from SAP_BRANCHES for update


select * from ctl_files where CTL_COUNTERPARTY = 'BRA560' ;
--create table jt_msg_files_050515 as
select * from msg_files where msg_COUNTERPARTY = 'BRA220' order by MSG_TIMESTAMP desc for update;
--create table jt_SAP_BRANCHES_050515 as
select * from SAP_BRANCHES

 in ('BRA310','BRA560','BRA220','BRA850')

select * from jt_msg_files_260217_BRA550 order by MSG_TIMESTAMP desc;
