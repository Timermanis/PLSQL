select count(*) from JT_1234HREF_250516 t--105521 48min

select count(*) from jt_123_250516 s--970713 41min

select count(*) from jt_1234_v2_250516 s--105521 37min

select count(*) from jt_1234_ANAS_260516--970713 47min

select * from jt_1234_ANAS_260516 where SUP_NAME = 'FRONTLINE LTD'
select count (distinct SUP_NAME) from jt_1234_ANAS_260516 where SUP_NAME = 'FRONTLINE LTD'
select distinct SUP_NAME from jt_1234_ANAS_260516

CREATE INDEX jt_sbr_epos_sup_name_idx
  ON jt_1234_ANAS_260516 (SUP_NAME);

CREATE INDEX jt_sbr_epos_sup_titl_name_idx
  ON jt_1234_ANAS_260516 (TITL_LONG_NAME);
  
  select count(*) from jt_1234_ANAS_260516 where SUP_NAME = 'FRONTLINE LTD'
  
select SUP_NAME,count(distinct TITL_LONG_NAME) Number_of_titles,count(distinct SUP_NAME_PORT) ports,count(*) from jt_1234_ANAS_260516 group by SUP_NAME
