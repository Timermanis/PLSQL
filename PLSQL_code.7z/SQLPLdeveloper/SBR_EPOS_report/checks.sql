select * from MULTIPLE t where MULT_MULTIPLE_CODE = 1032

select distinct SUP_NAME from jt_1234_ANAS_260516
