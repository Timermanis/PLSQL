select 
SUP_NAME,
j.cus_multiple_code multiple,
j.mult_name,
TITL_LONG_NAME,
sum(SBR_QTY) ORIGINAL_SO_QTY,
sum(SBR_RED_QTY) REDUCTION_QTY,
sum(NET_COMMITED_QUANTITY) "CLD Copies Invoiced",
sum(NET_OTHER_SALES_QUANTITY),
sum(NET_RETURN_QUANTITY),
sum(TOTAL),
sum(NET_BOX_OUT_QUANTITY),
sum(EPOS_TOTAL_SALES),
sum(EHIS_REP_QTY) Replenishment_qty

from jt_1234_ANAS_260516 j --where j.sup_name in ('FRONTLINE LTD')
group by j.sup_name,TITL_LONG_NAME,j.cus_multiple_code,j.mult_name,NET_BOX_OUT_QUANTITY
having NET_BOX_OUT_QUANTITY >0
------------------
select 
SUP_NAME,
TITL_LONG_NAME,
j.cus_multiple_code multiple,
j.mult_name,
sum(SBR_QTY) SBR_ORIGINAL_SO_QTY,
sum(SBR_RED_QTY) SBR_REDUCTION_QTY,
sum(NET_COMMITED_QUANTITY)  Copies_Invoiced,
sum(NET_OTHER_SALES_QUANTITY) OTHER_SALES_QUANTITY,
sum(NET_RETURN_QUANTITY) RETURNS,
sum(TOTAL)+sum(NET_BOX_OUT_QUANTITY) NET_SALES,

sum(EPOS_TOTAL_SALES) EPOS_Total_Sales,
sum(EHIS_REP_QTY) EPOS_Replenishment_qty

from jt_1234_ANAS_260516 j where j.sup_name in (".$pass_sup.")
group by j.sup_name,TITL_LONG_NAME,j.cus_multiple_code ,j.mult_name order by j.sup_name,TITL_LONG_NAME


select distinct mult_name from jt_1234_ANAS_260516
