CREATE INDEX SE_EXTR_ANS_INDEX
  ON SE_EXTR_ANS (net_agent_account_number, net_issue_ean,net_issue_year,net_branch_code,net_title_code);
  
CREATE INDEX SE_EXTR_SBR_INDEX
  ON SE_EXTR_SBR (customer_urn, issue_ean,issue_year,branch_code,title_code);
  
CREATE INDEX SE_EXTR_EPOS_HIS_INDEX
  ON SE_EXTR_ANS (ehis_urn, ehis_ean,ehis_year,ehis_branch_code,bris_title_code);
  
CREATE INDEX SE_EXTR_EPOS_TOT_INDEX
  ON SE_EXTR_EPOS_TOT (epos_urn, epos_ean,epos_year,epos_branch,bris_title_code);

full outer join SE_EXTR_SBR s on
a.net_agent_account_number = s.customer_urn and
a.net_issue_ean = s.issue_ean and
a.net_issue_year = s.issue_year and
a.net_branch_code = s.branch_code and
a.net_title_code = s.title_code 

 full outer join SE_EXTR_EPOS_HIS e on
a.net_agent_account_number = e.ehis_urn and
a.net_issue_ean = e.ehis_ean and
a.net_issue_year = e.ehis_year and
a.net_branch_code = e.ehis_branch_code and
a.net_title_code = e.bris_title_code

 full outer join SE_EXTR_EPOS_TOT t on
a.net_agent_account_number = t.epos_urn and
a.net_issue_ean = t.epos_ean and
a.net_issue_year = t.epos_year and
a.net_branch_code = t.epos_branch and
a.net_title_code = t.bris_title_code

select * from SE_VIEW_MAIN
