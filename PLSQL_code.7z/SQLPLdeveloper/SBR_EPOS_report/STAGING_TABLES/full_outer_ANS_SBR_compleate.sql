create table jt_test_ANS_SBR_outer_join as
select nvl(a.net_title_code,s.title_code) title_code,nvl(a.net_agent_account_number,s.customer_urn) URN,nvl(a.net_issue_ean,s.issue_ean) EAN,sum(a.net_commited_quantity) net_commited,sum(a.net_return_quantity) net_return,
sum(s.original_so_qty ) so_qty,sum(s.reduction_qty ) reduction_qty
from jt_ANS_EPOS_SBR a
 full outer join jt_SBR_TRANSACTIONS s on
a.net_agent_account_number = s.customer_urn and
a.net_issue_ean = s.issue_ean and
a.net_issue_year = s.issue_year and
a.net_branch_code = s.branch_code and
a.net_title_code = s.title_code 
group by a.net_agent_account_number,s.customer_urn,s.issue_ean,a.net_issue_ean,a.net_title_code,s.title_code 
----------------------
select * from jt_test_ANS_SBR_outer_join where URN=502963023823700 and EAN = 5053307011571 --NET_COMMITED is null 
drop table jt_test_ANS_SBR_outer_join

select * from jt_SBR_TRANSACTIONS where CUSTOMER_URN=502963066262900 and ISSUE_EAN = 978178494136901
select * from jt_ANS_EPOS_SBR where net_agent_account_number=502963066262900 and net_issue_ean = 978178494136901
