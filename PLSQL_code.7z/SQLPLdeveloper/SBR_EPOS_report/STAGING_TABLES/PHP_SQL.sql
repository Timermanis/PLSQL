select 
j.sup_name,
j.titl_long_name,
j.multiple,
sum(j.sbr_so_qty) ORIGINAL_SO_QTY,
sum(CASE WHEN (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) > j.net_commited THEN j.net_commited
         ELSE (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) end) New_Day_1_2,
sum(j.sbr_reduction_qty) REDUCTION_QTY,
sum(CASE WHEN 
           (CASE WHEN (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) > j.net_commited THEN j.net_commited 
           ELSE (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) end) >= j.net_commited
     THEN j.net_commited + j.net_other_sales - (CASE WHEN (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) > j.net_commited THEN j.net_commited 
         ELSE (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) end)
     ELSE j.net_other_sales end) New_Other_Sales,
sum (CASE WHEN j.net_other_sales > 0 THEN 1 else 0 end) Picks_Other_Sales,
sum(CASE WHEN j.net_net - j.sbr_so_qty <= 0 THEN 0 ELSE j.net_net - j.sbr_so_qty end) Extra_Sales,
sum((CASE WHEN j.net_net - j.sbr_so_qty <= 0 THEN 0 ELSE j.net_net - j.sbr_so_qty end) * j.titl_cover_price) Extra_Sales_RSV,
sum(j.epos_total_sales) Total_Sales,
sum(j.net_commited + j.net_other_sales - j.epos_total_sales) Notional_EPOS_Returns,
sum(j.net_credit) credits,  --NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total
sum(CASE WHEN (j.net_credit) > 0 AND (j.net_commited + j.net_other_sales - j.epos_total_sales) > 0 then 1 else 0 end) sellout_but_epos_indicated_not,
sum(CASE WHEN (j.net_credit) > 0 AND  j.net_net < j.sbr_so_qty then 1 else 0 end) sellout_under_initial_alloc,
sum(j.net_net) CLD_Net_Sales,
round((1 - (sum(CASE WHEN (j.net_credit) = 0 THEN (j.bris_recall_date - j.epos_last_sold) end)/sum(j.bris_recall_date - j.bris_on_sale_date))) * 100,2) Life_Cycle_Avail_2,
sum(CASE WHEN(j.net_credit) = 0 THEN 1 ELSE 0 end) Crude_Avail_2,
round((1 - sum(CASE WHEN(j.net_credit) = 0 THEN 1 ELSE 0 end) / count(*))*100,2) actual_availability,
round(nvl(sum(CASE WHEN (j.net_credit) = 0 THEN 
  CASE WHEN j.net_net = j.sbr_so_qty THEN 0 ELSE
    CASE WHEN j.net_net + 
      (CASE WHEN j.net_net=0 then j.net_net WHEN j.epos_total_sales/j.net_net > 0.899 then
        (CASE WHEN (j.net_credit) = 0 THEN 
          CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN j.epos_total_sales * 100/99.4 - j.epos_total_sales ELSE 
            CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN j.epos_total_sales * 100/98.8 - j.epos_total_sales ELSE
              CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN j.epos_total_sales * 100/98 - j.epos_total_sales end end end end)else 0 end )= j.sbr_so_qty then j.sbr_so_qty  - j.net_net
                else ((CASE WHEN j.net_net=0 then j.net_net WHEN j.epos_total_sales/j.net_net > 0.899 then
(CASE WHEN (j.net_credit) = 0 THEN 
  CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN j.epos_total_sales * 100/99.4 - j.epos_total_sales ELSE 
    CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN j.epos_total_sales * 100/98.8 - j.epos_total_sales ELSE
      CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN j.epos_total_sales * 100/98 - j.epos_total_sales end end end end)else 0 end)) end  end end),0),2) Lost_Sales,

nvl(round(100 - sum(CASE WHEN j.net_net=0 then j.net_net WHEN j.epos_total_sales/j.net_net > 0.899 then
        (CASE WHEN (j.net_credit) = 0 THEN 
          CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN (j.epos_total_sales * 100/99.4) - j.epos_total_sales ELSE 
            CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN (j.epos_total_sales * 100/98.8) - j.epos_total_sales ELSE
              CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN (j.epos_total_sales * 100/98) - j.epos_total_sales end end end end/(j.net_net/100))else 0 end),2),0) Consumer_Availability,
sum(j.ehis_rep_qty) total_SBR_instances,
 sum(CASE WHEN j.net_net + 
  CASE WHEN (j.net_credit) = 0 THEN 
  CASE WHEN j.net_net = j.sbr_so_qty THEN 0 ELSE
    CASE WHEN j.net_net + 
      (CASE WHEN j.net_net=0 then j.net_net WHEN j.epos_total_sales/j.net_net > 0.899 then
        (CASE WHEN (j.net_credit) = 0 THEN 
          CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN j.epos_total_sales * 100/99.4 - j.epos_total_sales ELSE 
            CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN j.epos_total_sales * 100/98.8 - j.epos_total_sales ELSE
              CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN j.epos_total_sales * 100/98 - j.epos_total_sales end end end end)else 0 end )= j.sbr_so_qty then j.sbr_so_qty - j.net_net
                else ((CASE WHEN j.net_net=0 then j.net_net WHEN j.epos_total_sales/j.net_net > 0.899 then
(CASE WHEN (j.net_credit) = 0 THEN 
  CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN j.epos_total_sales * 100/99.4 - j.epos_total_sales ELSE 
    CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN j.epos_total_sales * 100/98.8 - j.epos_total_sales ELSE
      CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN j.epos_total_sales * 100/98 - j.epos_total_sales end end end end)else 0 end)) end  end end = j.sbr_so_qty THEN 1 ELSE 0 end) whb_sellouts,

round (1- sum(CASE WHEN j.net_net + 
  CASE WHEN (j.net_credit) = 0 THEN 
  CASE WHEN j.net_net = j.sbr_so_qty THEN 0 ELSE
    CASE WHEN j.net_net + 
      (CASE WHEN j.net_net=0 then j.net_net WHEN j.epos_total_sales/j.net_net > 0.899 then
        (CASE WHEN (j.net_credit) = 0 THEN 
          CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN j.epos_total_sales * 100/99.4 - j.epos_total_sales ELSE 
            CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN j.epos_total_sales * 100/98.8 - j.epos_total_sales ELSE
              CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN j.epos_total_sales * 100/98 - j.epos_total_sales end end end end)else 0 end )= j.sbr_so_qty then j.sbr_so_qty - j.net_net
                else ((CASE WHEN j.net_net=0 then j.net_net WHEN j.epos_total_sales/j.net_net > 0.899 then
(CASE WHEN (j.net_credit) = 0 THEN 
  CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN j.epos_total_sales * 100/99.4 - j.epos_total_sales ELSE 
    CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN j.epos_total_sales * 100/98.8 - j.epos_total_sales ELSE
      CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN j.epos_total_sales * 100/98 - j.epos_total_sales end end end end)else 0 end)) end  end end = j.sbr_so_qty THEN 1 ELSE 0 end)/count(*),2) WHB_Crude_Availability,
       
sum(j.sbr_so_qty - j.net_net - (CASE WHEN j.net_net - j.sbr_so_qty <= 0 THEN 0 ELSE j.net_net - j.sbr_so_qty end)) WHB_RETURNS  

from jt_ANS_SBR_EHIS_EPOS_complete j --where j.sbr_qty is not null  ".$pass_sup." ".$pass_title."
group by j.sup_name,
j.titl_long_name,
j.multiple -- order by j.sup_name,TITL_LONG_NAME
