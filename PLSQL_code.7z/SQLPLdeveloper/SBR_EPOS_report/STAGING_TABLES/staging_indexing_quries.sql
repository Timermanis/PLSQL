create table jt_EPOS_ALL_HISTORY as--6.02 min
select  e.*,x.*,b.bris_title_code,m.mult_name,m.mult_multiple_code,b.bris_on_sale_date,b.bris_recall_date, b.bris_link_ean,b.bris_link_issue_year, c.cus_box_number,c.cus_branch_code from EPOS_ALL_HISTORY_MV e , customers c,branch_issues b,EPOS_URN_XREFS x, multiple m where e.ehis_urn = c.cus_account_number and e.ehis_year = 2016 and c.cus_account_status in (0,1) 
and c.cus_branch_code = e.ehis_branch_code  
AND  trunc(b.BRIS_RECALL_DATE)  BETWEEN   '15-JAN-2016' AND '21-JAN-2016' 
and b.bris_ean = e.ehis_ean and b.bris_branch_code = e.ehis_branch_code and b.bris_issue_year = e.ehis_year 
and b.bris_recall_date between c.cus_from_date and c.cus_to_date
and x.urn_mult = e.ehis_mult and x.urn_branch_code = e.ehis_branch_code and x.urn_urn = e.ehis_urn and x.urn_box_number = c.cus_box_number and x.urn_branch_code = c.cus_branch_code
and m.mult_multiple_code = c.cus_multiple_code

create index ind_jt_EPOS_ALL_HISTORY on jt_EPOS_ALL_HISTORY (ehis_urn,EHIS_EAN,EHIS_YEAR,EHIS_BRANCH_CODE)
drop index ind_jt_EPOS_ALL_HISTORY 
-------------------

--drop table jt_EPOS_TOTALS_MV
create table jt_EPOS_TOTALS as--2.52 min
select t.*,b.bris_title_code,m.mult_name,m.mult_multiple_code,b.bris_on_sale_date,b.bris_recall_date, b.bris_link_ean,b.bris_link_issue_year, c.cus_box_number,c.cus_branch_code 
from EPOS_TOTALS_MV t ,customers c,branch_issues b, multiple m 
where t.epos_branch = b.bris_branch_code and t.epos_ean = b.bris_ean and t.epos_year = b.bris_issue_year
and t.epos_urn = c.cus_account_number and t.epos_cus_from_date = c.cus_from_date
AND  trunc(b.BRIS_RECALL_DATE)  BETWEEN   '15-JAN-2016' AND '21-JAN-2016'
and m.mult_multiple_code = c.cus_multiple_code
and t.epos_total_sales != 0

drop table jt_EPOS_TOTALS 
select * from jt_EPOS_TOTALS
create index ind_jt_EPOS_TOTALS on jt_EPOS_TOTALS (epos_urn,EPOS_EAN,EPOS_YEAR,EPOS_BRANCH)--index
drop index ind_jt_EPOS_TOTALS 
-------------------

--drop table jt_SBR_TRANSACTIONS
create table jt_SBR_TRANSACTIONS as--3.25 min
select s.*,m.mult_name,m.mult_multiple_code,b.bris_on_sale_date,b.bris_recall_date, b.bris_link_ean,b.bris_link_issue_year, c.cus_box_number,c.cus_branch_code 
from SBR_TRANSACTIONS s ,customers c,branch_issues b, multiple m where s.branch_code = b.bris_branch_code and s.issue_ean = b.bris_ean and s.issue_year = b.bris_issue_year
and s.customer_urn = c.cus_account_number and s.title_code = b.bris_title_code and s.customer_from_date = c.cus_from_date 
AND  trunc(b.BRIS_RECALL_DATE)  BETWEEN   '15-JAN-2016' AND '21-JAN-2016'
and m.mult_multiple_code = c.cus_multiple_code  
and s.original_so_qty != 0

drop table jt_SBR_TRANSACTIONS 
create index ind_jt_SBR_TRANSACTIONS on jt_SBR_TRANSACTIONS (customer_urn,issue_ean,issue_year,branch_code)--index
drop index ind_jt_SBR_TRANSACTIONS 
-----------------------

--drop table jt_ANS_EPOS_SBR
create table jt_ANS_EPOS_SBR  as--6.46 min
select d.*,m.mult_name,m.mult_multiple_code,b.bris_on_sale_date,b.bris_recall_date, b.bris_link_ean,b.bris_link_issue_year, c.cus_box_number,c.cus_branch_code from agent_net_sales d ,customers c,branch_issues b, multiple m where d.net_branch_code = b.bris_branch_code and d.net_issue_ean = b.bris_ean and d.net_issue_year = b.bris_issue_year
and d.net_agent_account_number = c.cus_account_number and b.bris_recall_date between c.cus_from_date and c.cus_to_date
AND  trunc(b.BRIS_RECALL_DATE)  BETWEEN   '15-JAN-2016' AND '21-JAN-2016' 
and m.mult_multiple_code = c.cus_multiple_code 

drop table jt_ANS_EPOS_SBR
create index ind_jt_ANS_EPOS_SBR on jt_ANS_EPOS_SBR (net_agent_account_number,net_issue_ean,net_issue_year,net_branch_code)--index
drop index ind_jt_ANS_EPOS_SBR
------------------------------------------------------------------
