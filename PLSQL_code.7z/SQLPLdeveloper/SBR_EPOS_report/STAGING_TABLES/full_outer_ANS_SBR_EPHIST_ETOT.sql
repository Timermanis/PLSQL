----------------------MAIN EPOS/SBR QUERY---------------------
create table jt_test_ANS_SBR_EHIS_EPOS as

select u.sup_name,ti.titl_long_name,coalesce(a.mult_name,s.mult_name,e.mult_name,t.mult_name) multiple,
coalesce(a.net_title_code,s.title_code,e.bris_title_code,t.bris_title_code) title_code,coalesce(a.net_agent_account_number,s.customer_urn,e.ehis_urn,t.epos_urn) URN,
coalesce(a.net_issue_ean,s.issue_ean,e.ehis_ean,t.epos_ean) EAN,
sum(a.net_commited_quantity) net_commited,sum(a.net_return_quantity) net_return,sum(a.net_return_quantity) net_return,sum(s.original_so_qty ) sbr_so_qty,sum(s.reduction_qty ) sbr_reduction_qty,
sum(EHIS_REP_QTY) EHIS_REP_QTY, sum(EHIS_SO_QTY) EHIS_SO_QTY, sum(EHIS_BO_QTY) EHIS_BO_QTY, sum(EHIS_OTHERS_QTY) EHIS_OTHERS_QTY, sum(EHIS_RETURNS_QTY) EHIS_RETURNS_QTY,
sum(EPOS_TOTAL_SALES) EPOS_TOTAL_SALES

from jt_ANS_EPOS_SBR a

 full outer join jt_SBR_TRANSACTIONS s on
a.net_agent_account_number = s.customer_urn and
a.net_issue_ean = s.issue_ean and
a.net_issue_year = s.issue_year and
a.net_branch_code = s.branch_code and
a.net_title_code = s.title_code 

 full outer join jt_EPOS_ALL_HISTORY e on
a.net_agent_account_number = e.ehis_urn and
a.net_issue_ean = e.ehis_ean and
a.net_issue_year = e.ehis_year and
a.net_branch_code = e.ehis_branch_code and
a.net_title_code = e.bris_title_code

 full outer join jt_EPOS_TOTALS_MV t on
a.net_agent_account_number = t.epos_urn and
a.net_issue_ean = t.epos_ean and
a.net_issue_year = t.epos_year and
a.net_branch_code = t.epos_branch and
a.net_title_code = t.bris_title_code

 inner join titles ti on
coalesce(a.net_title_code,s.title_code,e.bris_title_code,t.bris_title_code) = ti.titl_code

 inner join suppliers u on
u.sup_code = nvl(ti.titl_supply_org_code_distribut,ti.titl_supply_org_code_published)
 
 group by a.net_agent_account_number,s.customer_urn,s.issue_ean,a.net_issue_ean,a.net_title_code,s.title_code,e.bris_title_code,e.ehis_urn,e.ehis_ean,e.ehis_year,t.epos_urn,t.epos_ean,
t.bris_title_code,ti.titl_long_name,u.sup_name,a.mult_name,s.mult_name,e.mult_name,t.mult_name


-------------------------------------INDEXES FOR MAIN QUERY

create index jt_ind_title_names on  jt_test_ANS_SBR_EHIS_EPOS(TITL_LONG_NAME)
create index jt_ind_multiple_sup on  jt_test_ANS_SBR_EHIS_EPOS(multiple,sup_name)


-------------------------------------TESTS MAIN QUERY
select distinct TITL_LONG_NAME from jt_test_ANS_SBR_EHIS_EPOS
select * from jt_test_ANS_SBR_EHIS_EPOS where NET_COMMITED is not null and SBR_SO_QTY is not null and EHIS_REP_QTY is not null and EPOS_TOTAL_SALES is not null
select * from jt_test_ANS_SBR_EHIS_EPOS where NET_COMMITED is null URN=502963023823700 and EAN = 5053307011571 and 
--drop table jt_test_ANS_SBR_EHISouter_join

select * from jt_test_ANS_SBR_EHIS_EPOS where EAN = 977146564312502
select * from jt_test_ANS_SBR_EHIS_EPOS where net_agent_account_number=502963066262900 and net_issue_ean = 978178494136901

