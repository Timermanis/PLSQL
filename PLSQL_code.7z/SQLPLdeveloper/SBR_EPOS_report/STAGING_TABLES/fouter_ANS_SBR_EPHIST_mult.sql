create table jt_test_ANS_SBR_EHISouter_join as

select coalesce(a.net_title_code,s.title_code,m.) title_code,coalesce(a.net_agent_account_number,s.customer_urn,e.ehis_urn) URN,coalesce(a.net_issue_ean,s.issue_ean,e.ehis_ean) EAN,
sum(a.net_commited_quantity) net_commited,sum(a.net_return_quantity) net_return,sum(s.original_so_qty ) so_qty,sum(s.reduction_qty ) reduction_qty,
sum(EHIS_REP_QTY) EHIS_REP_QTY, sum(EHIS_SO_QTY) EHIS_SO_QTY, sum(EHIS_BO_QTY) EHIS_BO_QTY, sum(EHIS_OTHERS_QTY) EHIS_OTHERS_QTY, sum(EHIS_RETURNS_QTY) EHIS_RETURNS_QTY

from jt_ANS_EPOS_SBR a
 full outer join jt_SBR_TRANSACTIONS s on
a.net_agent_account_number = s.customer_urn and
a.net_issue_ean = s.issue_ean and
a.net_issue_year = s.issue_year and
a.net_branch_code = s.branch_code and
a.net_title_code = s.title_code 
 full outer join jt_EPOS_ALL_HISTORY e on
a.net_agent_account_number = e.ehis_urn and
a.net_issue_ean = e.ehis_ean and
a.net_issue_year = e.ehis_year and
a.net_branch_code = e.ehis_branch_code 



group by a.net_agent_account_number,s.customer_urn,s.issue_ean,a.net_issue_ean,a.net_title_code,s.title_code,e.ehis_urn,e.ehis_ean,e.ehis_year 


----------------------
select * from jt_test_ANS_SBR_EHISouter_join where NET_COMMITED is null URN=502963023823700 and EAN = 5053307011571 and 
drop table jt_test_ANS_SBR_EHISouter_join

select * from jt_test_ANS_SBR_EHISouter_join where CUSTOMER_URN=502963066262900 and ISSUE_EAN = 978178494136901
select * from jt_test_ANS_SBR_EHISouter_join where net_agent_account_number=502963066262900 and net_issue_ean = 978178494136901
