select
j.cus_box_number,j.cus_branch_code, j.titl_cover_price,
sum(CASE WHEN (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) > j.net_commited THEN j.net_commited
        ELSE (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) end) New_Day_1_2,--,--OK
sum(j.net_commited + j.net_other_sales - j.epos_total_sales)   Notional_EPOS_Returns,
-------------------------------------------
sum(CASE WHEN(j.net_credit) = 0 THEN 1 ELSE 0 end) Crude_Avail_2,
-------------------------------------------
case when (j.net_commited + j.net_other_sales - j.net_net) =  0 then (j.bris_recall_date - j.epos_last_sold) end Days_off_sales_Actual,
case when j.net_net !=0 and  j.epos_total_sales/j.net_net > 0.899 then z.Lost_Sales else 0 end consumer_lost_sales,
sum(case when j.net_net !=0 and  j.epos_total_sales/j.net_net > 0.899 then z.Lost_Sales else 0 end) sum_consumer_lost_sales,  
case when (j.net_commited + j.net_other_sales - j.net_net) = 0 THEN 0 else case when (j.net_net + z.Lost_Sales) = j.sbr_so_qty then j.sbr_so_qty - j.net_net else z.Lost_Sales end end lost_sales_up_to_orig_step,
case when j.net_net + round(z.Lost_Sales) = j.sbr_so_qty then 1 else 0 end  CA_Would_Have_Been,
z.Lost_Sales,
sum(z.Lost_Sales) sum_Lost_Sales,
nvl(j.ehis_rep_qty,0) replenishment_qty

from JT_TEST_ONLY_SBR_COMPLETE j,
(select z.cus_branch_code,z.cus_box_number,z.ean,(CASE WHEN (z.net_commited + z.net_other_sales - z.net_net) = 0 THEN 
      CASE WHEN (z.bris_recall_date - z.epos_last_sold)=1 THEN (z.epos_total_sales * 100/99.4 - z.epos_total_sales) ELSE 
            CASE WHEN (z.bris_recall_date - z.epos_last_sold)=2 THEN (z.epos_total_sales * 100/98.8 - z.epos_total_sales) ELSE
              CASE WHEN (z.bris_recall_date - z.epos_last_sold)=3 THEN (z.epos_total_sales * 100/98 - z.epos_total_sales) ELSE
                CASE WHEN (z.bris_recall_date - z.epos_last_sold)=4 THEN (z.epos_total_sales * 100/96 - z.epos_total_sales) ELSE
                  CASE WHEN (z.bris_recall_date - z.epos_last_sold)=5 THEN (z.epos_total_sales * 100/94 - z.epos_total_sales) ELSE
                    CASE WHEN (z.bris_recall_date - z.epos_last_sold)=6 THEN (z.epos_total_sales * 100/93 - z.epos_total_sales) ELSE
                      CASE WHEN (z.bris_recall_date - z.epos_last_sold)=7 THEN (z.epos_total_sales * 100/91 - z.epos_total_sales) ELSE
                        CASE WHEN (z.bris_recall_date - z.epos_last_sold)=8 THEN (z.epos_total_sales * 100/88 - z.epos_total_sales) ELSE
                         CASE WHEN (z.bris_recall_date - z.epos_last_sold)=9 THEN (z.epos_total_sales * 100/86 - z.epos_total_sales) ELSE
                          CASE WHEN (z.bris_recall_date - z.epos_last_sold)=10 THEN (z.epos_total_sales * 100/84 - z.epos_total_sales) ELSE
                            CASE WHEN (z.bris_recall_date - z.epos_last_sold)=11 THEN (z.epos_total_sales * 100/82 - z.epos_total_sales) ELSE
                              CASE WHEN (z.bris_recall_date - z.epos_last_sold)=12 THEN (z.epos_total_sales * 100/79 - z.epos_total_sales) ELSE
                                CASE WHEN (z.bris_recall_date - z.epos_last_sold)=13 THEN (z.epos_total_sales * 100/77 - z.epos_total_sales) ELSE
                                  CASE WHEN (z.bris_recall_date - z.epos_last_sold)=14 THEN (z.epos_total_sales * 100/75 - z.epos_total_sales) ELSE
                                    CASE WHEN (z.bris_recall_date - z.epos_last_sold)=15 THEN (z.epos_total_sales * 100/72 - z.epos_total_sales) ELSE
                                      CASE WHEN (z.bris_recall_date - z.epos_last_sold)=16 THEN (z.epos_total_sales * 100/69 - z.epos_total_sales) ELSE
                                        CASE WHEN (z.bris_recall_date - z.epos_last_sold)=17 THEN (z.epos_total_sales * 100/66 - z.epos_total_sales) ELSE
                                          CASE WHEN (z.bris_recall_date - z.epos_last_sold)=18 THEN (z.epos_total_sales * 100/63 - z.epos_total_sales) ELSE
                                            CASE WHEN (z.bris_recall_date - z.epos_last_sold)=19 THEN (z.epos_total_sales * 100/60 - z.epos_total_sales) ELSE
                                              CASE WHEN (z.bris_recall_date - z.epos_last_sold)=20 THEN (z.epos_total_sales * 100/57 - z.epos_total_sales) ELSE
                                                CASE WHEN (z.bris_recall_date - z.epos_last_sold)=21 THEN (z.epos_total_sales * 100/54 - z.epos_total_sales) ELSE
                                                  CASE WHEN (z.bris_recall_date - z.epos_last_sold)=22 THEN (z.epos_total_sales * 100/50 - z.epos_total_sales) ELSE
                                                    CASE WHEN (z.bris_recall_date - z.epos_last_sold)=23 THEN (z.epos_total_sales * 100/46 - z.epos_total_sales) ELSE
                                                      CASE WHEN (z.bris_recall_date - z.epos_last_sold)=24 THEN (z.epos_total_sales * 100/42 - z.epos_total_sales) ELSE
                                                        CASE WHEN (z.bris_recall_date - z.epos_last_sold)=25 THEN (z.epos_total_sales * 100/37 - z.epos_total_sales) ELSE
                                                          CASE WHEN (z.bris_recall_date - z.epos_last_sold)=26 THEN (z.epos_total_sales * 100/33 - z.epos_total_sales) ELSE
                                                            CASE WHEN (z.bris_recall_date - z.epos_last_sold)=27 THEN (z.epos_total_sales * 100/28 - z.epos_total_sales) ELSE
                                                              CASE WHEN (z.bris_recall_date - z.epos_last_sold)=28 THEN (z.epos_total_sales * 100/23 - z.epos_total_sales) ELSE
                                                                CASE WHEN (z.bris_recall_date - z.epos_last_sold)=29 THEN (z.epos_total_sales * 100/16 - z.epos_total_sales) ELSE
                                                                  CASE WHEN (z.bris_recall_date - z.epos_last_sold)=30 THEN (z.epos_total_sales * 100/9 - z.epos_total_sales )
                                                                    end end end end end end end end end end end end end end end end end end end end end end end end end end end end end end end) Lost_Sales
from JT_TEST_ONLY_SBR_COMPLETE z) z 
where j.cus_box_number = z.cus_box_number and j.cus_branch_code = z.cus_branch_code and j.ean = z.ean and j.multiple_code = 2 and j.ean = 977136426413101
 group by j.cus_box_number,z.cus_box_number,j.cus_branch_code, z.cus_branch_code, j.net_commited,j.net_other_sales,j.net_net,j.bris_recall_date,j.epos_last_sold,j.epos_total_sales,j.sbr_so_qty,z.Lost_Sales,j.ehis_rep_qty, j.titl_cover_price
