select distinct SUP_NAME from jt_test_ALL_complete 
select distinct TITL_LONG_NAME from jt_test_ALL_complete 
select distinct MULTIPLE from jt_test_ALL_complete 
select * from jt_test_ALL_complete a

create table jt_PHP_SUP_TITL_MULTIPLE as
select distinct SUP_NAME,TITL_LONG_NAME,MULTIPLE from jt_test_ALL_complete 

select * from jt_PHP_SUP_TITL_MULTIPLE

select distinct MULTIPLE from jt_PHP_SUP_TITL_MULTIPLE
