select e.ehis_urn,e.ehis_ean,e.ehis_year from JT_EPOS_ALL_HISTORY e where e.ehis_urn = 502963040156300 and e.ehis_ean = 977136426413101 union
select t.epos_urn,t.epos_ean,t.epos_year from jt_EPOS_TOTALS t where t.epos_urn = 502963040156300 and t.epos_ean = 977175221001601

select distinct b.bris_issue_year from branch_issues b where b.bris_ean = 977000697821401

select '21-JAN-2016'  from dual

select to_date('20-JAN-2016') - 100 from dual
