select * from agent_net_sales a, multiple m where m.mult_multiple_code = a.net_multiple_code and m.mult_name = 'EASONS' and a.net_issue_ean = 977136426413101 and a.net_issue_year in (2015)
select * from jt_ANS_EPOS_SBR j where  j.mult_multiple_code = 2 and j.net_issue_ean = 977136426413101 and a.net_issue_year in (2015)
select * from jt_test_ANS_SBR_EHIS_EPOS t where t.multiple_code = 2 and t.ean = 977136426413101
select * from  jt_test_ONLY_SBR_complete s where s.multiple_code = 2 and s.ean = 977136426413101
