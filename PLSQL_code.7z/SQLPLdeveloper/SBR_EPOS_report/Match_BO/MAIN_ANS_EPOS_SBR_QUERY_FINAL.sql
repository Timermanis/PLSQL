--ALL
create table jt_test_ALL_complete as
select sup_name,titl_long_name,title_code,titl_cover_price, multiple,MULTIPLE_CODE, /*URN,*/cus_box_number,cus_branch_code,EAN,bris_on_sale_date,bris_recall_date,niss_official_on_sale_date,
sum(net_commited) net_commited,sum(net_return) net_return,sum(net_credit) net_credit,sum(net_other_sales) net_other_sales,sum(net_commited+net_other_sales-net_credit) net_net,
sum(sbr_so_qty) sbr_so_qty,sum(sbr_reduction_qty) sbr_reduction_qty,
sum(EHIS_REP_QTY) EHIS_REP_QTY, sum(EHIS_SO_QTY) EHIS_SO_QTY, sum(EHIS_BO_QTY) EHIS_BO_QTY, sum(EHIS_OTHERS_QTY) EHIS_OTHERS_QTY, sum(EHIS_RETURNS_QTY) EHIS_RETURNS_QTY,
sum(EPOS_TOTAL_SALES) EPOS_TOTAL_SALES,EPOS_LAST_SOLD 
from jt_test_ANS_SBR_EHIS_EPOS jt


-- where     EPOS_TOTAL_SALES != 0 or EPOS_TOTAL_SALES is not null !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

group by sup_name,titl_long_name, multiple,MULTIPLE_CODE,title_code, cus_box_number,cus_branch_code,
EAN,bris_on_sale_date,bris_recall_date,niss_official_on_sale_date,EPOS_LAST_SOLD,net_other_sales,net_net,titl_cover_price
--drop table jt_test_ALL_complete jt_test_ONLY_SBR_complete
select count(*) from jt_test_ALL_complete --where  578468 only  EPOS_TOTAL_SALES != 0

------------------------------------
--NO_SBR
create table jt_test_NO_SBR_complete as
select sup_name,titl_long_name,title_code,titl_cover_price, multiple,MULTIPLE_CODE, /*URN,*/cus_box_number,cus_branch_code,EAN,bris_on_sale_date,bris_recall_date,niss_official_on_sale_date,
sum(net_commited) net_commited,sum(net_return) net_return,sum(net_credit) net_credit,sum(net_other_sales) net_other_sales,sum(net_commited+net_other_sales-net_credit) net_net,
sum(sbr_so_qty) sbr_so_qty,sum(sbr_reduction_qty) sbr_reduction_qty,
sum(EHIS_REP_QTY) EHIS_REP_QTY, sum(EHIS_SO_QTY) EHIS_SO_QTY, sum(EHIS_BO_QTY) EHIS_BO_QTY, sum(EHIS_OTHERS_QTY) EHIS_OTHERS_QTY, sum(EHIS_RETURNS_QTY) EHIS_RETURNS_QTY,
sum(EPOS_TOTAL_SALES) EPOS_TOTAL_SALES,EPOS_LAST_SOLD 
from jt_test_ANS_SBR_EHIS_EPOS jt
 where

     (EPOS_TOTAL_SALES != 0 or EPOS_TOTAL_SALES is not null) and
     (sbr_so_qty is null  or sbr_so_qty = 0)
     
group by sup_name,titl_long_name, multiple,MULTIPLE_CODE,title_code, cus_box_number,cus_branch_code,
EAN,bris_on_sale_date,bris_recall_date,niss_official_on_sale_date,EPOS_LAST_SOLD,net_other_sales,net_net,titl_cover_price
--drop table jt_test_NO_SBR_complete
select * from jt_test_NO_SBR_complete
------------------------------------
--ONLY_SBR
create table jt_test_ONLY_SBR_complete as
select sup_name,titl_long_name,title_code,titl_cover_price, multiple,MULTIPLE_CODE, /*URN,*/cus_box_number,cus_branch_code,EAN,bris_on_sale_date,bris_recall_date,niss_official_on_sale_date,
sum(net_commited) net_commited,sum(net_return) net_return,sum(net_credit) net_credit,sum(net_other_sales) net_other_sales,sum(net_commited+net_other_sales-net_credit) net_net,
sum(sbr_so_qty) sbr_so_qty,sum(sbr_reduction_qty) sbr_reduction_qty,
sum(EHIS_REP_QTY) EHIS_REP_QTY, sum(EHIS_SO_QTY) EHIS_SO_QTY, sum(EHIS_BO_QTY) EHIS_BO_QTY, sum(EHIS_OTHERS_QTY) EHIS_OTHERS_QTY, sum(EHIS_RETURNS_QTY) EHIS_RETURNS_QTY,
sum(EPOS_TOTAL_SALES) EPOS_TOTAL_SALES,EPOS_LAST_SOLD 
from jt_test_ANS_SBR_EHIS_EPOS jt
 where

     (EPOS_TOTAL_SALES != 0 or EPOS_TOTAL_SALES is not null) and
     (sbr_so_qty is not null or sbr_so_qty != 0)
     
group by sup_name,titl_long_name, multiple,MULTIPLE_CODE,title_code, cus_box_number,cus_branch_code,
EAN,bris_on_sale_date,bris_recall_date,niss_official_on_sale_date,EPOS_LAST_SOLD,net_other_sales,net_net,titl_cover_price
--drop table jt_test_ONLY_SBR_complete
select count(*) from jt_test_ONLY_SBR_complete --142945 only  sbr_so_qty is not null

----------------------MAIN EPOS/SBR QUERY---------------------
create table jt_test_ANS_SBR_EHIS_EPOS as
select u.sup_name,ti.titl_long_name,ti.titl_cover_price,n.niss_official_on_sale_date,coalesce(a.bris_on_sale_date,s.bris_on_sale_date,e.bris_on_sale_date,t.bris_on_sale_date) bris_on_sale_date,
coalesce(a.cus_box_number,s.cus_box_number,e.cus_box_number,t.cus_box_number) cus_box_number, coalesce(a.cus_branch_code,s.cus_branch_code,e.cus_branch_code,t.cus_branch_code) cus_branch_code,
coalesce(a.mult_name,s.mult_name,e.mult_name,t.mult_name) multiple,coalesce(a.mult_multiple_code,s.mult_multiple_code,e.mult_multiple_code,t.mult_multiple_code) MULTIPLE_CODE,
coalesce(a.bris_recall_date,s.bris_recall_date,e.bris_recall_date,t.bris_recall_date) bris_recall_date,
coalesce(a.net_title_code,s.title_code,e.bris_title_code,t.bris_title_code) title_code,--,coalesce(a.net_agent_account_number,s.customer_urn,e.ehis_urn,t.epos_urn) URN,
coalesce(a.net_issue_ean,s.issue_ean,e.ehis_ean,t.epos_ean) EAN,

sum(a.net_commited_quantity) net_commited,sum(a.net_return_quantity) net_return,sum(a.net_other_sales_quantity) net_other_sales,
sum(a.net_commited_quantity+a.net_other_sales_quantity-a.net_credit_quantity) net_net,
sum(a.net_credit_quantity) net_credit,sum(s.original_so_qty ) sbr_so_qty,sum(s.reduction_qty ) sbr_reduction_qty,
sum(EHIS_REP_QTY) EHIS_REP_QTY, sum(EHIS_SO_QTY) EHIS_SO_QTY, sum(EHIS_BO_QTY) EHIS_BO_QTY, sum(EHIS_OTHERS_QTY) EHIS_OTHERS_QTY, sum(EHIS_RETURNS_QTY) EHIS_RETURNS_QTY,
sum(EPOS_TOTAL_SALES) EPOS_TOTAL_SALES,EPOS_LAST_SOLD

 from jt_ANS_EPOS_SBR a

 full outer join jt_SBR_TRANSACTIONS s on
a.net_agent_account_number = s.customer_urn and
a.net_issue_ean = s.issue_ean and
a.net_issue_year = s.issue_year and
a.net_branch_code = s.branch_code and
a.net_title_code = s.title_code 

 full outer join jt_EPOS_ALL_HISTORY e on
a.net_agent_account_number = e.ehis_urn and
a.net_issue_ean = e.ehis_ean and
a.net_issue_year = e.ehis_year and
a.net_branch_code = e.ehis_branch_code and
a.net_title_code = e.bris_title_code

 full outer join jt_EPOS_TOTALS t on
a.net_agent_account_number = t.epos_urn and
a.net_issue_ean = t.epos_ean and
a.net_issue_year = t.epos_year and
a.net_branch_code = t.epos_branch and
a.net_title_code = t.bris_title_code

 inner join titles ti on
coalesce(a.net_title_code,s.title_code,e.bris_title_code,t.bris_title_code) = ti.titl_code

 inner join normal_issues n on
coalesce(a.bris_link_ean,s.bris_link_ean,e.bris_link_ean,t.bris_link_ean) = n.niss_ean and
coalesce(a.bris_link_issue_year,s.bris_link_issue_year,e.bris_link_ean,t.bris_link_issue_year) = n.niss_issue_year 


 inner join suppliers u on
u.sup_code = nvl(ti.titl_supply_org_code_distribut,ti.titl_supply_org_code_published)

 inner join SBR_TITLE_GROUP_DETAILS st on
st.TGD_TITLE_NUMBER=ti.TITL_CODE

 inner join SBR_TITLE_GROUP_HEADERS sh on
sh.TGH_TITLE_GROUP_ISN = st.TGD_TITLE_GROUP_ISN

 where
  sh.TGH_TITLE_GROUP_NAME  =  'WHS 300 + weeklies'
  AND  decode(ti.TITL_ISSUE_FREQUENCY,'1','Daily','2','Sunday','3','Weekly','4','Fortnightly','5','Monthly','6','Bi-Monthly','7','Quarterly','8','Irregular','9','One-Shot','Unknown')  NOT IN  ('Daily', 'Weekly', 'Sunday')
  AND  coalesce(a.mult_multiple_code,s.mult_multiple_code,e.mult_multiple_code,t.mult_multiple_code)  IN  (888, 89, 209, 1, 907, 37, 767, 149, 92, 66, 227, 764, 188, 2, 143, 110, 91, 963, 229, 130, 124, 3, 1007, 721, 869, 640, 52, 29, 826, 723, 872, 947, 32, 163, 33, 187, 51, 34, 711, 779, 215, 450, 451, 158, 7, 8, 5, 85, 6, 10, 193)
  --AND a.net_branch_code = 'BRA220'--------------------------------------------
  
 group by a.net_agent_account_number,s.customer_urn,s.issue_ean,a.net_issue_ean,a.net_title_code,s.title_code,e.bris_title_code,e.ehis_urn,e.ehis_ean,e.ehis_year,t.epos_urn,t.epos_ean,
t.bris_title_code,ti.titl_long_name,u.sup_name,a.mult_name,s.mult_name,e.mult_name,t.mult_name,a.mult_multiple_code,s.mult_multiple_code,e.mult_multiple_code,t.mult_multiple_code,ti.titl_cover_price,
a.bris_on_sale_date,s.bris_on_sale_date,e.bris_on_sale_date,t.bris_on_sale_date,a.bris_recall_date,s.bris_recall_date,e.bris_recall_date,t.bris_recall_date,n.niss_official_on_sale_date,EPOS_LAST_SOLD,
a.cus_box_number,s.cus_box_number,e.cus_box_number,t.cus_box_number,a.cus_branch_code,s.cus_branch_code,e.cus_branch_code,t.cus_branch_code


-------------------------------TITLE CUSTOMER LEVEL-----------------------------------------------------------------------------------------------------------
--ALL
create table jt_test_ALL_complete as
select sup_name,titl_long_name,title_code,titl_cover_price, multiple,MULTIPLE_CODE, /*URN,*/cus_box_number,cus_branch_code,EAN,bris_on_sale_date,bris_recall_date,niss_official_on_sale_date,
sum(net_commited) net_commited,sum(net_return) net_return,sum(net_credit) net_credit,sum(net_other_sales) net_other_sales,sum(net_commited+net_other_sales-net_credit) net_net,
sum(sbr_so_qty) sbr_so_qty,sum(sbr_reduction_qty) sbr_reduction_qty,
sum(EHIS_REP_QTY) EHIS_REP_QTY, sum(EHIS_SO_QTY) EHIS_SO_QTY, sum(EHIS_BO_QTY) EHIS_BO_QTY, sum(EHIS_OTHERS_QTY) EHIS_OTHERS_QTY, sum(EHIS_RETURNS_QTY) EHIS_RETURNS_QTY,
sum(EPOS_TOTAL_SALES) EPOS_TOTAL_SALES,EPOS_LAST_SOLD 
from jt_test_ANS_SBR_EHIS_EPOS jt


-- where     EPOS_TOTAL_SALES != 0 or EPOS_TOTAL_SALES is not null !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

group by sup_name,titl_long_name, multiple,MULTIPLE_CODE,title_code, cus_box_number,cus_branch_code,
EAN,bris_on_sale_date,bris_recall_date,niss_official_on_sale_date,EPOS_LAST_SOLD,net_other_sales,net_net,titl_cover_price
--drop table jt_test_ALL_complete jt_test_ONLY_SBR_complete
select count(*) from jt_test_ALL_complete --where  578468 only  EPOS_TOTAL_SALES != 0

------------------------------------
--NO_SBR
create table jt_test_NO_SBR_complete as
select sup_name,titl_long_name,title_code,titl_cover_price, multiple,MULTIPLE_CODE, /*URN,*/cus_box_number,cus_branch_code,EAN,bris_on_sale_date,bris_recall_date,niss_official_on_sale_date,
sum(net_commited) net_commited,sum(net_return) net_return,sum(net_credit) net_credit,sum(net_other_sales) net_other_sales,sum(net_commited+net_other_sales-net_credit) net_net,
sum(sbr_so_qty) sbr_so_qty,sum(sbr_reduction_qty) sbr_reduction_qty,
sum(EHIS_REP_QTY) EHIS_REP_QTY, sum(EHIS_SO_QTY) EHIS_SO_QTY, sum(EHIS_BO_QTY) EHIS_BO_QTY, sum(EHIS_OTHERS_QTY) EHIS_OTHERS_QTY, sum(EHIS_RETURNS_QTY) EHIS_RETURNS_QTY,
sum(EPOS_TOTAL_SALES) EPOS_TOTAL_SALES,EPOS_LAST_SOLD 
from jt_test_ANS_SBR_EHIS_EPOS jt
 where

     (EPOS_TOTAL_SALES != 0 or EPOS_TOTAL_SALES is not null) and
     (sbr_so_qty is null  or sbr_so_qty = 0)
     
group by sup_name,titl_long_name, multiple,MULTIPLE_CODE,title_code, cus_box_number,cus_branch_code,
EAN,bris_on_sale_date,bris_recall_date,niss_official_on_sale_date,EPOS_LAST_SOLD,net_other_sales,net_net,titl_cover_price
--drop table jt_test_NO_SBR_complete
select * from jt_test_NO_SBR_complete
------------------------------------
--ONLY_SBR
create table jt_test_ONLY_SBR_complete as
select sup_name,titl_long_name,title_code,titl_cover_price, multiple,MULTIPLE_CODE, /*URN,*/cus_box_number,cus_branch_code,EAN,bris_on_sale_date,bris_recall_date,niss_official_on_sale_date,
sum(net_commited) net_commited,sum(net_return) net_return,sum(net_credit) net_credit,sum(net_other_sales) net_other_sales,sum(net_commited+net_other_sales-net_credit) net_net,
sum(sbr_so_qty) sbr_so_qty,sum(sbr_reduction_qty) sbr_reduction_qty,
sum(EHIS_REP_QTY) EHIS_REP_QTY, sum(EHIS_SO_QTY) EHIS_SO_QTY, sum(EHIS_BO_QTY) EHIS_BO_QTY, sum(EHIS_OTHERS_QTY) EHIS_OTHERS_QTY, sum(EHIS_RETURNS_QTY) EHIS_RETURNS_QTY,
sum(EPOS_TOTAL_SALES) EPOS_TOTAL_SALES,EPOS_LAST_SOLD 
from jt_test_ANS_SBR_EHIS_EPOS jt
 where

     (EPOS_TOTAL_SALES != 0 or EPOS_TOTAL_SALES is not null) and
     (sbr_so_qty is not null or sbr_so_qty != 0)
     
group by sup_name,titl_long_name, multiple,MULTIPLE_CODE,title_code, cus_box_number,cus_branch_code,
EAN,bris_on_sale_date,bris_recall_date,niss_official_on_sale_date,EPOS_LAST_SOLD,net_other_sales,net_net,titl_cover_price
--drop table jt_test_ONLY_SBR_complete
select count(*) from jt_test_ONLY_SBR_complete --142945 only  sbr_so_qty is not null

----------------------MAIN EPOS/SBR QUERY---------------------
create table jt_test_ANS_SBR_EHIS_EPOS as
select u.sup_name,ti.titl_long_name,ti.titl_cover_price,n.niss_official_on_sale_date,coalesce(a.bris_on_sale_date,s.bris_on_sale_date,e.bris_on_sale_date,t.bris_on_sale_date) bris_on_sale_date,
coalesce(a.cus_box_number,s.cus_box_number,e.cus_box_number,t.cus_box_number) cus_box_number, coalesce(a.cus_branch_code,s.cus_branch_code,e.cus_branch_code,t.cus_branch_code) cus_branch_code,
coalesce(a.mult_name,s.mult_name,e.mult_name,t.mult_name) multiple,coalesce(a.mult_multiple_code,s.mult_multiple_code,e.mult_multiple_code,t.mult_multiple_code) MULTIPLE_CODE,
coalesce(a.bris_recall_date,s.bris_recall_date,e.bris_recall_date,t.bris_recall_date) bris_recall_date,
coalesce(a.net_title_code,s.title_code,e.bris_title_code,t.bris_title_code) title_code,--,coalesce(a.net_agent_account_number,s.customer_urn,e.ehis_urn,t.epos_urn) URN,
coalesce(a.net_issue_ean,s.issue_ean,e.ehis_ean,t.epos_ean) EAN,

sum(a.net_commited_quantity) net_commited,sum(a.net_return_quantity) net_return,sum(a.net_other_sales_quantity) net_other_sales,
sum(a.net_commited_quantity+a.net_other_sales_quantity-a.net_credit_quantity) net_net,
sum(a.net_credit_quantity) net_credit,sum(s.original_so_qty ) sbr_so_qty,sum(s.reduction_qty ) sbr_reduction_qty,
sum(EHIS_REP_QTY) EHIS_REP_QTY, sum(EHIS_SO_QTY) EHIS_SO_QTY, sum(EHIS_BO_QTY) EHIS_BO_QTY, sum(EHIS_OTHERS_QTY) EHIS_OTHERS_QTY, sum(EHIS_RETURNS_QTY) EHIS_RETURNS_QTY,
sum(EPOS_TOTAL_SALES) EPOS_TOTAL_SALES,EPOS_LAST_SOLD

 from jt_ANS_EPOS_SBR a

 full outer join jt_SBR_TRANSACTIONS s on
a.net_agent_account_number = s.customer_urn and
a.net_issue_ean = s.issue_ean and
a.net_issue_year = s.issue_year and
a.net_branch_code = s.branch_code and
a.net_title_code = s.title_code 

 full outer join jt_EPOS_ALL_HISTORY e on
a.net_agent_account_number = e.ehis_urn and
a.net_issue_ean = e.ehis_ean and
a.net_issue_year = e.ehis_year and
a.net_branch_code = e.ehis_branch_code and
a.net_title_code = e.bris_title_code

 full outer join jt_EPOS_TOTALS t on
a.net_agent_account_number = t.epos_urn and
a.net_issue_ean = t.epos_ean and
a.net_issue_year = t.epos_year and
a.net_branch_code = t.epos_branch and
a.net_title_code = t.bris_title_code

 inner join titles ti on
coalesce(a.net_title_code,s.title_code,e.bris_title_code,t.bris_title_code) = ti.titl_code

 inner join normal_issues n on
coalesce(a.bris_link_ean,s.bris_link_ean,e.bris_link_ean,t.bris_link_ean) = n.niss_ean and
coalesce(a.bris_link_issue_year,s.bris_link_issue_year,e.bris_link_ean,t.bris_link_issue_year) = n.niss_issue_year 


 inner join suppliers u on
u.sup_code = nvl(ti.titl_supply_org_code_distribut,ti.titl_supply_org_code_published)

 inner join SBR_TITLE_GROUP_DETAILS st on
st.TGD_TITLE_NUMBER=ti.TITL_CODE

 inner join SBR_TITLE_GROUP_HEADERS sh on
sh.TGH_TITLE_GROUP_ISN = st.TGD_TITLE_GROUP_ISN

 where
  sh.TGH_TITLE_GROUP_NAME  =  'WHS 300 + weeklies'
  AND  decode(ti.TITL_ISSUE_FREQUENCY,'1','Daily','2','Sunday','3','Weekly','4','Fortnightly','5','Monthly','6','Bi-Monthly','7','Quarterly','8','Irregular','9','One-Shot','Unknown')  NOT IN  ('Daily', 'Weekly', 'Sunday')
  AND  coalesce(a.mult_multiple_code,s.mult_multiple_code,e.mult_multiple_code,t.mult_multiple_code)  IN  (888, 89, 209, 1, 907, 37, 767, 149, 92, 66, 227, 764, 188, 2, 143, 110, 91, 963, 229, 130, 124, 3, 1007, 721, 869, 640, 52, 29, 826, 723, 872, 947, 32, 163, 33, 187, 51, 34, 711, 779, 215, 450, 451, 158, 7, 8, 5, 85, 6, 10, 193)
  --AND a.net_branch_code = 'BRA220'--------------------------------------------
  
 group by a.net_agent_account_number,s.customer_urn,s.issue_ean,a.net_issue_ean,a.net_title_code,s.title_code,e.bris_title_code,e.ehis_urn,e.ehis_ean,e.ehis_year,t.epos_urn,t.epos_ean,
t.bris_title_code,ti.titl_long_name,u.sup_name,a.mult_name,s.mult_name,e.mult_name,t.mult_name,a.mult_multiple_code,s.mult_multiple_code,e.mult_multiple_code,t.mult_multiple_code,ti.titl_cover_price,
a.bris_on_sale_date,s.bris_on_sale_date,e.bris_on_sale_date,t.bris_on_sale_date,a.bris_recall_date,s.bris_recall_date,e.bris_recall_date,t.bris_recall_date,n.niss_official_on_sale_date,EPOS_LAST_SOLD,
a.cus_box_number,s.cus_box_number,e.cus_box_number,t.cus_box_number,a.cus_branch_code,s.cus_branch_code,e.cus_branch_code,t.cus_branch_code


-----------------------------------------------------------------------------------------------------------------------------------------------------------




