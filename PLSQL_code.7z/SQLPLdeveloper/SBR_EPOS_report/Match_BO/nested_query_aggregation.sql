with a as
(select
j.urn,
sum(CASE WHEN (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) > j.net_commited THEN j.net_commited
        ELSE (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) end) New_Day_1_2--,--OK
from JT_TEST_ONLY_SBR_COMPLETE j group by urn)
--------------------------- 
select 
sum(case when a.New_Day_1_2 < = j.net_commited then j.net_commited + j.net_other_sales - a.New_Day_1_2 else j.net_commited end)  New_Other_Sales  
from a a,JT_TEST_ONLY_SBR_COMPLETE j where a.urn = j.urn

