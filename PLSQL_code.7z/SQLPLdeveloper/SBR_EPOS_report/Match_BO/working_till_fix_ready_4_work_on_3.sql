with a as
(select
j.urn,
sum(CASE WHEN (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) > j.net_commited THEN j.net_commited
        ELSE (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) end) New_Day_1_2,--,--OK
sum(j.net_commited + j.net_other_sales - j.epos_total_sales)   Notional_EPOS_Returns,
sum(CASE WHEN(j.net_credit) = 0 THEN 1 ELSE 0 end) Crude_Avail_2,
case when (j.net_commited + j.net_other_sales - j.net_net) =  0 then (j.bris_recall_date - j.epos_last_sold) end Days_off_sales_Actual,
-- = If (<Total Sales>/<CLD Net Sales>)>0.899 Then <Lost Sales> Else 0
case when j.net_net !=0 and  j.epos_total_sales/j.net_net > 0.899 then z.Lost_Sales else 0 end consumer_lost_sales,
case when (j.net_commited + j.net_other_sales - j.net_net) = 0 THEN 0 else case when (j.net_net + z.Lost_Sales) = j.sbr_so_qty then j.sbr_so_qty - j.net_net else z.Lost_Sales end end lost_sales_up_to_orig_step,
--z.Lost_Sales,

 --If (<CLD Net Sales>+<Lost Sales>)>=<Original So Qty> Then 1 Else 0
case when j.net_net + round(z.Lost_Sales) = j.sbr_so_qty then 1 else 0 end  CA_Would_Have_Been,

sum(z.Lost_Sales) sum_Lost_Sales,
nvl(j.ehis_rep_qty,0) replenishment_qty

from JT_TEST_ONLY_SBR_COMPLETE j,
(select urn,round((CASE WHEN (z.net_commited + z.net_other_sales - z.net_net) = 0 THEN 
      CASE WHEN (z.bris_recall_date - z.epos_last_sold)=1 THEN z.epos_total_sales * 100/99.4 - z.epos_total_sales ELSE 
            CASE WHEN (z.bris_recall_date - z.epos_last_sold)=2 THEN z.epos_total_sales * 100/98.8 - z.epos_total_sales ELSE
              CASE WHEN (z.bris_recall_date - z.epos_last_sold)=3 THEN z.epos_total_sales * 100/98 - z.epos_total_sales ELSE
                CASE WHEN (z.bris_recall_date - z.epos_last_sold)=4 THEN z.epos_total_sales * 100/96 - z.epos_total_sales ELSE
                  CASE WHEN (z.bris_recall_date - z.epos_last_sold)=5 THEN z.epos_total_sales * 100/94 - z.epos_total_sales ELSE
                    CASE WHEN (z.bris_recall_date - z.epos_last_sold)=6 THEN z.epos_total_sales * 100/93 - z.epos_total_sales ELSE
                      CASE WHEN (z.bris_recall_date - z.epos_last_sold)=7 THEN z.epos_total_sales * 100/91 - z.epos_total_sales ELSE
                        CASE WHEN (z.bris_recall_date - z.epos_last_sold)=8 THEN z.epos_total_sales * 100/88 - z.epos_total_sales ELSE
                         CASE WHEN (z.bris_recall_date - z.epos_last_sold)=9 THEN z.epos_total_sales * 100/86 - z.epos_total_sales ELSE
                          CASE WHEN (z.bris_recall_date - z.epos_last_sold)=10 THEN z.epos_total_sales * 100/84 - z.epos_total_sales ELSE
                            CASE WHEN (z.bris_recall_date - z.epos_last_sold)=11 THEN z.epos_total_sales * 100/82 - z.epos_total_sales ELSE
                              CASE WHEN (z.bris_recall_date - z.epos_last_sold)=12 THEN z.epos_total_sales * 100/79 - z.epos_total_sales ELSE
                                CASE WHEN (z.bris_recall_date - z.epos_last_sold)=13 THEN z.epos_total_sales * 100/77 - z.epos_total_sales ELSE
                                  CASE WHEN (z.bris_recall_date - z.epos_last_sold)=14 THEN z.epos_total_sales * 100/75 - z.epos_total_sales ELSE
                                    CASE WHEN (z.bris_recall_date - z.epos_last_sold)=15 THEN z.epos_total_sales * 100/72 - z.epos_total_sales ELSE
                                      CASE WHEN (z.bris_recall_date - z.epos_last_sold)=16 THEN z.epos_total_sales * 100/69 - z.epos_total_sales ELSE
                                        CASE WHEN (z.bris_recall_date - z.epos_last_sold)=17 THEN z.epos_total_sales * 100/66 - z.epos_total_sales ELSE
                                          CASE WHEN (z.bris_recall_date - z.epos_last_sold)=18 THEN z.epos_total_sales * 100/63 - z.epos_total_sales ELSE
                                            CASE WHEN (z.bris_recall_date - z.epos_last_sold)=19 THEN z.epos_total_sales * 100/60 - z.epos_total_sales ELSE
                                              CASE WHEN (z.bris_recall_date - z.epos_last_sold)=20 THEN z.epos_total_sales * 100/57 - z.epos_total_sales ELSE
                                                CASE WHEN (z.bris_recall_date - z.epos_last_sold)=21 THEN z.epos_total_sales * 100/54 - z.epos_total_sales ELSE
                                                  CASE WHEN (z.bris_recall_date - z.epos_last_sold)=22 THEN z.epos_total_sales * 100/50 - z.epos_total_sales ELSE
                                                    CASE WHEN (z.bris_recall_date - z.epos_last_sold)=23 THEN z.epos_total_sales * 100/46 - z.epos_total_sales ELSE
                                                      CASE WHEN (z.bris_recall_date - z.epos_last_sold)=24 THEN z.epos_total_sales * 100/42 - z.epos_total_sales ELSE
                                                        CASE WHEN (z.bris_recall_date - z.epos_last_sold)=25 THEN z.epos_total_sales * 100/37 - z.epos_total_sales ELSE
                                                          CASE WHEN (z.bris_recall_date - z.epos_last_sold)=26 THEN z.epos_total_sales * 100/33 - z.epos_total_sales ELSE
                                                            CASE WHEN (z.bris_recall_date - z.epos_last_sold)=27 THEN z.epos_total_sales * 100/28 - z.epos_total_sales ELSE
                                                              CASE WHEN (z.bris_recall_date - z.epos_last_sold)=28 THEN z.epos_total_sales * 100/23 - z.epos_total_sales ELSE
                                                                CASE WHEN (z.bris_recall_date - z.epos_last_sold)=29 THEN z.epos_total_sales * 100/16 - z.epos_total_sales ELSE
                                                                  CASE WHEN (z.bris_recall_date - z.epos_last_sold)=30 THEN z.epos_total_sales * 100/11 - z.epos_total_sales 
                                                                    end end end end end end end end end end end end end end end end end end end end end end end end end end end end end end end),2) Lost_Sales
from JT_TEST_ONLY_SBR_COMPLETE z) z
where j.urn = z.urn
 group by j.urn,z.urn,j.net_commited,j.net_other_sales,j.net_net,j.bris_recall_date,j.epos_last_sold,j.epos_total_sales,j.sbr_so_qty,z.Lost_Sales,j.ehis_rep_qty)

select 
j.titl_long_name,
sum(j.sbr_so_qty) ORIGINAL_SO_QTY,--OK
sum(CASE WHEN (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) > j.net_commited THEN j.net_commited
         ELSE (CASE WHEN j.net_commited >=1 then (j.sbr_so_qty - j.sbr_reduction_qty) else j.net_commited end) end) New_Day_1_2,--OK
sum(j.sbr_reduction_qty) REDUCTION_QTY,--OK
sum(case when a.New_Day_1_2 < = j.net_commited then j.net_commited + j.net_other_sales - a.New_Day_1_2 else j.net_commited end)  New_Other_Sales ,     
sum (CASE WHEN j.net_other_sales > 0 THEN 1 else 0 end) Picks_Other_Sales ,
sum(CASE WHEN j.net_net - j.sbr_so_qty <= 0 THEN 0 ELSE j.net_net - j.sbr_so_qty end) Extra_Sales ,
sum((CASE WHEN j.net_net - j.sbr_so_qty <= 0 THEN 0 ELSE j.net_net - j.sbr_so_qty end) * j.titl_cover_price) Extra_Sales_RSV ,
sum(j.epos_total_sales) Total_Sales,  
sum(j.net_credit) credits,  
sum(CASE WHEN (j.net_credit) = 0 AND (a.Notional_EPOS_Returns) > 0 then 1 else 0 end) sellout_but_epos_indicated_not ,
sum(CASE WHEN (j.net_credit) = 0 AND  j.net_net < j.sbr_so_qty then 1 else 0 end) sellout_under_initial_alloc,
sum(j.net_net) CLD_Net_Sales,
round((1 - (sum(CASE WHEN (j.net_credit) = 0 THEN (j.bris_recall_date - j.epos_last_sold) end)/sum(j.bris_recall_date - j.bris_on_sale_date))) * 100,2) Life_Cycle_Avail_2,
round((1- (Sum(Crude_Avail_2)/Count(*)))*100,2) Crude_Avail_2,
sum(case when consumer_lost_sales = 0 then 0 else lost_sales_up_to_orig_step end) lost_sales_BO,
sum(CA_Would_Have_Been),--1


--((1- (Sum(<CA Would Have Been>)/CountAll(<Box Number>)))*100)

((1-(sum(CA_Would_Have_Been) / count(*))) * 100),

sum(consumer_lost_sales) consumer_lost_sales,
sum(replenishment_qty) replenishment_qty,
count(replenishment_qty) total_SBR_instances




from a a,JT_TEST_ONLY_SBR_COMPLETE j where a.urn = j.urn --where j.sbr_qty is not null  ".$pass_sup." ".$pass_title."
group by j.titl_long_name --,j.net_net,sum_Lost_Sales--,
--j.multiple, -- order by j.sup_name,TITL_LONG_NAME
--j.urn
