create table SE_SELECT_TITLE as
select distinct SUP_NAME,TITL_LONG_NAME,MULTIPLE from jt_test_ONLY_SBR_complete_mult--jt_test_ALL_complete 
select distinct MULTIPLE from jt_test_ONLY_SBR_complete_mult--jt_test_ALL_complete 
