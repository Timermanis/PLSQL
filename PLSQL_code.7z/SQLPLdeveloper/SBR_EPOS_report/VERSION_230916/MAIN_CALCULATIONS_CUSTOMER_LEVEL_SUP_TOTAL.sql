select * from jt_SUP_sbr_all  where titl_long_name = 'TAB PUZZLE SELECTION'
create table jt_SUP_sbr_all as
with a as
(select
j.cus_box_number,j.cus_branch_code, j.titl_cover_price,j.net_commited,j.titl_long_name,j.ean,j.bris_recall_date,j.sup_name,j.multiple,j.multiple_code,
j.net_commited pre_net_commited,j.net_net,j.epos_total_sales, j.sbr_reduction_qty,j.sbr_so_qty,zz.Lost_Sales,zz.New_Day_1_2,nvl(j.ehis_rep_qty,0) replenishment_qty,
zz.Notional_EPOS_Returns Notional_EPOS_Returns , j.net_credit, j.net_other_sales,zz.consumer_lost_sales,zz.Extra_Sales,

CASE WHEN(j.net_credit) = 0 THEN 1 ELSE 0 end Crude_Avail_2,
-------------------------------------------
case when (j.net_commited + j.net_other_sales - j.net_net) =  0 then (j.bris_recall_date - j.epos_last_sold) end Days_off_sales_Actual,
------------------------------------------
case when zz.consumer_lost_sales = 0 then 0 else zz.lost_sales_up_to_orig_step end lost_sales_up_to_original_sup,
------------------------------------------
case when j.net_net + round(zz.Lost_Sales) = j.sbr_so_qty then 1 else 0 end  CA_Would_Have_Been,
------------------------------------------
(case when zz.New_Day_1_2 < = j.net_commited then j.net_commited + j.net_other_sales - zz.New_Day_1_2 else j.net_commited end)  New_Other_Sales ,   
------------------------------------------
(CASE WHEN j.net_other_sales > 0 THEN 1 else 0 end) Picks_Other_Sales ,
------------------------------------------
j.sbr_so_qty - j.net_net - zz.Extra_Sales Returns_2,
------------------------------------------
((CASE WHEN j.net_net - j.sbr_so_qty <= 0 THEN 0 ELSE j.net_net - j.sbr_so_qty end) * j.titl_cover_price) Extra_Sales_RSV ,
------------------------------------------
(CASE WHEN (j.net_credit) = 0 AND (zz.Notional_EPOS_Returns) > 0 then 1 else 0 end) sellout_but_epos_indicated_not ,
------------------------------------------
(CASE WHEN (j.net_credit) = 0 AND  j.net_net < j.sbr_so_qty then 1 else 0 end) sellout_under_initial_alloc,
------------------------------------------
round((1 - ((CASE WHEN (j.net_credit) = 0 THEN (j.bris_recall_date - j.epos_last_sold) end)/(j.bris_recall_date - j.bris_on_sale_date))) * 100,2) Life_Cycle_Avail_2,
------------------------------------------
round((((CASE WHEN (j.net_credit) = 0 THEN (j.bris_recall_date - j.epos_last_sold) end)/(j.bris_recall_date - j.bris_on_sale_date))) * 100,2) Life_Cycle_Avail_2_2,
------------------------------------------
CASE WHEN (j.net_credit) = 0 THEN (j.bris_recall_date - j.epos_last_sold) end Days_off_sales,
  ----------------------------------------
j.bris_recall_date - j.bris_on_sale_date  Days_On_Sales

from jt_test_ALL_complete_mult j, jt_test_all_sbr_calcul_cus zz 
where j.cus_box_number = zz.cus_box_number and j.cus_branch_code = zz.cus_branch_code and j.ean = zz.ean  and j.epos_total_sales >0)-- and j.sbr_so_qty is not null and j.epos_total_sales >0)
-----------------------
select 
a.sup_name,
sum(a.sbr_so_qty) sbr_ORIGINAL_SO_QTY,
sum(a.sbr_reduction_qty) sbr_REDUCTION_QTY,
--sum(a.sbr_so_qty - a.sbr_reduction_qty) ,
sum(a.epos_total_sales) EPOS_Total_Sales, 
sum(a.net_net) CLD_Net_Sales,
sum(a.net_commited) CLD_commited,

sum(a.net_credit) CLD_credit,
sum( replenishment_qty) ehis_replenishment_qty, 
Count(unique a.cus_box_number||a.cus_branch_code) count_customers, 
sum(a.New_Day_1_2) New_Day_1_2,
sum(case when a.New_Day_1_2 < = a.net_commited then a.net_commited + a.net_other_sales - a.New_Day_1_2 else a.net_commited end)  New_Other_Sales ,    
sum (CASE WHEN a.net_other_sales > 0 THEN 1 else 0 end) Picks_Other_Sales ,
sum(CASE WHEN a.net_net - a.sbr_so_qty <= 0 THEN 0 ELSE a.net_net - a.sbr_so_qty end) Extra_Sales ,
sum((CASE WHEN a.net_net - a.sbr_so_qty <= 0 THEN 0 ELSE a.net_net - a.sbr_so_qty end) * a.titl_cover_price) Extra_Sales_RSV ,
round(sum(lost_sales_up_to_original_sup)) lost_sales,
nvl(round((1 - (sum(Days_off_sales))/(sum(Days_on_sales))) * 100,2),100) Life_Cycle_Avail_2,
round((1- (Sum(Crude_Avail_2)/Count(*)))*100,2) Crude_Avail_2,
round(case when sum(a.net_net) != 0 then 100 - sum(consumer_lost_sales)/(sum(a.net_net)/100) end,2) Consumer_Availability,
round(((1-(sum(CA_Would_Have_Been) / count(*))) * 100),2) WHB_Crude,
sum(CA_Would_Have_Been) whb_sellouts,
sum (returns_2) WHB_Unsolds
from a a  --where 1=1  ".$pass_sup." ".$pass_mult." ".$pass_title."
group by a.sup_name

-----------------------------------------BRANCHES----------------------------------------------------
select * from jt_SUP_sbr_all_branch  where titl_long_name = 'TAB PUZZLE SELECTION'
create table jt_SUP_sbr_all_branch as
with a as
(select
j.cus_box_number,j.cus_branch_code, j.titl_cover_price,j.net_commited,j.titl_long_name,j.ean,j.bris_recall_date,j.sup_name,j.multiple,j.multiple_code,
j.net_commited pre_net_commited,j.net_net,j.epos_total_sales, j.sbr_reduction_qty,j.sbr_so_qty,zz.Lost_Sales,zz.New_Day_1_2,nvl(j.ehis_rep_qty,0) replenishment_qty,
zz.Notional_EPOS_Returns Notional_EPOS_Returns , j.net_credit, j.net_other_sales,zz.consumer_lost_sales,zz.Extra_Sales,

CASE WHEN(j.net_credit) = 0 THEN 1 ELSE 0 end Crude_Avail_2,
-------------------------------------------
case when (j.net_commited + j.net_other_sales - j.net_net) =  0 then (j.bris_recall_date - j.epos_last_sold) end Days_off_sales_Actual,
------------------------------------------
case when zz.consumer_lost_sales = 0 then 0 else zz.lost_sales_up_to_orig_step end lost_sales_up_to_original_sup,
------------------------------------------
case when j.net_net + round(zz.Lost_Sales) = j.sbr_so_qty then 1 else 0 end  CA_Would_Have_Been,
------------------------------------------
(case when zz.New_Day_1_2 < = j.net_commited then j.net_commited + j.net_other_sales - zz.New_Day_1_2 else j.net_commited end)  New_Other_Sales ,   
------------------------------------------
(CASE WHEN j.net_other_sales > 0 THEN 1 else 0 end) Picks_Other_Sales ,
------------------------------------------
j.sbr_so_qty - j.net_net - zz.Extra_Sales Returns_2,
------------------------------------------
((CASE WHEN j.net_net - j.sbr_so_qty <= 0 THEN 0 ELSE j.net_net - j.sbr_so_qty end) * j.titl_cover_price) Extra_Sales_RSV ,
------------------------------------------
(CASE WHEN (j.net_credit) = 0 AND (zz.Notional_EPOS_Returns) > 0 then 1 else 0 end) sellout_but_epos_indicated_not ,
------------------------------------------
(CASE WHEN (j.net_credit) = 0 AND  j.net_net < j.sbr_so_qty then 1 else 0 end) sellout_under_initial_alloc,
------------------------------------------
round((1 - ((CASE WHEN (j.net_credit) = 0 THEN (j.bris_recall_date - j.epos_last_sold) end)/(j.bris_recall_date - j.bris_on_sale_date))) * 100,2) Life_Cycle_Avail_2,
------------------------------------------
round((((CASE WHEN (j.net_credit) = 0 THEN (j.bris_recall_date - j.epos_last_sold) end)/(j.bris_recall_date - j.bris_on_sale_date))) * 100,2) Life_Cycle_Avail_2_2,
------------------------------------------
CASE WHEN (j.net_credit) = 0 THEN (j.bris_recall_date - j.epos_last_sold) end Days_off_sales,
  ----------------------------------------
j.bris_recall_date - j.bris_on_sale_date  Days_On_Sales

from jt_test_ALL_complete_mult j, jt_test_all_sbr_calcul_cus zz 
where j.cus_box_number = zz.cus_box_number and j.cus_branch_code = zz.cus_branch_code and j.ean = zz.ean  and j.epos_total_sales >0)-- and j.sbr_so_qty is not null and j.epos_total_sales >0)
-----------------------
select 
a.sup_name,a.cus_branch_code,
sum(a.sbr_so_qty) sbr_ORIGINAL_SO_QTY,
sum(a.sbr_reduction_qty) sbr_REDUCTION_QTY,
--sum(a.sbr_so_qty - a.sbr_reduction_qty) ,
sum(a.epos_total_sales) EPOS_Total_Sales, 
sum(a.net_net) CLD_Net_Sales,
sum(a.net_commited) CLD_commited,

sum(a.net_credit) CLD_credit,
sum( replenishment_qty) ehis_replenishment_qty, 
Count(unique a.cus_box_number||a.cus_branch_code) count_customers, 
sum(a.New_Day_1_2) New_Day_1_2,
sum(case when a.New_Day_1_2 < = a.net_commited then a.net_commited + a.net_other_sales - a.New_Day_1_2 else a.net_commited end)  New_Other_Sales ,    
sum (CASE WHEN a.net_other_sales > 0 THEN 1 else 0 end) Picks_Other_Sales ,
sum(CASE WHEN a.net_net - a.sbr_so_qty <= 0 THEN 0 ELSE a.net_net - a.sbr_so_qty end) Extra_Sales ,
sum((CASE WHEN a.net_net - a.sbr_so_qty <= 0 THEN 0 ELSE a.net_net - a.sbr_so_qty end) * a.titl_cover_price) Extra_Sales_RSV ,
round(sum(lost_sales_up_to_original_sup)) lost_sales,
nvl(round((1 - (sum(Days_off_sales))/(sum(Days_on_sales))) * 100,2),100) Life_Cycle_Avail_2,
round((1- (Sum(Crude_Avail_2)/Count(*)))*100,2) Crude_Avail_2,
round(case when sum(a.net_net) != 0 then 100 - sum(consumer_lost_sales)/(sum(a.net_net)/100) end,2) Consumer_Availability,
round(((1-(sum(CA_Would_Have_Been) / count(*))) * 100),2) WHB_Crude,
sum(CA_Would_Have_Been) whb_sellouts,
sum (returns_2) WHB_Unsolds
from a a  --where 1=1  ".$pass_sup." ".$pass_mult." ".$pass_title."
group by a.sup_name,a.cus_branch_code
