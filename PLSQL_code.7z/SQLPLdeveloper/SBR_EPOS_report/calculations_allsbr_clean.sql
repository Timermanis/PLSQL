
select 
j.SUP_NAME,
j.titl_long_name,
j.issu_reference,
sum(SBR_QTY) ORIGINAL_SO_QTY,
sum(CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) NEW_DAY_1, 
sum(CASE WHEN (CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) > NET_COMMITED_QUANTITY THEN NET_COMMITED_QUANTITY 
         ELSE (CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) end) New_Day_1_2,
sum(SBR_RED_QTY) REDUCTION_QTY,
sum(CASE WHEN 
           (CASE WHEN (CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) > NET_COMMITED_QUANTITY THEN NET_COMMITED_QUANTITY 
           ELSE (CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) end) >= NET_COMMITED_QUANTITY
     THEN NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - (CASE WHEN (CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) > NET_COMMITED_QUANTITY THEN NET_COMMITED_QUANTITY 
         ELSE (CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) end)
     ELSE NET_OTHER_SALES_QUANTITY end) New_Other_Sales,
sum (CASE WHEN NET_OTHER_SALES_QUANTITY > 0 THEN 1 else 0 end) Picks_Other_Sales,
sum(CASE WHEN j.total - SBR_QTY <= 0 THEN 0 ELSE j.total - SBR_QTY end) Extra_Sales,
sum((CASE WHEN j.total - SBR_QTY <= 0 THEN 0 ELSE j.total - SBR_QTY end) * j.titl_cover_price) Extra_Sales_RSV,
sum(EPOS_TOTAL_SALES) Total_Sales,
sum(NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - EPOS_TOTAL_SALES) Notional_EPOS_Returns,
sum(NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) credits,
sum(CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) > 0 AND (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - EPOS_TOTAL_SALES) > 0 then 1 else 0 end) sellout_but_epos_indicated_not,
sum(CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) > 0 AND  j.total < SBR_QTY then 1 else 0 end) sellout_under_initial_alloc,
sum(j.total) CLD_Net_Sales,
round((1 - (sum(CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN (j.bris_recall_date - j.epos_last_sold) end)/sum(j.bris_recall_date - j.bris_on_sale_date))) * 100,2) Life_Cycle_Avail_2,
sum(CASE WHEN(NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 1 ELSE 0 end) Crude_Avail_2,
round((1 - sum(CASE WHEN(NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 1 ELSE 0 end) / count(*))*100,2) actual_availability,
round(nvl(sum(CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
  CASE WHEN j.total = SBR_QTY THEN 0 ELSE
    CASE WHEN j.total + 
      (CASE WHEN j.total=0 then j.total WHEN EPOS_TOTAL_SALES/j.total > 0.899 then
        (CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
          CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN EPOS_TOTAL_SALES * 100/99.4 - EPOS_TOTAL_SALES ELSE 
            CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN EPOS_TOTAL_SALES * 100/98.8 - EPOS_TOTAL_SALES ELSE
              CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN EPOS_TOTAL_SALES * 100/98 - EPOS_TOTAL_SALES end end end end)else 0 end )= SBR_QTY then SBR_QTY - j.total
                else ((CASE WHEN j.total=0 then j.total WHEN EPOS_TOTAL_SALES/j.total > 0.899 then
(CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
  CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN EPOS_TOTAL_SALES * 100/99.4 - EPOS_TOTAL_SALES ELSE 
    CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN EPOS_TOTAL_SALES * 100/98.8 - EPOS_TOTAL_SALES ELSE
      CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN EPOS_TOTAL_SALES * 100/98 - EPOS_TOTAL_SALES end end end end)else 0 end)) end  end end),0),2) Lost_Sales,

nvl(round(100 - sum(CASE WHEN j.total=0 then j.total WHEN EPOS_TOTAL_SALES/j.total > 0.899 then
        (CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
          CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN (EPOS_TOTAL_SALES * 100/99.4) - EPOS_TOTAL_SALES ELSE 
            CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN (EPOS_TOTAL_SALES * 100/98.8) - EPOS_TOTAL_SALES ELSE
              CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN (EPOS_TOTAL_SALES * 100/98) - EPOS_TOTAL_SALES end end end end/(j.total/100))else 0 end),2),0) Consumer_Availability,
sum(EHIS_REP_QTY) total_SBR_instances,
 sum(CASE WHEN j.total + 
  CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
  CASE WHEN j.total = SBR_QTY THEN 0 ELSE
    CASE WHEN j.total + 
      (CASE WHEN j.total=0 then j.total WHEN EPOS_TOTAL_SALES/j.total > 0.899 then
        (CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
          CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN EPOS_TOTAL_SALES * 100/99.4 - EPOS_TOTAL_SALES ELSE 
            CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN EPOS_TOTAL_SALES * 100/98.8 - EPOS_TOTAL_SALES ELSE
              CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN EPOS_TOTAL_SALES * 100/98 - EPOS_TOTAL_SALES end end end end)else 0 end )= SBR_QTY then SBR_QTY - j.total
                else ((CASE WHEN j.total=0 then j.total WHEN EPOS_TOTAL_SALES/j.total > 0.899 then
(CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
  CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN EPOS_TOTAL_SALES * 100/99.4 - EPOS_TOTAL_SALES ELSE 
    CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN EPOS_TOTAL_SALES * 100/98.8 - EPOS_TOTAL_SALES ELSE
      CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN EPOS_TOTAL_SALES * 100/98 - EPOS_TOTAL_SALES end end end end)else 0 end)) end  end end = SBR_QTY THEN 1 ELSE 0 end) whb_sellouts --, --CA Would Have Been
from jt_1234_ANAS_260516 j 
group by j.sup_name,j.titl_long_name,j.issu_reference

