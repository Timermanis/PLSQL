select * from agent_net_sales a where a.net_issue_year = 2016

select c.cus_box_number,c.cus_branch_code,count(cus_account_number) from customers c 
where c.cus_to_date > '01-DEC-3000'group by c.cus_box_number,c.cus_branch_code having count(cus_account_number) >1

select bris_branch_code, bris_ean,bris_issue_year
from branch_issues
where bris_issue_year > 2015
and bris_link_ean is null


select distinct j.titl_long_name from jt_1234_ANAS_260516 j where 1=1 and j.mult_name in ('WHS TRAVEL U/GROUND') and j.sup_name in ('FRONTLINE LTD','SEYMOUR DISTRIBUTION (UK) LTD')
