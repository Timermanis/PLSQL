--=100-(<Sum consumer lost sales>/(<CLD Net Sales>/100))
--consumer lost sales = If (<Total Sales>/<CLD Net Sales>)>0.899 Then <Lost Sales> Else 0
--Lost Sales == If (<credits>=0) Then If (<Days off sales Actual>=1) Then (<Total Sales>*100/99.4-<Total Sales>) Else If  (<Days off sales Actual>=2) Then (<Total Sales>*100/98.8-<Total Sales>) Else If (<Days off sales Actual>=3) Then (<Total Sales>*100/98-<Total Sales>) Else If  (<Days off sales Actual>=4) Then (<Total Sales>*100/96-<Total Sales>) Else If  (<Days off sales Actual>=5) Then (<Total Sales>*100/94-<Total Sales>) Else If  (<Days off sales Actual>=6) Then (<Total Sales>*100/93-<Total Sales>) Else If  (<Days off sales Actual>=7) Then (<Total Sales>*100/91-<Total Sales>) Else If  (<Days off sales Actual>=8) Then (<Total Sales>*100/88-<Total Sales>) Else If  (<Days off sales Actual>=9) Then (<Total Sales>*100/86-<Total Sales>) Else If  (<Days off sales Actual>=10) Then (<Total Sales>*100/84-<Total Sales>) Else If  (<Days off sales Actual>=11) Then (<Total Sales>*100/82-<Total Sales>) Else If  (<Days off sales Actual>=12) Then (<Total Sales>*100/79-<Total Sales>) Else If  (<Days off sales Actual>=13) Then (<Total Sales>*100/77-<Total Sales>) Else If  (<Days off sales Actual>=14) Then (<Total Sales>*100/75-<Total Sales>) Else If  (<Days off sales Actual>=15) Then (<Total Sales>*100/72-<Total Sales>) Else If  (<Days off sales Actual>=16) Then (<Total Sales>*100/69-<Total Sales>) Else If  (<Days off sales Actual>=17) Then (<Total Sales>*100/66-<Total Sales>) Else If  (<Days off sales Actual>=18) Then (<Total Sales>*100/63-<Total Sales>) Else If  (<Days off sales Actual>=19) Then (<Total Sales>*100/60-<Total Sales>) Else If  (<Days off sales Actual>=20) Then (<Total Sales>*100/57-<Total Sales>) Else If  (<Days off sales Actual>=21) Then (<Total Sales>*100/54-<Total Sales>) Else If  (<Days off sales Actual>=22) Then (<Total Sales>*100/50-<Total Sales>) Else If  (<Days off sales Actual>=23) Then (<Total Sales>*100/46-<Total Sales>) Else If  (<Days off sales Actual>=24) Then (<Total Sales>*100/42-<Total Sales>) Else If  (<Days off sales Actual>=25) Then (<Total Sales>*100/37-<Total Sales>) Else If  (<Days off sales Actual>=26) Then (<Total Sales>*100/33-<Total Sales>) Else If  (<Days off sales Actual>=27) Then (<Total Sales>*100/28-<Total Sales>) Else If  (<Days off sales Actual>=28) Then (<Total Sales>*100/23-<Total Sales>) Else If  (<Days off sales Actual>=29) Then (<Total Sales>*100/16-<Total Sales>) Else If  (<Days off sales Actual>=30) Then (<Total Sales>*100/9-<Total Sales>) 
-- sum(nvl(AGENT_NET_SALES.NET_BOX_OUT_QUANTITY,0) + nvl(AGENT_NET_SALES.NET_COMMITED_QUANTITY,0)+ nvl(AGENT_NET_SALES.NET_OTHER_SALES_QUANTITY,0) - nvl(AGENT_NET_SALES.NET_CREDIT_QUANTITY,0))
select 
j.SUP_NAME,j.

nvl(round(100 - sum(CASE WHEN j.net_return_quantity <> 0 then  case WHEN (EPOS_TOTAL_SALES/j.total) > 0.899 then
        (CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
          CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN (EPOS_TOTAL_SALES * 100/99.4) - EPOS_TOTAL_SALES ELSE 
            CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN (EPOS_TOTAL_SALES * 100/98.8) - EPOS_TOTAL_SALES ELSE
              CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN (EPOS_TOTAL_SALES * 100/98) - EPOS_TOTAL_SALES end end end end/(j.total/100))else 0 end end),2),0) Consumer_Availability

from jt_1234_ANAS_260516 j where j.sup_name = 'COMAG MAGAZINE MARKETING'
group by j.sup_name


select 
j.SUP_NAME,

nvl(round(100 - sum(CASE WHEN j.total <> 0 then  case WHEN (EPOS_TOTAL_SALES/j.total) > 0.899 then
        (CASE WHEN (j.net_return_quantity) = 0 THEN 
          CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN (EPOS_TOTAL_SALES * 100/99.4) - EPOS_TOTAL_SALES ELSE 
            CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN (EPOS_TOTAL_SALES * 100/98.8) - EPOS_TOTAL_SALES ELSE
              CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN (EPOS_TOTAL_SALES * 100/98) - EPOS_TOTAL_SALES end end end end/abs(j.total/100))else 0 end end),2),0) Consumer_Availability

from jt_1234_ANAS_260516 j where j.sup_name = 'COMAG MAGAZINE MARKETING'
group by j.sup_name

select 
j.SUP_NAME,j.cus_box_number,

sum( case WHEN (j.total<0) then 1 end)
      
from jt_1234_ANAS_260516 j --where j.sup_name = 'COMAG MAGAZINE MARKETING'
group by j.sup_name,j.cus_box_number

select 
j.SUP_NAME,j.cus_box_number,

sum( CASE WHEN (j.bris_recall_date - j.epos_last_sold)> 3 then 1 end)
      
from jt_1234_ANAS_260516 j --where j.sup_name = 'COMAG MAGAZINE MARKETING'
group by j.sup_name,j.cus_box_number


select * from customers c where c.cus_account_number = 502963050181200
select * from agent_net_sales a where a.net_agent_account_number = 502963050181200 and a.net_issue_ean=977135127116613
