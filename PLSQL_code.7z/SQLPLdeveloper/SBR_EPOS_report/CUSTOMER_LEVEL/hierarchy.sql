select * from jt_test_CUS_NO_SBR_complete;--main
select * from jt_test_CUS_ONLY_SBR_complete;
select * from jt_test_CUS_ALL_complete



select * from jt_title_sbr_all
select * from jt_title_no_sbr
select * from jt_title_only_sbr
