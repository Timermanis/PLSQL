drop table jt_title_only_sbr_branch
select * from jt_title_only_sbr_branch where titl_long_name = 'TAB PUZZLE SELECTION'
create table jt_title_only_sbr_branch as
with a as
(select
j.cus_box_number,j.cus_branch_code, j.titl_cover_price,j.net_commited,j.titl_long_name,j.ean,j.bris_recall_date,j.sup_name,j.niss_cover_price,j.niss_official_on_sale_date,j.niss_reference,
j.net_commited pre_net_commited,j.net_net,j.epos_total_sales, j.sbr_reduction_qty,j.sbr_so_qty,zz.Lost_Sales,zz.New_Day_1_2,nvl(j.ehis_rep_qty,0) replenishment_qty,
zz.Notional_EPOS_Returns Notional_EPOS_Returns , j.net_credit, j.net_other_sales,zz.consumer_lost_sales,zz.Extra_Sales,zz.CA_Would_Have_Been,

CASE WHEN(j.net_credit) = 0 THEN 1 ELSE 0 end Crude_Avail_2,
-------------------------------------------
case when zz.consumer_lost_sales = 0 then 0 else zz.lost_sales_up_to_orig_step end lost_sales_up_to_original_sup,
------------------------------------------
j.cus_box_number||j.cus_branch_code store_count,
------------------------------------------
(case when zz.New_Day_1_2 < = j.net_commited then j.net_commited + j.net_other_sales - zz.New_Day_1_2 else j.net_commited end)  New_Other_Sales ,   
------------------------------------------
(CASE WHEN j.net_other_sales > 0 THEN 1 else 0 end) Picks_Other_Sales ,
------------------------------------------
j.sbr_so_qty - (j.net_net - zz.Extra_Sales) Returns_2,
------------------------------------------
((CASE WHEN j.net_net - j.sbr_so_qty <= 0 THEN 0 ELSE j.net_net - j.sbr_so_qty end) * j.niss_cover_price) Extra_Sales_RSV ,
------------------------------------------
(CASE WHEN (j.net_credit) = 0 AND (zz.Notional_EPOS_Returns) > 0 then 1 else 0 end) sellout_but_epos_indicated_not ,
------------------------------------------
(CASE WHEN (j.net_credit) = 0 AND  j.net_net < j.sbr_so_qty then 1 else 0 end) sellout_under_initial_alloc,
------------------------------------------
round((1 - ((CASE WHEN (j.net_credit) = 0 THEN (j.bris_recall_date - to_date(trim(j.epos_last_sold))) end)/(j.bris_recall_date - j.bris_on_sale_date))) * 100,2) Life_Cycle_Avail_2,
------------------------------------------
CASE WHEN (j.net_credit) = 0 THEN (j.bris_recall_date - to_date(trim(j.epos_last_sold))) end Days_off_sales_actual,
------------------------------------------
CASE WHEN (zz.Notional_EPOS_Returns) = 0 THEN (j.bris_recall_date - to_date(trim(j.epos_last_sold))) end Days_off_sales,
------------------------------------------
j.bris_recall_date - j.bris_on_sale_date Days_On_Sales
from jt_test_CUS_ONLY_SBR_complete j, jt_test_only_sbr_calcul_cus zz
where j.cus_box_number = zz.cus_box_number and j.cus_branch_code = zz.cus_branch_code and j.ean = zz.ean and j.sbr_so_qty is not null and j.epos_total_sales >0) 
--and j.ean = 977135127116606  
-----------------------
select 
titl_long_name,
a.ean,a.bris_recall_date,niss_official_on_sale_date,niss_reference,cus_branch_code,
sup_name,
count(store_count) store_count,
a.titl_cover_price,
sum( replenishment_qty) ehis_replenishment_qty,
sum(a.sbr_so_qty) sbr_ORIGINAL_SO_QTY,
sum(a.New_Day_1_2) New_Day_1_2,
sum(a.sbr_reduction_qty) sbr_REDUCTION_QTY,
sum(New_Other_Sales) New_Other_Sales,
sum(Picks_Other_Sales) Picks_Other_Sales,
sum(a.Extra_Sales) Extra_Sales,
sum(a.Extra_Sales_RSV) Extra_Sales_RSV,
sum(a.epos_total_sales) epos_total_sales,
sum(a.Notional_EPOS_Returns) Notional_EPOS_Returns,
sum(a.net_credit) CLD_credit,
sum(a.net_commited) CLD_commited,----------------------
sum(sellout_but_epos_indicated_not) sellout_but_epos_indicated_not,
sum(sellout_under_initial_alloc) sellout_under_initial_alloc,
sum(a.net_net) CLD_Net_Sales,
sum(a.Days_off_sales) Days_off_sales,
sum(a.Days_off_sales_actual) Days_off_sales_actual,
nvl(round((1 - (sum(a.Days_off_sales_actual))/(sum(Days_on_sales))) * 100,2),100) Life_Cycle_Avail_2,
round((1- (Sum(Crude_Avail_2)/Count(*)))*100,2) actual_availability,
sum(Crude_Avail_2) Crude_Avail_2,
round(sum(lost_sales_up_to_original_sup)) lost_sales_up_to_original_sup,
round(case when sum(a.net_net) != 0 then 100 - sum(consumer_lost_sales)/(sum(a.net_net)/100) end,2) Consumer_Availability,
round(((1-(sum(CA_Would_Have_Been) / count(*))) * 100),2) WHB_Crude,
sum(CA_Would_Have_Been) whb_sellouts,
sum (returns_2) WHB_Unsolds
from a a  
group by a.titl_long_name, a.ean, a.bris_recall_date,a.sup_name,a.titl_cover_price,niss_official_on_sale_date,niss_reference,cus_branch_code--,a.multiple,a.multiple_code

--------------------------------------------------------------title only sbr-----------------------------------------------------------------------
--drop table jt_title_only_sbr
select * from jt_title_only_sbr where titl_long_name = 'TAB PUZZLE SELECTION'
create table jt_title_only_sbr as
with a as
(select
j.cus_box_number,j.cus_branch_code, j.titl_cover_price,j.net_commited,j.titl_long_name,j.ean,j.bris_recall_date,j.sup_name,j.niss_cover_price,j.niss_official_on_sale_date,j.niss_reference,
j.net_commited pre_net_commited,j.net_net,j.epos_total_sales, j.sbr_reduction_qty,j.sbr_so_qty,zz.Lost_Sales,zz.New_Day_1_2,nvl(j.ehis_rep_qty,0) replenishment_qty,
zz.Notional_EPOS_Returns Notional_EPOS_Returns , j.net_credit, j.net_other_sales,zz.consumer_lost_sales,zz.Extra_Sales,zz.CA_Would_Have_Been,

CASE WHEN(j.net_credit) = 0 THEN 1 ELSE 0 end Crude_Avail_2,
-------------------------------------------
case when zz.consumer_lost_sales = 0 then 0 else zz.lost_sales_up_to_orig_step end lost_sales_up_to_original_sup,
------------------------------------------
j.cus_box_number||j.cus_branch_code store_count,
------------------------------------------
(case when zz.New_Day_1_2 < = j.net_commited then j.net_commited + j.net_other_sales - zz.New_Day_1_2 else j.net_commited end)  New_Other_Sales ,   
------------------------------------------
(CASE WHEN j.net_other_sales > 0 THEN 1 else 0 end) Picks_Other_Sales ,
------------------------------------------
j.sbr_so_qty - (j.net_net - zz.Extra_Sales) Returns_2,
------------------------------------------
((CASE WHEN j.net_net - j.sbr_so_qty <= 0 THEN 0 ELSE j.net_net - j.sbr_so_qty end) * j.niss_cover_price) Extra_Sales_RSV ,
------------------------------------------
(CASE WHEN (j.net_credit) = 0 AND (zz.Notional_EPOS_Returns) > 0 then 1 else 0 end) sellout_but_epos_indicated_not ,
------------------------------------------
(CASE WHEN (j.net_credit) = 0 AND  j.net_net < j.sbr_so_qty then 1 else 0 end) sellout_under_initial_alloc,
------------------------------------------
round((1 - ((CASE WHEN (j.net_credit) = 0 THEN (j.bris_recall_date - to_date(trim(j.epos_last_sold))) end)/(j.bris_recall_date - j.bris_on_sale_date))) * 100,2) Life_Cycle_Avail_2,
------------------------------------------
CASE WHEN (j.net_credit) = 0 THEN (j.bris_recall_date - to_date(trim(j.epos_last_sold))) end Days_off_sales_actual,
------------------------------------------
CASE WHEN (zz.Notional_EPOS_Returns) = 0 THEN (j.bris_recall_date - to_date(trim(j.epos_last_sold))) end Days_off_sales,
------------------------------------------
j.bris_recall_date - j.bris_on_sale_date Days_On_Sales
from jt_test_CUS_ONLY_SBR_complete j, jt_test_only_sbr_calcul_cus zz
where j.cus_box_number = zz.cus_box_number and j.cus_branch_code = zz.cus_branch_code and j.ean = zz.ean and j.sbr_so_qty is not null and j.epos_total_sales >0) 
--and j.ean = 977135127116606  
-----------------------
select 
titl_long_name,
a.ean,a.bris_recall_date,niss_official_on_sale_date,niss_reference,
sup_name,
count(store_count) store_count,
a.titl_cover_price,
sum( replenishment_qty) ehis_replenishment_qty,
sum(a.sbr_so_qty) sbr_ORIGINAL_SO_QTY,
sum(a.New_Day_1_2) New_Day_1_2,
sum(a.sbr_reduction_qty) sbr_REDUCTION_QTY,
sum(New_Other_Sales) New_Other_Sales,
sum(Picks_Other_Sales) Picks_Other_Sales,
sum(a.Extra_Sales) Extra_Sales,
sum(a.Extra_Sales_RSV) Extra_Sales_RSV,
sum(a.epos_total_sales) epos_total_sales,
sum(a.Notional_EPOS_Returns) Notional_EPOS_Returns,
sum(a.net_credit) CLD_credit,
sum(a.net_commited) CLD_commited,----------------------
sum(sellout_but_epos_indicated_not) sellout_but_epos_indicated_not,
sum(sellout_under_initial_alloc) sellout_under_initial_alloc,
sum(a.net_net) CLD_Net_Sales,
sum(a.Days_off_sales) Days_off_sales,
sum(a.Days_off_sales_actual) Days_off_sales_actual,
nvl(round((1 - (sum(a.Days_off_sales_actual))/(sum(Days_on_sales))) * 100,2),100) Life_Cycle_Avail_2,
round((1- (Sum(Crude_Avail_2)/Count(*)))*100,2) actual_availability,
sum(Crude_Avail_2) Crude_Avail_2,
round(sum(lost_sales_up_to_original_sup)) lost_sales_up_to_original_sup,
round(case when sum(a.net_net) != 0 then 100 - sum(consumer_lost_sales)/(sum(a.net_net)/100) end,2) Consumer_Availability,
round(((1-(sum(CA_Would_Have_Been) / count(*))) * 100),2) WHB_Crude,
sum(CA_Would_Have_Been) whb_sellouts,
sum (returns_2) WHB_Unsolds
from a a  
group by a.titl_long_name, a.ean, a.bris_recall_date,a.sup_name,a.titl_cover_price,niss_official_on_sale_date,niss_reference--,a.multiple,a.multiple_code
