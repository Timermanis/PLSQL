select bris_recall_date - epos_last_sold, count(*)

from JT_1234_ANAS_060716_TEST_BO t where EPOS_TOTAL_SALES != 0 and ORIGINAL_SO_QTY != 0 group by sup_name,TITL_LONG_NAME,TITL_COVER_PRICE, t.bris_ean,bris_recall_date - epos_last_sold --t.net_agent_account_number,
