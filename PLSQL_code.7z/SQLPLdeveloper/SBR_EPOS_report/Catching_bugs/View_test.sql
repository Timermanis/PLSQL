select b.cus_branch_code cus_branch_code,b.cus_box_number cus_box_number,b.ean ean,nvl(b.Lost_Sales,0) Lost_Sales,a.net_credit,b.Days_off_sales_Actual,
a.net_commited + a.net_other_sales - a.epos_total_sales   Notional_EPOS_Returns,a.net_commited,


(CASE WHEN a.net_net - a.sbr_so_qty <= 0 THEN 0 ELSE a.net_net - a.sbr_so_qty end) Extra_Sales ,
CASE WHEN (CASE WHEN a.net_commited >=1 then (a.sbr_so_qty - a.sbr_reduction_qty) else a.net_commited end) > a.net_commited THEN a.net_commited
        ELSE (CASE WHEN a.net_commited >=1 then (a.sbr_so_qty - a.sbr_reduction_qty) else a.net_commited end) end New_Day_1_2,

nvl(case when a.net_net !=0 and  a.epos_total_sales/a.net_net > 0.899 then b.Lost_Sales else 0 end ,0) consumer_lost_sales,--= If (<Total Sales>/<CLD Net Sales>)>0.899 Then <Lost Sales> Else 0
------
to_number(nvl(case when a.net_credit = 0 then case when a.net_net >= a.sbr_so_qty then 0 else case when (a.net_net + b.Lost_Sales) = a.sbr_so_qty then a.sbr_so_qty - a.net_net else b.Lost_Sales end end end,0)) lost_sales_up_to_orig_step,

------
a.sbr_so_qty,
a.net_net,
--nvl(case when (a.net_net + trunc(b.Lost_Sales)) >= a.sbr_so_qty then 1 else 0 end  ,0) CA_Would_Have_Been
nvl(case when (trunc(a.net_net) + nvl(trunc(b.Lost_Sales),0)) >= a.sbr_so_qty  then 1 else 0 end  ,0) CA_Would_Have_Been
 from jt_test_CUS_ONLY_SBR_complete a,
(select z.cus_branch_code,z.cus_box_number,z.ean,
case when (z.net_commited + z.net_other_sales - z.net_net) =  0 then (z.bris_recall_date - to_date(trim(z.epos_last_sold))) end Days_off_sales_Actual,
(CASE WHEN (z.net_credit) = 0 THEN
      CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=1 THEN (z.epos_total_sales * 100/99.4 - z.epos_total_sales) ELSE
            CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=2 THEN (z.epos_total_sales * 100/98.8 - z.epos_total_sales) ELSE
              CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=3 THEN (z.epos_total_sales * 100/98 - z.epos_total_sales) ELSE
                CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=4 THEN (z.epos_total_sales * 100/96 - z.epos_total_sales) ELSE
                  CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=5 THEN (z.epos_total_sales * 100/94 - z.epos_total_sales) ELSE
                    CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=6 THEN (z.epos_total_sales * 100/93 - z.epos_total_sales) ELSE
                      CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=7 THEN (z.epos_total_sales * 100/91 - z.epos_total_sales) ELSE
                        CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=8 THEN (z.epos_total_sales * 100/88 - z.epos_total_sales) ELSE
                         CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=9 THEN (z.epos_total_sales * 100/86 - z.epos_total_sales) ELSE
                          CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=10 THEN (z.epos_total_sales * 100/84 - z.epos_total_sales) ELSE
                            CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=11 THEN (z.epos_total_sales * 100/82 - z.epos_total_sales) ELSE
                              CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=12 THEN (z.epos_total_sales * 100/79 - z.epos_total_sales) ELSE
                                CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=13 THEN (z.epos_total_sales * 100/77 - z.epos_total_sales) ELSE
                                  CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=14 THEN (z.epos_total_sales * 100/75 - z.epos_total_sales) ELSE
                                    CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=15 THEN (z.epos_total_sales * 100/72 - z.epos_total_sales) ELSE
                                      CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=16 THEN (z.epos_total_sales * 100/69 - z.epos_total_sales) ELSE
                                        CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=17 THEN (z.epos_total_sales * 100/66 - z.epos_total_sales) ELSE
                                          CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=18 THEN (z.epos_total_sales * 100/63 - z.epos_total_sales) ELSE
                                            CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=19 THEN (z.epos_total_sales * 100/60 - z.epos_total_sales) ELSE
                                              CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=20 THEN (z.epos_total_sales * 100/57 - z.epos_total_sales) ELSE
                                                CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=21 THEN (z.epos_total_sales * 100/54 - z.epos_total_sales) ELSE
                                                  CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=22 THEN (z.epos_total_sales * 100/50 - z.epos_total_sales) ELSE
                                                    CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=23 THEN (z.epos_total_sales * 100/46 - z.epos_total_sales) ELSE
                                                      CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=24 THEN (z.epos_total_sales * 100/42 - z.epos_total_sales) ELSE
                                                        CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=25 THEN (z.epos_total_sales * 100/37 - z.epos_total_sales) ELSE
                                                          CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=26 THEN (z.epos_total_sales * 100/33 - z.epos_total_sales) ELSE
                                                            CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=27 THEN (z.epos_total_sales * 100/28 - z.epos_total_sales) ELSE
                                                              CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=28 THEN (z.epos_total_sales * 100/23 - z.epos_total_sales) ELSE
                                                                CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=29 THEN (z.epos_total_sales * 100/16 - z.epos_total_sales) ELSE
                                                                  CASE WHEN (z.bris_recall_date - to_date(trim(z.epos_last_sold)))=30 THEN (z.epos_total_sales * 100/9 - z.epos_total_sales )
                                                                    end end end end end end end end end end end end end end end end end end end end end end end end end end end end end end end) Lost_Sales
from jt_test_CUS_ONLY_SBR_complete z) b where a.cus_box_number = b.cus_box_number and a.cus_branch_code = b.cus_branch_code and a.ean = b.ean and a.title_code = 2703 
and  a.sbr_so_qty is  null and a.net_other_sales >0
;
