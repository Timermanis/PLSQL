
select 
j.SUP_NAME,
j.titl_long_name,
j.issu_reference,
count(distinct TITL_LONG_NAME) titles_qty,
--count(j.cus_box_number,j.branch_name) STORE_COUNT, add into table :)

sum(SBR_QTY) ORIGINAL_SO_QTY,
sum(CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) NEW_DAY_1, 
--= If (<New Day 1>><Day One Supply >) Then <Day One Supply > Else <New Day 1>
sum(CASE WHEN (CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) > NET_COMMITED_QUANTITY THEN NET_COMMITED_QUANTITY 
  ELSE (CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) end) New_Day_1_2,
sum(SBR_RED_QTY) REDUCTION_QTY,
-- If <New Day 1 (2)><=<Day One Supply > Then ((<CLD Commited Quantity>+<CLD Box Out Quantity>)+<CLD Other Sales Quantity>)-<New Day 1 (2)> Else <CLD Other Sales Quantity>
sum(CASE WHEN 
           (CASE WHEN (CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) > NET_COMMITED_QUANTITY THEN NET_COMMITED_QUANTITY 
           ELSE (CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) end) >= NET_COMMITED_QUANTITY
     THEN NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - (CASE WHEN (CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) > NET_COMMITED_QUANTITY THEN NET_COMMITED_QUANTITY 
         ELSE (CASE WHEN NET_COMMITED_QUANTITY >=1 then (SBR_QTY-SBR_RED_QTY) else NET_COMMITED_QUANTITY end) end)
     ELSE NET_OTHER_SALES_QUANTITY end) New_Other_Sales,
-- If <CLD Other Sales Quantity>>0 Then 1
sum (CASE WHEN NET_OTHER_SALES_QUANTITY > 0 THEN 1 end) Picks_Other_Sales,
--= If <CLD Net Sales>-<Original So Qty><=0 Then 0 Else <CLD Net Sales>-<Original So Qty>
sum(CASE WHEN j.total - SBR_QTY <= 0 THEN 0 ELSE j.total - SBR_QTY end) Extra_Sales,
sum((CASE WHEN j.total - SBR_QTY <= 0 THEN 0 ELSE j.total - SBR_QTY end) * j.titl_cover_price) Extra_Sales_RSV,
sum(EPOS_TOTAL_SALES) Total_Sales,
--=<CLD Commited Quantity>+<CLD Other Sales Quantity>+<CLD Box Out Quantity>-<Total Sales>
sum(NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - EPOS_TOTAL_SALES) Notional_EPOS_Returns,
--=<Day One Supply >+<CLD Other Sales Quantity>-<CLD Net Sales>
sum(NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) credits,
--=Sum(If <credits>=0 And <Notional EPOS Returns>>0 Then 1)
sum(CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) > 0 AND (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - EPOS_TOTAL_SALES) > 0 then 1 else 0 end) sellout_but_epos_indicated_not,
--= Sum(If <credits>=0 And <CLD Net Sales><<Original So Qty> Then 1)
sum(CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) > 0 AND  j.total < SBR_QTY then 1 else 0 end) sellout_under_initial_alloc,
sum(j.total) CLD_Net_Sales,
--=(1- (Sum(<Days off sales Actual>)/Sum(<Days On Sale>)))*100	Days off sales Actual = If (<credits> = 0) Then DaysBetween(<Date Last Sold> ,<Bris Recall Date>)||	Days On Sale =DaysBetween(<Bris On Sale Date> ,<Bris Recall Date>)
round((1 - (sum(CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN (j.bris_recall_date - j.epos_last_sold) end)/sum(j.bris_recall_date - j.bris_on_sale_date))) * 100,2) Life_Cycle_Avail_2,
--=Sum(<Crude Avail 2>) -> If(<credits>= 0 ) Then  1
sum(CASE WHEN(NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 1 ELSE 0 end) Crude_Avail_2,
--=(1- (Sum(<Crude Avail 2>)/CountAll(<Bris On Sale Date>)))*100
--sum((1 - (CASE WHEN(NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 1 ELSE 0 end) / count(j.bris_on_sale_date))*100),
round((1 - sum(CASE WHEN(NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 1 ELSE 0 end) / count(*))*100,2) actual_availability,
--= If <consumer lost sales>=0 Then 0 Else <lost sales up to orig step>	 || consumer lost sales = If (<Total Sales>/<CLD Net Sales>)>0.899 Then <Lost Sales> Else 0
--lost sales = If (<credits>=0) Then If (<Days off sales Actual>=1) Then (<Total Sales>*100/99.4-<Total Sales>) Else If  (<Days off sales Actual>=2) Then (<Total Sales>*100/98.8-<Total Sales>) Else If (<Days off sales Actual>=3) Then (<Total Sales>*100/98-<Total Sales
--consumer lost sales = If (<Total Sales>/<CLD Net Sales>)>0.899 Then <Lost Sales> Else 0
--CASE WHEN EPOS_TOTAL_SALES/j.total > 0.899 THEN
--lost sales = If (<credits>=0) Then If (<Days off sales Actual>=1) Then (<Total Sales>*100/99.4-<Total Sales>) Else If  (<Days off sales Actual>=2) Then (<Total Sales>*100/98.8-<Total Sales>) Else If (<Days off sales Actual>=3) Then (<Total Sales>*100/98-<Total Sales
--lost sales up to orig step =  If <credits>=0 Then If (<CLD Net Sales>>=<Original So Qty>) Then 0 Else If(<CLD Net Sales>+<Lost Sales>) >=<Original So Qty>  Then (<Original So Qty>-<CLD Net Sales>) Else <Lost Sales>
 
CASE WHEN 
sum(CASE WHEN j.total=0 then j.total WHEN EPOS_TOTAL_SALES/j.total > 0.899 then
 (CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
  CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN EPOS_TOTAL_SALES * 100/99.4 - EPOS_TOTAL_SALES ELSE 
    CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN EPOS_TOTAL_SALES * 100/98.8 - EPOS_TOTAL_SALES ELSE
      CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN EPOS_TOTAL_SALES * 100/98 - EPOS_TOTAL_SALES end end end end)else 0 end) =0 THEN 0 end ,
        
--lost sales up to orig step =  If <credits>=0 Then If (<CLD Net Sales>>=<Original So Qty>) Then 0 Else If(<CLD Net Sales>+<Lost Sales>) >=<Original So Qty>  Then (<Original So Qty>-<CLD Net Sales>) Else <Lost Sales>
round(nvl(sum(CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
  CASE WHEN j.total = SBR_QTY THEN 0 ELSE
    CASE WHEN j.total + 
      (CASE WHEN j.total=0 then j.total WHEN EPOS_TOTAL_SALES/j.total > 0.899 then
        (CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
          CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN EPOS_TOTAL_SALES * 100/99.4 - EPOS_TOTAL_SALES ELSE 
            CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN EPOS_TOTAL_SALES * 100/98.8 - EPOS_TOTAL_SALES ELSE
              CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN EPOS_TOTAL_SALES * 100/98 - EPOS_TOTAL_SALES end end end end)else 0 end )= SBR_QTY then SBR_QTY - j.total
                else ((CASE WHEN j.total=0 then j.total WHEN EPOS_TOTAL_SALES/j.total > 0.899 then
(CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
  CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN EPOS_TOTAL_SALES * 100/99.4 - EPOS_TOTAL_SALES ELSE 
    CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN EPOS_TOTAL_SALES * 100/98.8 - EPOS_TOTAL_SALES ELSE
      CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN EPOS_TOTAL_SALES * 100/98 - EPOS_TOTAL_SALES end end end end)else 0 end)) end  end end),0),2) Lost_Sales,

nvl(round(100 - sum(CASE WHEN j.total=0 then j.total WHEN EPOS_TOTAL_SALES/j.total > 0.899 then
        (CASE WHEN (NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY - j.total) = 0 THEN 
          CASE WHEN (j.bris_recall_date - j.epos_last_sold)=1 THEN (EPOS_TOTAL_SALES * 100/99.4) - EPOS_TOTAL_SALES ELSE 
            CASE WHEN (j.bris_recall_date - j.epos_last_sold)=2 THEN (EPOS_TOTAL_SALES * 100/98.8) - EPOS_TOTAL_SALES ELSE
              CASE WHEN (j.bris_recall_date - j.epos_last_sold)=3 THEN (EPOS_TOTAL_SALES * 100/98) - EPOS_TOTAL_SALES end end end end/(j.total/100))else 0 end),2),0) Consumer_Availability,
sum(EHIS_REP_QTY) total_SBR_instances,-- Replenishment_qty,
--=((1- (Sum(<CA Would Have Been>)/CountAll(<Box Number>)))*100)	||   CA Would Have Been = If (<CLD Net Sales>+<Lost Sales>)>=<Original So Qty> Then 1 Else 0
--CASE WHEN j.total + 


sum(NET_COMMITED_QUANTITY) Day_One_Supply,
sum(NET_OTHER_SALES_QUANTITY),
sum(NET_RETURN_QUANTITY),
sum(TOTAL),
sum(NET_BOX_OUT_QUANTITY)



from jt_1234_ANAS_260516 j where j.sup_name in ('FRONTLINE LTD')
group by j.sup_name,j.titl_long_name,j.issu_reference

