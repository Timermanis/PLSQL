SELECT 
*
FROM  agent_net_sales a
---------------------------------------------------------------------------------------------------------------------------------------------
 inner join BRANCH_ISSUES b on
        a.NET_ISSUE_EAN=b.BRIS_EAN
        and a.NET_ISSUE_YEAR=b.BRIS_ISSUE_YEAR
        and a.NET_BRANCH_CODE=b.BRIS_BRANCH_CODE  
 inner join normal_issues  n on
        n.niss_ean = b.bris_link_ean
        and n.niss_issue_year = b.bris_link_issue_year
 inner join titles t on
        t.titl_code = n.niss_title_code
 inner join customers c on
        c.cus_account_number = a.net_agent_account_number
 inner join multiple m on
        m.mult_multiple_code = c.cus_multiple_code  
 inner join suppliers s on       
        s.sup_code = t.titl_supply_org_code_distribut
 inner join suppliers ss on         
        t.TITL_PORTFOLIO_CODE=ss.SUP_CODE
 inner join BRANCH_PARENTS br on 
        br.BRANCH_CODE=b.BRIS_BRANCH_CODE
 inner join WEEK_LOOKUPS w on        
        n.niss_issue_week=w.wel_week_number
        and n.niss_issue_year=w.wel_year_number
 inner join SBR_TITLE_GROUP_DETAILS  st on  
        st.TGD_TITLE_NUMBER=t.TITL_CODE  
 inner join SBR_TITLE_GROUP_HEADERS  sh on 
        sh.TGH_TITLE_GROUP_ISN=st.TGD_TITLE_GROUP_ISN
 full outer join SBR_TRANSACTIONS st on----------------------------------------------------
        a.NET_AGENT_ACCOUNT_NUMBER = st.CUSTOMER_URN 
 inner join  SBR_TRANSACTIONS a on 
        a.NET_ISSUE_EAN = a.ISSUE_EAN and
        a.NET_ISSUE_YEAR = a.ISSUE_YEAR            
 full outer join EPOS_TOTALS_MV et on 
        a.NET_AGENT_ACCOUNT_NUMBER = et.EPOS_URN
 inner join  EPOS_TOTALS_MV e on 
        a.NET_BRANCH_CODE= e.EPOS_BRANCH 
        and a.NET_ISSUE_EAN= e.EPOS_EAN
        and a.NET_ISSUE_YEAR= e.EPOS_YEAR
        and b.bris_branch_code = e.epos_branch
        and e.epos_urn = c.cus_account_number
 full outer join EPOS_ALL_HISTORY_MV eh on 
        a.NET_AGENT_ACCOUNT_NUMBER = eh.EHIS_URN
 full outer join EPOS_URN_XREFS ex on
        a.NET_AGENT_ACCOUNT_NUMBER = ex.URN_URN
   ----------------------------------------------------------------------------------------------
   and  sh.TGH_TITLE_GROUP_NAME  =  'WHS 300 + weeklies'
  AND  trunc(b.BRIS_RECALL_DATE)  BETWEEN   '15-JAN-2016' AND '21-JAN-2016'
  AND  decode(t.TITL_ISSUE_FREQUENCY,'1','Daily','2','Sunday','3','Weekly','4','Fortnightly','5','Monthly','6','Bi-Monthly','7','Quarterly','8','Irregular','9','One-Shot','Unknown')  NOT IN  ('Daily', 'Weekly', 'Sunday')
  AND  nvl(c.CUS_MULTIPLE_CODE,0)  IN  (888, 89, 209, 1, 907, 37, 767, 149, 92, 66, 227, 764, 188, 2, 143, 110, 91, 963, 229, 130, 124, 3, 1007, 721, 869, 640, 52, 29, 826, 723, 872, 947, 32, 163, 33, 187, 51, 34, 711, 779, 215, 450, 451, 158, 7, 8, 5, 85, 6, 10, 193)
  AND  t.TITL_CODE  =  6359 and a.NET_AGENT_ACCOUNT_NUMBER = 502963004319000
  and n.niss_issue_year  in (2015, 2016)
  AND  n.niss_issue_week  in (41,44,52,48,39,50,45,2,42,47,1,40,46,51,53,38,36,43,37,49)
  and e.EPOS_TOTAL_SALES != 0
  and n.niss_type_flag != 'S'
