a.bris_title_code = c.titl_code
and x.PIX_LEGACY_TITLE = c.titl_code
and a.bris_title_code = x.pix_legacy_title

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code

-----------------------
and x.pix_legacy_title in (select unique x.PIX_LEGACY_TITLE from jt_pix_main_legacy_titles x where x.PIX_MAIN_LEGACY_TITLE in 
(select y.PIX_MAIN_LEGACY_TITLE from jt_pix_main_legacy_titles y where y.PIX_LEGACY_TITLE = 90976))
and a.bris_issue_year = 2016
group by x.pix_main_legacy_title ,a.bris_issue_day ,a.bris_issue_week ,a.bris_issue_year 
order by a.bris_issue_year,a.bris_issue_week;

1 1003  0 1 2016  16766 7248  9518
2 1043  0 1 2016  5915  2482  3433
3 1045  0 1 2016  11526 5020  6506
4 1048  0 1 2016  10236 4523  5713

select t.titl_code,t.titl_long_name from titles t where t.titl_code in (select unique x.PIX_LEGACY_TITLE from jt_pix_main_legacy_titles x where x.PIX_MAIN_LEGACY_TITLE in 
(select y.PIX_MAIN_LEGACY_TITLE from jt_pix_main_legacy_titles y where y.PIX_LEGACY_TITLE = 90976))
------------------------------
select t.titl_code,t.titl_long_name from titles t where t.titl_code in (select unique x.PIX_LEGACY_TITLE from plant_issues_xref x where x.PIX_MAIN_LEGACY_TITLE = 1003) 
select distinct PIX_MAIN_LEGACY_TITLE,pix_legacy_title from plant_issues_xref where PIX_LEGACY_TITLE = 21870
select * from plant_issues_xref where PIX_LEGACY_TITLE = 21870 and pix_year = 2016
select * from plant_issues_xref where PIX_main_LEGACY_TITLE = 1003 and pix_year = 2016
select * from plant_issues_xref v, agent_net_sales n 
