
select ag.net_branch_code,c.titl_code title,c.titl_long_name name,a.bris_on_sale_date,b.niss_issue_day "WEEK DAY",b.niss_issue_week WEEK,b.niss_issue_year YEAR,b.niss_ean,sum(ag.NET_COMMITED_QUANTITY) sales,sum(ag.net_credit_quantity) credits,sum(ag.NET_COMMITED_QUANTITY - ag.net_credit_quantity) "TOTAL (SALES - CREDITS)" 
from  agent_net_sales ag, branch_issues a, normal_issues b, titles c where
a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year

and b.niss_title_code = c.titl_code

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code
-----------------------
--and a.bris_on_sale_date = '12-FEB-16'
--and ag.net_agent_account_number =  
and b.niss_title_code = 5250
and b.niss_issue_year in (2015)
and b.niss_ean = 977135497070701
--and a.bris_branch_code in ( 'BRA550')
group by c.titl_code, b.niss_issue_day,b.niss_issue_week,b.niss_issue_year,b.niss_ean,c.titl_long_name,ag.net_branch_code,a.bris_on_sale_date
--------------------------------
select * from branch_issues b where b.bris_title_code = 9032 and b.bris_issue_year in (2016) and b.bris_branch_code = 'BRA220' order by b.bris_issue_year, b.bris_issue_week for update; -- moved br_is away to week 2016/54 and related ans to 2015
select * from branch_issues b where b.bris_ean = 977135497070701 and b.bris_branch_code = 'BRA550' and b.bris_issue_year = 2015 order by b.bris_issue_year, b.bris_issue_week 
select * from normal_issues n where n.niss_title_code = 4988 and n.niss_issue_year in (2016) for update
select * from normal_issues n where n.niss_ean =  977026723915412 and n.niss_issue_year = 2015

select * from customer_x_ref x where x.ccr_bus_partner_id=130736 --124014  --502963007119300
select * from plant_issues_xref p where p.PIX_EAN in  (977135593458603,977135593458604) and PIX_YEAR = 2016

select * from branch_issues b where b.bris_ean = 977135497070702
select * from normal_issues n where n.NISS_EAN in (977135942315401,660042101501001)
select * from agent_net_sales a where a.net_issue_year=2016 and a.net_issue_ean =  977135497070799
select * from agent_net_sales a where a.net_issue_year=2016 and a.net_agent_account_number=502963007119300 and a.net_issue_ean =  977135497070799
