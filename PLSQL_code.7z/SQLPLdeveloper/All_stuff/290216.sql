select *
  from publisher_agent_matrix m
 where m.puba_supply_org_code = 3532 
 and m.puba_agent_account_number in 
 (740157853000600,
502963070552499,
503103126205600,
503103126200101,
503103126203200,
503103126226100,
503103126228500,
503103126239100,
503103126256800,
503103126232200,
503103126208700,
502963069876500
) for update
--740157853000600 
  
select * from customer_x_ref x where x.ccr_bus_partner_id in (128628,136318,136321,136323,136328,136329,136336,136392,136460,
157853,136332,136756)

select * from customer_x_ref x where x.ccr_cust_urn = 740157853000600
select *
  from publisher_agent_matrix m
 where --m.puba_supply_org_code = 3532 and
  m.puba_agent_account_number in 
 (7740157853000600
)
