select distinct (t.bris_title_code) from BRANCH_ISSUES t where t.bris_issue_year = 2016
