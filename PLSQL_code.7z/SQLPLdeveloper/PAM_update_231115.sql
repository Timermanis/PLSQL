select * from PUBLISHER_AGENT_MATRIX t where      t.puba_agent_account_number in --and t.puba_supply_org_code=2413
(select x.ccr_cust_urn from customer_x_ref x 
where x.ccr_bus_partner_id in (136730 
)) 
and  t.puba_date_to > '31/DEC/3000' 
for update

--missing in PAM
10/05/2016

select * from customer_x_ref x where x.ccr_cust_urn = 503103120627200 for update
select * from jt_PUBLISHER_AGENT_MATRIX m where m.puba_agent_account_number = 503103120627200 and m.puba_supply_org_code = 1004 for update
where x.ccr_bus_partner_id in (158534)

BP 130736 and 134742 � pub code 1002

21/04/2016
--create table jt_231115_PAM_backup as
update publisher_agent_matrix  
set puba_date_to = trunc(sysdate - 1) where 
 puba_supply_org_code in (
SELECT    c.*
FROM      ( SELECT    DISTINCT m.puba_supply_org_code
            FROM      customers c
                      JOIN  publisher_agent_matrix m
                      ON    m.puba_agent_account_number = c.cus_account_number
            WHERE     c.cus_multiple_code = 77
            AND       SYSDATE BETWEEN c.cus_from_date AND c.cus_to_date
            AND       SYSDATE BETWEEN m.puba_date_from AND m.puba_date_to)  c
           JOIN  suppliers s
           ON    s.sup_code = c.puba_supply_org_code)        
and puba_date_to >= sysdate
and puba_agent_account_number in (select x.cus_account_number from customers x where x.cus_multiple_code = 77) 
--select * from customer_x_ref x where x.ccr_bus_partner_id = 112544
---------------------------------------------------
select *
  from publisher_agent_matrix m
 where m.puba_supply_org_code in (
SELECT    c.*
FROM      ( SELECT    DISTINCT m.puba_supply_org_code
            FROM      customers c
                      JOIN  publisher_agent_matrix m
                      ON    m.puba_agent_account_number = c.cus_account_number
            WHERE     c.cus_multiple_code = 77
            AND       SYSDATE BETWEEN c.cus_from_date AND c.cus_to_date
            AND       SYSDATE BETWEEN m.puba_date_from AND m.puba_date_to)  c
           JOIN  suppliers s
           ON    s.sup_code = c.puba_supply_org_code)        
--and m.puba_date_to <= sysdate-2
and m.puba_agent_account_number in (select x.cus_account_number from customers x where x.cus_multiple_code = 77) 
--select * from customer_x_ref x where x.ccr_bus_partner_id = 112544
-------------------------
select *
  from publisher_agent_matrix f where f.puba_agent_account_number in (select puba_agent_account_number from jt_231115_PAM_backup)
  and f.puba_date_to >= sysdate-2
--------------------------------  
SELECT    s.*
FROM      ( SELECT    DISTINCT m.puba_supply_org_code
            FROM      customers c
                      JOIN  publisher_agent_matrix m
                      ON    m.puba_agent_account_number = c.cus_account_number
            WHERE     c.cus_multiple_code = 77
            AND       SYSDATE BETWEEN c.cus_from_date AND c.cus_to_date
            --AND       SYSDATE BETWEEN m.puba_date_from AND m.puba_date_to
            )  c
           JOIN  suppliers s
           ON    s.sup_code = c.puba_supply_org_code

  
  
