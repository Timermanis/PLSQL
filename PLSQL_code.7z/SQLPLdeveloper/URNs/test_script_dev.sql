select * from customers c
where c.cus_account_number in 
()
and c.cus_from_date = 
select cu.cus_from_date from customers cu
where c
