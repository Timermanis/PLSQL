select sum(p.invoiced_QTY-p.return_qty) IKW_SALES_TOTAL, sum(p.return_qty) IKW_RETURNS,  sum(p.invoiced_QTY) IKW_sales, m.iss_original_year IKW_year, m.iss_original_week  IKW_week,m.iss_original_day IKW_DAY,m.prod_num IKW_title

from plant_cust_iss_rtrn_summaries p
, dw.retailer r
, dw.media m
, dw.latest_wholesaler_mv w
, refmast.plant_issues_xref_base x
where  p.plant_issue_id = m.dimension_key
and p.outlet_id = r.dimension_key
and r.out_spoke_num = w.spo_num

and x.pix_sap_id = m.plis_issue_num
and x.pix_spoke_code = 'BRA'||LPAD(m.plis_plant_num, 3, '0')
--and m.plis_plant_num = r.out_spoke_num

and x.pix_main_legacy_title in (select distinct pix_main_legacy_title from refmast.plant_issues_xref_base where pix_legacy_title = 2540)
--and x.pix_legacy_title = ".$sq_var."
and m.iss_original_year =2016
and m.plis_handled_year = 2016
and x.pix_year = 2016
group by m.iss_ean, m.iss_original_year, m.iss_original_week, m.prod_num,m.iss_name,m.iss_original_day
order by m.iss_original_year, m.iss_original_week
