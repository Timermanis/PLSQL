select a.BRIS_TITLE_CODE,a.bris_issue_day day,a.bris_issue_week WEEK,sum(b.NET_COMMITED_QUANTITY) MIS_sales,sum(b.net_return_quantity) MIS_returns, sum(b.NET_COMMITED_QUANTITY - b.net_return_quantity) MIS_SALES_total 
from branch_issues a , agent_net_sales b,jt_pix_main_legacy_titles x
where 
b.NET_ISSUE_YEAR = a.BRIS_ISSUE_YEAR and
b.NET_ISSUE_EAN = a.BRIS_EAN and
b.NET_BRANCH_CODE = a.BRIS_BRANCH_CODE and
----
a.bris_title_code = x.pix_legacy_title and
b.net_title_code = x.pix_legacy_title and
-----------------
a.BRIS_ISSUE_YEAR = 2016 and
b.NET_ISSUE_YEAR = 2016 and
b.NET_TITLE_CODE = 90976 and
a.BRIS_TITLE_CODE = 90976
-----------------
group by a.BRIS_TITLE_CODE,a.bris_issue_day ,a.bris_issue_week 
-------------------------------------------------------------------------------------------------------------------------------------------------
select x.pix_spoke_code,x.pix_main_legacy_title,x.pix_legacy_title,a.bris_issue_day day,a.bris_issue_week WEEK,sum(b.NET_COMMITED_QUANTITY) MIS_sales,sum(b.net_return_quantity) MIS_returns, sum(b.NET_COMMITED_QUANTITY - b.net_return_quantity) MIS_SALES_total 
from branch_issues a , agent_net_sales b,jt_pix_main_legacy_titles x
where 
b.NET_ISSUE_YEAR = a.BRIS_ISSUE_YEAR and
b.NET_ISSUE_EAN = a.BRIS_EAN and
b.NET_BRANCH_CODE = a.BRIS_BRANCH_CODE and
----
b.net_branch_code = x.pix_branch_code and
a.bris_branch_code = x.pix_branch_code and
----
a.bris_title_code = x.pix_legacy_title and
b.net_title_code = x.pix_legacy_title and
-----------------
-----------------
a.BRIS_ISSUE_YEAR = 2016 and
a.bris_issue_week = 1 and
b.NET_ISSUE_YEAR = 2016 and
 x.pix_legacy_title in (select unique x.PIX_LEGACY_TITLE from jt_pix_main_legacy_titles x where x.PIX_MAIN_LEGACY_TITLE in 
(select y.PIX_MAIN_LEGACY_TITLE from jt_pix_main_legacy_titles y where y.PIX_LEGACY_TITLE = 4770))
-----------------
group by x.pix_main_legacy_title,a.bris_issue_day ,a.bris_issue_week,x.pix_spoke_code,x.pix_legacy_title 
-----------------------------------------------------------------------
select a.BRIS_TITLE_CODE,a.bris_issue_day day,a.bris_issue_week WEEK,sum(b.NET_COMMITED_QUANTITY) MIS_sales,sum(b.net_return_quantity) MIS_returns, 
sum(b.NET_COMMITED_QUANTITY - b.net_return_quantity) MIS_SALES_total 
from branch_issues a , agent_net_sales b where 
b.NET_ISSUE_YEAR = a.BRIS_ISSUE_YEAR and
b.NET_ISSUE_EAN = a.BRIS_EAN and
b.NET_BRANCH_CODE = a.BRIS_BRANCH_CODE and
-----------------
a.BRIS_ISSUE_YEAR = 2016 and
b.NET_ISSUE_YEAR = 2016 and
b.NET_TITLE_CODE = 4123 and
a.BRIS_TITLE_CODE = 4123 and
a.BRIS_ISSUE_WEEK = 1 
-----------------
group by a.BRIS_TITLE_CODE,a.bris_issue_day ,a.bris_issue_week 
