select a.BRIS_TITLE_CODE,a.bris_issue_day day,a.bris_issue_week WEEK,sum(b.NET_COMMITED_QUANTITY) MIS_sales,sum(b.net_return_quantity) MIS_returns, 
sum(b.NET_COMMITED_QUANTITY - b.net_return_quantity) MIS_SALES_total 
from support.ip_branch_issues_skin a , support.ip_agent_net_sales_skin b where 
b.NET_ISSUE_YEAR = a.BRIS_ISSUE_YEAR and
b.NET_ISSUE_EAN = a.BRIS_EAN and
b.NET_BRANCH_CODE = a.BRIS_BRANCH_CODE and
-----------------
a.BRIS_ISSUE_YEAR = 2016 and
b.NET_ISSUE_YEAR = 2016 and
b.NET_TITLE_CODE = 4770 and
a.BRIS_TITLE_CODE = 4770 and
a.BRIS_ISSUE_WEEK = 1 
-----------------
group by a.BRIS_TITLE_CODE,a.bris_issue_day ,a.bris_issue_week 

select * from refmast.plant_issues_xref_base x where x.PIX_EAN = 843161800421001 for update
