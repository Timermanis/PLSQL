select t.t_type,t.correct_sign ,count (t.iss_type)from JT_SIGN_FIX_IKNOW_140515_DW t
group by t.t_type,t.correct_sign


select sign,sum(number_iss_type) from
(select t.t_type t_type,t.correct_sign sign ,count (t.iss_type) number_iss_type from JT_SIGN_FIX_IKNOW_140515_DW t
group by t.t_type,t.correct_sign)
group by sign

select sign,count(t_type) from
(select t.t_type t_type,t.correct_sign sign ,count (t.iss_type) number_iss_type from jt_sign_fix_210515 t--6,76
group by t.t_type,t.correct_sign)
group by sign

 JT_SIGN_FIX_210515_V2 a,JT_SIGN_FIX_IKNW190515_TEST b
 
 select sign,count(t_type) from
(select t.t_type t_type,t.correct_sign sign ,count (t.iss_type) number_iss_type from JT_SIGN_FIX_IKNW190515_TEST t--6,37
group by t.t_type,t.correct_sign)
group by sign
