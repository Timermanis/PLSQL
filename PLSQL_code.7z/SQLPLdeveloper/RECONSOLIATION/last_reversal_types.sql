create table jt_ret_tra_sign_010615_140_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 140                      --
and 
(
TRANSACTION_QUANTITY>0
or RETAIL_VALUE_EXCL_VAT>0
or RETAIL_VALUE_VAT>0
or TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
or TRADE_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  


'Z3'


) );
select count(*) from jt_ret_tra_sign_010615_140_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) *(-1),
RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)*(-1)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT) *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) ,
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_010615_140_neg)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_tra_sign_010615_492_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 492                      --
and 
(
TRANSACTION_QUANTITY>0
or RETAIL_VALUE_EXCL_VAT>0
or RETAIL_VALUE_VAT>0
or TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
or TRADE_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  


'Z3'


) );
select count(*) from jt_ret_tra_sign_010615_492_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) *(-1),
RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)*(-1)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT) *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) ,
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_010615_492_neg)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_tra_sign_010615_181_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 181                      --
and 
(
TRANSACTION_QUANTITY>0
or RETAIL_VALUE_EXCL_VAT>0
or RETAIL_VALUE_VAT>0
or TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
or TRADE_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  


'Z3'


) );
select count(*) from jt_ret_tra_sign_010615_181_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) *(-1),
RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)*(-1)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT) *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) ,
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_010615_181_neg)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_tra_sign_010615_508_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 508                      --
and 
(
TRANSACTION_QUANTITY>0
or RETAIL_VALUE_EXCL_VAT>0
or RETAIL_VALUE_VAT>0
or TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
or TRADE_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  


'Z3'


) );
select count(*) from jt_ret_tra_sign_010615_508_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) *(-1),
RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)*(-1)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT) *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) ,
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_010615_508_neg)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_tra_sign_010615_119_pos as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 119                      --
and 
(
TRANSACTION_QUANTITY<0
--or RETAIL_VALUE_EXCL_VAT<0
or RETAIL_VALUE_VAT<0
or TRADE_VALUE_EXCL_VAT <0
or COST_VALUE_EXCL_VAT <0
or COST_VALUE_VAT <0
or TRADE_VALUE_VAT <0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  


'Z3'


) );
select count(*) from jt_ret_tra_sign_010615_119_pos

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT),--*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT),--*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT),-- *(-1) 
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_010615_119_pos)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_tra_sign_010615_136_pos as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 136                      --
and 
(
TRANSACTION_QUANTITY<0
--or RETAIL_VALUE_EXCL_VAT<0
or RETAIL_VALUE_VAT<0
or TRADE_VALUE_EXCL_VAT <0
or COST_VALUE_EXCL_VAT <0
or COST_VALUE_VAT <0
or TRADE_VALUE_VAT <0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  


'Z3'


) );
select count(*) from jt_ret_tra_sign_010615_136_pos

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT),--*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT),--*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT),-- *(-1) 
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_010615_136_pos)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

create table jt_ret_tra_sign_010615_178_pos as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 152                      --
and 
(
TRANSACTION_QUANTITY<0
or RETAIL_VALUE_EXCL_VAT<0
or RETAIL_VALUE_VAT<0
or TRADE_VALUE_EXCL_VAT <0
or COST_VALUE_EXCL_VAT <0
or COST_VALUE_VAT <0
or TRADE_VALUE_VAT <0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  


'Z4'


) );
select count(*) from jt_ret_tra_sign_010615_178_pos

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT),--*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT),--*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT),-- *(-1) 
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_010615_178_pos)    --
