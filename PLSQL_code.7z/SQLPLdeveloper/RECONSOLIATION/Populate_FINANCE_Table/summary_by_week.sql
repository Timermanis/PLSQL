select fwk_num,count(*) from FINANCIAL_WEEK_SUMMARY t group by fwk_num order by fwk_num
