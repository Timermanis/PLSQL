select trunc(s.transaction_date) trans_date, count(*) num_rows,to_char(to_date(trunc(s.transaction_date),'dd/mm/yyyy'), 'D')
from datain.hist_zpx_strn_stg s
group by trunc(s.transaction_date) order by TRANS_DATE

select * from calendar c where c.fwk_num=201501
