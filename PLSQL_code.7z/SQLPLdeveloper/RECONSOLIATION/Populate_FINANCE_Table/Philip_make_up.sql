SELECT 
--w.spo_num, 
   c.fpd_name month,
   s.fwk_num  week, 
   w.bra_num branch_num,
   w.bra_name branch_name, 
   m.iss_segment_name,
   pub.ven_name publisher,
   dist.ven_name distributor,
   m.iss_frequency_descr frequency,
   nvl(m.prod_family_name,m.prod_name) title,
   decode( s.sas_id, 10001, 'Monthlies', 10002,'Weeklies',10003, 'Partworks',10004,'Weeklies',10005, 'Dailies M-F',10006,  'Dailies Sat',10007, 'Sundays', 10008, 'Stickers' , s.sas_id) sas_grp,
-- qty's
  sum(invoiced_qty) inv_qty,
  sum(credit_qty) credit_qty,
  sum(invoiced_qty - credit_qty) net_qty,
  -- Changed to ensure for cost picks up cost currency and for rsv for plant 30 which can be a mix of Euro and sterling retailer_transactions pick up
  -- appropriate currency
-- RSV
   round(sum(nvl(s.retail_inv_value,0) *  case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ),2) retail_invoiced,
   round(sum(nvl(s.retail_credit_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ),2) retail_credits,
     round(sum(nvl(s.retail_inv_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ) - sum(nvl(s.retail_credit_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ),2) net_retail,  
-- Retail VAT
   round(sum(nvl(s.retail_inv_vat_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ),2) retail_invoiced_vat,
   round(sum(nvl(s.retail_credit_vat_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ),2) retail_credits_vat,
     round(sum(nvl(s.retail_inv_vat_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ) - sum(nvl(s.retail_credit_vat_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ),2) net_retail_vat,  
-- Trade
   round(sum(nvl(s.trade_inv_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ),2) trade_invoiced,
   round(sum(nvl(s.trade_credit_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ),2) trade_credits,
     round(sum(nvl(s.trade_inv_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ) - sum(nvl(s.trade_credit_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ),2) net_trade,  
-- Trade VAT
   round(sum(nvl(s.trade_inv_vat_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ),2) trade_invoiced_vat,
   round(sum(nvl(s.trade_credit_vat_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ),2) trade_credits_vat,
     round(sum(nvl(s.trade_inv_vat_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ) - sum(nvl(s.trade_credit_vat_value,0) * case when w.bra_num = 390 then 1 ELSE cct.ccnv_conversion_rate END ),2) net_trade_vat,  
-- Cost
     round(sum(nvl(s.cost_inv_value,0) * case when w.bra_num = 390 then 1 ELSE ccc.ccnv_conversion_rate END),2) cost_invoiced,  -- AMT 01 = 1 when GBP to GBP else actual conv rate
     round(sum(nvl(s.cost_credit_value,0) * case when w.bra_num = 390 then 1 ELSE ccc.ccnv_conversion_rate END),2) cost_credits, -- AMT 01
   round(sum(nvl(s.cost_inv_value,0) * case when w.bra_num = 390 then 1 ELSE ccc.ccnv_conversion_rate END ) 
   - sum(nvl(s.cost_credit_value,0) * case when w.bra_num = 390 then 1 ELSE ccc.ccnv_conversion_rate END),2) net_cost  
FROM
dw.financial_week_summary s,
media m,
refmast.discount_types tt,
refmast.discount_types ct,
dw.wholesaler w,
dw.currency_convertor cct , -- TRADE CURRENCY CONVERSION
dw.currency_convertor ccc ,  -- COST CURRENCY CONVERSION
dw.currency trade_cu,
dw.latest_publisher_mv pub,
dw.latest_distributor_mv dist,
dw.calendar c
, dw.currency cost_cu
where c.fwk_end_date between w.spo_eff_date and w.spo_exp_date
and c.fwk_id = s.fwk_id
and c.dimension_key = c.fwk_id
and s.plis_id = m.plis_id(+)
and s.plant_num = m.plis_plant_num(+)
and  s.plant_num = w.spo_num
and  m.plis_trade_discount_type_descr = tt.disct_name(+)
and   m.plis_cost_discount_type_descr = ct.disct_name(+)
and s.sas_id between 10001 and 10008
and trade_cu.dimension_key = s.currency_id
and cct.ccnv_currency_converting_from = trade_cu.cur_code
and cct.ccnv_company_num =  w.com_num
and  cct.ccnv_currency_converting_to = 'GBP'
and cct.ccnv_rate_type = 'TRADE'
and  c.fwk_start_date between cct.ccnv_eff_date and cct.ccnv_exp_date
and  ccc.ccnv_currency_converting_from = COST_cu.cur_code
and ccc.ccnv_company_num = w.com_num
and  ccc.ccnv_currency_converting_to = 'GBP'
and ccc.ccnv_rate_type = 'COST' 
and  c.fwk_start_date  between ccc.ccnv_eff_date and ccc.ccnv_exp_date
and pub.ven_num = plis_publisher_num
and dist.ven_num = plis_distributor_num
and s.fwk_num between 201501 and 201501


and s.cost_currency_id = cost_cu.dimension_key  -- AMT 01
AND W.SPO_NUM  in (20,30,390)
--AND SAS_ID = 10001
GROUP BY 
w.spo_num,
   s.fwk_num, 
   c.fpd_name,
   w.bra_num,
   w.bra_name, 
   m.iss_segment_name,
   pub.ven_name,
   dist.ven_name,
   nvl(m.prod_family_name,m.prod_name),
   m.iss_frequency_descr,
    decode( s.sas_id, 10001, 'Monthlies', 10002,'Weeklies',10003, 'Partworks',10004,'Weeklies',10005, 'Dailies M-F',10006,  'Dailies Sat',10007, 'Sundays', 10008, 'Stickers' , s.sas_id)
