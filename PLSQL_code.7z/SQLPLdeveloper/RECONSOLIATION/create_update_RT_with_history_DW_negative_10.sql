create table jt_ret_tra_sign_210515_126_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 126                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'Z4'

) );
select count(*) from jt_ret_tra_sign_210515_126_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_126_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_101_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 101                        --
and 
(
--or TRADE_VALUE_VAT < 0                             --
--or RETAIL_VALUE_VAT <0
TRADE_VALUE_EXCL_VAT >0
--or TRANSACTION_QUANTITY <0
--or RETAIL_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'TU',
'TH',
'WZ',
'Z2',
'WE',
'MO',
'Z1',
'FR',
'SU',
'Z9',
'Z8',
'MZ',
'SA'
) );
select count(*) from jt_ret_tra_sign_210515_101_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) ,
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_101_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------HIGH NUMBER RECORDS DUE TO WRONG UPDATE Z3 152-------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_152_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 152                        --
and 
(
--or TRADE_VALUE_VAT < 0                             --
--or RETAIL_VALUE_VAT <0
TRADE_VALUE_EXCL_VAT >0
--or TRANSACTION_QUANTITY <0
--or RETAIL_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
--or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'Z3'

) );
select count(*) from jt_ret_tra_sign_210515_152_neg

----------------------------------------------------------------------RUNNING NOW 21/05/15/ 17:25--------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_152_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------HIGH NUMBER RECORDS DUE TO WRONG UPDATE Z3 128---------------------------------------------------------------------
create table jt_ret_tra_sign_210515_128_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 128                        --
and 
(
--or TRADE_VALUE_VAT < 0                             --
--or RETAIL_VALUE_VAT <0
TRADE_VALUE_EXCL_VAT >0
--or TRANSACTION_QUANTITY <0
--or RETAIL_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'Z3'

) );
select count(*) from jt_ret_tra_sign_210515_128_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_128_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_125_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 125                        --
and 
(
--or TRADE_VALUE_VAT < 0                             --
--or RETAIL_VALUE_VAT <0
TRADE_VALUE_EXCL_VAT >0
--or TRANSACTION_QUANTITY <0
--or RETAIL_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'SA',
'Z1',
'SU',
'FR',
'MZ',
'TH',
'WZ',
'WE',
'MO',
'TU',
'Z8',
'Z2'


) );
select count(*) from jt_ret_tra_sign_210515_125_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1)
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_125_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_119_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 119                        --
and 
(
--or TRADE_VALUE_VAT < 0                             --
--or RETAIL_VALUE_VAT <0
TRADE_VALUE_EXCL_VAT >0
--or TRANSACTION_QUANTITY <0
--or RETAIL_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
--or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'MZ',
'SU',
'FR',
'TU',
'Z2',
'Z1',
'SA',
'WZ',
'WE',
'TH',
'Z5',
'MO'

) );
select count(*) from jt_ret_tra_sign_210515_119_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_119_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_115_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 115                        --
and 
(
--or TRADE_VALUE_VAT < 0                             --
--or RETAIL_VALUE_VAT <0
TRADE_VALUE_EXCL_VAT >0
--or TRANSACTION_QUANTITY <0
--or RETAIL_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
--or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'SU',
'WZ',
'SA',
'MZ',
'TH',
'WE',
'TU',
'Z1',
'MO',
'FR'

) );
select count(*) from jt_ret_tra_sign_210515_115_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_115_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_103_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 103                        --
and 
(
--or TRADE_VALUE_VAT < 0                             --
--or RETAIL_VALUE_VAT <0
TRADE_VALUE_EXCL_VAT >0
--or TRANSACTION_QUANTITY <0
--or RETAIL_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
--or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'Z4',
'MZ'

) );
select count(*) from jt_ret_tra_sign_210515_103_neg
----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_103_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_101_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 101                        --
and 
(
--or TRADE_VALUE_VAT < 0                             --
--or RETAIL_VALUE_VAT <0
TRADE_VALUE_EXCL_VAT >0
--or TRANSACTION_QUANTITY <0
--or RETAIL_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'TU',
'TH',
'WZ',
'Z2',
'WE',
'MO',
'Z1',
'FR',
'SU',
'Z9',
'Z8',
'MZ',
'SA'
) );

select count(*) from jt_ret_tra_sign_210515_101_neg
----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_101_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
