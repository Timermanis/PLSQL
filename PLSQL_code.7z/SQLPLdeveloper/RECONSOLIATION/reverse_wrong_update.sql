update retailer_transaction t set 
COST_VALUE_EXCL_VAT = COST_VALUE_EXCL_VAT*(-1) ,
TRADE_VALUE_EXCL_VAT = TRADE_VALUE_EXCL_VAT*(-1) 

where dwh_num in(
select dwh_num from jt_ret_trans_signs_190515_5403 
where reporting_trn_type_id  != 5403  )
