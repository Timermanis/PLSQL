create table jt_ret_trans_signs_190515_5403 as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 5403                        --
--and (TRADE_VALUE_VAT < 0                             --
--or RETAIL_VALUE_VAT <0
or TRADE_VALUE_EXCL_VAT <0
--or TRANSACTION_QUANTITY <0
--or RETAIL_VALUE_EXCL_VAT <0
or COST_VALUE_EXCL_VAT <0
--and COST_VALUE_VAT <0
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'FR',
'Z2',
'TU',
'MO',
'Z4',
'WE',
'TH',
'SU',
'MZ',
'SA',
'WZ'

) )

--------------------------------------------------------------------------------------------
update dw.retailer_transaction rt set                  --
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT),--*(-1)  ,
--COST_VALUE_VAT = abs(COST_VALUE_VAT)--*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT),-- *(-1) ,
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_trans_signs_190515_5403)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_trans_signs_190515_5203 as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 5203                        --
--and (TRADE_VALUE_VAT < 0                             --
--or RETAIL_VALUE_VAT <0
--or TRADE_VALUE_EXCL_VAT <0
--or TRANSACTION_QUANTITY <0
--or RETAIL_VALUE_EXCL_VAT <0
--or COST_VALUE_EXCL_VAT <0
and COST_VALUE_VAT <0
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'MZ',
'MO',
'WE',
'SA',
'FR',
'SU',
'TH'
) )

--------------------------------------------------------------------------------------------
update dw.retailer_transaction rt set                  --
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
--COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT),--*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)--*(-1)  ,
--TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT),-- *(-1) ,
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_trans_signs_190515_5203)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_trans_signs_190515_436 as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 436                        --
and (TRADE_VALUE_VAT < 0                             --
or RETAIL_VALUE_VAT <0
or TRADE_VALUE_EXCL_VAT <0
or TRANSACTION_QUANTITY <0
or RETAIL_VALUE_EXCL_VAT <0
or COST_VALUE_EXCL_VAT <0
or COST_VALUE_VAT <0)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'Z4'

) )

--------------------------------------------------------------------------------------------
update dw.retailer_transaction rt set                  --
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT),--*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT),--*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT),-- *(-1) ,
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_trans_signs_190515_436)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_trans_signs_190515_152 as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 152                        --
and (TRADE_VALUE_VAT > 0                             --
or RETAIL_VALUE_VAT >0
or TRADE_VALUE_EXCL_VAT >0
or TRANSACTION_QUANTITY >0
or RETAIL_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'Z4'

) )

--------------------------------------------------------------------------------------------
update dw.retailer_transaction rt set                  --
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) *(-1),
RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)*(-1)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT) *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) ,
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  *(-1)
where dwh_num in(
select dwh_num from jt_ret_trans_signs_190515_152)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_trans_signs_180515_146 as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 146                        --
and rt.COST_VALUE_VAT < 0                             --
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
('Z4',                                                    --  
'FR',
'MZ'
) )

--------------------------------------------------------------------------------------------
update dw.retailer_transaction rt set                  --
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) 
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT)  ,
--COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)  
COST_VALUE_VAT = abs(COST_VALUE_VAT)--*(-1)  
--TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT)  ,
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  
where dwh_num in(
select dwh_num from jt_ret_trans_signs_180515_146)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_trans_signs_180515_144_ as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 144                        --
and (TRANSACTION_QUANTITY < 0 or 
RETAIL_VALUE_EXCL_VAT < 0 or 
RETAIL_VALUE_VAT < 0 or 
COST_VALUE_EXCL_VAT < 0 or 
TRADE_VALUE_EXCL_VAT < 0 or   
TRADE_VALUE_VAT < 0)                            --
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'MZ'
) )

--------------------------------------------------------------------------------------------
update dw.retailer_transaction rt set                  --
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) ,
RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT)  ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT),--*(-1)  
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT)  ,
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  
where dwh_num in(
select dwh_num from jt_ret_trans_signs_180515_144_)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_trans_signs_180515_136 as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 136                        --
and (TRADE_VALUE_VAT > 0                             --
or RETAIL_VALUE_VAT >0
or TRADE_VALUE_EXCL_VAT >0
or TRANSACTION_QUANTITY >0)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'Z3'

) )

--------------------------------------------------------------------------------------------
update dw.retailer_transaction rt set                  --
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT) *(-1) ,
--COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)  
--COST_VALUE_VAT = abs(COST_VALUE_VAT)--*(-1)  
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) ,
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  *(-1)
where dwh_num in(
select dwh_num from jt_ret_trans_signs_180515_136)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_trans_signs_180515_119 as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 119                        --
and (rt.TRADE_VALUE_VAT > 0                             --
or rt.retail_value_vat >0
or TRADE_VALUE_EXCL_VAT >0
or TRANSACTION_QUANTITY >0)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'Z3'

) )

--------------------------------------------------------------------------------------------
update dw.retailer_transaction rt set                  --
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT) *(-1) ,
--COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)  
--COST_VALUE_VAT = abs(COST_VALUE_VAT)--*(-1)  
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) ,
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  *(-1)
where dwh_num in(
select dwh_num from jt_ret_trans_signs_180515_119)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_trans_signs_180515_107 as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 107                        --
and rt.COST_VALUE_VAT < 0                             --
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'TH',
'MZ',
'MO',
'SU',
'FR',
'TU',
'SA',
'WZ'

) )

--------------------------------------------------------------------------------------------
update dw.retailer_transaction rt set                  --
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) 
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT)  ,
--COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)  
COST_VALUE_VAT = abs(COST_VALUE_VAT)--*(-1)  
--TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT)  ,
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  
where dwh_num in(
select dwh_num from jt_ret_trans_signs_180515_107)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_trans_signs_180515_102 as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 102                        --
and rt.COST_VALUE_VAT < 0                             --
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  
'MO',
'MZ'
) )

--------------------------------------------------------------------------------------------
update dw.retailer_transaction rt set                  --
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) 
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT)  ,
--COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)  
COST_VALUE_VAT = abs(COST_VALUE_VAT)--*(-1)  
--TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT)  ,
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  
where dwh_num in(
select dwh_num from jt_ret_trans_signs_180515_102)    --
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
-->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
create table jt_ret_trans_signs_180515_16 as select *
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 16
and rt.transaction_quantity < 0
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
('Z2',
'MO',
'WE',
'SA',
'TH',
'Z1',
'MZ',
'Z7',
'SU',
'WZ',
'TU',
'FR',
'##'


) )

--------------------------------------------------------------------------------------------
update dw.retailer_transaction rt set 
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) 
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT)  ,
--COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)  
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  
--TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT)  ,
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  
where dwh_num in(
select dwh_num from jt_ret_trans_signs_180515_16)
-----------------------------------------------------------------------------------------
create table jt_ret_trans_signs_180515_03 as select *
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 3
and rt.COST_VALUE_EXCL_VAT < 0
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
('SA',
'SU',
'TH',
'##',
'Z4',
'Z2',
'Z1',
'MO',
'Z8',
'FR',
'TU',
'WZ',
'MZ',
'WE'

) )

--------------------------------------------------------------------------------------------
update retailer_transaction rt set 
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) ,
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT)  ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)  
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  
--TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT)  ,
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  
where dwh_num in(
select dwh_num from jt_ret_trans_signs_180515_03)
