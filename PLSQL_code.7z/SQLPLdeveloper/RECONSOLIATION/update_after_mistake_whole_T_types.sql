
------------------------------------------------------------------------------------------------------------------------------


create table jt_ret_tra_sign_210515_178_8t as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  in (392,
391,
390,
388,
374,
149,
128,
126
)                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0

);

select count(*) from jt_ret_tra_sign_210515_178_8t--829

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_178_8t)    --
------------------------------------------------------------------------------------------------------------------------------

create table jt_ret_tra_sign_210515_178_7t as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  in (450,
448,
429,
426,
407,
405,
393
)                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0

);

select count(*) from jt_ret_tra_sign_210515_178_7t--829

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_178_7t)    --
------------------------------------------------------------------------------------------------------------------------------


create table jt_ret_tra_sign_210515_178_6t as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  in (490,
473,
472,
469,
465,
463,
462
)                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0

);

select count(*) from jt_ret_tra_sign_210515_178_6t

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  

COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,

TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 

where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_178_6t)    --
------------------------------------------------------------------------------------------------------------------------------


create table jt_ret_tra_sign_210515_178_5t as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  in (512,
510,
509,
506,
491

)                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0

);

select count(*) from jt_ret_tra_sign_210515_178_5t--829

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_178_5t)    --
------------------------------------------------------------------------------------------------------------------------------


create table jt_ret_tra_sign_210515_178_4t as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  in (9717,
5398,
5327,
515,
513
)                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0

);

select count(*) from jt_ret_tra_sign_210515_178_4t--829

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_178_4t)    --
------------------------------------------------------------------------------------------------------------------------------


create table jt_ret_tra_sign_210515_178_3t as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  in (12543,12542,9763)                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0

);

select count(*) from jt_ret_tra_sign_210515_178_3t--829

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_178_3t)    --
------------------------------------------------------------------------------------------------------------------------------

