create table jt_sign_fix_iknw180515_test as
select a.t_type, 
iss_type,
a.correct_sign,
a.pos_qty,
a.pos_retail_val,
a.pos_trade_val,
a.pos_cost_val,
a.pos_retail_VAT,
a.pos_trade_VAT,
a.pos_cost_VAT,
a.neg_qty,
a.neg_retail_val,
a.neg_trade_val,
a.neg_cost_val,
a.neg_retail_VAT,
a.neg_trade_VAT,
a.neg_cost_VAT

from (select rt.reporting_trn_type_id t_type,
m.iss_type_code iss_type, 
max(decode(decode( (select count(*) from dw.sign_reversals sr where  rept.dimension_key = sr.sr_type_id and m.iss_type_code = sr.sr_iss_type),0, nvl(rept.typ_reversal_flag,0),  decode(nvl(rept.typ_reversal_flag,0),0,1,0)),1,'NEG','POS')) correct_sign,
sum(decode(sign(rt.transaction_quantity),1,1,0)) pos_qty,
sum(decode(sign(retail_value_excl_vat),1,1,0)) pos_retail_val,
sum(decode(sign(trade_value_excl_vat),1,1,0)) pos_trade_val,
sum(decode(sign(cost_value_excl_vat),1,1,0)) pos_cost_val,

sum(decode(sign(retail_value_vat),1,1,0)) pos_retail_VAT,
sum(decode(sign(trade_value_vat),1,1,0)) pos_trade_VAT,
sum(decode(sign(cost_value_vat),1,1,0)) pos_cost_VAT,

sum(decode(sign(rt.transaction_quantity),-1,1,0)) neg_qty,
sum(decode(sign(retail_value_excl_vat),-1,1,0)) neg_retail_val,
sum(decode(sign(trade_value_excl_vat),-1,1,0)) neg_trade_val,
sum(decode(sign(cost_value_excl_vat),-1,1,0)) neg_cost_val,

sum(decode(sign(retail_value_vat),-1,1,0)) neg_retail_VAT,
sum(decode(sign(trade_value_vat),-1,1,0)) neg_trade_VAT,
sum(decode(sign(cost_value_vat),-1,1,0)) neg_cost_VAT
FROM 
dw.retailer_transaction rt,
dw.retailer_trn_report_type rept,
dw.media m
WHERE rept.dimension_key=rt.reporting_trn_type_id
and rt.PLANT_ISSUE_ID = m.DIMENSION_KEY 
and rt.PARTITIONING_DATE = m.ISS_PARTITIONING_DATE

GROUP BY
rt.reporting_trn_type_id, m.iss_type_code) a
where ((a.correct_sign = 'NEG' 
          and ((a.pos_qty > 0)
     OR (a.pos_retail_val > 0)
     OR (a.pos_trade_val > 0)
     OR (a.pos_cost_val > 0)
     OR (a.pos_retail_VAT > 0)
     OR (a.pos_trade_VAT > 0)
     OR (a.pos_cost_VAT > 0))) 
OR (a.correct_sign = 'POS' 
   and ((a.neg_qty > 0)
OR (a.neg_retail_val > 0)
OR (a.neg_trade_val > 0)
OR (a.neg_cost_val > 0)
OR (a.neg_retail_VAT > 0)
OR (a.neg_trade_VAT > 0)
OR (a.neg_cost_VAT > 0))))
