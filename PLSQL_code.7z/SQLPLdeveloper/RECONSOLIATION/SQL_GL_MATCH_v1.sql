--The following sql is ran to get the complete set of data for a week (As highlighted near the end of the script).

-- full reconcile sql with currency conversion
SELECT
   ikw.fwk_num fwk_num,
   ikw.bra_num bra_num,
   ikw.bra_name bra_name,
  ikw.sas_grp sas_grp,
   ikw.net_trade,
   ikw.net_cost,
    fin.adj_net_trade,
    fin.adj_net_cost,
   fin.adj_net_trade - ikw.net_trade trade_diff,
   fin.adj_net_cost - ikw.net_cost cost_diff
   --
  ,
  ikw.trade_invoiced,
  ikw.trade_credits,
  ikw.cost_invoiced,
  ikw.cost_credits,
     ikw.calc_net_trade,
   ikw.calc_net_cost,
     fin.trade_invoiced,
  fin.trade_credits,
   fin.journal_sales_value,
   fin.journal_cost_value,
   fin.net_trade,
   fin.cost_value
FROM
--ikw part
(SELECT 
   s.FWK_NUM fwk_num, 
   w.bra_num bra_num,
   w.bra_name bra_name, 
   decode( s.SAS_ID, 10001, 'Monthlies', 10002,'Weeklies',10003, 'Partworks',10004,'Weeklies',10005, 'Dailies M-F',10006,  'Dailies Sat',10007, 'Sundays', 10008, 'Stickers' , s.SAS_ID) sas_grp,
   round(sum(nvl(s.TRADE_INV_VALUE,0) * case when w.bra_num = 390 then 1 else cct.ccnv_conversion_rate end),2) trade_invoiced,
   round(sum(nvl(s.TRADE_CREDIT_VALUE,0) * case when w.bra_num = 390 then 1 else cct.ccnv_conversion_rate end),2) trade_credits,
     round(sum(nvl(s.TRADE_INV_VALUE,0) * case when w.bra_num = 390 then 1 else cct.ccnv_conversion_rate end) - sum(nvl(s.TRADE_CREDIT_VALUE,0) * case when w.bra_num = 390 then 1 else cct.ccnv_conversion_rate end),2) net_trade,  
     round(sum(nvl(s.COST_INV_VALUE,0) * case when w.bra_num = 390 then 1 else cct.ccnv_conversion_rate end),2) cost_invoiced,
    
    round(sum(nvl(s.COST_CREDIT_VALUE,0) * case when w.bra_num = 390 then 1 else ccc.ccnv_conversion_rate end),2) cost_credits,
   round(sum(nvl(s.COST_INV_VALUE,0) * case when w.bra_num = 390 then 1 else ccc.ccnv_conversion_rate end) - 
   sum(nvl(s.COST_CREDIT_VALUE,0) * case when w.bra_num = 390 then 1 else ccc.ccnv_conversion_rate end),2) net_cost,
   --
round(sum(case when nvl(tt.reporting_type_percent_flag,0) = 1 then
 (M.PLIS_RETAIL_PRICE *  (abs(nvl(s.INVOICED_QTY,0) - nvl(s.CREDIT_QTY,0)))) * (1 - (m.plis_trade_discount/100))
  when nvl(tt.reporting_type_ppc_flag,0) = 1 then
 (M.PLIS_RETAIL_PRICE - m.plis_trade_discount) *  (abs(nvl(s.INVOICED_QTY,0) - nvl(s.CREDIT_QTY,0)))
  end),2) calc_net_trade,
  round(sum(case when nvl(ct.reporting_type_percent_flag,0) = 1 then
 (M.PLIS_RETAIL_PRICE *  (abs(nvl(s.INVOICED_QTY,0) - nvl(s.CREDIT_QTY,0)))) * (1 - (m.plis_cost_discount/100))
  when nvl(ct.reporting_type_ppc_flag,0) = 1 then
 (M.PLIS_RETAIL_PRICE - m.plis_cost_discount) *  (abs(nvl(s.INVOICED_QTY,0) - nvl(s.CREDIT_QTY,0)))
  end),2) calc_net_cost
  --
  FROM DW.FINANCIAL_WEEK_SUMMARY s,media m,
refmast.discount_types tt,
refmast.discount_types ct,
dw.wholesaler w,
dw.CURRENCY_CONVERTOR cct ,
dw.CURRENCY_CONVERTOR ccc ,  
dw.currency cu,
dw.currency cost_cu,
calendar c
where c.fwk_end_date between w.spo_eff_date and w.spo_exp_date
and c.fwk_id = s.fwk_id
and c.dimension_key = c.fwk_id
and s.plis_id = m.plis_id(+)
and s.plant_num = m.plis_plant_num(+)
and  s.plant_num = w.spo_num
and  m.plis_trade_discount_type_descr = tt.disct_name(+)
and   m.plis_cost_discount_type_descr = ct.disct_name(+)
and s.sas_id between 10001 and 10008
and cu.DIMENSION_KEY = s.currency_id
and cu.DIMENSION_KEY = s.cost_currency_id--.currency_id
and cct.ccnv_currency_converting_from = cu.cur_code
and cct.ccnv_company_num =  w.com_num
and  cct.ccnv_currency_converting_to = 'GBP'
and cct.ccnv_rate_type = 'TRADE'
and  c.fwk_start_date between cct.ccnv_eff_date and cct.ccnv_exp_date
and  ccc.ccnv_currency_converting_from = COST_cu.cur_code
and ccc.ccnv_company_num = w.com_num
and  ccc.ccnv_currency_converting_to = 'GBP'
and ccc.ccnv_rate_type = 'COST' 
and  c.fwk_start_date  between ccc.ccnv_eff_date and ccc.ccnv_exp_date
group by  s.FWK_NUM, 
   w.bra_num,
   w.bra_name, 
    decode( s.SAS_ID, 10001, 'Monthlies', 10002,'Weeklies',10003, 'Partworks',10004,'Weeklies',10005, 'Dailies M-F',10006,  'Dailies Sat',10007, 'Sundays', 10008, 'Stickers' , s.SAS_ID) ) ikw,
-- gl part
(select gl.fwk_num fwk_num,
gl.bra_num bra_num,
gl.bra_name bra_name,
gl.sas_grp sas_grp,
nvl(gl.sales,0) trade_invoiced,
nvl(gl.returns,0) trade_credits,
nvl(journ.sales_j,0) journal_sales_value,
nvl(journ.COS_j,0) journal_cost_value,
nvl(gl.sales,0) - nvl(gl.returns,0) net_trade,
(nvl(gl.sales,0) - nvl(gl.returns,0)) + nvl(journ.sales_j,0) adj_net_trade,
gl.cos cost_value,
gl.cos - nvl(journ.COS_j,0)  adj_net_cost
from
(select f.fwk_num fwk_num,  
 w.bra_num bra_num,  
 w.bra_name bra_name,
decode( g.gg_sas_id, 10001, 'Monthlies', 10002,'Weeklies',10003, 'Partworks',10004,'Weeklies',10005, 'Dailies M-F',10006,  'Dailies Sat',10007, 'Sundays', 10008, 'Stickers' , g.gg_sas_id) sas_grp ,
sum(decode(g.gg_type, 'Sales',f.value * -1,0)) sales,
sum(decode(g.gg_type, 'Returns',f.value,0)) Returns,
sum(decode(g.gg_type, 'COS',f.value,0)) COS
from dw.finance_gl f,
dw.wholesaler w,
calendar c,
gl_group g
where c.fwk_end_date between w.spo_eff_date and w.spo_exp_date
and c.fwk_id = f.finwk_id
and c.dimension_key = c.fwk_id
and w.spo_num = f.plant_num
and f.gl_id = g.gg_id
and g.gg_sas_id between 10001 and 10008
group by
f.fwk_num,   
 w.bra_num,  
  w.bra_name,
decode( g.gg_sas_id, 10001, 'Monthlies', 10002,'Weeklies',10003, 'Partworks',10004,'Weeklies',10005, 'Dailies M-F',10006,  'Dailies Sat',10007, 'Sundays', 10008, 'Stickers' , g.gg_sas_id)) gl,
(select 
c.fwk_num, 
w.bra_num bra_num,
w.bra_name bra_name, 
decode( g.gg_sas_id, 10001, 'Monthlies', 10002,'Weeklies',10003, 'Partworks',10004,'Weeklies',10005, 'Dailies M-F',10006,  'Dailies Sat',10007, 'Sundays', 10008, 'Stickers' , g.gg_sas_id) sas_grp,
sum(decode(g.gg_type,'Sales', fin_value,0)) sales_j,
sum(decode(g.gg_type,'COS', fin_value,0)) COS_j
from journal_transaction j, 
calendar c,
dw.wholesaler w,
gl_group g
where  j.gl_id = g.gg_id
and g.gg_sas_id between 10001 and 10008
and j.posting_date_day_id = c.day_id
and j.plant_id = w.dimension_key
group by
c.fwk_num,   
w.bra_num,
w.bra_name,
decode( g.gg_sas_id, 10001, 'Monthlies', 10002,'Weeklies',10003, 'Partworks',10004,'Weeklies',10005, 'Dailies M-F',10006,  'Dailies Sat',10007, 'Sundays', 10008, 'Stickers' , g.gg_sas_id)) journ
where gl.fwk_num = journ.fwk_num(+)
and gl.bra_num = journ.bra_num(+)
and gl.bra_name = journ.bra_name(+)
and gl.sas_grp = journ.sas_grp(+)) fin
WHERE  fin.fwk_num = ikw.fwk_num
and fin.bra_num = ikw.bra_num
and fin.bra_name = ikw.bra_name
and fin.sas_grp = ikw.sas_grp
and fin.fwk_num = 201501
order by 
   ikw.fwk_num,
  decode(ikw.bra_num,20,9020,390,9390,ikw.bra_num),
   ikw.bra_name,
   decode( ikw.sas_grp, 'Dailies M-F',1, 'Dailies Sat',2,'Sundays',3,'Weeklies',4,'Monthlies',5,'Partworks',6,'Stickers',7)

/*
The results from this are placed in a spreadsheet under the tab for the week.
The differences from this are then automatically shown on the summary tabs.

The one for 2014 will need to be copied as 2014 and the tabs / headings changed to 2014
The week tabs can be cleared of data in readiness of the 2014 being ran and pasted in.

There is no data in the finance_gl table yet for 2014, we will speak with phillip on Monday to get this in.
*/
