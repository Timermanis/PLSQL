
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------178-------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_178_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 178                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
or TRADE_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'Z2',
'##',
'Z5',
'TU',
'WE',
'SU',
'MO',
'Z8',
'Z1',
'MZ',
'FR',
'SA',
'TH',
'Z4',
'WZ'

) );
select count(*) from jt_ret_tra_sign_210515_178_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_178_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------175-----------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_175_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 175                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'WE',
'Z4',
'Z7',
'Z8',
'Z2',
'TH',
'Z1',
'MZ',
'SU',
'FR',
'MO',
'TU',
'SA',
'WZ'


) );
select count(*) from jt_ret_tra_sign_210515_175_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_175_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------156------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_156_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 156                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'MZ',
'TH',
'TU',
'MO',
'Z8',
'FR',
'Z1',
'WZ',
'Z9',
'SA',
'WE',
'Z2',
'Z5',
'SU'


) );
select count(*) from jt_ret_tra_sign_210515_156_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_156_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------149--------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_149_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 149                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'WZ',
'SU'


) );
select count(*) from jt_ret_tra_sign_210515_149_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_149_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------141--------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_141_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 141                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'SA',
'WE',
'MZ',
'WZ',
'TH',
'MO',
'SU',
'Z9',
'Z2',
'TU',
'FR',
'Z8',
'Z1'

) );
select count(*) from jt_ret_tra_sign_210515_141_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_141_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------138------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_138_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 138                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'Z4'

) );
select count(*) from jt_ret_tra_sign_210515_138_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_138_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------137--------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_137_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 137                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'MO',
'SA',
'Z8',
'MZ',
'Z2',
'WE',
'Z1',
'TU',
'WZ',
'FR',
'SU',
'TH'


) );
select count(*) from jt_ret_tra_sign_210515_137_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_137_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------128_v2-------------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_128_v2 as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 128                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'Z7'

) );
select count(*) from jt_ret_tra_sign_210515_128_v2

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_128_v2)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------126----------------------------------------------------------------------------------------------------
create table jt_ret_tra_sign_210515_126_neg as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 126                        --
and 
(

TRADE_VALUE_EXCL_VAT >0
or COST_VALUE_EXCL_VAT >0
or COST_VALUE_VAT >0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  

'Z4'

) );
select count(*) from jt_ret_tra_sign_210515_126_neg

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tra_sign_210515_126_neg)    --
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
