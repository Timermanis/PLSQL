create table jt_ret_tr_sign_220515_rev_pos1 as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  in  (136,
152
)                       --
and 
(
TRANSACTION_QUANTITY  >0
or COST_VALUE_EXCL_VAT >0
or TRADE_VALUE_EXCL_VAT >0
or TRADE_VALUE_VAT >0
or RETAIL_VALUE_VAT >0
or RETAIL_VALUE_EXCL_VAT  >0
or COST_VALUE_VAT >0

)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  


'Z3',
'Z4'

) );
select count(*) from jt_ret_tr_sign_220515_rev_pos1

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) *(-1),
RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)*(-1)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT) *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT) *(-1) ,
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT) *(-1)
where dwh_num in(
select dwh_num from jt_ret_tr_sign_220515_rev_pos1)    --

119	Z3	POS
136	Z3	POS
152	Z4	POS
462	Z4	POS
463	Z2	POS


------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

create table jt_ret_tr_sign_220515_reversa2 as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  in  (140,
181,508
)                       --
and 
(
--TRANSACTION_QUANTITY  <0
COST_VALUE_EXCL_VAT <0
--or TRADE_VALUE_EXCL_VAT <0
--or TRADE_VALUE_VAT <0
--or RETAIL_VALUE_VAT <0
)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  


'Z3'


) );
select count(*) from jt_ret_tr_sign_220515_reversa2

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)--*(-1)  
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
--TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT),-- *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tr_sign_220515_reversa1)    --

140	Z3	NEG
181	Z3	NEG
447	Z4	NEG
492	Z3	NEG
508	Z3	NEG

------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
create table jt_ret_tr_sign_220515_neg_last as select * --
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 5403                        --
and 
(

TRADE_VALUE_EXCL_VAT <0

)
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
(                                                      --  


'WZ'

) );
select count(*) from jt_ret_tr_sign_220515_neg_last

----------------------------------------------------------------------
update dw.retailer_transaction rt set                  
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY),-- *(-1),
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT),--*(-1)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT),-- *(-1) ,
--COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)*(-1)  ,
--COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT)-- *(-1) 
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)--  *(-1)
where dwh_num in(
select dwh_num from jt_ret_tr_sign_220515_neg_last)    --
