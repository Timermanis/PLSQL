update retailer_transaction rt set 
TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) ,
RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)  ,
RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT)  ,
COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)  ,
COST_VALUE_VAT = abs(COST_VALUE_VAT)  ,
TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT)  ,
TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  
where dwh_num in(
select dwh_num
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 101
and rt.cost_value_vat > 0


and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                    where m.iss_type_code in  ('MO','TU','WE','TH','FR','SA','SU','MZ','WZ') )

