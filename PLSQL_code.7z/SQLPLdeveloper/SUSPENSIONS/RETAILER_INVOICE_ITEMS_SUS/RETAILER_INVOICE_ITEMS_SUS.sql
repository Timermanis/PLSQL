--Reson because customers could be out of customer number reange. Have to have a look into archive.zpx_riv_hed (query bellow), 
--if CUSTOMER_ID is not between 100 000 - 200 000 must move to bin.
select * from RETAILER_INVOICE_ITEMS_SUS 

select * from archive.zpx_riv_head_stg_bak z where z.document_id in (select s.RII_INVOICE_DOCUMENT_NUM from RETAILER_INVOICE_ITEMS_SUS s where z.CUSTOMER_ID <=100000)

select * from archive.zpx_riv_head_stg_bak z where z.document_id in (select s.RII_INVOICE_DOCUMENT_NUM from RETAILER_INVOICE_ITEMS_SUS s where z.CUSTOMER_ID >=200000)

insert into RETAILER_INVOICE_ITEMS_BIN 
(select t.*,'JT' WHO_BINNED,sysdate WHEN_BINNED  from RETAILER_INVOICE_ITEMS_SUS t where t.RII_INVOICE_DOCUMENT_NUM in  
(select z.document_id from archive.zpx_riv_head_stg_bak z where z.customer_id <=100000))

delete from RETAILER_INVOICE_ITEMS_sus t where t.RII_INVOICE_DOCUMENT_NUM in  
(select z.document_id from archive.zpx_riv_head_stg_bak z where z.customer_id <=100000)


