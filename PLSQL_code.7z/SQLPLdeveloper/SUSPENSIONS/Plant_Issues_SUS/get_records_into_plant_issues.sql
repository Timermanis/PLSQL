select * from SALES_ORGANISATION_ISSUES_SUS t ;
select * from PLANT_ISSUES_SUS t ;
select * from ISSUES_SUS t
