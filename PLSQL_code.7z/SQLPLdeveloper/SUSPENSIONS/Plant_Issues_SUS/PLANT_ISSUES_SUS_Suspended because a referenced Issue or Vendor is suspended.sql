select ORA_ERR_MESG$,count(*) from PLANT_ISSUES_SUS t
group by ORA_ERR_MESG$

--Very possible that plant issue has been created much earlier than should so suspended because no calendar entries for these dates. Just live as it is
select PLIS_ISSUE_NUM,count(*) from PLANT_ISSUES_SUS t where ORA_ERR_MESG$ like '%Suspended because a referenced Issue or Vendor is suspended.%' and PLIS_ISSUE_NUM = 403260014
group by PLIS_ISSUE_NUM

select * from PLANT_ISSUES_SUS t where ORA_ERR_MESG$ like '%Suspended because a referenced Issue or Vendor is suspended.%' and PLIS_ISSUE_NUM = 403260014



select * from PLANT_ISSUES_SUS t where ORA_ERR_MESG$ like '%Suspended because a referenced Issue or Vendor is suspended.%'

select c.* from issues_SUS c,PLANT_ISSUES_SUS p where p.ORA_ERR_MESG$ like '%Suspended because a referenced Issue or Vendor is suspended.%'
and c.iss_num = p.plis_issue_num
and c.iss_publication_date < sysdate
select * from PLANT_ISSUES_SUS t  where  PLIS_ISSUE_NUM = 497560008  --205050 / 203837

select *
from refmast.issues k
where k.iss_num = 411890013;
 
select *
from refstg.plant_issueS_sus p
where p.plis_issue_num = 411890013;

select *
from refstg.issueS_sus p
where p.iss_num = 411890013;
 
select *
from dw.vendor v
where v.ven_num in (204716)--,203841)

--Suspended because a referenced Issue or Vendor is suspended.
select * from ISSUES_SUS where ISS_NUM = 403260014 
select * from ISSUES_SUS where ISS_NUM = 411890013

update ISSUES_SUS set ISS_VAT_TYPE_UK = 0
select * from ISSUES_SUS where ISS_VAT_TYPE_UK = 2 

update ISSUES_SUS set ISS_VAT_TYPE_UK = 0
 where ISS_VAT_TYPE_UK = 2 
--ISS_CHLD_VAT_UK_FK	Foreign	ISS_VAT_TYPE_UK	Y	REFMAST.LATEST_VAT_UK_MV	VAT_TYPE_CODE	
select * from refmast.LATEST_VAT_UK_MV
select * from REFMAST.LATEST_VAT_EIRE_MV
