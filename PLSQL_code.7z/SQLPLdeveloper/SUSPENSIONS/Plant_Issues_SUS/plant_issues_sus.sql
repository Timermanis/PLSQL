select trunc(PLIS_PLANNED_ON_SALE_DATE),t.* from PLANT_ISSUES_SUS t  where ORA_ERR_MESG$ like '%rt NULL into ("REFSTG"."PLANT_ISSUES_CC"."%'  
and trunc(PLIS_PLANNED_ON_SALE_DATE) <to_date('31/12/2014','dd/mm/yyyy')

select PLIS_ISSUE_NUM, count(*) from PLANT_ISSUES_SUS t  where ORA_ERR_MESG$ like '%rt NULL into ("REFSTG"."PLANT_ISSUES_CC"."%'  
and trunc(PLIS_PLANNED_ON_SALE_DATE) <to_date('31/12/2014','dd/mm/yyyy')
group by PLIS_ISSUE_NUM

select PLIS_ISSUE_NUM,count(*) from PLANT_ISSUES_SUS where trunc(PLIS_PLANNED_ON_SALE_DATE) <to_date('31/12/2014','dd/mm/yyyy') group by PLIS_ISSUE_NUM

select * from PLANT_ISSUES_SUS t  where ORA_ERR_MESG$ like '%rt NULL into ("REFSTG"."PLANT_ISSUES_CC"."%'   and PLIS_ISSUE_NUM = 471630012
select * from PLANT_ISSUES_SUS t  where ORA_ERR_MESG$ like '%rt NULL into ("REFSTG"."PLANT_ISSUES_CC"."%'   and PLIS_ISSUE_NUM like '471630%'


select * from refmast.latest_products_mv where prod_num like '%471630031%'
376400002
384010002
select i.iss_name, i.iss_publication_date, i.iss_num, s.plis_plant_num
from refstg.plant_issues_sus s, refmast.issues i 
where s.plis_issue_num = i.iss_num and i.iss_num in(384010002)
and ISS_NAME like '% NP%'

select * from dw.retailer_transaction t where PLANT_ISSUE_ID in (376400002)


select i.iss_name, i.iss_publication_date, i.iss_num, s.plis_plant_num --select ALL "never published" (NP) issues from  plant_issues_sus
from refstg.plant_issues_sus s, refmast.issues i 
where s.plis_issue_num = i.iss_num and  ISS_NAME like '% NP%'

select * from retailer_transactions_sus t where t.RTRN_ISSUE_NUM in ( --check if we have records in retailer_transactions_sus - NO ANY
select  i.iss_num
from refstg.plant_issues_sus s, refmast.issues i 
where s.plis_issue_num = i.iss_num and  ISS_NAME like '% NP%')

select * from plant_ISSUES_SUS where PLIS_ISSUE_NUM in (352480276,368480254)

insert into refstg.plant_issues_bin t (select s.*,'JT'  ,sysdate
from refstg.plant_issues_sus s where s.plis_actual_on_sale_date < sysdate -180 and s.ora_err_mesg$ is not null)
delete from plant_ISSUES_SUS s where s.plis_actual_on_sale_date < sysdate -180 and s.ora_err_mesg$ is not null

(select s.*,'JTIMERMANIS'  ,sysdate
from refstg.plant_issues_sus s, refmast.issues i 
where s.plis_issue_num = i.iss_num and  ISS_NAME like '% NP%')

delete from refstg.plant_issues_sus s where s.PLIS_ISSUE_NUM in( --delete these records
select  i.iss_num
from refstg.plant_issues_sus s, refmast.issues i 
where s.plis_issue_num = i.iss_num and  ISS_NAME like '% NP%')
