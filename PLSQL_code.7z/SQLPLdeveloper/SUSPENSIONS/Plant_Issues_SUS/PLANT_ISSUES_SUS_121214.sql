select ORA_ERR_MESG$,count(*) from PLANT_ISSUES_SUS t
group by ORA_ERR_MESG$

select PLIS_ISSUE_NUM,count(*) from PLANT_ISSUES_SUS t where ORA_ERR_MESG$ like '%Suspended because a referenced Issue or Vendor is suspended.%'
group by PLIS_ISSUE_NUM

select PLIS_ISSUE_NUM,count(*) from PLANT_ISSUES_SUS t where ORA_ERR_MESG$ like '%FSTG"."PLANT_ISSUES_CC"."PLIS_PUBLISHER_NUM%'
group by PLIS_ISSUE_NUM

select * from PLANT_ISSUES_SUS t where PLIS_ISSUE_NUM=100000001960266

select * from issues_sus where ISS_NUM=100000001960266
select * from refmast.issues where ISS_NUM=100000001960275

select * from refmast.issues where ISS_PRODUCT_NUM=10000000196 order by ISS_PUBLICATION_DATE desc
