select  c.* from customer_details_sus c for update
select CD_POSTCODE, c.* from customer_details_cc c
where CD_COUNTRY_CODE = 'IE'

select * from customer_details_sus for update

select * from archive.zpx_cus_dtls_stg_bak where customer_id = '0000116669'

116669
CI23 8RI

select * from refmast.latest_customers_mv where CD_POSTCODE_INNER is null
