select LTRN_LEVY_CODE,count(*) from LEVY_AND_MISC_PROD_SUS
group by LTRN_LEVY_CODE

select LTRN_LEVY_CODE,LTRN_DOCUMENT_CODE, count(*) from LEVY_AND_MISC_PROD_SUS s
group by LTRN_LEVY_CODE,LTRN_DOCUMENT_CODE

select * from LEVY_AND_MISC_PROD_SUS where LTRN_LEVY_CODE = '000000000565640001'

select a.ltrn_levy_code,b.ISS_NAME from LEVY_AND_MISC_PROD_SUS a, dw.media b where to_number(trim(a.ltrn_levy_code)) = b.plis_issue_num and a.ltrn_levy_code in ('000000000565640001') 
group by a.ltrn_levy_code,b.ISS_NAME--SELFIE STICKS                 WALLET HERO                   ONE SHOT

1	000000000565640001	FOLDAWAY BAG                  ONE SHOT



select * from dw.media
select decode(trim(a.ltrn_levy_code),null,1,(trim(a.ltrn_levy_code)) )from LEVY_AND_MISC_PROD_SUS a
select to_number(to_char(a.ltrn_levy_code)) from LEVY_AND_MISC_PROD_SUS a
select a.ltrn_levy_code from LEVY_AND_MISC_PROD_SUS a


create table   as 
select * from LEVY_AND_MISC_PROD_sus where LTRN_LEVY_CODE = '000000000565640001'
insert into LEVY_AND_MISC_PROD_bin select l.*, 'JT', sysdate from LEVY_AND_MISC_PROD_sus l where LTRN_LEVY_CODE = '000000000570240001'
delete from LEVY_AND_MISC_PROD_sus where LTRN_LEVY_CODE = '000000000570240001'

alter table LEVY_AND_MISC_PROD_bin 
ADD (WHO_BINNED varchar(2),
WHEN_BINNED date)

select * from LEVY_AND_MISC_PROD_bin 


insert into LEVY_AND_MISC_PROD_bin select d.*,'JT',sysdate from  LEVY_AND_MISC_PROD_SUS d where to_date(sysdate,'dd-MON-yy')-to_date(rpad(LTRN_TIMESTAMP,9),'dd-MON-yy')>180
delete from LEVY_AND_MISC_PROD_sus where to_date(sysdate,'dd-MON-yy')-to_date(rpad(LTRN_TIMESTAMP,9),'dd-MON-yy')>180
