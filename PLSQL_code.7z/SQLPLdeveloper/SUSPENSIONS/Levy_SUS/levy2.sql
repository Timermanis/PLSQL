--Add these records in Levy_SUS not in refmast.levies-----
--TEST into insert from map_sus_stg2_lev_ins1
FOLDAWAY BAG
----------------------------------------------------------
1	000000000501080001	SELFIE STICKS                 ONE SHOT 
1	000000000565640001	FOLDAWAY BAG                  ONE SHOT

select * from refmast.sas_codes t where t.sas_code = 'ZR'
select * from refmast.sas_codes t where t.sas_name like '%STI%'
select * from refmast.levies d where  LEVY_name like '%BAG%'
select * from refmast.levies where LEVY_name like '%FOLDAWAY BAG%'   --inserted VIVID E LIQUID 000000000492220001 ZL
select a.* from archive.zpx_ltrn_stg_bak a,refmast.issues b where LEVY_ID like '%501080001%' and a.levy_id=b.iss_num
select * from dw.media c where c.iss_num = '000000000565640001'--000000000492220001

select a.* from archive.zpx_ltrn_stg_bak a,refmast.issues b where LEVY_ID like '%501080001%' and a.levy_id=b.iss_num
select * from dw.media c where c.iss_num = 000000000565640001--000000000490300001 LIBERTY TATTOOS

select * from refstg.levies_sus for update

select localtimestamp from dual
--map_sus_stg2_lev_ins1 TO TEST 
--VIVID E LIQUID
   	LEVY_CODE	LEVY_NAME	LEVY_SAS_CODE
1	000000000492220001	VIVID E LIQUID	ZL

--VIVID SPARE BATTERIES
   	LEVY_CODE	LEVY_NAME	LEVY_SAS_CODE
1	000000000472020002	VIVID SPARE BATTERIES	ZL

--SELFIE STICKS
   	LEVY_CODE	LEVY_NAME	LEVY_SAS_CODE
	A72	SALES STICKERS GRS	08


select systimestamp from dual
update refstg.levies_sus set LEVY_TIMESTAMP = systimestamp where LEVY_CODE = 000000000565640001
LEVY_AND_MISC_PROD_SUS
