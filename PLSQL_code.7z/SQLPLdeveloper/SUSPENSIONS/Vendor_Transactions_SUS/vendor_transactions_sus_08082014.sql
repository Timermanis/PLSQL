select VTRN_VENDOR_NUM,count(*),VTRN_TIMESTAMP, min(VTRN_TRANSACTION_DATE),max(VTRN_TRANSACTION_DATE) from VENDOR_TRANSACTIONS_SUS
group by VTRN_VENDOR_NUM,VTRN_TIMESTAMP order by VTRN_TIMESTAMP desc, count(*) desc;

select * from VENDOR_TRANSACTIONS_SUS a,vendor_transactions_bin b where a.VTRN_TIMESTAMP = b.VTRN_TIMESTAMP

--VTRN_SRC_DOCUMENT_NUM, VTRN_SRC_ITEM_NUM, VTRN_TYPE_CODE, VTRN_MATERIAL_DOC_ID
insert into VENDOR_TRANSACTIONS_bin 
(select v.*,'JTIMERMANIS',sysdate from VENDOR_TRANSACTIONS_SUS v where v.vtrn_vendor_num=203837);

delete from VENDOR_TRANSACTIONS_SUS where vtrn_vendor_num=203837


select VTRN_SRC_DOCUMENT_NUM, VTRN_SRC_ITEM_NUM, VTRN_TYPE_CODE, VTRN_MATERIAL_DOC_ID from VENDOR_TRANSACTIONS_SUS v where v.vtrn_vendor_num=203837

select * from REFSTG.VENDOR_TRANSACTIONS_CC where vtrn_vendor_num=203837

select * from all_all_tables where table_name like '%ZPX%VEN%'

select * from archive.ZPX_VEN_STG_BAK where id like '%203837%';

select * from refmast.latest_vendors_mv where ven_num like '%203837%';


select * from archive.ZPX_VEN_XRF_STG_BAK a where a.vendor_id ;
