
insert into vendor_transactions_bin 
(select v.*,'JTIMERMANIS',  sysdate from VENDOR_TRANSACTIONS_SUS v where to_date(rpad(VTRN_TIMESTAMP,9),'dd-mm-yy')< to_date ('30-04-14', 'dd-mm-yy')) ;

delete from vendor_transactions_sus v where (v.vtrn_timestamp, v.vtrn_issue_num) in 
(select v.vtrn_timestamp, v.vtrn_issue_num from VENDOR_TRANSACTIONS_SUS v where to_date(rpad(VTRN_TIMESTAMP,9),'dd-mm-yy')< to_date ('30-04-14', 'dd-mm-yy'));

select * from vendor_transactions_bin v ;
