select ORA_ERR_MESG$, count (*) from refstg.vendor_transactions_sus
group by ORA_ERR_MESG$;
select * from vendor_transactions_sus where ORA_ERR_MESG$ like '%STG"."VENDOR_TRANSACTIONS_CC"."VTRN_ISSUE_STAR%'  and VTRN_ISSUE_NUM = 380460001 
order by VTRN_TIMESTAMP desc;
-- Checking ORA-01400: cannot insert NULL into ("REFSTG"."VENDOR_TRANSACTIONS_CC"."VTRN_ISSUE_START_DATE")
select VTRN_ISSUE_START_DATE,v.* from refstg.vendor_transactions_sus v
where ORA_ERR_MESG$ like '%STG"."VENDOR_TRANSACTIONS_CC"."VTRN_ISSUE_STAR%' and VTRN_ISSUE_NUM = 397870001
order by VTRN_TIMESTAMP desc;
----- Group by DATE
select trunc (VTRN_TRANSACTION_DATE),count(*),sum(VTRN_COST_VALUE_EXCL_VAT) from refstg.vendor_transactions_sus 
where ORA_ERR_MESG$ like '%STG"."VENDOR_TRANSACTIONS_CC"."VTRN_ISSUE_STAR%' 
group by trunc (VTRN_TRANSACTION_DATE) 
order by trunc (VTRN_TRANSACTION_DATE) desc;
---GROUP by ISSUE_NUM
select VTRN_ISSUE_NUM,count(*),min(VTRN_TRANSACTION_DATE ),max(VTRN_TRANSACTION_DATE ) from refstg.vendor_transactions_sus 
where ORA_ERR_MESG$ like '%STG"."VENDOR_TRANSACTIONS_CC"."VTRN_ISSUE_STAR%'-- Group by ISSUE
group by VTRN_ISSUE_NUM
order by count(*) desc;
---
select sum(VTRN_COST_VALUE_EXCL_VAT) from refstg.vendor_transactions_sus 
where ORA_ERR_MESG$ like '%STG"."VENDOR_TRANSACTIONS_CC"."VTRN_ISSUE_STAR%'
---
select * from refmast.plant_issues p where p.plis_issue_num = 397880001;--Ckecking issue_number in refmast.plant_issues
---
select * from refmast.sales_organisation_issues s where s.sois_issue_num = 397880001;--Ckecking issue_number in refmast.sales_organisation_issues
---
select * from refmast.issues s where s.iss_num = 397880001;
--------
select * from refmast.products s where s.prod_num = 38046;
-----
select * from dw.vendor_trn_document_type
---------Insert into bin----------
insert into vendor_transactions_bin
(select p.*, 'JTIMERMANIS',  sysdate from vendor_transactions_sus p 
where ORA_ERR_MESG$ like '%STG"."VENDOR_TRANSACTIONS_CC"."VTRN_ISSUE_STAR%'  and VTRN_ISSUE_NUM = 397840001 )
------------Delete from SUS--------
delete from vendor_transactions_sus where ORA_ERR_MESG$ like '%STG"."VENDOR_TRANSACTIONS_CC"."VTRN_ISSUE_STAR%'  and VTRN_ISSUE_NUM = 397840001
---------------BIN transactions------
select VTRN_ISSUE_NUM, max(VTRN_TRANSACTION_DATE),count(*), WHEN_BINNED from vendor_transactions_bin 
--where WHO_BINNED ='JTIMERMANIS'
group by VTRN_ISSUE_NUM,WHEN_BINNED
--------------------LAST FEW DAYS grouped by ISSUE_NUM-----
select VTRN_ISSUE_NUM,count(*) from vendor_transactions_sus where VTRN_TIMESTAMP > to_date ('22-07-14','dd-mm-yy')
group by VTRN_ISSUE_NUM order by count(*) desc;
---------------------
select * from vendor_transactions_sus where VTRN_ISSUE_NUM = 100000006290001
