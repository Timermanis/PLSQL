CREATE or replace VIEW suspension_view_jt_010415_sus (suspended, error, "TABLE_SUS")
  AS
       -------RETAILER------- 
select  CDI_TIMESTAMP suspended, ORA_ERR_MESG$ error , 'CUSTOMER_DELIVERY_INFO_SUS' "TABLE" from  CUSTOMER_DELIVERY_INFO_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CDI_TIMESTAMP,9),'dd-MON-yy')>14   union
select  CD_TIMESTAMP, ORA_ERR_MESG$, 'CUSTOMER_DETAILS_SUS'  from  CUSTOMER_DETAILS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CD_TIMESTAMP,9),'dd-MON-yy')>14  union 
select  CH_TIMESTAMP, ORA_ERR_MESG$, 'CUSTOMER_HOURS_SUS'  from  CUSTOMER_HOURS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CH_TIMESTAMP,9),'dd-MON-yy')>14 union 
select  CSA_TIMESTAMP, ORA_ERR_MESG$, 'CUSTOMER_SALES_AIDS_SUS'  from  CUSTOMER_SALES_AIDS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CSA_TIMESTAMP,9),'dd-MON-yy')>14 union
select  CSI_TIMESTAMP, ORA_ERR_MESG$, 'CUSTOMER_SUP_INFO_SUS'  from  CUSTOMER_SUP_INFO_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CSI_TIMESTAMP,9),'dd-MON-yy')>14 union
select  CPMB_TIMESTAMP, ORA_ERR_MESG$, 'cus_prod_matrix_band_sus'  from  cus_prod_matrix_band_sus where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CPMB_TIMESTAMP,9),'dd-MON-yy')>14 union
select  PAYM_TIMESTAMP, ORA_ERR_MESG$, 'PAYMENT_METHODS_SUS'  from  PAYMENT_METHODS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(PAYM_TIMESTAMP,9),'dd-MON-yy')>14 union
select  out_eff_date, ORA_ERR_MESG$, 'dwstg.DWS_RETAILER_SUS'  from  dwstg.DWS_RETAILER_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(out_eff_date,9),'dd-MON-yy')>14 union
       -------VENDOR/MEDIA RELATED-------  
select   VEN_TIMESTAMP, ORA_ERR_MESG$, 'VENDORS_SUS'  from  VENDORS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(VEN_TIMESTAMP,9),'dd-MON-yy')>14 union
select   PROD_TIMESTAMP, ORA_ERR_MESG$, 'PRODUCTS_SUS'  from  PRODUCTS_SUS  where to_date(sysdate,'dd-MON-yy')-to_date(rpad(PROD_TIMESTAMP,9),'dd-MON-yy')>14 union
select   LEVY_TIMESTAMP, ORA_ERR_MESG$, 'LEVIES_SUS'  from  LEVIES_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(LEVY_TIMESTAMP,9),'dd-MON-yy')>14  union
select   ISS_TIMESTAMP, ORA_ERR_MESG$, 'ISSUES_SUS'  from  ISSUES_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(ISS_TIMESTAMP,9),'dd-MON-yy')>14  union
select   PLIS_TIMESTAMP, ORA_ERR_MESG$, 'PLANT_ISSUES_SUS'  from  PLANT_ISSUES_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(PLIS_TIMESTAMP,9),'dd-MON-yy')>14  union
select   SOIS_TIMESTAMP, ORA_ERR_MESG$, 'SALES_ORGANISATION_ISSUES_SUS'  from  SALES_ORGANISATION_ISSUES_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(SOIS_TIMESTAMP,9),'dd-MON-yy')>14 union
select   PLIS_ACTUAL_ON_SALE_DATE, ORA_ERR_MESG$, 'dwstg.DWS_MEDIA_SUS'  from  dwstg.DWS_MEDIA_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(PLIS_ACTUAL_ON_SALE_DATE,9),'dd-MON-yy')>14 union
select   VEN_EFF_DATE, ORA_ERR_MESG$, 'dwstg.DWS_VENDOR_SUS'  from  dwstg.DWS_VENDOR_SUS  where to_date(sysdate,'dd-MON-yy')-to_date(rpad(VEN_EFF_DATE,9),'dd-MON-yy')>14 union
       -------GENERAL FACTS RELATED-------   
select   RTRN_TIMESTAMP, ORA_ERR_MESG$, 'RETAILER_TRANSACTIONS_SUS'  from  RETAILER_TRANSACTIONS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RTRN_TIMESTAMP,9),'dd-MON-yy')>14 union
select   RTRN_TIMESTAMP, ORA_ERR_MESG$, 'RETAILER_TRANSACTIONS_STRN_SUS'  from  RETAILER_TRANSACTIONS_STRN_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RTRN_TIMESTAMP,9),'dd-MON-yy')>14  union
select   LTRN_TIMESTAMP, ORA_ERR_MESG$, 'LEVY_AND_MISC_PROD_SUS'  from  LEVY_AND_MISC_PROD_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(LTRN_TIMESTAMP,9),'dd-MON-yy')>14  union
select   STRN_TIMESTAMP, ORA_ERR_MESG$, 'STOCK_TRANSACTIONS_SUS'  from  STOCK_TRANSACTIONS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(STRN_TIMESTAMP,9),'dd-MON-yy')>14  union
select   VTRN_TIMESTAMP, ORA_ERR_MESG$, 'VENDOR_TRANSACTIONS_SUS'  from  VENDOR_TRANSACTIONS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(VTRN_TIMESTAMP,9),'dd-MON-yy')>14 union
select   RIH_TIMESTAMP, ORA_ERR_MESG$, 'RETAILER_INVOICE_HEADERS_SUS'  from  RETAILER_INVOICE_HEADERS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RIH_TIMESTAMP,9),'dd-MON-yy')>14  union
select   RII_TIMESTAMP, ORA_ERR_MESG$, 'RETAILER_INVOICE_ITEMS_SUS'  from  RETAILER_INVOICE_ITEMS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RII_TIMESTAMP,9),'dd-MON-yy')>14  union
       -------FODI RELATED------- 
select   KTOT_RUN_DATE, ORA_ERR_MESG$, 'refstg.fodi_totals_sus'  from  refstg.fodi_totals_sus where to_date(sysdate,'dd-MON-yy')-to_date(rpad(KTOT_RUN_DATE,9),'dd-MON-yy')>14 union
       -------MISC RELATED-------  
select   VAT_TIMESTAMP, ORA_ERR_MESG$, 'VAT_SUS'  from  VAT_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(VAT_TIMESTAMP,9),'dd-MON-yy')>14  union
select   CNTY_TIMESTAMP, ORA_ERR_MESG$, 'COUNTIES_SUS'  from  COUNTIES_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CNTY_TIMESTAMP,9),'dd-MON-yy')>14   union
select   SPO_EFF_DATE, ORA_ERR_MESG$, 'KTOT_RUN_DATE'  from  dwstg.DWS_WHOLESALER_SUS  union
       -------ORPHAN MANAGEMENT RELATED-------   
select   RIH_TIMESTAMP, 'ORPHAN MANAGEMENT RELATED', 'RETAILER_INVOICE_HEADERS_OM'   from  RETAILER_INVOICE_HEADERS_OM where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RIH_TIMESTAMP,9),'dd-MON-yy')>14  union
select   RII_TIMESTAMP, 'ORPHAN MANAGEMENT RELATED', 'RETAILER_INVOICE_ITEMS_OM'   from  RETAILER_INVOICE_ITEMS_OM  where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RII_TIMESTAMP,9),'dd-MON-yy')>14 union
select   RTRN_TIMESTAMP, 'ORPHAN MANAGEMENT RELATED', 'RETAILER_TRANSACTIONS_OM'   from  RETAILER_TRANSACTIONS_OM where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RTRN_TIMESTAMP,9),'dd-MON-yy')>14 union
select   STRN_TIMESTAMP, 'ORPHAN MANAGEMENT RELATED', 'STOCK_TRANSACTIONS_OM'   from  STOCK_TRANSACTIONS_OM  where to_date(sysdate,'dd-MON-yy')-to_date(rpad(STRN_TIMESTAMP,9),'dd-MON-yy')>14 union
select   VTRN_TIMESTAMP, 'ORPHAN MANAGEMENT RELATED', 'VENDOR_TRANSACTIONS_OM'   from  VENDOR_TRANSACTIONS_OM where to_date(sysdate,'dd-MON-yy')-to_date(rpad(VTRN_TIMESTAMP,9),'dd-MON-yy')>14 union
select   LTRN_TIMESTAMP, 'ORPHAN MANAGEMENT RELATED', 'LEVY_AND_MISC_PROD_TRN_OM'   from  LEVY_AND_MISC_PROD_TRN_OM where to_date(sysdate,'dd-MON-yy')-to_date(rpad(LTRN_TIMESTAMP,9),'dd-MON-yy')>14  union
select   KTOT_TIMESTAMP, 'ORPHAN MANAGEMENT RELATED', 'FODI_TOTALS_OM'   from  FODI_TOTALS_OM where to_date(sysdate,'dd-MON-yy')-to_date(rpad(KTOT_TIMESTAMP,9),'dd-MON-yy')>14 ;
