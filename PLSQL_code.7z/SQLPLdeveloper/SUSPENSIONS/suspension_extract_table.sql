       -------RETAILER------- 
select   *  from  CUSTOMER_DELIVERY_INFO_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CDI_TIMESTAMP,9),'dd-MON-yy')>14   ;
select   *  from  CUSTOMER_DETAILS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CD_TIMESTAMP,9),'dd-MON-yy')>14   ;
select   *  from  CUSTOMER_HOURS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CH_TIMESTAMP,9),'dd-MON-yy')>14 ;
select   *  from  CUSTOMER_SALES_AIDS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CSA_TIMESTAMP,9),'dd-MON-yy')>14;
select   *  from  CUSTOMER_SUP_INFO_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CSI_TIMESTAMP,9),'dd-MON-yy')>14;
select   *  from  cus_prod_matrix_band_sus where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CPMB_TIMESTAMP,9),'dd-MON-yy')>14;
select   *  from  PAYMENT_METHODS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(PAYM_TIMESTAMP,9),'dd-MON-yy')>14;
select   *  from  dwstg.DWS_RETAILER_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(out_eff_date,9),'dd-MON-yy')>14 ;
       -------VENDOR/MEDIA RELATED-------  
select   *  from  VENDORS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(VEN_TIMESTAMP,9),'dd-MON-yy')>14 ;
select   *  from  PRODUCTS_SUS  where to_date(sysdate,'dd-MON-yy')-to_date(rpad(PROD_TIMESTAMP,9),'dd-MON-yy')>14 ;
select   *  from  LEVIES_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(LEVY_TIMESTAMP,9),'dd-MON-yy')>14  ;
select   *  from  ISSUES_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(ISS_TIMESTAMP,9),'dd-MON-yy')>14  ;
select   *  from  PLANT_ISSUES_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(PLIS_TIMESTAMP,9),'dd-MON-yy')>14  ;
select   *  from  SALES_ORGANISATION_ISSUES_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(SOIS_TIMESTAMP,9),'dd-MON-yy')>14 ;
select   *  from  dwstg.DWS_MEDIA_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(PLIS_ACTUAL_ON_SALE_DATE,9),'dd-MON-yy')>14 ;
select   *  from  dwstg.DWS_VENDOR_SUS  where to_date(sysdate,'dd-MON-yy')-to_date(rpad(VEN_EFF_DATE,9),'dd-MON-yy')>14 ;
       -------GENERAL FACTS RELATED-------   
select   *  from  RETAILER_TRANSACTIONS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RTRN_TIMESTAMP,9),'dd-MON-yy')>14 ;
select   *  from  RETAILER_TRANSACTIONS_STRN_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RTRN_TIMESTAMP,9),'dd-MON-yy')>14  ;
select   *  from  LEVY_AND_MISC_PROD_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(LTRN_TIMESTAMP,9),'dd-MON-yy')>14  ;
select   *  from  STOCK_TRANSACTIONS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(STRN_TIMESTAMP,9),'dd-MON-yy')>14  ;
select   *  from  VENDOR_TRANSACTIONS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(VTRN_TIMESTAMP,9),'dd-MON-yy')>14 ;
select   *  from  RETAILER_INVOICE_HEADERS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RIH_TIMESTAMP,9),'dd-MON-yy')>14  ;
select   *  from  RETAILER_INVOICE_ITEMS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RII_TIMESTAMP,9),'dd-MON-yy')>14  ;
       -------FODI RELATED------- 
select   *  from  refstg.fodi_totals_sus;
       -------MISC RELATED-------  
select   *  from  VAT_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(VAT_TIMESTAMP,9),'dd-MON-yy')>14  ;
select   *  from  COUNTIES_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(CNTY_TIMESTAMP,9),'dd-MON-yy')>14   ;
select   *  from  dwstg.DWS_WHOLESALER_SUS  ;
       -------ORPHAN MANAGEMENT RELATED-------   
select   *  from  RETAILER_INVOICE_HEADERS_OM where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RIH_TIMESTAMP,9),'dd-MON-yy')>14  ;
select   *  from  RETAILER_INVOICE_ITEMS_OM  where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RII_TIMESTAMP,9),'dd-MON-yy')>14 ;
select   *  from  RETAILER_TRANSACTIONS_OM where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RTRN_TIMESTAMP,9),'dd-MON-yy')>14 ;
select   *  from  STOCK_TRANSACTIONS_OM  where to_date(sysdate,'dd-MON-yy')-to_date(rpad(STRN_TIMESTAMP,9),'dd-MON-yy')>14 ;
select   *  from  VENDOR_TRANSACTIONS_OM where to_date(sysdate,'dd-MON-yy')-to_date(rpad(VTRN_TIMESTAMP,9),'dd-MON-yy')>14 ;
select   *  from  LEVY_AND_MISC_PROD_TRN_OM where to_date(sysdate,'dd-MON-yy')-to_date(rpad(LTRN_TIMESTAMP,9),'dd-MON-yy')>14  ;
select   *  from  FODI_TOTALS_OM where to_date(sysdate,'dd-MON-yy')-to_date(rpad(KTOT_TIMESTAMP,9),'dd-MON-yy')>14 ;
