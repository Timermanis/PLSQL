select * from stock_transactions_sus
select STRN_ISSUE_NUM, count(*) from STOCK_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '%insert NULL into ("REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_%' 
 group by STRN_ISSUE_NUM order by count(*) desc

select * from stock_transactions_sus where STRN_ISSUE_NUM=375170001 
and ORA_ERR_MESG$ like '%insert NULL into ("REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_%' 
order by STRN_TRANSACTION_DATE_NUM desc--have a look to highest suspension number for issue

select * from refmast.plant_issues where PLIS_ISSUE_NUM = 375170001--nonexist

select * from refmast.issues i where i.iss_num = 375170001--nonexist

select * from termsprd.latest_media_issue where id = 375170001--1 record

select * from termsprd.latest_plant_issue where ISSUE_ID = 375170001 --number of records, it means skipped in passing data from MIS to IKW

select * from refstg.plant_issues_sus where PLIS_ISSUE_NUM = 375170001
--------------------------------------------------------------------------------------------------------------------------------
446150001
select * from stock_transactions_sus where STRN_ISSUE_NUM=446150001 
and ORA_ERR_MESG$ like '%insert NULL into ("REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_%' 
order by STRN_TRANSACTION_DATE_NUM desc--have a look to highest suspension number for issue

select * from refmast.plant_issues where PLIS_ISSUE_NUM = 446150001

select * from refmast.issues i where i.iss_num = 446150001

select * from termsprd.latest_media_issue where id = 446150001

select * from termsprd.latest_plant_issue where ISSUE_ID = 446150001

select * from refstg.plant_issues_sus where PLIS_ISSUE_NUM = 446150001
----------------------------------------------------------------------------------------------------------------------------------
382430001
select * from stock_transactions_sus where STRN_ISSUE_NUM=382430001 
and ORA_ERR_MESG$ like '%insert NULL into ("REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_%' 
order by STRN_TRANSACTION_DATE_NUM desc

select * from refmast.plant_issues where PLIS_ISSUE_NUM = 382430001

select * from refmast.issues i where i.iss_num = 382430001

select * from termsprd.latest_media_issue where id = 382430001

select * from termsprd.latest_plant_issue where ISSUE_ID = 382430001

select * from refstg.plant_issues_sus where PLIS_ISSUE_NUM = 382430001
