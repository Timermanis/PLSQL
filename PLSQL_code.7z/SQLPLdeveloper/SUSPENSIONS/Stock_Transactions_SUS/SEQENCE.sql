select * from CSC_DATA t
select dw.stock_trn_report_type_seq.nextval from dual
