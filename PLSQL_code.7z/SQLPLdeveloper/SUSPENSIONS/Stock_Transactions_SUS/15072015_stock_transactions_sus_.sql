
select STRN_LOCATION_TO_CODE,STRN_LOCATION_FROM_CODE,  STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG,count(*), sum(strn_cost_value) from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%' --1525 rows
--and  STRN_LOCATION_FROM_CODE = 'GR'
group by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG
order by count(*) desc;

select * from stock_transactions_sus
--where (STRN_LOCATION_TO_CODE='####' and STRN_LOCATION_FROM_CODE='WAS'  and STRN_MOVEMENT_CODE= 'Z02' and STRN_CREDIT_OR_DEBIT_CODE ='S' and STRN_INTERBRANCH_FLAG=0 and rownum<3)
--where (STRN_LOCATION_TO_CODE='RRT' and STRN_LOCATION_FROM_CODE='OVS'  and STRN_MOVEMENT_CODE= '302' and STRN_CREDIT_OR_DEBIT_CODE ='H' and STRN_INTERBRANCH_FLAG=1 and rownum<3)
--where (STRN_LOCATION_TO_CODE='OVS' and STRN_LOCATION_FROM_CODE='RRT'  and STRN_MOVEMENT_CODE= '302' and STRN_CREDIT_OR_DEBIT_CODE ='S' and STRN_INTERBRANCH_FLAG=1 and rownum<3)
where (STRN_LOCATION_TO_CODE='OVSR' and STRN_LOCATION_FROM_CODE='WAS'  and STRN_MOVEMENT_CODE= '301' and STRN_CREDIT_OR_DEBIT_CODE ='H' and STRN_INTERBRANCH_FLAG=1 and rownum<3)
--where (STRN_LOCATION_TO_CODE='WAS' and STRN_LOCATION_FROM_CODE='OVSR'  and STRN_MOVEMENT_CODE= '301' and STRN_CREDIT_OR_DEBIT_CODE ='S' and STRN_INTERBRANCH_FLAG=1 and rownum<3)

insert into stock_transactions_bin
select s.*,'JT',sysdate from stock_transactions_sus s where s.strn_location_to_code ='RTWM' and s.strn_location_from_code = 'RTWM'  and s.strn_movement_code='301'

delete from stock_transactions_sus s where s.strn_location_to_code ='RTWM' and s.strn_location_from_code = 'RTWM'  and s.strn_movement_code='301'
