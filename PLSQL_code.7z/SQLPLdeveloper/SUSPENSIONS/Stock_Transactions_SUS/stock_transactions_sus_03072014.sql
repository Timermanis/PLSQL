-- list of issues in sus that are VAT issues before the cutover
insert into stock_transactions_bin
(select s2.*,'JT', sysdate from stock_transactions_sus s2
where s2.strn_issue_num in 
(select distinct sts.strn_issue_num
from stock_transactions_sus sts,
(select i2.iss_product_num prod, min( i2.iss_num) iss
from  refmast.issues i2,stock_transactions_sus sts 
where i2.iss_product_num = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4) 
and  i2.iss_name like '%VAT %'
and i2.iss_type_code = 'Z4'
group by i2.iss_product_num
) first_iss
where first_iss.prod = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4)
and sts.strn_issue_num < first_iss.iss
)
)

---------------------------------DELETE from SUS---------------
delete from stock_transactions_sus s2 
where s2.strn_issue_num in                                                     
(select distinct sts.strn_issue_num
from 
stock_transactions_sus sts,
(select i2.iss_product_num prod, min( i2.iss_num) iss
from  refmast.issues i2,stock_transactions_sus sts 
 where i2.iss_product_num = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4) 
 and  i2.iss_name like '%VAT %'
and i2.iss_type_code = 'Z4'
group by i2.iss_product_num) first_iss
where first_iss.prod = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4)
and sts.strn_issue_num < first_iss.iss)

