insert into DW.STOCK_TRN_REPORT_TYPE (DIMENSION_KEY,TYP_ID,TYP_LOC_FROM_CODE,TYP_LOC_TO_CODE,TYP_MOVEMENT_CODE,TYP_CREDIT_DEBIT_FLAG,TYP_REPORTING_OBJECT,TYP_INTERBRANCH_FLAG) 
(select unique dw.stock_trn_report_type_seq.nextval,dw.stock_trn_report_type_seq.nextval,STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE,'To allow suspended records to load EAGLE', STRN_INTERBRANCH_FLAG 
from  refstg.STOCK_TRANSACTIONS_SUS 
where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.STRN_STRT_FK) violated%' 
and STRN_SPOKE_NUM in (740,790)
and STRN_TRANSACTION_DATE > to_date ('05/07/2014','dd/mm/yyyy')--to_date ('05/07/2015','dd/mm/yyyy')
group by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE,STRN_INTERBRANCH_FLAG)

create table missing_rep_types as
select unique STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE,'To allow suspended records to load EAGLE' TYP_REPORTING_OBJECT, STRN_INTERBRANCH_FLAG 
from  refstg.STOCK_TRANSACTIONS_SUS 
where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.STRN_STRT_FK) violated%' 
and STRN_SPOKE_NUM in (740,790)
and STRN_TRANSACTION_DATE > to_date ('05/07/2014','dd/mm/yyyy')

select * from missing_rep_types


insert into DW.STOCK_TRN_REPORT_TYPE (DIMENSION_KEY,TYP_ID,TYP_LOC_FROM_CODE,TYP_LOC_TO_CODE,TYP_MOVEMENT_CODE,TYP_CREDIT_DEBIT_FLAG,TYP_REPORTING_OBJECT,TYP_INTERBRANCH_FLAG) values
(dw.stock_trn_report_type_seq.nextval,dw.stock_trn_report_type_seq.nextval,'SBR', 'GR','ZR1','S','To allow suspended records load 020815',0) 

insert into DW.STOCK_TRN_REPORT_TYPE (DIMENSION_KEY,TYP_ID,TYP_LOC_FROM_CODE,TYP_LOC_TO_CODE,TYP_MOVEMENT_CODE,TYP_CREDIT_DEBIT_FLAG,TYP_REPORTING_OBJECT,TYP_INTERBRANCH_FLAG) values
(dw.stock_trn_report_type_seq.nextval,dw.stock_trn_report_type_seq.nextval,'GR', 'SBR','ZR1','H','To allow suspended records load 020815',0) 

insert into DW.STOCK_TRN_REPORT_TYPE (DIMENSION_KEY,TYP_ID,TYP_LOC_FROM_CODE,TYP_LOC_TO_CODE,TYP_MOVEMENT_CODE,TYP_CREDIT_DEBIT_FLAG,TYP_REPORTING_OBJECT,TYP_INTERBRANCH_FLAG) values
(dw.stock_trn_report_type_seq.nextval,dw.stock_trn_report_type_seq.nextval,'SBR', 'GR','343','H','To allow suspended records load 020815',0) 

insert into DW.STOCK_TRN_REPORT_TYPE (DIMENSION_KEY,TYP_ID,TYP_LOC_FROM_CODE,TYP_LOC_TO_CODE,TYP_MOVEMENT_CODE,TYP_CREDIT_DEBIT_FLAG,TYP_REPORTING_OBJECT,TYP_INTERBRANCH_FLAG) values
(dw.stock_trn_report_type_seq.nextval,dw.stock_trn_report_type_seq.nextval,'GR', 'SBR','343','S','To allow suspended records load 020815',0) 


















select b.ORA_ERR_MESG$,ROW_NUMBER( ) OVER (PARTITION BY
b.strn_movement_code order by strn_movement_code) row_number1 
 from DW.STOCK_TRN_REPORT_TYPE a,refstg.STOCK_TRANSACTIONS_SUS b 
where a.TYP_LOC_FROM_CODE = b.STRN_LOCATION_FROM_CODE
and a.TYP_LOC_TO_CODE = b.STRN_LOCATION_TO_CODE 
and a.TYP_MOVEMENT_CODE = b.STRN_MOVEMENT_CODE 
and a.TYP_CREDIT_DEBIT_FLAG = b.STRN_CREDIT_OR_DEBIT_CODE 
and a.TYP_INTERBRANCH_FLAG = b.STRN_INTERBRANCH_FLAG
and row_number1 = 1
and b.ORA_ERR_MESG$ like '% integrity constraint (REFSTG.STRN_STRT_FK) violated%' 
and b.STRN_SPOKE_NUM in (740,790)
and b.STRN_TRANSACTION_DATE > to_date ('05/07/2014','dd/mm/yyyy')

select * 
from  refstg.STOCK_TRANSACTIONS_SUS 
where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.STRN_STRT_FK) violated%' 

--TYP_LOC_FROM_CODE, TYP_LOC_TO_CODE, TYP_MOVEMENT_CODE, TYP_CREDIT_DEBIT_FLAG, TYP_INTERBRANCH_FLAG
