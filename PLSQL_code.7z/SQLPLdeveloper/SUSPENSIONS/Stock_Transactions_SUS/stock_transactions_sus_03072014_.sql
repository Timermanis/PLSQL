select * from stock_transactions_sus

-------------------------prepearing for cleaning up stock_transactions_sus. Using for every case due to missing issue for covermount (Z4) before moving from MIS to IKW--
--1	STOCK_TRANSACTIONS_SUS	"ORA-01400: cannot insert NULL into (""REFSTG"".""STOCK_TRANSACTIONS_CC"".""STRN_ISSUE_START_DATE"")

select  sts.*
from 
stock_transactions_sus sts,
(select i2.iss_product_num prod, min( i2.iss_num) iss
from  refmast.issues i2,stock_transactions_sus sts 
 where i2.iss_product_num = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4) 
 and  i2.iss_name like '%VAT %'
and i2.iss_type_code = 'Z4'
group by i2.iss_product_num) first_iss
where first_iss.prod = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4)
and sts.strn_issue_num < first_iss.iss
order by 1

insert into stock_transactions_bin 
select  sts.*,'JT',sysdate
from 
stock_transactions_sus sts,
(select i2.iss_product_num prod, min( i2.iss_num) iss
from  refmast.issues i2,stock_transactions_sus sts 
 where i2.iss_product_num = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4) 
 and  i2.iss_name like '%VAT %'
and i2.iss_type_code = 'Z4'
group by i2.iss_product_num) first_iss
where first_iss.prod = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4)
and sts.strn_issue_num < first_iss.iss
order by 1

delete from stock_transactions_sus where (STRN_SRC_DOCUMENT_NUM,STRN_TIMESTAMP,STRN_LOCATION_TO_CODE,STRN_DWH_NUM) in 
(select  sts.STRN_SRC_DOCUMENT_NUM,sts.STRN_TIMESTAMP,sts.STRN_LOCATION_TO_CODE,STRN_DWH_NUM
from 
stock_transactions_sus sts,
(select i2.iss_product_num prod, min( i2.iss_num) iss
from  refmast.issues i2,stock_transactions_sus sts 
 where i2.iss_product_num = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4) 
 and  i2.iss_name like '%VAT %'
and i2.iss_type_code = 'Z4'
group by i2.iss_product_num) first_iss
where first_iss.prod = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4)
and sts.strn_issue_num < first_iss.iss)

select STRN_TIMESTAMP,count(*) from stock_transactions_sus group by STRN_TIMESTAMP

---------------------select all issues from stock_transactions_sus where is a record in refmast.issues
select distinct s.STRN_ISSUE_NUM from stock_transactions_sus s, refmast.issues i
where i.iss_product_num = substr(s.strn_issue_num,1,length(s.strn_issue_num)-4) -- join tables
and ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%'--select this error type


------------------------------------------------ SUS combinations
--ORA-02291: integrity constraint (REFSTG.STRN_STRT_FK) violated - parent key not found

select STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG,count(*), sum(strn_cost_value) from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%' --1525 rows 
--and  STRN_LOCATION_FROM_CODE = 'GR'
group by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG
order by sum(strn_cost_value) desc, count(*) desc

order by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG

select distinct STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG
 from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%' --1525 rows 
and  STRN_LOCATION_FROM_CODE = 'SBR'
order by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG

------------------------------------------------- DW.STOCK_TRN_REPORT_TYPE is not updated TEST
select * from DW.STOCK_TRN_REPORT_TYPE
where TYP_LOC_FROM_CODE	='GR'

and  TYP_LOC_TO_CODE	='GR'
--TYP_MOVEMENT_CODE	 ='301'
--and TYP_CREDIT_DEBIT_FLAG	 ='H'
--and TYP_INTERBRANCH_FLAG ='1'
-----------------------------------------------1. missing MOVEMENT_CODE in DW.STOCK_TRN_REPORT_TYPE 7 records
select distinct (STRN_MOVEMENT_CODE) from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%'
and STRN_MOVEMENT_CODE not in (select distinct(TYP_MOVEMENT_CODE) from DW.STOCK_TRN_REPORT_TYPE)
-----------------------------------------------2. missing TYP_LOC_FROM_CODE in DW.STOCK_TRN_REPORT_TYPE 0 records
select distinct (STRN_LOCATION_FROM_CODE) from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%'
and STRN_LOCATION_FROM_CODE not in (select distinct(TYP_LOC_FROM_CODE) from DW.STOCK_TRN_REPORT_TYPE)
-----------------------------------------------3. missing TYP_LOC_TO_CODE in DW.STOCK_TRN_REPORT_TYPE 0 records
select distinct (STRN_LOCATION_TO_CODE) from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%'
and STRN_LOCATION_TO_CODE not in (select distinct(TYP_LOC_TO_CODE) from DW.STOCK_TRN_REPORT_TYPE)
-----------------------------------------------4. missing MOVEMENT_CODE in DW.STOCK_TRN_REPORT_TYPE 0 records
select distinct ( STRN_CREDIT_OR_DEBIT_CODE) from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%'
and  STRN_CREDIT_OR_DEBIT_CODE not in (select distinct( TYP_CREDIT_DEBIT_FLAG) from DW.STOCK_TRN_REPORT_TYPE)



select * from DW.STOCK_TRN_REPORT_TYPE where 



select * from stock_transactions_sus
--where (STRN_LOCATION_FROM_CODE='SBR' and STRN_LOCATION_TO_CODE='GR' and STRN_MOVEMENT_CODE= '301' and STRN_CREDIT_OR_DEBIT_CODE ='H' and STRN_INTERBRANCH_FLAG=1 and rownum<3)
--where (STRN_LOCATION_FROM_CODE='GR' and STRN_LOCATION_TO_CODE='SBR' and STRN_MOVEMENT_CODE= '301' and STRN_CREDIT_OR_DEBIT_CODE ='S' and STRN_INTERBRANCH_FLAG=1 and rownum<3)
--where (STRN_LOCATION_FROM_CODE='OVS' and STRN_LOCATION_TO_CODE='RTWM' and STRN_MOVEMENT_CODE= '301' and STRN_CREDIT_OR_DEBIT_CODE ='H' and STRN_INTERBRANCH_FLAG=1 and rownum<3)
--where (STRN_LOCATION_FROM_CODE='RTWM' and STRN_LOCATION_TO_CODE='OVS' and STRN_MOVEMENT_CODE= '301' and STRN_CREDIT_OR_DEBIT_CODE ='S' and STRN_INTERBRANCH_FLAG=1 and rownum<3)
where(STRN_LOCATION_FROM_CODE='GR' and STRN_LOCATION_TO_CODE='####' and STRN_MOVEMENT_CODE= '642' and STRN_CREDIT_OR_DEBIT_CODE ='S' and STRN_INTERBRANCH_FLAG=0 and rownum<3)

--Checking stock_transaction_sus older than 2 week NO ISSUE DATE due to missing plant issue
select * from stock_transactions_sus 
where ORA_ERR_MESG$ like '%"REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_DATE%' 
and to_date(sysdate,'dd-MON-yy')-to_date(rpad(STRN_TIMESTAMP,9),'dd-MON-yy')>14 order by STRN_TIMESTAMP

--Find issues with top count records
select STRN_ISSUE_NUM,count(*) from stock_transactions_sus 
where ORA_ERR_MESG$ like '%"REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_DATE%' 
and to_date(sysdate,'dd-MON-yy')-to_date(rpad(STRN_TIMESTAMP,9),'dd-MON-yy')>14 
group by STRN_ISSUE_NUM

--have a look into
select * from stock_transactions_sus 
where ORA_ERR_MESG$ like '%"REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_DATE%' 
and STRN_ISSUE_NUM = 446150001 order by STRN_TRANSACTION_DATE

select * from refmast.current_products_mv where PROD_NUM in (39785,39785,39784,39788,37517,44615,38243)

select s.strn_issue_num,p.prod_name,STRN_TRANSACTION_DATE,count(*) from stock_transactions_sus s, refmast.current_products_mv p
where lpad(s.strn_issue_num,5)=p.prod_num
and s.STRN_ISSUE_NUM like '%01'
group by s.strn_issue_num,p.prod_name,STRN_TRANSACTION_DATE
order by count(*) desc

select STRN_ISSUE_NUM,count(*) from stock_transactions_sus 
where ORA_ERR_MESG$ like '%"REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_DATE%' 
and to_date(sysdate,'dd-MON-yy')-to_date(rpad(STRN_TIMESTAMP,9),'dd-MON-yy')>14 
group by STRN_ISSUE_NUM

select *
from  refmast.issues where ISS_NUM = 446150001

select  sts.*
from
stock_transactions_sus sts,
(select i2.iss_product_num prod, min( i2.iss_num) iss
from  refmast.issues i2,stock_transactions_sus sts 
 where i2.iss_product_num = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4)
 and  i2.iss_name like '%VAT %'
and i2.iss_type_code = 'Z4'
group by i2.iss_product_num) first_iss
where first_iss.prod = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4)
--and sts.strn_issue_num < first_iss.iss
order by 1

select * from refmast.products p,refstg.issues_sus i--check does the refstg.issues_sus product exists into refmast.products
where  i.ISS_PRODUCT_NUM=p.prod_num(+)
and p.prod_num is null
