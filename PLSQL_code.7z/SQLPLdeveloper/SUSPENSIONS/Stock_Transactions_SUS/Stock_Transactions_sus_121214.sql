
select ORA_ERR_MESG$,count(*) from STOCK_TRANSACTIONS_SUS --"RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_NUM
group by ORA_ERR_MESG$;

select *from STOCK_TRANSACTIONS_SUS y --
where ORA_ERR_MESG$ like '%rity constraint (REFSTG.STRN_STRT_FK) %' 
and STRN_LOCATION_TO_CODE = 'GR' and STRN_LOCATION_FROM_CODE = 'WAS'order by y.strn_transaction_date;
----------
select * from dw.stock_transaction

with a
as
(
select y.strn_location_from_code,y.strn_location_to_code,y.strn_movement_code--,y.strn_credit_or_debit_code,count(*),sum(STRN_COST_VALUE) 
from STOCK_TRANSACTIONS_SUS y 
where ORA_ERR_MESG$ like '%rity constraint (REFSTG.STRN_STRT_FK) %' 
minus
select b.TYP_LOC_FROM_CODE,b.TYP_LOC_TO_CODE,b.TYP_MOVEMENT_CODE--,y.strn_credit_or_debit_code,count(*),sum(STRN_COST_VALUE) 
from dw.stock_trn_report_type b )
select distinct a.*--,k.strn_transaction_date
from a, STOCK_TRANSACTIONS_SUS k
where k.strn_location_to_code = a.strn_location_to_code
and k.strn_location_from_code = a.strn_location_from_code
and k.strn_movement_code = a.strn_movement_code


group by y.strn_location_to_code,y.strn_location_from_code,y.strn_movement_code,y.strn_credit_or_debit_code
order by sum(STRN_COST_VALUE) desc
3	GR	RTWM	301	S	2	10801.89
4	RTWM	GR	301	H	2	10801.83


select * from dw.stock_trn_report_type;
select * from dw.stock_trn_location_type;
select * from dw.stock_trn_movement_type

select * from dw.stock_trn_report_type where TYP_LOC_TO_CODE='####' and TYP_LOC_FROM_CODE='####' and TYP_MOVEMENT_CODE = 301 for update --and TYP_CREDIT_DEBIT_FLAG='S' ;
select y.strn_location_from_code,y.strn_location_to_code,y.strn_movement_code--,y.strn_credit_or_debit_code,count(*),sum(STRN_COST_VALUE) 
from STOCK_TRANSACTIONS_SUS y 
where ORA_ERR_MESG$ like '%rity constraint (REFSTG.STRN_STRT_FK) %' 
and 

select * from dw.stock_trn_report_type where TYP_LOC_TO_CODE='WAS' and TYP_LOC_FROM_CODE='GR' for update

select  dw.stock_trn_report_type_seq.nextval from dual

49544

