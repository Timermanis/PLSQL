select * from plant_issues_sus 
--------------------------------------
select ORA_ERR_MESG$,count(*) from plant_issues_sus
group by ORA_ERR_MESG$
--------------------------------------
select * from plant_issues_sus where ORA_ERR_MESG$ like '%REFSTG"."PLANT_ISSUES_CC"."PLIS_PU%' and PLIS_ISSUE_NUM = 41582129
--------------------------------------
select PLIS_COMPANY_NUM,count(*) from plant_issues_sus where ORA_ERR_MESG$ like '%REFSTG"."PLANT_ISSUES_CC"."PLIS_PU%'
group by PLIS_COMPANY_NUm
-------------------------------------
select * from refmast.plant_issues where PLIS_ISSUE_NUM like '%41582129';
select * from refmast.issues where ISS_NUM like '%41582129';
-------------------------------------
select * from refmast.products where prod_NUM = 4158;
-------------------------------------Select statement for DELETE
select distinct pl.PLIS_PLANT_NUM,pl.PLIS_ISSUE_NUM,(trunc(substr(concat('0',PLIS_ISSUE_NUM),-9,5))),pr.prod_NUM  from plant_issues_sus pl,refmast.products pr  
where  (trunc(substr(concat('0',PLIS_ISSUE_NUM),-9,5))) = pr.prod_NUM  and PLIS_UPDATE_FLAG_WRK ='D'
---------------------------------------move data to BIN table
create table plant_issues_bin as 
select *  from plant_issues_sus pl where (pl.PLIS_PLANT_NUM,pl.PLIS_ISSUE_NUM) in 
(select distinct pl.PLIS_PLANT_NUM,pl.PLIS_ISSUE_NUM  from plant_issues_sus pl,refmast.products pr  
where  (trunc(substr(concat('0',PLIS_ISSUE_NUM),-9,5))) = pr.prod_NUM  and PLIS_UPDATE_FLAG_WRK ='D' )
--------------------------------------DELETE statement for plant_issues_sus
delete from plant_issues_bin where (PLIS_PLANT_NUM,PLIS_ISSUE_NUM) in
(select distinct pl.PLIS_PLANT_NUM,pl.PLIS_ISSUE_NUM  from plant_issues_sus pl,refmast.products pr  
where  (trunc(substr(concat('0',PLIS_ISSUE_NUM),-9,5))) = pr.prod_NUM  and PLIS_UPDATE_FLAG_WRK ='D' )
--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
--///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
-------------------------------------1Select statement for DELETE
select p.* from refmast.issues i,plant_issues_sus p where i.ISS_NUM =  p.plis_issue_num and i.iss_update_flag_wrk = 'D'
---------------------------------------1
select * from plant_issues_bin
---------------------------------------1move data to BIN table
insert into plant_issues_bin 
(select p.*, 'JTIMERMANIS',  sysdate from refmast.issues i,plant_issues_sus p where i.ISS_NUM =  p.plis_issue_num and i.iss_update_flag_wrk = 'D')
--------------------------------------1.DELETE statement for plant_issues_sus
delete from plant_issues_sus where (PLIS_PLANT_NUM,PLIS_ISSUE_NUM) in
(select p.PLIS_PLANT_NUM,p.PLIS_ISSUE_NUM from refmast.issues i,plant_issues_sus p where i.ISS_NUM =  p.plis_issue_num and i.iss_update_flag_wrk = 'D')
------------------------------------1
select * from support.plant_issues_bin
--drop table support.plant_issues_bin
--------------------------------------
select * from refmast.issues i,plant_issues_sus p where i.ISS_PARENT_ISS_NUM =  p.plis_issue_num and i.iss_update_flag_wrk = 'D'

