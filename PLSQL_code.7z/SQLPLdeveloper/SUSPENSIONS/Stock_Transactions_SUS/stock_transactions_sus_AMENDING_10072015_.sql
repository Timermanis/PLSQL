select * from ZPX_ST_LTYP_STG_BAK t -- transaction types

select * from stock_transactions_sus
where STRN_LOCATION_TO_CODE =  STRN_LOCATION_FROM_CODE
--order by  strn_issue_num,strn_transaction_date

select ora_err_mesg$, count(*)
from stock_transactions_sus
group by ora_err_mesg$

-- check issues to be used
select * -- i.iss_name
from refmast.issues i 
where --i.iss_name like  'DR WHO% PART%' -- '%VAT %'
i.iss_type_code = 'Z4'
order by iss_num

select *
from refmast.plant_issues
where plis_issue_num in (297082057,350180088)
and plis_plant_num = '560'

-- list of issues in sus that are VAT issues before the cutover
insert into stock_transactions_bin(
select * 
from stock_transactions_sus s2
where s2.strn_issue_num in (
 select distinct sts.strn_issue_num
 from 
 stock_transactions_sus sts,
  (select i2.iss_product_num prod, min( i2.iss_num) iss
   from  refmast.issues i2,stock_transactions_sus sts 
   where i2.iss_product_num = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4) 
   and  i2.iss_name like '%VAT %'
   and i2.iss_type_code = 'Z4'
   group by i2.iss_product_num) first_iss
 where first_iss.prod = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4)
 and sts.strn_issue_num < first_iss.iss))

order by 1
-------------------------prepearing for cleaning up
select  sts.*
from 
stock_transactions_sus sts,
(select i2.iss_product_num prod, min( i2.iss_num) iss
from  refmast.issues i2,stock_transactions_sus sts 
 where i2.iss_product_num = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4) 
 and  i2.iss_name like '%VAT %'
and i2.iss_type_code = 'Z4'
group by i2.iss_product_num) first_iss
where first_iss.prod = substr(sts.strn_issue_num,1,length(sts.strn_issue_num)-4)
and sts.strn_issue_num < first_iss.iss
order by 1

select * from refmast.issues where ISS_HANDLED_YEAR_M <2010
---------------------select all issues from stock_transactions_sus where is a record in refmast.issues
select distinct s.STRN_ISSUE_NUM,s.* from stock_transactions_sus s, refmast.issues i
where i.iss_product_num = substr(s.strn_issue_num,1,length(s.strn_issue_num)-4) -- join tables
and ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%'--select this error type
----------------------create BIN table-------------------
--create table stock_transactions_bin_030714 as 
(select * from stock_transactions_sus s where s.STRN_ISSUE_NUM  not in 
(select  distinct s.STRN_ISSUE_NUM from stock_transactions_sus s, refmast.issues i
where i.iss_product_num = substr(s.strn_issue_num,1,length(s.strn_issue_num)-4) 
and ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%')
and ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%'
)



------------------------------------------------ SUS combinations
select STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG,count(*), sum(strn_cost_value) from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%' --1525 rows 
--and  STRN_LOCATION_FROM_CODE = 'GR'
group by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG
order by sum(strn_cost_value) desc, count(*) desc

order by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG

select distinct STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG
 from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%' --1525 rows 
and  STRN_LOCATION_FROM_CODE = 'SBR'
order by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG

------------------------------------------------- DW.STOCK_TRN_REPORT_TYPE is not updated TEST
select * from DW.STOCK_TRN_REPORT_TYPE
where TYP_LOC_FROM_CODE  ='OVSR' and TYP_LOC_TO_CODE = 'SBR'

and  TYP_LOC_TO_CODE  ='GR'
--TYP_MOVEMENT_CODE   ='301'
--and TYP_CREDIT_DEBIT_FLAG   ='H'
--and TYP_INTERBRANCH_FLAG ='1'
-----------------------------------------------1. missing MOVEMENT_CODE in DW.STOCK_TRN_REPORT_TYPE 7 records
select distinct (STRN_MOVEMENT_CODE) from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%'
and STRN_MOVEMENT_CODE not in (select distinct(TYP_MOVEMENT_CODE) from DW.STOCK_TRN_REPORT_TYPE)
-----------------------------------------------2. missing TYP_LOC_FROM_CODE in DW.STOCK_TRN_REPORT_TYPE 0 records
select distinct (STRN_LOCATION_FROM_CODE) from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%'
and STRN_LOCATION_FROM_CODE not in (select distinct(TYP_LOC_FROM_CODE) from DW.STOCK_TRN_REPORT_TYPE)
-----------------------------------------------3. missing TYP_LOC_TO_CODE in DW.STOCK_TRN_REPORT_TYPE 0 records
select distinct (STRN_LOCATION_TO_CODE) from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%'
and STRN_LOCATION_TO_CODE not in (select distinct(TYP_LOC_TO_CODE) from DW.STOCK_TRN_REPORT_TYPE)
-----------------------------------------------4. missing MOVEMENT_CODE in DW.STOCK_TRN_REPORT_TYPE 0 records
select distinct ( STRN_CREDIT_OR_DEBIT_CODE) from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%'
and  STRN_CREDIT_OR_DEBIT_CODE not in (select distinct( TYP_CREDIT_DEBIT_FLAG) from DW.STOCK_TRN_REPORT_TYPE)



select * from DW.STOCK_TRN_REPORT_TYPE where 



select * from stock_transactions_sus
--where (STRN_LOCATION_FROM_CODE='SBR' and STRN_LOCATION_TO_CODE='GR' and STRN_MOVEMENT_CODE= '301' and STRN_CREDIT_OR_DEBIT_CODE ='H' and STRN_INTERBRANCH_FLAG=1 and rownum<3)
--where (STRN_LOCATION_FROM_CODE='GR' and STRN_LOCATION_TO_CODE='SBR' and STRN_MOVEMENT_CODE= '301' and STRN_CREDIT_OR_DEBIT_CODE ='S' and STRN_INTERBRANCH_FLAG=1 and rownum<3)
--where (STRN_LOCATION_FROM_CODE='OVS' and STRN_LOCATION_TO_CODE='RTWM' and STRN_MOVEMENT_CODE= '301' and STRN_CREDIT_OR_DEBIT_CODE ='H' and STRN_INTERBRANCH_FLAG=1 and rownum<3)
--where (STRN_LOCATION_FROM_CODE='RTWM' and STRN_LOCATION_TO_CODE='OVS' and STRN_MOVEMENT_CODE= '301' and STRN_CREDIT_OR_DEBIT_CODE ='S' and STRN_INTERBRANCH_FLAG=1 and rownum<3)
where(STRN_LOCATION_FROM_CODE='GR' and STRN_LOCATION_TO_CODE='####' and STRN_MOVEMENT_CODE= '642' and STRN_CREDIT_OR_DEBIT_CODE ='S' and STRN_INTERBRANCH_FLAG=0 and rownum<3)




create table support.stock_transactions_temp as
(select * from DW.STOCK_TRN_REPORT_TYPE where typ_id in (107,623,35908,15167,14278))
--------------------------------------------------After Data provided by Frank Etherson <Frank.Etherson@menziesdistribution.com>
select typ_id,TYP_LOC_FROM_CODE, TYP_LOC_TO_CODE, TYP_MOVEMENT_CODE, TYP_CREDIT_DEBIT_FLAG, TYP_INTERBRANCH_FLAG from DW.STOCK_TRN_REPORT_TYPE where typ_id in (107,623,35908,15167,14278)
--
select * from DW.STOCK_TRN_REPORT_TYPE where typ_id in (107,623,35908,15167,14278)
--
select * from support.stock_transactions_temp;
select * from support.stock_transactions_temp_v2 for update
select STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG,count(*), sum(strn_cost_value) from stock_transactions_sus s
where ora_err_mesg$ like '%REFSTG.STRN_STRT_FK%' --1525 rows 
--and  STRN_LOCATION_FROM_CODE = 'GR'
group by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG
order by sum(strn_cost_value) desc, count(*) desc
--------------------------------------------------------INSERT-------------
--update support.stock_transactions_temp_v2
set DIMENSION_KEY = support.jt_sus_26_06_14_seq.nextval,typ_id=support.jt_sus_26_06_14_seq.nextval where dimension_key in (107,623,14278,15167,35908);
------------UPDATE dw sequence into support table
update support.stock_transactions_temp_v2
set DIMENSION_KEY = dw.stock_trn_report_type_seq.nextval,typ_id = dw.stock_trn_report_type_seq.nextval where dimension_key in (107,623,14278,15167,35908);
---------------INSERT support.stock_transactions_temp_v2 into DW.STOCK_TRN_REPORT_TYPE
insert into DW.STOCK_TRN_REPORT_TYPE (select * from support.stock_transactions_temp_v2)
----------------

select * from  DW.STOCK_TRN_REPORT_TYPE where DIMENSION_KEY = 107
---------------------------21082014
select STRN_MOVEMENT_CODE, s.strn_location_to_code,count (*) from stock_transactions_sus s 
where s.strn_location_to_code = '####' group by STRN_MOVEMENT_CODE,s.strn_location_to_code --strn_location_to_code = ####
select STRN_MOVEMENT_CODE, s.strn_location_to_code,count (*) from stock_transactions_sus s 
where s.strn_movement_code in ('161','505','551','101')and s.strn_location_to_code = '####' group by STRN_MOVEMENT_CODE,s.strn_location_to_code
select STRN_MOVEMENT_CODE, s.strn_location_from_code,count (*) from stock_transactions_sus s 
where s.strn_location_from_code = '####' group by STRN_MOVEMENT_CODE,s.strn_location_from_code --strn_location_to_code = ####
------
select STRN_SPOKE_NUM,
STRN_ISSUE_NUM,
STRN_TRANSACTION_DATE,
STRN_LOCATION_TO_CODE,
STRN_LOCATION_FROM_CODE,
STRN_MOVEMENT_CODE,
STRN_CREDIT_OR_DEBIT_CODE,
STRN_CURRENCY_CODE,
STRN_QUANTITY,
STRN_COST_VALUE,
STRN_SRC_DOCUMENT_NUM,
STRN_SRC_ITEM_NUM,
STRN_DWH_NUM,
STRN_TIMESTAMP,
STRN_TRANSACTION_DATE_NUM,
STRN_ISSUE_START_DATE,
STRN_SEQ_NO,
STRN_VENDOR_NUM,
STRN_ADVISED_QTY,
STRN_RETAIL_NET_VALUE,
STRN_RETAIL_VAT_VALUE,
STRN_TRADE_NET_VALUE,
STRN_TRADE_VAT_VALUE,
STRN_COST_VAT_VALUE,
STRN_PF_RUN_NUM,
STRN_ISSUE_PUB_DATE,
STRN_COMPANY_NUM,
STRN_INTERBRANCH_FLAG,
STRN_INTERBRANCH_PLANT_NUM
 from stock_transactions_sus s where s.strn_movement_code in ('161','505','551','101')and s.strn_location_to_code = '####' order by STRN_MOVEMENT_CODE
--------------------------
select 
*

 from stock_transactions_sus s where s.strn_movement_code in ('161','505','551','101')and s.strn_location_to_code = '####' order by STRN_MOVEMENT_CODE

------------------------
select STRN_MOVEMENT_CODE, count (*) from stock_transactions_sus s  group by STRN_MOVEMENT_CODE--group by STRN_MOVEMENT_CODE
select * from stock_transactions_sus s where STRN_MOVEMENT_CODE='311'--where STRN_MOVEMENT_CODE='311'
select t.strn_location_to_code,count (*) from STOCK_TRANSACTIONS_SUS t group by strn_location_to_code order by count (*)--group by strn_location_to_code
select t.strn_location_from_code,count (*) from STOCK_TRANSACTIONS_SUS t group by strn_location_from_code order by count (*)--group by strn_location_from_code
select t.strn_location_from_code,t.strn_location_to_code,count (*) from STOCK_TRANSACTIONS_SUS t group by strn_location_from_code,t.strn_location_to_code order by count (*)
select s.strn_spoke_num,s.strn_issue_num,s.strn_location_to_code,s.strn_location_from_code,s.ora_err_mesg$,s.strn_transaction_date_num from stock_transactions_sus s 
where s.strn_location_from_code='GR' and s.strn_location_to_code = '####' order by s.strn_transaction_date_num
-----------------------------020914--------------------
select STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG,count(*), sum(strn_cost_value) from stock_transactions_sus s
where ora_err_mesg$ like '%STRN_ISSUE_START_DATE%' --1525 rows 
group by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG
order by sum(strn_cost_value) desc, count(*) desc
---------------------------------------------------
select * from refstg.stock_transactions_sus
where (STRN_LOCATION_FROM_CODE='WAS' and STRN_LOCATION_TO_CODE='####' and STRN_MOVEMENT_CODE= '551' and STRN_CREDIT_OR_DEBIT_CODE ='H' and STRN_INTERBRANCH_FLAG=0) 
and   substr(STRN_TRANSACTION_DATE,8,4)<14
and ora_err_mesg$ like '%STRN_ISSUE_START_DATE%' 
------------------------080914-------------------------
select * from plant_issues_xref_base
-----------------------------------------------------------
insert into refstg.stock_transactions_bin 
select distinct s.*,'JTIMERMANIS',sysdate from refstg.stock_transactions_sus s,refmast.plant_issues_xref_base p--distinct s.* 
where s.STRN_ISSUE_NUM = to_number(PIX_SAP_ID)
and s.STRN_SPOKE_NUM = substr(PIX_BRANCH_CODE,4,3)
and(s.STRN_LOCATION_FROM_CODE='WAS' and s.STRN_LOCATION_TO_CODE='####' and s.STRN_MOVEMENT_CODE= '551' and s.STRN_CREDIT_OR_DEBIT_CODE ='H' and s.STRN_INTERBRANCH_FLAG=0) 
and   substr(s.STRN_TRANSACTION_DATE,8,4)<14
and s.ora_err_mesg$ like '%STRN_ISSUE_START_DATE%'
and (p.pix_year is null and p.pix_week is null and p.pix_day is null)
-------------------------------------------------------
delete from refstg.stock_transactions_sus 
where (STRN_ISSUE_NUM,STRN_SPOKE_NUM,STRN_SRC_DOCUMENT_NUM) in (select  s.STRN_ISSUE_NUM,s.STRN_SPOKE_NUM,s.STRN_SRC_DOCUMENT_NUM from refstg.stock_transactions_sus s,refmast.plant_issues_xref_base p
where s.STRN_ISSUE_NUM = to_number(PIX_SAP_ID)
and s.STRN_SPOKE_NUM = substr(PIX_BRANCH_CODE,4,3)
and(s.STRN_LOCATION_FROM_CODE='WAS' and s.STRN_LOCATION_TO_CODE='####' and s.STRN_MOVEMENT_CODE= '551' and s.STRN_CREDIT_OR_DEBIT_CODE ='H' and s.STRN_INTERBRANCH_FLAG=0) 
and   substr(s.STRN_TRANSACTION_DATE,8,4)<14
and s.ora_err_mesg$ like '%STRN_ISSUE_START_DATE%'
and (p.pix_year is null and p.pix_week is null and p.pix_day is null))
