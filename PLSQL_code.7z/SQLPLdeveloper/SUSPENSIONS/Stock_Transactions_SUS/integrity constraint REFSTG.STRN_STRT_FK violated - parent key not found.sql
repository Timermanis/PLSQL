select * from stock_transactions_sus s where ORA_ERR_MESG$ like '%integrity constraint (REFSTG.STRN_STRT_FK) violated - parent key not found%' 
and s.strn_location_from_code = '####'
and STRN_LOCATION_TO_CODE = '####'
--and STRN_MOVEMENT_CODE = 'ZO1'
and STRN_CREDIT_OR_DEBIT_CODE = 'S'
and STRN_INTERBRANCH_FLAG =0

select STRN_ISSUE_NUM, count(*),sum(STRN_COST_VALUE) from STOCK_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '%integrity constraint (REFSTG.STRN_STRT_FK) violated - parent key not found%' 
 group by STRN_ISSUE_NUM order by count(*) desc
 
 select STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG,sum(STRN_COST_VALUE),count(*) from STOCK_TRANSACTIONS_SUS 
 where ORA_ERR_MESG$ like '%integrity constraint (REFSTG.STRN_STRT_FK) violated - parent key not found%' 
 group by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG order by count(*) desc
 
 insert into DW.STOCK_TRN_REPORT_TYPE (DIMENSION_KEY,TYP_ID,TYP_LOC_FROM_CODE,TYP_LOC_TO_CODE,TYP_MOVEMENT_CODE,TYP_CREDIT_DEBIT_FLAG,TYP_REPORTING_OBJECT,TYP_INTERBRANCH_FLAG) values
(dw.stock_trn_report_type_seq.nextval,dw.stock_trn_report_type_seq.nextval,'CLM', '9988','311','S','To allow suspended records load 240815',0) 

 select * from refstg.stock_transactions_sus where ORA_ERR_MESG$ like '%integrity constraint (REFSTG.STRN_STRT_FK) violated - parent key not found%' 

select * from stock_transactions_sus where STRN_ISSUE_NUM=90274169

 select * from refmast.stock_trn_movement_types
 select * from  refmast.stock_trn_location_types
 -----------------not processed yet--------------------
select * from  dw.stock_trn_report_type r where r.typ_loc_from_code = '####' and r.typ_loc_to_code = '####' and r.typ_credit_debit_flag = 'S' for update --162
select * from  dw.stock_trn_report_type r where r.typ_loc_from_code = 'SBR' and r.typ_loc_to_code = 'OVSR' and r.typ_credit_debit_flag = 'H' for update --343


select dw.stock_trn_report_type_seq.nextval from dual--49763 for OVSR SBR
