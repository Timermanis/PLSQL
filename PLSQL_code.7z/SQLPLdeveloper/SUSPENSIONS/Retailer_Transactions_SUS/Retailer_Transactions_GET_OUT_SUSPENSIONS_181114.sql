select * from support.JT_RETAILER_TRN_REPORT_TYPE
insert into retailer_trn_report_type select * from support.JT_RETAILER_TRN_REPORT_TYPE
select * from all_db_links
select * from retailer_trn_report_type where dimension_key in (12461,392)
