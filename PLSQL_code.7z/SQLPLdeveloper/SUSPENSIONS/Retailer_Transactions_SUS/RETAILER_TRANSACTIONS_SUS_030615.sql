select RTRN_ISSUE_NUM,count( *) from retailer_TRANSACTIONS_SUS y --
where ORA_ERR_MESG$ like '%ORA-01400: cannot insert NULL into ("REFSTG"."RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_NUM")%'
--and RTRN_ISSUE_NUM like '%0001'
group by RTRN_ISSUE_NUM order by count (*) desc

select ORA_ERR_MESG$,count( *) from retailer_TRANSACTIONS_SUS y --
--where ORA_ERR_MESG$ like '%ot insert NULL into ("REFSTG"."RETAILER_TRANSACTIONS_CC"."RT%' and RTRN_DOCUMENT_TYPE_CODE not like '#%'
group by ORA_ERR_MESG$ order by count (*) desc

with a
as
(select RTRN_ISSUE_NUM ,count( *) b from retailer_TRANSACTIONS_SUS y --
where ORA_ERR_MESG$ like '%ot insert NULL into ("REFSTG"."RETAILER_TRANSACTIONS_CC"."RT%' and RTRN_DOCUMENT_TYPE_CODE not like '#%'
group by RTRN_ISSUE_NUM) 
select sum (b) from a


select count(*) from retailer_TRANSACTIONS_SUS where RTRN_DOCUMENT_TYPE_CODE  like '#%'and RTRN_ITEM_TYPE_CODE like '#%'
select * from retailer_TRANSACTIONS_bin
--insert into retailer_TRANSACTIONS_bin p
(select p.*, 'JTIMERMANIS',  sysdate from retailer_TRANSACTIONS_SUS p where RTRN_DOCUMENT_TYPE_CODE  like '#%'and RTRN_ITEM_TYPE_CODE like '#%')
--delete from retailer_TRANSACTIONS_SUS  where RTRN_DOCUMENT_TYPE_CODE  like '#%'and RTRN_ITEM_TYPE_CODE like '#%'

--Highest count sus records for issue 460630001,461120001,460630002 are document/item_type #001,#002 so we skip it beause they are not used in iknow 


select * from retailer_TRANSACTIONS_SUS y --
--where ORA_ERR_MESG$ like '%ot insert NULL into ("REFSTG"."RETAILER_TRANSACTIONS_CC"."RT%' 
where RTRN_ISSUE_NUM=100000014380040 and RTRN_TRANSACTION_DATE = to_date('11/05/2015','dd/mm/yyyy')
 

select * from refmast.plant_issues where PLIS_ISSUE_NUM = 351570005--375170001--460630001

select * from plant_issues_sus where PLIS_ISSUE_NUM = 460630001
select * from issues_sus where ISS_NUM = 375170001--460630001
select * from sales_organisation_issues_sus where SOIS_ISSUE_NUM = 460630001
select * from refmast.issues where ISS_NUM = 375170001--460630001
select * from refmast.products where prod_num = 35157--37517
