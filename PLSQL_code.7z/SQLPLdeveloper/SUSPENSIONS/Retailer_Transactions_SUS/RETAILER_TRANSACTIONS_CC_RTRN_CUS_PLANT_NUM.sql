select  * from  RETAILER_TRANSACTIONS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RTRN_TIMESTAMP,9),'dd-MON-yy')>180 --missing customer
and ORA_ERR_MESG$ like '%LER_TRANSACTIONS_CC"."RTRN_CUS_PLANT_%' 

insert into retailer_TRANSACTIONS_bin
select t.*,'JT reverse',sysdate from retailer_TRANSACTIONS_SUS t where ORA_ERR_MESG$ like '%LER_TRANSACTIONS_CC"."RTRN_CUS_PLANT_%' 
and to_date(sysdate,'dd-MON-yy')-to_date(rpad(RTRN_TIMESTAMP,9),'dd-MON-yy')>180

delete from retailer_TRANSACTIONS_SUS t where ORA_ERR_MESG$ like '%LER_TRANSACTIONS_CC"."RTRN_CUS_PLANT_%' 
and to_date(sysdate,'dd-MON-yy')-to_date(rpad(RTRN_TIMESTAMP,9),'dd-MON-yy')>180
