select ORA_ERR_MESG$,count(*) from refstg.RETAILER_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '%Suspended because a referenced Customer or Plant Issue is%'
group by ORA_ERR_MESG$
--ORA-01400: cannot insert NULL into ("REFSTG"."RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_NUM")


select * from RETAILER_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '%Suspended because a referenced Customer or Plant Issue is%' and RTRN_ISSUE_NUM = 261462159
select * from REFSTG.RETAILER_TRANSACTIONS_CC where rtrn_issue_num = 403260014-- 477070001
select * from dw.RETAILER_TRANSACTION t where t.outlet_id =111425
select * from dw.latest_product_mv where prod_num = '100000012550002'
select * from plant_issues_sus p where p.plis_issue_num = 403260014
select * from issues_sus i where i.ora_err_mesg$ like '%ISS_CHLD_VAT_UK%'

select RTRN_ISSUE_NUM,count(*) from RETAILER_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '%uspended because a referenced Customer%' group by RTRN_ISSUE_NUM
,RTRN_SUPPLY_PHASE_CODE having RTRN_SUPPLY_PHASE_CODE like '%ORBIT%' order by count (*) desc 


RTRN_ISSUE_NUM, COUNT(*)
474910001	625
474180001	980



select count(*) from RETAILER_TRANSACTIONS_SUS where RTRN_TRANSACTION_DATE < to_date ('01/01/2014','dd/mm/yyyy')
and ORA_ERR_MESG$ like '%RTRN_PRODUCT_NUM%';-- 10/09/14 (1423) on monitoring
--group by RTRN_TRANSACTION_DATE

select * from RETAILER_TRANSACTIONS_SUS where RTRN_TRANSACTION_DATE = to_date ('02/11/2013','dd/mm/yyyy')

select RTRN_TRANSACTION_DATE,RTRN_ISSUE_NUM,count(*) from RETAILER_TRANSACTIONS_SUS where /*RTRN_TRANSACTION_DATE < to_date ('01/01/2014','dd/mm/yyyy')
and*/ ORA_ERR_MESG$ like '%RTRN_PRODUCT_NUM%' and RTRN_ISSUE_NUM > 100000000000000
group by RTRN_ISSUE_NUM,RTRN_TRANSACTION_DATE order by count(*)desc

select RTRN_TRANSACTION_DATE,RTRN_ISSUE_NUM,count(*) from RETAILER_TRANSACTIONS_SUS where RTRN_TRANSACTION_DATE > to_date ('02/09/2014','dd/mm/yyyy')
group by RTRN_ISSUE_NUM,RTRN_TRANSACTION_DATE

select * from refmast.issues where iss_num = 131652235;

insert into RETAILER_TRANSACTIONS_bin
select s.*,'JTIMERMANIS', sysdate 
from RETAILER_TRANSACTIONS_SUS s where RTRN_TRANSACTION_DATE < to_date ('01/01/2014','dd/mm/yyyy')
and ORA_ERR_MESG$ like '%RTRN_PRODUCT_NUM%';

delete from RETAILER_TRANSACTIONS_SUS  where RTRN_TRANSACTION_DATE < to_date ('01/01/2014','dd/mm/yyyy')
and ORA_ERR_MESG$ like '%RTRN_PRODUCT_NUM%';--deleted 1423 rows 19/09/2014

--15/10/14 removed 966 for the rtrn_issue_num because there is no plant_issue since 15/02/2014 and have never been before
insert into RETAILER_TRANSACTIONS_bin 
select s.*,'JTIMERMANIS', sysdate 
from RETAILER_TRANSACTIONS_SUS s where ORA_ERR_MESG$ like '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_%' and s.rtrn_transaction_date < sysdate - 160
and  rtrn_transaction_date <='01-JAN-2015'

delete from RETAILER_TRANSACTIONS_SUS  where ORA_ERR_MESG$ like '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_%' and rtrn_transaction_date < sysdate - 160
and  rtrn_transaction_date <='01-JAN-2015'

select * from RETAILER_TRANSACTIONS_SUS f where ORA_ERR_MESG$ like '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_%' and f.rtrn_transaction_date < sysdate - 160
and  rtrn_transaction_date <='01-JAN-2015'
