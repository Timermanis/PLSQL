select ORA_ERR_MESG$,count(*) from RETAILER_TRANSACTIONS_SUS --"RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_NUM
group by ORA_ERR_MESG$;
-----------------------------Select from '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_NUM%';
select count(RTRN_ISSUE_NUM),RTRN_ISSUE_NUM,length(RTRN_ISSUE_NUM)   from RETAILER_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_NUM%'
group by RTRN_ISSUE_NUM having length(RTRN_ISSUE_NUM)=15 and count(RTRN_ISSUE_NUM)>100 order by count(LENGTH(RTRN_ISSUE_NUM)) desc;
-------------------------------------
select * from RETAILER_TRANSACTIONS_sus r where LENGTH(r.RTRN_ISSUE_NUM)= 15; --5574
-------------------------------------
select * from RETAILER_TRANSACTIONS_sus r where RTRN_ISSUE_NUM= 100000006290001;
select sum(RTRN_RETAIL_VALUE_EXCL_VAT*RTRN_QUANTITY) from RETAILER_TRANSACTIONS_sus r where RTRN_ISSUE_NUM= 100000006290001;
--------------------------------------
select r.rtrn_trans_plant_num, count(r.rtrn_trans_plant_num) from refstg.RETAILER_TRANSACTIONS_SUS r where ORA_ERR_MESG$ like '%integrity constraint (REFSTG.RTRN_RTRT_FK) violated -%'
--and r.rtrn_issue_num = 460630001
group by r.rtrn_trans_plant_num;
-----------------------
--ORA-01400: cannot insert NULL into ("REFSTG"."RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_NUM");
------------------------
select * from RETAILER_TRANSACTIONS_CC r where LENGTH(r.RTRN_ISSUE_NUM) in (5,15);
---------------------------------------
select to_number(issue_id),z.*  from zpx_rtrn_cdn_stg_bak z where length (to_number(issue_id))=15 ;
select *  from archive.zpx_rtrn_cdn_stg_bak z where  ltrim(issue_id)like '100000012550002';
-----------------------------------------Select transactions for last two days----------------467270007
select * from RETAILER_TRANSACTIONS_sus where RTRN_TRANSACTION_DATE < to_date('01/01/2014','dd/mm/yyyy')
--------------
select * from RETAILER_TRANSACTIONS_sus where RTRN_ISSUE_PUB_DATE > sysdate
---------------
select iss_name,min (ISS_PUBLICATION_DATE),max(ISS_INVOICE_DATE_M)  from RETAILER_TRANSACTIONS_sus 
group by iss_name, (ISS_PUBLICATION_DATE),(ISS_INVOICE_DATE_M)
----------------
select * from rETAILER_TRANSACTIONS_bin
----------------------------------------------121114-----------------------------------------------------------------------------------------------------------------------
select * from RETAILER_TRANSACTIONS_SUS --
where ORA_ERR_MESG$ like '%constraint (REFSTG.RTRN_RTRT_FK) violated%';
select * from RETAILER_TRANSACTIONS_SUS r --
where ORA_ERR_MESG$ like '%constraint (REFSTG.RTRN_RTRT_FK) violated%' and r.rtrn_issue_num=460290001;
--ORA-02291: integrity constraint (REFSTG.RTRN_RTRT_FK) violated - parent key not found
select RTRN_ISSUE_NUM,RTRN_DOCUMENT_TYPE_CODE, RTRN_ITEM_TYPE_CODE, RTRN_ORIG_DOCUMENT_TYPE_CODE, RTRN_ORIG_ITEM_TYPE_CODE, RTRN_SUPPLY_PHASE_CODE, RTRN_ACTY_CRED_REF_REASON_FLAG from RETAILER_TRANSACTIONS_SUS r --
where  r.rtrn_issue_num=460290001;
select * from dw.RETAILER_TRN_REPORT_TYPE where 
RTRN_DOCUMENT_TYPE_CODE	RTRN_ITEM_TYPE_CODE	RTRN_ORIG_DOCUMENT_TYPE_CODE	RTRN_ORIG_ITEM_TYPE_CODE	RTRN_SUPPLY_PHASE_CODE	RTRN_ACTY_CRED_REF_REASON_FLAG
2	ZRRC	ZRID	ZOV	ZO1	N/A	0
---TYP_DOCUMENT_TYPE_CODE, TYP_ITEM_TYPE_CODE, TYP_ORIG_DOCUMENT_TYPE_CODE, TYP_ORIG_ITEM_TYPE_CODE, TYP_SUPPLY_PHASE_CODE, TYP_ACTY_CRED_REF_REASON_FLAG
select *
 from dw.RETAILER_TRN_REPORT_TYPE r where r.typ_document_type_code = 'JTA' and r.TYP_ITEM_TYPE_CODE='ZDNP' and TYP_ORIG_DOCUMENT_TYPE_CODE='ZOV' and
 TYP_ORIG_ITEM_TYPE_CODE, TYP_SUPPLY_PHASE_CODE, TYP_ACTY_CRED_REF_REASON_FLAG
 
 
select *
 from dw.RETAILER_TRN_REPORT_TYPE r where r.typ_document_type_code = 'ZRRC' and r.TYP_ITEM_TYPE_CODE='ZRID' and TYP_ORIG_DOCUMENT_TYPE_CODE='ZOV'




select *from RETAILER_TRANSACTIONS_SUS y --
where ORA_ERR_MESG$ like '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT%' order by y.rtrn_transaction_date;


select RTRN_ISSUE_NUM,y.rtrn_trans_plant_num, count(*)from RETAILER_TRANSACTIONS_SUS y --
where ORA_ERR_MESG$ like '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT%'
group by RTRN_ISSUE_NUM,y.rtrn_trans_plant_num order by count(*) desc;

STOCK_TRANSACTIONS_SUS
select ORA_ERR_MESG$,count(*) from STOCK_TRANSACTIONS_SUS --"RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_NUM
group by ORA_ERR_MESG$;
