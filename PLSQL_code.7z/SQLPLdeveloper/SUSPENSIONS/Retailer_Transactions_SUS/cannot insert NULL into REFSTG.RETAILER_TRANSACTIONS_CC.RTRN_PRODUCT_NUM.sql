--Usually missing plant issues for a plant. Let material master group about the problem adding snapshot in email.
select RTRN_ISSUE_NUM,RTRN_SUPPLY_PHASE_CODE,RTRN_TRANS_PLANT_NUM,count( *) from retailer_TRANSACTIONS_SUS y --
where ORA_ERR_MESG$ like '%ORA-01400: cannot insert NULL into ("REFSTG"."RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_NUM")%'
--and RTRN_ISSUE_NUM  like '%9999'
group by RTRN_ISSUE_NUM,RTRN_SUPPLY_PHASE_CODE,RTRN_TRANS_PLANT_NUM order by count (*) desc 

select * from plant_issues_sus p  where p.plis_issue_num=100000027290001

select * from retailer_TRANSACTIONS_SUS s where RTRN_ISSUE_NUM=100000027290001 --and s.rtrn_trans_plant_num in (20,220,350,550,560,740)
select RTRN_TRANS_PLANT_NUM from retailer_TRANSACTIONS_SUS s where RTRN_ISSUE_NUM=100000027290001 group by RTRN_TRANS_PLANT_NUM --550
select RTRN_TRANS_PLANT_NUM from retailer_TRANSACTIONS_SUS s where RTRN_ISSUE_NUM=100000006870002 group by RTRN_TRANS_PLANT_NUM --740
select RTRN_TRANS_PLANT_NUM from retailer_TRANSACTIONS_SUS s where RTRN_ISSUE_NUM=100000009180001 group by RTRN_TRANS_PLANT_NUM --550
select RTRN_TRANS_PLANT_NUM from retailer_TRANSACTIONS_SUS s where RTRN_ISSUE_NUM=48852341 group by RTRN_TRANS_PLANT_NUM --470
select RTRN_TRANS_PLANT_NUM from retailer_TRANSACTIONS_SUS s where RTRN_ISSUE_NUM=100000008410001 group by RTRN_TRANS_PLANT_NUM --550
select RTRN_TRANS_PLANT_NUM from retailer_TRANSACTIONS_SUS s where RTRN_ISSUE_NUM=44972341 group by RTRN_TRANS_PLANT_NUM --470
select RTRN_TRANS_PLANT_NUM from retailer_TRANSACTIONS_SUS s where RTRN_ISSUE_NUM=42852340 group by RTRN_TRANS_PLANT_NUM --470
select RTRN_TRANS_PLANT_NUM from retailer_TRANSACTIONS_SUS s where RTRN_ISSUE_NUM=100000014410057 group by RTRN_TRANS_PLANT_NUM --740
select * from dw.retailer_TRANSACTION d where d.plant_issue_id=48852341

select * from refmast.plant_issues p where p.plis_issue_num = 48852341
    RTRN_ISSUE_NUM  RTRN_SUPPLY_PHASE_CODE  COUNT(*)
1 100000027290001 N/A 316
2 100000006870002 N/A 184
3 100000009180001 N/A 132
4 48852341  N/A 103
5 100000008410001 N/A 87
6 44972341  N/A 67
7 42852340  N/A 61
8 100000014410057 N/A 61


select * from dw.media m where m.plis_issue_num = 559220007
select distinct(ISS_NAME) from dw.media m where m.iss_name like '%USA TODAY%'

select * from retailer_TRANSACTIONS_SUS s where RTRN_ISSUE_NUM=100000017960015 and s.rtrn_trans_plant_num in (20,220,350,550,560,740)
select * from dw.retailer_TRANSACTION d where d.plant_issue_id=100000017960015
select * from refmast.plant_issues p where p.plis_issue_num = 100000017960015
select * from refmast.plant_issues p where p.plis_issue_num = 100000014380042;
select * from refmast.plant_issues p where p.plis_issue_num = 100000014380041;
select * from refmast.plant_issues p where p.plis_issue_num = 100000014410052;
select * from refmast.plant_issues p where p.plis_issue_num = 100000014410053;
select * from refmast.plant_issues p where p.plis_issue_num = 45752216

2 100000017960015 459
3 100000014380042 448
4 100000014380041 327
5 100000014410052 324
6 100000014410053 205
7 100000014410054 151


select  * from  refstg.RETAILER_TRANSACTIONS_SUS c where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RTRN_TIMESTAMP,9),'dd-MON-yy')>180  
and ORA_ERR_MESG$ like '%ORA-01400: cannot insert NULL into ("REFSTG"."RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_NUM")%'

select  * from  refstg.RETAILER_TRANSACTIONS_SUS c where to_date(rpad(RTRN_TIMESTAMP,9),'dd-MON-yy')<'01-JAN-2015'  
and ORA_ERR_MESG$ like '%ORA-01400: cannot insert NULL into ("REFSTG"."RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_NUM")%'



select * from plant_issues_sus p  where p.plis_issue_num in(
100000027290001,
100000006870002,
100000009180001,
48852341,
100000008410001,
44972341,
100000014410057,
42852340,
100000014410051,
100000014420065,
100000008390001,
356609999,
100000006310001,
414250004,
100000022690002,
100000022690003,
444290001)

