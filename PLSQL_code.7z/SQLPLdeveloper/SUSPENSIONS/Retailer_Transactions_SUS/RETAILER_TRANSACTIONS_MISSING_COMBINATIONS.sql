--RETAILER_TRANSACTIONS_SUS
--SOLUTION FOR '% integrity constraint (REFSTG.STRN_STRT_FK) violated%' JUST ADD INTO DW.STOCK_TRN_REPORT_TYPE
select RTRN_ISSUE_NUM,count(*) from RETAILER_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '%integrity constraint (REFSTG.RTRN_RTRT_FK) violated%' --and STRN_COST_VALUE =0
group by RTRN_ISSUE_NUM

select * from RETAILER_TRANSACTIONS_SUS r where r.ora_err_mesg$ like '%integrity constraint (REFSTG.RTRN_RTRT_FK) violated%' and RTRN_ISSUE_NUM = 492220001


select RTRN_DOCUMENT_TYPE_CODE, RTRN_ITEM_TYPE_CODE, RTRN_ORIG_DOCUMENT_TYPE_CODE, RTRN_ORIG_ITEM_TYPE_CODE, RTRN_SUPPLY_PHASE_CODE, RTRN_ACTY_CRED_REF_REASON_FLAG, count(*),sum(s.RTRN_RETAIL_VALUE_EXCL_VAT)  from RETAILER_TRANSACTIONS_SUS  s
where ORA_ERR_MESG$ like '%integrity constraint (REFSTG.RTRN_RTRT_FK) violated%' 
group by RTRN_DOCUMENT_TYPE_CODE, RTRN_ITEM_TYPE_CODE, RTRN_ORIG_DOCUMENT_TYPE_CODE, RTRN_ORIG_ITEM_TYPE_CODE, RTRN_SUPPLY_PHASE_CODE,
 RTRN_ACTY_CRED_REF_REASON_FLAG order by count(*) desc,sum(s.RTRN_RETAIL_VALUE_EXCL_VAT)

select *  from RETAILER_TRANSACTIONS_SUS  s
where ORA_ERR_MESG$ like '%integrity constraint (REFSTG.RTRN_RTRT_FK) violated%' 
and RTRN_DOCUMENT_TYPE_CODE = 'ZRSR'
and RTRN_ITEM_TYPE_CODE = 'ZRID' 
and RTRN_ORIG_DOCUMENT_TYPE_CODE = 'JTA'
--ORBITBPUKM
--ORBITBPPAL

select * from DW.RETAILER_TRN_REPORT_TYPE 
where TYP_DOCUMENT_TYPE_CODE ='ZRSC'
and TYP_ITEM_TYPE_CODE = 'ZRIC'
and TYP_ORIG_DOCUMENT_TYPE_CODE = 'JTA' 
--and TYP_ORIG_ITEM_TYPE_CODE = 'ZDIC' for update

select * from DW.RETAILER_TRN_REPORT_TYPE 
where TYP_DOCUMENT_TYPE_CODE ='ZRSC'
and TYP_ITEM_TYPE_CODE = 'ZRIC'
and TYP_ORIG_DOCUMENT_TYPE_CODE = 'ZDIC' 


select * from RETAILER_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.RTRN_STRT_FK) violated%' and RTRN_SPOKE_NUM in (740,790)
and RTRN_TRANSACTION_DATE > to_date ('04/07/2015','dd/mm/yyyy')

select dw.retailer_trn_report_type_seq.NEXTVAL from dual--12661

create table jt_missing_rep_types as
select unique RTRN_LOCATION_FROM_CODE, RTRN_LOCATION_TO_CODE, RTRN_MOVEMENT_CODE, RTRN_CREDIT_OR_DEBIT_CODE,'To allow suspended records to load EAGLE' TYP_REPORTING_OBJECT, RTRN_INTERBRANCH_FLAG 
from  refstg.RETAILER_TRANSACTIONS_SUS 
where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.RTRN_STRT_FK) violated%' 
and RTRN_SPOKE_NUM in (740,790)
and RTRN_TRANSACTION_DATE > to_date ('05/07/2015','dd/mm/yyyy')


insert into DW.RETAILER_TRN_REPORT_TYPE (DIMENSION_KEY,TYP_ID,TYP_LOC_FROM_CODE,TYP_LOC_TO_CODE,TYP_MOVEMENT_CODE,TYP_CREDIT_DEBIT_FLAG,TYP_REPORTING_OBJECT,TYP_INTERBRANCH_FLAG) 
(select dw.RETAILER_trn_report_type_seq.nextval,dw.RETAILER_trn_report_type_seq.nextval,RTRN_LOCATION_FROM_CODE, RTRN_LOCATION_TO_CODE, RTRN_MOVEMENT_CODE, RTRN_CREDIT_OR_DEBIT_CODE,TYP_REPORTING_OBJECT, RTRN_INTERBRANCH_FLAG 
from  support.jt_missing_rep_types )

--1	ZRSC	ZRIC	JTA	ZDIC	N/A	0	379	42144.8
select *
from dw.retailer_trn_report_type rtrt
where rtrt.typ_item_type_code = 'ZDIC'
and rtrt.typ_document_type_code = 'JTA'

select t.* from DW.RETAILER_TRN_REPORT_TYPE t where t.typ_orig_document_type_code = 'JTA' and t.typ_orig_item_type_code = 'ZDIC'  for update

select t.* from DW.RETAILER_TRN_REPORT_TYPE t
where t.typ_document_type_code = 'JTA' and t.typ_item_type_code = 'ZDIC'  for update --and typ_ORIG_DOCUMENT_TYPE_CODE = 'JTA' and t.typ_orig_item_type_code = 'ZPAK'

select t.* from DW.RETAILER_TRN_REPORT_TYPE t where t.typ_orig_document_type_code = 'JTA' and t.typ_orig_item_type_code = 'ZDIC'

insert into DW.RETAILER_TRN_REPORT_TYPE (DIMENSION_KEY,TYP_ID,TYP_LOC_FROM_CODE,TYP_LOC_TO_CODE,TYP_MOVEMENT_CODE,TYP_CREDIT_DEBIT_FLAG,TYP_REPORTING_OBJECT,TYP_INTERBRANCH_FLAG) 
(select RETAILER_trn_report_type_seq.nextval,RETAILER_trn_report_type_seq.nextval,RTRN_LOCATION_FROM_CODE, RTRN_LOCATION_TO_CODE, RTRN_MOVEMENT_CODE, RTRN_CREDIT_OR_DEBIT_CODE,'To allow suspended records to load EAGLE', RTRN_INTERBRANCH_FLAG) 

select RTRN_DOCUMENT_TYPE_CODE, RTRN_ITEM_TYPE_CODE, RTRN_ORIG_DOCUMENT_TYPE_CODE, RTRN_ORIG_ITEM_TYPE_CODE, RTRN_SUPPLY_PHASE_CODE, RTRN_ACTY_CRED_REF_REASON_FLAG, count(*),sum(s.RTRN_RETAIL_VALUE_EXCL_VAT)  from RETAILER_TRANSACTIONS_SUS  s
where ORA_ERR_MESG$ like '%integrity constraint (REFSTG.RTRN_RTRT_FK) violated%' 
group by RTRN_DOCUMENT_TYPE_CODE, RTRN_ITEM_TYPE_CODE, RTRN_ORIG_DOCUMENT_TYPE_CODE, RTRN_ORIG_ITEM_TYPE_CODE, RTRN_SUPPLY_PHASE_CODE,
 RTRN_ACTY_CRED_REF_REASON_FLAG order by count(*) desc,sum(s.RTRN_RETAIL_VALUE_EXCL_VAT)
-------------------------

insert into  RETAILER_TRANSACTIONS_bin 
select s.*,'JT',sysdate from RETAILER_TRANSACTIONS_SUS s where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.RTRN_STRT_FK) violated%' 
and (RTRN_DOCUMENT_TYPE_CODE = 'ZRSR' and RTRN_ITEM_TYPE_CODE = 'ZRID' and RTRN_ORIG_DOCUMENT_TYPE_CODE = 'JTA')
or (RTRN_DOCUMENT_TYPE_CODE = 'ZRSC' and RTRN_ITEM_TYPE_CODE = 'ZRIC' and RTRN_ORIG_DOCUMENT_TYPE_CODE = 'JTA')

delete from RETAILER_TRANSACTIONS_SUS s where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.RTRN_STRT_FK) violated%' 
and (RTRN_DOCUMENT_TYPE_CODE = 'ZRSR' and RTRN_ITEM_TYPE_CODE = 'ZRID' and RTRN_ORIG_DOCUMENT_TYPE_CODE = 'JTA' )
or (RTRN_DOCUMENT_TYPE_CODE = 'ZRSC' and RTRN_ITEM_TYPE_CODE = 'ZRIC' and RTRN_ORIG_DOCUMENT_TYPE_CODE = 'JTA' )
------------------------

select * from RETAILER_TRANSACTIONS_SUS s where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.RTRN_STRT_FK) violated%' 
and (RTRN_DOCUMENT_TYPE_CODE = 'ZRSR' and RTRN_ITEM_TYPE_CODE = 'ZRID' and RTRN_ORIG_DOCUMENT_TYPE_CODE = 'JTA')
or (RTRN_DOCUMENT_TYPE_CODE = 'ZRSC' and RTRN_ITEM_TYPE_CODE = 'ZRIC' and RTRN_ORIG_DOCUMENT_TYPE_CODE = 'JTA')


