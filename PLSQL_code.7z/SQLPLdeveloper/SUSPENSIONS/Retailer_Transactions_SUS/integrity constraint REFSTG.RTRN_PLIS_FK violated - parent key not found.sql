select RTRN_ISSUE_NUM,count( *) from retailer_TRANSACTIONS_SUS y --
where ORA_ERR_MESG$ like '%tegrity constraint (REFSTG.RTRN_PLIS_FK%'
--and RTRN_ISSUE_NUM like '%0001'
group by RTRN_ISSUE_NUM order by count (*) desc

RTRN_PLIS_FK	Foreign	RTRN_TRANS_PLANT_NUM, RTRN_ISSUE_NUM	Y	DW.MEDIA	PLIS_PLANT_NUM, PLIS_ISSUE_NUM	No action	N	N	Y	27/05/2013 10:22:57

insert into retailer_TRANSACTIONS_bin
select t.*,'JT reverse',sysdate from retailer_TRANSACTIONS_SUS t where ORA_ERR_MESG$ like '%tegrity constraint (REFSTG.RTRN_PLIS_FK%'

delete from retailer_TRANSACTIONS_SUS t where ORA_ERR_MESG$ like '%tegrity constraint (REFSTG.RTRN_PLIS_FK%'
