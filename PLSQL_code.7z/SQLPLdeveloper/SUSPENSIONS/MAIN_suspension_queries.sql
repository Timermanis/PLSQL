select table_sus,error,count(*) from refstg.suspension_view_jt_6_months t group by table_sus,error order by count(*) desc;
select table_sus,error,count(*) from refstg.suspension_view_jt_2_months t group by table_sus,error order by count(*) desc;
select table_sus,error,count(*) from refstg.suspension_view_jt_2_weeks t group by table_sus ,error  order by count(*) desc;
select table_sus,error,count(*) from refstg.suspension_view_jt_1_week t group by table_sus,error order by count(*) desc;
select table_sus,error,count(*) from refstg.SUSPENSION_VIEW_JT_2_DAYS t group by table_sus , error order by count(*) desc;
select table_sus,error,count(*) from refstg.SUSPENSION_VIEW_JT_all_SUS t group by table_sus,error order by count(*) desc

--SUS records < 1week
select table_sus,error,sum(count) "DIFF ALL-1st.WEEK"from 
(select table_sus,error,-count(*) count from refstg.suspension_view_jt_1_week a group by table_sus,error  union all
select table_sus,error,count(*)  count from refstg.SUSPENSION_VIEW_JT_all_SUS b group by table_sus,error )
group by table_sus,error order by sum(count) desc

select STRN_ISSUE_NUM,sum(STRN_COST_VALUE),count(*) from refstg.stock_transactions_sus where ORA_ERR_MESG$ = 'ORA-01400: cannot insert NULL into ("REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_DATE")
' and to_date(sysdate,'dd-MON-yy') - to_date(rpad(STRN_TIMESTAMP,9),'dd-MON-yy') >180 
group by STRN_ISSUE_NUM

select * from refstg.stock_transactions_sus where ORA_ERR_MESG$ = 'ORA-01400: cannot insert NULL into ("REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_DATE")
' and to_date(sysdate,'dd-MON-yy') - to_date(rpad(STRN_TIMESTAMP,9),'dd-MON-yy') >180 

insert into refstg.stock_transactions_bin 
select s.* from refstg.stock_transactions_sus s where ORA_ERR_MESG$ = 'ORA-01400: cannot insert NULL into ("REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_DATE")
' and to_date(sysdate,'dd-MON-yy') - to_date(rpad(STRN_TIMESTAMP,9),'dd-MON-yy') >180 


select * from refstg.RETAILER_TRANSACTIONS_OM

select ORA_ERR_MESG$, count(*) from ISSUES_SUS group by ORA_ERR_MESG$

--STOCK_TRANSACTIONS_SUS
select STRN_ISSUE_NUM,strn_transaction_date,count(*) from STOCK_TRANSACTIONS_SUS h where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.STRN_STRT_FK) violated%' --and STRN_COST_VALUE =0
group by STRN_ISSUE_NUM,strn_transaction_date
having h.strn_transaction_date < sysdate -180

delete from STOCK_TRANSACTIONS_SUS a where strn_transaction_date < sysdate -180 and ORA_ERR_MESG$ like '% integrity constraint (REFSTG.STRN_STRT_FK) violated%'
insert into STOCK_TRANSACTIONS_BIN select a.*,'JT',sysdate from  STOCK_TRANSACTIONS_SUS a where strn_transaction_date < sysdate -180 and ORA_ERR_MESG$ like '% integrity constraint (REFSTG.STRN_STRT_FK) violated%'

 
insert into STOCK_TRANSACTIONS_BIN select a.*,'JT',sysdate from  STOCK_TRANSACTIONS_SUS a where strn_transaction_date < sysdate -180 and STRN_COST_VALUE = 0
delete from STOCK_TRANSACTIONS_SUS a where strn_transaction_date < sysdate -180 and STRN_COST_VALUE = 0

insert into STOCK_TRANSACTIONS_BIN select a.*,'JT',sysdate from  STOCK_TRANSACTIONS_SUS a where ORA_ERR_MESG$ like '%insert NULL into ("REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_%' 
and strn_transaction_date <='01-JAN-2014'

delete from STOCK_TRANSACTIONS_SUS a where ORA_ERR_MESG$ like '%insert NULL into ("REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_%' 
and strn_transaction_date <='01-JAN-2014'

select * from STOCK_TRANSACTIONS_SUS where strn_transaction_date < sysdate -180

--select sysdate -30 from dual
select STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG, count(*) from STOCK_TRANSACTIONS_SUS 
where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.STRN_STRT_FK) violated%' --and --STRN_COST_VALUE =0
group by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG--missing transaction types

select * from STOCK_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '%insert NULL into ("REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_%' 
and strn_transaction_date < sysdate -180
and strn_transaction_date <='01-JAN-2014'

group by STRN_ISSUE_NUM order by count(*) desc

 select STRN_ISSUE_NUM, count(*) from STOCK_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.STRN_STRT_FK) violated%' 
 group by STRN_ISSUE_NUM 
 
select * from STOCK_TRANSACTIONS_SUS where STRN_ISSUE_NUM = 420010008
--SALES_ORGANISATION_ISSUES_SUS
select * from SALES_ORGANISATION_ISSUES_SUS where ORA_ERR_MESG$ like '%uspended because a%' 
create table SALES_ORGANISATION_ISSUES_bin as (select c.* from SALES_ORGANISATION_ISSUES_SUS c where c.sois_issue_num in (352480276,368480254))
delete from  SALES_ORGANISATION_ISSUES_SUS c where c.sois_issue_num in (352480276,368480254)
update sales_organisation_issues_bin set WHO_BINNED='JT',WHEN_BINNED=sysdate


--RETAILER_TRANSACTIONS_SUS
select * from RETAILER_TRANSACTIONS_SUS f where ORA_ERR_MESG$ like '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_%' and f.rtrn_transaction_date < sysdate - 160
and  rtrn_transaction_date <='01-JAN-2015' order by abs(RTRN_RETAIL_VALUE_EXCL_VAT) desc

select RTRN_ISSUE_NUM, count(*) from RETAILER_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_%' group by RTRN_ISSUE_NUM
select * from RETAILER_TRANSACTIONS_SUS  where ORA_ERR_MESG$ like '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_%' 
select * from RETAILER_TRANSACTIONS_SUS  where RTRN_ISSUE_NUM in( 100000017960015)



select c.*,'JT' 'WHO_BINNED',sysdate 'WHEN_BINNED' from SALES_ORGANISATION_ISSUES_SUS c where in (352480276,368480254)

--PLANT_ISSUES_SUS --Mainly problems regarding plant issues created in advance, have a look to PLIS_PLANNED_ON_SALE_DATE --
-create table support.SUSPENSION_NO_DISTRIB_210415 as
select * from plant_ISSUES_SUS s where  s.plis_actual_on_sale_date < sysdate -180 and s.ora_err_mesg$ is not null
-update plant_ISSUES_SUS set PLIS_DISTRIBUTOR_NUM = 204116 where ORA_ERR_MESG$ like '%TG.PLIS_VEN_DIST_FK%' and PLIS_DISTRIBUTOR_NUM = 201624
select PLIS_ISSUE_NUM, count(*) from plant_ISSUES_SUS where ORA_ERR_MESG$ like '%"PLANT_ISSUES_CC"%' group by PLIS_ISSUE_NUM --order by PLIS_TIMESTAMP 
select * from refstg.plant_ISSUES_SUS where PLIS_ISSUE_NUM in (100000014380040 )

select PLIS_PUBLISHER_NUM,PLIS_DISTRIBUTOR_NUM, count(*) from plant_issues_cc
group by PLIS_PUBLISHER_NUM,PLIS_DISTRIBUTOR_NUM
having PLIS_PUBLISHER_NUM - PLIS_DISTRIBUTOR_NUM =0

select * from refmast.latest_spokes_mv
select * from refmast.latest_vendors_mv where VEN_NUM = 204116
select * from termsprd.latest_plant_issue where ISSUE_ID = 352480276

--ISSUES_SUS
select * from issues_sus j where j.iss_num = 100000014380040
select * from issues_sus where ORA_ERR_MESG$ like '%aint (REFSTG.ISS_CHLD_ISS_FK) violated - pa%'
select * from REFMAST.Latest_Vat_Mv
select * from REFMAST.ISSUES f where f.iss_parent_iss_num = 100000014380040
select * from REFMAST.ISSUES f where f.iss_parent_iss_num like '3684717%'--------------------------
select * from REFMAST.ISSUES where ISS_NAME like '%WEEKEND YORK%'
select * from REFMAST.ISSUES where ISS_PARENT_ISS_NUM = 368470724
select * from REFMAST.ISSUES where ISS_NAME like 'MAIL ENG M-S (YORKSHIRE%'
select * from REFMAST.ISSUES where ISS_NAME like 'MOS EVENT POLY YORK%'
select * from refmast.products where PROD_NUM = 36848

--VENDOR_TRANSACTIONS_SUS
insert into VENDOR_TRANSACTIONS_bin select a.*,'JT',sysdate from VENDOR_TRANSACTIONS_SUS a;
delete from VENDOR_TRANSACTIONS_SUS
--CUSTOMER_SUP_INFO_SUS
select * from CUSTOMER_SUP_INFO_SUS where PROD_NUM = 36848

select * from archive.zpx_plnt_iss_stg_bak v where issue_id = 54762295 and v.spoke_id = 470

insert into RETAILER_INVOICE_HEADERS_OMbin select a.*,'JT',sysdate from RETAILER_INVOICE_HEADERS_OM a
delete  from RETAILER_INVOICE_HEADERS_OM
select * from DWSTG.DWS_RETAILER_bin

select * from dw.latest_retailer_mv   _RETAILER_SUS
a.*,WHO_BINNED,WHEN_BINNED
delete from vendor_transactions_om
create table RETAILER_INVOICE_HEADERS_OMbin as
select  * from RETAILER_INVOICE_HEADERS_OM a where 1=2

alter table RETAILER_INVOICE_HEADERS_OMbin 
add  (WHO_BINNED varchar2(15),
WHEN_BINNED date)

select distinct p.* from RETAILER_TRANSACTIONS_SUS g,PLANT_ISSUES_SUS p
where g.rtrn_issue_num = p.plis_issue_num




