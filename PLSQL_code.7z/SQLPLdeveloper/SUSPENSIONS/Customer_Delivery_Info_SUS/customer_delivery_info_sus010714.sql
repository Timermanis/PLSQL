------------------------------------------------------------230316_missing 910 customers--------------------
select cdi_customer_num,c.* from customer_delivery_info_sus c where c.cdi_drop_name  like '%SKYLORD TRAVEL PLC%';--158090,159161
select c.* from CUSTOMER_SUP_INFO_SUS c
--THOMSON RETAIL
select * from refmast.latest_customers_mv r where r.cd_customer_num = 160178 --r.cd_name like '%SKYLORD TRAVEL PLC%'--149259

select cdi_customer_num,c.* from customer_delivery_info_sus c where c.cdi_drop_name  like '%D P & L TRAVEL LTD%';--
select c.* from CUSTOMER_SUP_INFO_SUS c
--THOMSON RETAIL
select * from refmast.latest_customers_mv r where r.cd_name like '%D P & L TRAVEL LTD%'--149259
--------------------------------------------------------------------------------
select c.* from customer_delivery_info_sus c

select * from refmast.customer_delivery_info 

select distinct r.CD_HUB_NUM,r.cd_name,b.* from refmast.latest_customers_mv r, customer_delivery_info_sus b 
--where b.cdi_customer_num=r.cd_customer_num--no rows returned. This is the cause of the error
where b.cdi_drop_name = r.cd_name order by CDI_ADDRESS_LINE1

select distinct r.CD_HUB_NUM,r.cd_spoke_num,b.cdi_customer_num,r.cd_customer_num,b.* from refmast.latest_customers_mv r, customer_delivery_info_sus b 
--where b.cdi_customer_num=r.cd_customer_num--no rows returned. This is the cause of the error
where b.cdi_drop_name = r.cd_name and b.cdi_customer_num = 161780

select * from refmast.latest_customers_mv r where r.cd_name = 'THE FLIGHTS GURU LTD'

select * from refmast.latest_customers_mv m where m.cd_customer_num = 160301

select * from refmast.customer_details r, customer_delivery_info_sus c 
where c.cdi_customer_num=r.cd_customer_num--Check match in refmast.customer_details. no rows returned.

select * from  customer_delivery_info_sus c 

select trunc(a.customer_id),a.* from archive.zpx_cus_deli_stg_bak a
LEFT OUTER JOIN customer_delivery_info_sus c  
on trunc(a.customer_id)=c.cdi_customer_num--Check match in archive table. 12859 rows returned

select a.customer_id, count(a.customer_id) from archive.zpx_cus_deli_stg_bak a
LEFT OUTER JOIN customer_delivery_info_sus c  
on trunc(a.customer_id)=c.cdi_customer_num
group by a.customer_id
--------------------------------------------------02.07.2014--------------------------------
select * from  customer_delivery_info_sus c 
select * from  customer_delivery_info_sus where CDI_CUSTOMER_NUM like '9%'
insert into customer_delivery_info_bin  (select s.*,'JT',sysdate from  customer_delivery_info_sus s) /* where s.cdi_customer_num = 143497*/) CDI_CUSTOMER_NUM like '9%');
select * from  customer_delivery_info_bin
delete from customer_delivery_info_sus where cdi_customer_num = 143497 --CDI_CUSTOMER_NUM like '9%'
select * from  customer_delivery_info_sus
--------------------------------------------------------------------------
select * from refmast.latest_customers_mv r where CD_POSTCODE = 'PO30 5HB'--CDI_CUSTOMER_NUM 147338
select * from refmast.latest_customers_mv r where CD_CUSTOMER_NUM =156076

select * from  customer_delivery_info_sus c 
