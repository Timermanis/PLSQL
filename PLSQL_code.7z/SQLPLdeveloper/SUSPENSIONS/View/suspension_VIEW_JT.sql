select table_sus,error,count(*) from refstg.SUSPENSION_VIEW_JT_010415_SUS t group by table_sus,error order by count(*) desc 
select table_sus,error,count(*) from refstg.SUSPENSION_VIEW_JT_all_SUS t group by table_sus,error order by count(*) desc 

select * from refstg.SUSPENSION_VIEW_JT_010415_SUS intersect
select * from refstg.SUSPENSION_VIEW_JT_all_SUS

select ORA_ERR_MESG$, count(*) from ISSUES_SUS group by ORA_ERR_MESG$

--STOCK_TRANSACTIONS_SUS
select STRN_ISSUE_NUM,count(*) from STOCK_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.STRN_STRT_FK) violated%' --and STRN_COST_VALUE =0
group by STRN_ISSUE_NUM

select STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG, count(*) from STOCK_TRANSACTIONS_SUS 
where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.STRN_STRT_FK) violated%' --and --STRN_COST_VALUE =0
group by STRN_LOCATION_FROM_CODE, STRN_LOCATION_TO_CODE, STRN_MOVEMENT_CODE, STRN_CREDIT_OR_DEBIT_CODE, STRN_INTERBRANCH_FLAG--missing transaction types

select STRN_ISSUE_NUM, count(*) from STOCK_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '%insert NULL into ("REFSTG"."STOCK_TRANSACTIONS_CC"."STRN_ISSUE_START_%' 
 group by STRN_ISSUE_NUM order by count(*) desc
 select STRN_ISSUE_NUM, count(*) from STOCK_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '% integrity constraint (REFSTG.STRN_STRT_FK) violated%' 
 group by STRN_ISSUE_NUM 
 
select * from STOCK_TRANSACTIONS_SUS where STRN_ISSUE_NUM = 375170001
--SALES_ORGANISATION_ISSUES_SUS
select * from SALES_ORGANISATION_ISSUES_SUS where ORA_ERR_MESG$ like '%uspended because a%' 
create table SALES_ORGANISATION_ISSUES_bin as (select c.* from SALES_ORGANISATION_ISSUES_SUS c where c.sois_issue_num in (352480276,368480254))
delete from  SALES_ORGANISATION_ISSUES_SUS c where c.sois_issue_num in (352480276,368480254)
update sales_organisation_issues_bin set WHO_BINNED='JT',WHEN_BINNED=sysdate


--RETAILER_TRANSACTIONS_SUS
select * from RETAILER_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_%' order by RTRN_PARTITIONING_DATE 
select RTRN_ISSUE_NUM, count(*) from RETAILER_TRANSACTIONS_SUS where ORA_ERR_MESG$ like '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_%' group by RTRN_ISSUE_NUM
select * from RETAILER_TRANSACTIONS_SUS  where ORA_ERR_MESG$ like '%RETAILER_TRANSACTIONS_CC"."RTRN_PRODUCT_%' 
select * from RETAILER_TRANSACTIONS_SUS  where RTRN_ISSUE_NUM = 352480276


select c.*,'JT' 'WHO_BINNED',sysdate 'WHEN_BINNED' from SALES_ORGANISATION_ISSUES_SUS c where in (352480276,368480254)

--PLANT_ISSUES_SUS
-create table support.SUSPENSION_NO_DISTRIB_210415 as
select * from plant_ISSUES_SUS where PLIS_ISSUE_NUM = 368480254 ORA_ERR_MESG$ like '%TG.PLIS_VEN_DIST_FK%' order by PLIS_TIMESTAMP 
-update plant_ISSUES_SUS set PLIS_DISTRIBUTOR_NUM = 204116 where ORA_ERR_MESG$ like '%TG.PLIS_VEN_DIST_FK%' and PLIS_DISTRIBUTOR_NUM = 201624
select PLIS_ISSUE_NUM, count(*) from plant_ISSUES_SUS where ORA_ERR_MESG$ like '%"PLANT_ISSUES_CC"%' group by PLIS_ISSUE_NUM --order by PLIS_TIMESTAMP 
select * from plant_ISSUES_SUS where PLIS_ISSUE_NUM in (352480276,368480254)

select PLIS_PUBLISHER_NUM,PLIS_DISTRIBUTOR_NUM, count(*) from plant_issues_cc
group by PLIS_PUBLISHER_NUM,PLIS_DISTRIBUTOR_NUM
having PLIS_PUBLISHER_NUM - PLIS_DISTRIBUTOR_NUM =0

select * from refmast.latest_spokes_mv
select * from refmast.latest_vendors_mv where VEN_NUM = 204116
select * from termsprd.latest_plant_issue where ISSUE_ID = 352480276

--ISSUES_SUS
select * from issues_sus 
select * from issues_sus where ORA_ERR_MESG$ like '%aint (REFSTG.ISS_CHLD_ISS_FK) violated - pa%'
select * from REFMAST.Latest_Vat_Mv
select * from REFMAST.ISSUES f where f.iss_parent_iss_num = 368471771
select * from REFMAST.ISSUES f where f.iss_parent_iss_num like '3684717%'--------------------------
select * from REFMAST.ISSUES where ISS_NAME like '%WEEKEND YORK%'
select * from REFMAST.ISSUES where ISS_PARENT_ISS_NUM = 368470724
select * from REFMAST.ISSUES where ISS_NAME like 'MAIL ENG M-S (YORKSHIRE%'
select * from REFMAST.ISSUES where ISS_NAME like 'MOS EVENT POLY YORK%'
select * from refmast.products where PROD_NUM = 36848

--VENDOR_TRANSACTIONS_SUS
insert into VENDOR_TRANSACTIONS_bin select a.*,'JT',sysdate from VENDOR_TRANSACTIONS_SUS a
delete from VENDOR_TRANSACTIONS_SUS

