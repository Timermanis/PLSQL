select ERROR,TABLE_SUS,count(*) from SUSPENSION_VIEW_JT_010415_SUS t group by ERROR,TABLE_SUS order by 3 desc
