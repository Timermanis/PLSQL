select ERROR,TABLE_SUS,count(*) from SUSPENSION_VIEW_JT_010415_SUS t group by ERROR,TABLE_SUS order by 3 desc

select * from RETAILER_INVOICE_ITEMS_SUS
select RII_INVOICE_DOCUMENT_NUM, count(*) from RETAILER_INVOICE_ITEMS_SUS group by  RII_INVOICE_DOCUMENT_NUM
insert into  refstg.retailer_invoice_headers_bin select h.*,'JT',sysdate from RETAILER_INVOICE_HEADERS_SUS h
delete from RETAILER_INVOICE_HEADERS_SUS

insert into  refstg.retailer_invoice_items_bin select h.*,'JT',sysdate from retailer_invoice_items_sus h
delete from retailer_invoice_items_sus
