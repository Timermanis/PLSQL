select * from issues_sus
where ORA_ERR_MESG$ like '%REFSTG.ISS_CHLD_VAT_UK_FK%';--2

select * from issues_sus
where ORA_ERR_MESG$ like '%REFSTG.CHILD_ISS_PUBN_DATE_FK%';--iss_product_num = 468540001

select * from issues_sus
where ORA_ERR_MESG$ like '%G.ISS_PUBN_DATE_FK%';--iss_product_num = 468540001



select ORA_ERR_MESG$,count( *) from issues_sus --ORA-02291: integrity constraint (REFSTG.ISS_CHLD_VAT_UK_FK) violated - parent key not found
group by ORA_ERR_MESG$

select * from issues_sus i, latest_vat_uk_mv l
select * from refmast.latest_vat_uk_mv l
select * from refmast.issues i where i.iss_num like '%46854%'
