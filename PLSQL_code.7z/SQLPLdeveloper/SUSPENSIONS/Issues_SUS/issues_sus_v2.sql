ORA-02291: integrity constraint (REFSTG.ISS_CHLD_ISS_FK) violated - parent key not found
--ISSUES_SUS

select ORA_ERR_MESG$,count( *) from issues_sus where ORA_ERR_MESG$ like '%constraint (REFSTG.ISS_CHLD_ISS_FK)%'
group by ORA_ERR_MESG$


select * from issues_sus where ORA_ERR_MESG$ like '%constraint (REFSTG.ISS_CHLD_ISS_FK)%'

select * from issues_sus 
select * from issues_sus where ORA_ERR_MESG$ like '%G.CHILD_ISS_PUBN_DATE_FK%'
select * from REFMAST.Latest_Vat_Mv
select * from REFMAST.ISSUES f where f.iss_parent_iss_num = 368471771
select * from REFMAST.ISSUES f where f.iss_parent_iss_num like '3684717%'--------------------------
select * from REFMAST.ISSUES where ISS_NAME like '%WEEKEND YORK%'
select * from REFMAST.ISSUES where ISS_PARENT_ISS_NUM = 368470724
select * from REFMAST.ISSUES where ISS_NAME like 'MAIL ENG M-S (YORKSHIRE%'
select * from REFMAST.ISSUES where ISS_NAME like 'MOS EVENT POLY YORK%'
select * from refmast.products where PROD_NUM = 36848

insert into refstg.issues_bin (select t.*,'JT',sysdate from issues_sus t where t.iss_num in (352480276,368480254))
(select s.*,'JTIMERMANIS'  ,sysdate 'WHEN_BINNED')

delete from issues_sus where iss_num in (352480276,368480254)

select * from plant_ISSUES_SUS where PLIS_ISSUE_NUM in (352480276,368480254)
