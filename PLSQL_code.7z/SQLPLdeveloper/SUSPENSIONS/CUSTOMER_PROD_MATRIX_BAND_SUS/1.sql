select * from cus_prod_matrix_band_sus
select * from  cus_prod_matrix_band_bin 
select * from REFMAST.LATEST_CUSTOMERS_MV where CD_CUSTOMER_NUM like '%102067%'
select max(CD_CUSTOMER_NUM) from REFMAST.LATEST_CUSTOMERS_MV
create table cus_prod_matrix_band_bin as select * from cus_prod_matrix_band_sus
delete from cus_prod_matrix_band_sus
