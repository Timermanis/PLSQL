--CREATE TABLE customer_hours_bin AS SELECT * FROM customer_hours_sus where CH_CUSTOMER_NUM = 99230
SELECT * FROM customer_hours_sus
delete from customer_hours_sus where CH_CUSTOMER_NUM = 99230

insert into customer_hours_bin
SELECT s.*, 'JT',sysdate FROM customer_hours_sus s
select * from REFMAST.LATEST_CUSTOMERS_MV l where l.cd_customer_num in (160333,
160302,
160301
) 
