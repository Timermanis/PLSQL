select * from refstg.customer_hours_sus
insert into refstg.customer_hours_bin select a.*,'JT',sysdate from refstg.customer_hours_sus a where ORA_ERR_MESG$ like '%ORA-02291%'
delete from refstg.customer_hours_sus c where ORA_ERR_MESG$ like '%ORA-02291%'
select * from retailer_transactions_sus where RTRN_CUSTOMER_NUM =145338
select * from refmast.customer_hours c where c.ch_customer_num = 156076
select * from LATEST_CUSTOMERS_MV t  where t.CD_CUSTOMER_NUM = 156076

insert into refstg.CUSTOMER_SUP_INFO_bin select a.*,sysdate,'JT' from refstg.CUSTOMER_SUP_INFO_SUS a where ORA_ERR_MESG$ like '%CSI_CUS_FK%'
delete from refstg.CUSTOMER_SUP_INFO_sus c where ORA_ERR_MESG$ like '%CSI_CUS_FK%'

insert into refstg.CUSTOMER_DELIVERY_INFO_bin select a.*,'JT',sysdate from refstg.CUSTOMER_DELIVERY_INFO_SUS a where ORA_ERR_MESG$ like '%CSI_CUS_FK%'
delete from refstg.CUSTOMER_DELIVERY_INFO_SUS c where ORA_ERR_MESG$ like '%CSI_CUS_FK%'
