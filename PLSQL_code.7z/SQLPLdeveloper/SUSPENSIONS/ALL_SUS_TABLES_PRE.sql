select 'select * from '||owner||'.'||table_name||';',num_rows counter  from all_all_tables where table_name like '%SUS' and owner not like 'SUPPORT' ;
select owner||'.'||table_name||';' SUS_TABLEs,num_rows records from all_all_tables where table_name like '%SUS' and owner not like 'SUPPORT' and num_rows>0

