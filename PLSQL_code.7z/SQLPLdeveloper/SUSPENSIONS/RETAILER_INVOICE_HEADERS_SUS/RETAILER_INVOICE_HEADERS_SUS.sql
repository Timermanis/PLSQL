select * from RETAILER_INVOICE_HEADERS_SUS where RIH_TIMESTAMP > to_date('01-09-2014','dd-mm-yy') and RIH_CUSTOMER_NUM like '1%'
select * from RETAILER_INVOICE_HEADERS_SUS where RIH_SRC_DOCUMENT_NUM = 3940338204--like '1%'
--------------------------------------------------------------------
select * from RETAILER_INVOICE_ITEMS_SUS a,RETAILER_INVOICE_HEADERS_SUS b --RIH_CUSTOMER_NUM JUST in range 100000-200000 are relevant customers !!!!!!!!!!
where a.rii_invoice_document_num = b.rih_src_document_num and RIH_CUSTOMER_NUM >= 100000 and RIH_CUSTOMER_NUM <=200000
------------------------------------------------------------------------
select * from RETAILER_INVOICE_ITEMS_bin; 
select * from RETAILER_INVOICE_HEADERS_bin 


insert into RETAILER_INVOICE_HEADERS_bin 
select t.*,'JT' WHO_BINNED,sysdate WHEN_BINNED  from RETAILER_INVOICE_HEADERS_SUS t where RIH_CUSTOMER_NUM = 116669

delete from RETAILER_INVOICE_HEADERS_SUS t where RIH_CUSTOMER_NUM = 116669
--------------------------
insert into RETAILER_INVOICE_ITEMS_bin select a.*,'JT',sysdate from 
RETAILER_INVOICE_ITEMS_SUS a,RETAILER_INVOICE_HEADERS_bin b 
where a.rii_invoice_document_num = b.rih_src_document_num and RIH_CUSTOMER_NUM = 116669

delete from RETAILER_INVOICE_ITEMS_SUS where rii_invoice_document_num in (select a.rii_invoice_document_num from
RETAILER_INVOICE_ITEMS_SUS a,RETAILER_INVOICE_HEADERS_bin b 
where a.rii_invoice_document_num = b.rih_src_document_num and RIH_CUSTOMER_NUM = 116669)

--truncate table RETAILER_INVOICE_HEADERS_SUS

insert into RETAILER_INVOICE_ITEMS_bin 
select t.*,'JT' WHO_BINNED,sysdate WHEN_BINNED  from RETAILER_INVOICE_ITEMS_SUS t

select  *  from  RETAILER_INVOICE_HEADERS_SUS where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RIH_TIMESTAMP,9),'dd-MON-yy')>180 

insert into RETAILER_INVOICE_ITEMS_bin 
select   t.*,'JT',sysdate from  RETAILER_INVOICE_ITEMS_SUS t where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RII_TIMESTAMP,9),'dd-MON-yy')>180  

delete from RETAILER_INVOICE_ITEMS_SUS t where to_date(sysdate,'dd-MON-yy')-to_date(rpad(RII_TIMESTAMP,9),'dd-MON-yy')>180 

