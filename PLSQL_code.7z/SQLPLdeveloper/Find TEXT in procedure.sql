select * from KPI_TOTALS t where  t.kpt_year = 2015 and t.kpt_week_no = 41 and t.kpt_day_no = 1 and t.kpt_pub_code=1004

SELECT * FROM DBA_source WHERE (text) LIKE '%No suspended data%' and owner = 'JM'

SELECT * FROM DBA_source WHERE (text) LIKE '%OTHER_QTY_SOLD%' and owner = 'JM'
SELECT * FROM DBA_source d WHERE d.TEXT like '%partition_start_date%'


SELECT * FROM DBA_source WHERE (text) LIKE '%T_T_base_v5%'
SELECT * FROM DBA_source WHERE (text) LIKE '%CSC_data (limit: 1)%' order by name, line

select table_name from dba_tab_columns where column_name='ISSUE_ID';

SELECT * FROM DBA_source WHERE (text) LIKE 'issues_xref%'
