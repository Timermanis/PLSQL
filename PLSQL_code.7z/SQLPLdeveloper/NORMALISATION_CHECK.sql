select bris_branch_code, bris_ean,bris_issue_year
from branch_issues
where bris_issue_year = 2016
and bris_link_ean is null


select to_char(sysdate,'D') from dual
