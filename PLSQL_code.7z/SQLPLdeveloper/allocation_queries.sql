-- INEWS (login/password is cas/alloc on INEWS)

-- Step 1. Use the provided workbook to retrieve the titles associated with the allocation.

select t.cawt_title_code from cas_allocation_workbook_titles t
where t.cawt_workbook_id = &workbook;--62586 --4259
4285 2089


-- Step 2. Use the title(s) returned from Step 1 and the required branch(es) to retrieve the title associated with the queried branch(es) for the allocation.

-- The title_list should be comma separated
-- The branch_list should be comma separated with the 6 character legacy branch code in single quotes (e.g. 'BRA560','BRA550')

select t.caot_location_code, t.caot_jm_title_code, u.caou_link_location_code
from cas_org_unit_title_schedules t, cas_allocation_workbooks w, cas_organisation_units u
where w.cawb_workbook_id = &workbook
and u.caou_location_code = t.caot_location_code
and w.cawb_on_sale_date between t.caot_date_from and t.caot_date_to
and w.cawb_on_sale_date between u.caou_from_date and u.caou_to_date
and t.caot_jm_title_code in (&title_list)
and t.caot_location_code in (&branch_list);

select * from cas_org_unit_title_schedules --cas_organisation_units

-- Step 3. Use the required title code to check NORMAL_ISSUES

-- invest_title is the title code returned in Step 2.
-- invest_year and invest_min_week are user input taken back enough to recover the last 6 closed net sales. As I said before I generally go back 8 weeks for regional/daily/sunday titles
-- invest_day is the day of the associated issue being investigated. 1-6 for daily titles and zero for regional and sunday titles

select * from normal_issues t
where t.NISS_TITLE_CODE = &invest_title
and t.NISS_ISSUE_YEAR = &invest_year
and t.NISS_ISSUE_WEEK > &invest_min_week
and t.NISS_ISSUE_DAY = &invest_day;

-- Step 4. Use the required title and branch codes to check BRANCH_ISSUES using the same parameters plus...

-- invest_branch is the link location code returned from step 2.

select * from branch_issues t
where t.BRIS_BRANCH_CODE = &invest_branch
and t.BRIS_TITLE_CODE = &invest_title
and t.BRIS_ISSUE_YEAR = &invest_year
and t.BRIS_ISSUE_WEEK > &invest_min_week
and t.BRIS_ISSUE_DAY = &invest_day;



-- IMAG (login/password is cas/alloc on HOCAS)

-- Step 1. Use the provided workbook id to retrieve the title code
as
select t.cawb_title_code from cas_allocation_workbooks t
where t.cawb_workbook_id = &workbook;
2089
-- Step 2. Use the required title code to check NORMAL_ISSUES

-- invest_title is the title code returned in Step 1.
-- invest_year and invest_min_week are user input taken back enough to recover the last 6 closed net sales. As I said before I generally go back 8 weeks for regional/daily/sunday titles

select * from normal_issues t
where t.NISS_TITLE_CODE = &invest_title
and t.NISS_ISSUE_YEAR = &invest_year
and t.NISS_ISSUE_WEEK > &invest_min_week;

-- Step 4. Use the required title and branch codes to check BRANCH_ISSUES using the same parameters plus the queried branch

select * from branch_issues t
where t.BRIS_BRANCH_CODE = &invest_branch
and t.BRIS_TITLE_CODE = &invest_title
and t.BRIS_ISSUE_YEAR = &invest_year
and t.BRIS_ISSUE_WEEK > &invest_min_week;
