
select    distinct a.hamo_id,
                    to_char(a.hamo_issue_ean),  
                    a.hamo_issue_year, 
                    to_char(a.hamo_agent_number),
                    nvl( a.hamo_box_out_quantity,     0),
                    nvl( a.hamo_credit_quantity,      0),
                    nvl( a.hamo_other_sales_quantity, 0),
                    nvl( a.hamo_committed_quantity,   0),
                    nvl( a.hamo_casual_quantity,      0),
                    to_char( nvl( a.hamo_first_sale_flag,  0)),
                    to_char( nvl( a.hamo_sell_out_flag,    0)),
                    nvl( a.hamo_first_return_flag, 0),  
                    nvl( a.hamo_supplies_returned_against,  0),
                    nvl( a.hamo_return_quantity,            0),
                    c.cus_anmw_code,
                    c.cus_postcode_outer,
                    bt.bran_branch_code,
                    nvl( c.cus_multiple_code, 0),
                    nvl( c.cus_selected_agent_net_sales,'N'),
                    nvl( arbg.arbg_band_code, decode(substr(rb.rb_band_code,1,3), 'TEL', 'TEL      Z', 'IPC', 'IPC      I', ' ' )),
                    to_char(a.hamo_issue_invoice_date,'DD-MON-YYYY:HH24:MI:SS'),
                    nvl( m.mult_selected_multiple,'N'),
                    a.hamo_title_code,
                    decode( t.titl_selected_anmw,
                            'Y',        'Y',
                            decode( t.titl_supplier_selected_anmw,
                                    'Y',          'Y',
                                    'N')),
                    decode(c.cus_type,
                            'I',    0,
                            ((nvl( a.hamo_box_out_quantity,     0) +
                              nvl( a.hamo_other_sales_quantity, 0) +
                              nvl( a.hamo_committed_quantity,   0) +
                              nvl( a.hamo_casual_quantity,      0) -
                              nvl( a.hamo_credit_quantity,      0)  ) *
                             decode(a.hamo_day_of_week,
                                    NULL,   bt.bran_cover_price *
                                            (100 - nvl( tvb.titv_agent_discount,
                                                       bt.bran_trade_discount)),
                                    nvl( bt.bran_retail_price_except_day, -666),
                                            bt.bran_retail_price_exception *
                                            (100 - nvl( tvb.titv_agent_discount,
                                                       bt.bran_trade_discount)),
                                    bt.bran_cover_price *
                                    (100 - nvl( tvb.titv_agent_discount,
                                                 bt.bran_trade_discount))
                                     ) ) * 100 ),    
                    c.cus_type,
                    a.hamo_ctb_flag
    FROM
                    agent_movements            a,
                    customers                  c,
                    branch_terms               bt,
                    titles                     t,
                    issues                     i,
                    multiple                   m,
                    agent_retailer_band_groups arbg,
                    agent_variable_terms       avt,
                    title_variable_term_bands  tvb,
                    retailer_bands             rb
    WHERE 
                  a.hamo_agent_number = c.cus_account_number
            and   a.hamo_issue_invoice_date between c.cus_from_date and 
                                                    c.cus_to_date
            and   a.hamo_issue_invoice_date between bt.bran_date_from and
                                                    bt.bran_date_to   
            and   a.hamo_title_code = bt.bran_title_code 
            and   'BRA310' = bt.bran_branch_code
            and   t.titl_code       =  a.hamo_title_code
            and   i.issu_ean        =  a.hamo_issue_ean
            and   i.issu_issue_year =  a.hamo_issue_year
            and   c.cus_multiple_code = m.mult_multiple_code(+)
            and   arbg.arbg_account_number(+) = a.hamo_agent_number
            and   arbg.arbg_titl_code(+) = a.hamo_title_code
            and   a.hamo_issue_invoice_date between arbg.arbg_date_from(+) and
                                                    arbg.arbg_date_to(+)
            and   a.hamo_agent_number = avt.agent_account_number(+) 
            and   a.hamo_title_code   = avt.title_code(+) 
            and   a.hamo_issue_invoice_date between avt.date_from(+) and
                                                    avt.date_to(+)   
            and   avt.titvarbnd_titv_band = tvb.titv_title_band(+)
            and   avt.title_code          = tvb.titv_title_code(+)
            and   ((a.hamo_issue_invoice_date between tvb.titv_date_from and
                                                      tvb.titv_date_to) OR 
                    avt.title_code IS NULL)
            and   a.hamo_title_code = rb.rb_titl_code (+)
            and   i.issu_ean = 977003373682519;
