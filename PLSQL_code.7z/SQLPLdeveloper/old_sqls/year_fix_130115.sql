SELECT nvl( pix.pix_legacy_ean, pix.pix_ean ),pix.pix_spoke_code,
             nvl( pix.pix_legacy_year, nvl( pix.pix_year, pix.pix_orig_year ) ),
             pix.pix_legacy_title,
             pix.pix_orig_day,
             trunc( next_day(pix.pix_plant_on_sale_date-1,'Saturday') ),
             pix.pix_plant_on_sale_date
      FROM   plant_issues_xref pix -- use the view
      WHERE  pix.pix_spoke_code in( 'BRA850','BRA330')
      AND    pix.pix_sap_id     = 000000000455960015;
      
SELECT nvl( pix.pix_legacy_ean, pix.pix_ean ),
             nvl( pix.pix_legacy_year, nvl( pix.pix_year, pix.pix_orig_year ) ),
             pix.pix_legacy_title,
             pix.pix_orig_day,
             trunc( next_day(pix.pix_plant_on_sale_date-1,'Saturday') ),
             pix.pix_plant_on_sale_date
      FROM   plant_issues_xref pix -- use the view
      WHERE  pix.pix_spoke_code in( select pix_spoke_code from plant_issues_xref where PIX_BRANCH_CODE = 'BRA850' and pix_legacy_year = min(pix_legacy_year))
      AND    pix.pix_sap_id     = 000000000455960015;
      
SELECT --nvl( pix.pix_legacy_ean, pix.pix_ean ),
             MIN( nvl( pix.pix_legacy_year, pix.pix_year) )
            -- pix.pix_legacy_title,
            -- pix.pix_orig_day,
            -- trunc( next_day(pix.pix_plant_on_sale_date-1,'Saturday') ),
            -- pix.pix_plant_on_sale_date
      FROM   plant_issues_xref pix -- use the view
      WHERE  pix.PIX_BRANCH_CODE = 'BRA850'                                 --Branch
      AND    pix.pix_sap_id     = 000000000455960015;
      
      
 SELECT MIN( nvl( pix.pix_legacy_year, pix.pix_year) ), MIN( pix.pix_plant_on_sale_date )
    FROM   plant_issues_xref pix
    WHERE  pix.pix_sap_id             = 000000000455960015
    AND    pix.pix_branch_code        = 'BRA850' 
    AND    pix.pix_legacy_title       = 45596
    AND    pix.pix_plant_on_sale_date IS NOT NULL;
