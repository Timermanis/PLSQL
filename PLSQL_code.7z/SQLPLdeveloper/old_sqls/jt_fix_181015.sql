select * from agent_movements --count(*)362444

select count(*) from agent_movements a, customers c
where a.hamo_agent_number = c.cus_account_number
and a.hamo_issue_invoice_date between c.cus_from_date and c.cus_to_date--count(*)362454 !!!!!



 --count(*)362444

select a.* from agent_movements a, customers c
where a.hamo_agent_number = c.cus_account_number
and a.hamo_issue_invoice_date between c.cus_from_date and c.cus_to_date--0
minus
select * from agent_movements
-----------------------------------------------------
create table jt_fix as
select c.* from agent_movements a, customers c
where a.hamo_agent_number = c.cus_account_number
and a.hamo_issue_invoice_date between c.cus_from_date and c.cus_to_date--362454

-------------------------------------------------------
select * from jt_fix j
minus
select * from customers  --0

select * from jt_fix f, agent_movements a

--------------------------------------------------------
select count(*) from jt_fix j--362454
select count(*) from agent_movements a  --362444
------------------------------------------------------------
select count(*) from agent_movements a, customers c
where a.hamo_agent_number = c.cus_account_number
and a.hamo_issue_invoice_date >= c.cus_from_date 
and a.hamo_issue_invoice_date <= c.cus_to_date--                          between count(*)362454 !!!!!
---------------------------------------------------------------
select count(unique a.hamo_agent_number) from agent_movements a--8454                       count(*)362444

select count( unique a.hamo_agent_number) from agent_movements a, customers c
where a.hamo_agent_number = c.cus_account_number
and a.hamo_issue_invoice_date between c.cus_from_date and c.cus_to_date--count(*)362454 !!!!!
-----------------------------------------------------------
create table account_numbers as
select unique a.hamo_agent_number from agent_movements a
--------------------------------------------------------------------
create table unique_urn_to_from as
select  unique a.hamo_agent_number,c.cus_from_date, c.cus_to_date from agent_movements a, customers c
where a.hamo_agent_number = c.cus_account_number
and a.hamo_issue_invoice_date between c.cus_from_date and c.cus_to_date

select HAMO_AGENT_NUMBER,count(*) from unique_urn_to_from group by HAMO_AGENT_NUMBER having count(*)>1
-----------------------------------------------------------------------------------

select HAMO_AGENT_NUMBER,count(*) from unique_urn_to_from group by HAMO_AGENT_NUMBER having count(*)>1--5589

SELECT
    n.HAMO_AGENT_NUMBER, cus_from_date, cus_to_date,
    ROW_NUMBER() OVER (PARTITION BY n.HAMO_AGENT_NUMBER ORDER BY cus_from_date desc) rn
  FROM unique_urn_to_from n,(select HAMO_AGENT_NUMBER,count(*) from unique_urn_to_from group by HAMO_AGENT_NUMBER having count(*)>1) m
  where n.hamo_agent_number = m.hamo_agent_number
---------------------------------------------------------------
select hamo_id,hamo_agent_number from agent_movements where hamo_id in(219103,
220336,
198223,
200948,
185308,
102439,
220297,
220736,
117741,
262321
)

select a.hamo_id,count(*) from agent_movements a, customers c
where a.hamo_agent_number = c.cus_account_number
and a.hamo_issue_invoice_date between c.cus_from_date and c.cus_to_date--count(*)362454 !!!!!
group by a.hamo_id having count(*)>1

219103	2 26/09/2015 26/09/2015
220336	2 19/09/2015
198223	2 19/09/2015
200948	2
185308	2
102439	2
220297	2
220736	2
117741	2
262321	2

102439	502963036224600
117741	502963036224600
185308	502963036224600
198223	502963036224600
200948	502963036224600
219103	502963036224600
220297	502963036224600
220336	502963036224600
220736	502963036224600
262321	502963036224600
















