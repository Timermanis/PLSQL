select * from ctl_files c where c.ctl_counterparty='BRA550' order by c.ctl_next_seq_no desc for update;
select * from sap_branches for update;
create table jt_msg_09012016 as
select * from msg_files m where m.msg_counterparty ='BRA550' order by m.msg_timestamp desc for update
group by m.msg_status having trunc (m.msg_timestamp) > to_date('01/12/2014','dd/mm/yyyy')

select * from ctl_files c where c.ctl_counterparty='BRA850' order by c.ctl_next_seq_no desc; --for update;
select * from sap_branches; --for update;
select * from msg_files m where m.msg_counterparty ='BRA850' order by m.msg_timestamp desc --for update
