select * from branch_issues b where b.bris_ean=977096337219342 

select * from plant_issues_xref x where x.PIX_EAN = 977096337219342 

select * from plant_issues_xref x where x.PIX_LEGACY_TITLE in 
(4315,
34527,
40122) 
and x.PIX_BRANCH_CODE = 'BRA220' and x.PIX_YEAR = 2015


select * from normal_issues n where n.niss_title_code in 
(4315,
34527,
40122) and n.niss_issue_year = 2015

select * from titles t where t.titl_code=4315
select * from titles t where t.titl_long_name like '%CHICHESTER OBSERVER%'
4315
34527
40122



                      
select * from customers c where c.cus_account_number=503103104070800
