begin
  for rec in (select table_name, substr(table_name,10,8),trim(to_char(sysdate-30,'yyyymmdd'))
              from   all_tables 
              where  
              (table_name like 'ICSD_____20%'
                or table_name like 'BISD_____20%'
                or table_name like 'ISUD_____20%'
                or table_name like 'KPSD_____20%'
                or table_name like 'MFHD_____20%'
                or table_name like 'TWSD_____20%')
                 AND (substr(table_name,10,8) < trim(to_char(sysdate-30,'yyyymmdd')))
                
             )
  loop
    execute immediate 'drop table '||rec.table_name;
  end loop;             
end;
