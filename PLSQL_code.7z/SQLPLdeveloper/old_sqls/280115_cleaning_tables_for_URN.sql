--drop table jt_280115_cleanup_SHELV_SPACES
create table jt_280115_cleanup_SHELV_SPACES as --SHELVING_SPACES 883 rows
select * from  SHELVING_SPACES a
where SSP_OWNED_BY_AGENT_CUS_ACCOUNT  not  in (select  c.cus_account_number from jt_280115_customers c  ) 
---
--drop table jt_280115_clean_AGENT_MEMBERs
create table jt_280115_clean_AGENT_MEMBERs as --AGENT_MEMBERs 12803 rows
select * from  AGENT_MEMBERs a
where AG_M_AGENT_ACCOUNT_NUMBER  not  in (select  c.cus_account_number from jt_280115_customers c  )
---
--drop table jt_280115_clean_AGEN_VAR_TERMS
create table jt_280115_clean_AGEN_VAR_TERMS as --AGENT_VARIABLE_TERMS 9715 rows
select * from  AGENT_VARIABLE_TERMS a
where AGENT_ACCOUNT_NUMBER  not  in (select  c.cus_account_number from jt_280115_customers c  )
---
--drop table jt_280115_clean_MULT_MEMBERS
create table jt_280115_clean_MULT_MEMBERS as --MULTIPLE_MEMBERS 79341 rows
select * from  MULTIPLE_MEMBERS a
where MMEM_CUST_ACCOUNT_NUMBER  not  in (select  c.cus_account_number from jt_280115_customers c  )

--create table jt_280115_customers as select distinct CUS_ACCOUNT_NUMBER from customers --290115
--drop table jt_280115_customers
-------------------------------------------------------------------------------------------------------------
delete  from SHELVING_SPACES s where s.SSP_OWNED_BY_AGENT_CUS_ACCOUNT in (select jt.SSP_OWNED_BY_AGENT_CUS_ACCOUNT from jt_280115_cleanup_SHELV_SPACES jt)
---
delete  from  AGENT_MEMBERs a where a.AG_M_AGENT_ACCOUNT_NUMBER in (select jt.AG_M_AGENT_ACCOUNT_NUMBER from jt_280115_clean_AGENT_MEMBERs jt)
---
delete from AGENT_VARIABLE_TERMS a where a.AGENT_ACCOUNT_NUMBER in (select jt.AGENT_ACCOUNT_NUMBER from jt_280115_clean_AGEN_VAR_TERMS jt)
---
delete  from MULTIPLE_MEMBERS m where m.MMEM_CUST_ACCOUNT_NUMBER in (select jt.MMEM_CUST_ACCOUNT_NUMBER from jt_280115_clean_MULT_MEMBERS jt)
