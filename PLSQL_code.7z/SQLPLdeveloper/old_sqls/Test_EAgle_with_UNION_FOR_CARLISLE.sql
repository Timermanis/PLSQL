
--------------------------------------1---------------------------------------------------------------------------------------------------------------------    

select b.* from archive.zpx_cus_dtls_stg_bak  b--5
    where (b.ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ)-4 from archive.archive_audit)) 
    and customer_id in (select customer_id from archive.zpx_cus_dtls_stg_bak a, VIEW_CARL_PREST_KEND_JTXREF@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER 
    and xref.PRM_OLD_BRANCH = 'BRA310');

----------------------------------------2

select b.* from archive.zpx_cus_supi_stg_bak  b--2
    where (b.ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ)-4 from archive.archive_audit)) 
    and customer_id in (select customer_id from archive.zpx_cus_supi_stg_bak a, VIEW_CARL_PREST_KEND_JTXREF@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER--); 
    and xref.PRM_OLD_BRANCH = 'BRA310');
  
----------------------------------------3

select b.* from archive.zpx_cus_deli_stg_bak  b--2
    where (b.ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ)-4 from archive.archive_audit)) 
    and customer_id in (select customer_id from archive.zpx_cus_deli_stg_bak a, VIEW_CARL_PREST_KEND_JTXREF@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER--); 
    and xref.PRM_OLD_BRANCH = 'BRA310');

----------------------------------------4

select b.* from archive.zpx_cus_hrs_stg_bak  b--1
    where (b.ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ)-4 from archive.archive_audit)) 
    and customer_id in (select customer_id from archive.zpx_cus_hrs_stg_bak a, VIEW_CARL_PREST_KEND_JTXREF@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER--); 
    and xref.PRM_OLD_BRANCH = 'BRA310');

----------------------------------------5

select b.* from archive.zpx_cus_xrf_stg_bak  b--8
    where (b.ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ)-4 from archive.archive_audit)) 
    and customer_id in (select customer_id from archive.zpx_cus_xrf_stg_bak a, VIEW_CARL_PREST_KEND_JTXREF@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER--) 
    and xref.PRM_OLD_BRANCH = 'BRA310');

----------------------------------------
