--Philip/Jan, can you take a look at this please. Looks like there is an issue with issue EAN on NORMAL_ISSUES and the link EAN on BRANCH_ISSUES  
--that is preventing the sales history for the Z4 title 40122 being displayed correctly.

select t.niss_issue_week,t.niss_issue_year,t.niss_title_code,t.niss_ean from normal_issues t
where t.niss_title_code = 4270
and t.NISS_ISSUE_YEAR in (2015) order by NISS_EAN desc for update;

select t.bris_branch_code,t.bris_issue_week,t.bris_issue_year,t.bris_title_code,t.bris_ean,t.bris_link_ean from branch_issues t
where --t.BRIS_BRANCH_CODE = 'BRA220'
 t.BRIS_LINK_ISSUE_YEAR in (2015)
and t.BRIS_TITLE_CODE in (4270)
and t.bris_issue_year = 2015
order by BRIS_ean desc for update;

select * from plant_issues_xref x where x.PIX_LEGACY_TITLE in(34527,40122) order by x.PIX_YEAR,x.PIX_WEEK 
select * from titles d where d.titl_code in (34527,40122);
select * from titles d where d.titl_long_name like '%CAMPBELTOWN%'Campbeltown Courier

select t.niss_issue_week,t.niss_issue_year,t.niss_title_code,t.niss_ean from normal_issues t where t.niss_issue_year=2015 and t.niss_ean = 30345271514001

select * from agent_net_sales a where a.net_issue_ean = 30401221543001 for update --30401221543001 --30401221541001 30401221543001
