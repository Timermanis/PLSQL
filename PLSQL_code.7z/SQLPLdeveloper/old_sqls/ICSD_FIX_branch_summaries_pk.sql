create table jt_PIX_060515_850 as
--select * from plant_issues_xref_base where PIX_SAP_ID=000000000053832273 and PIX_BRANCH_CODE in ('BRA310') union
select * from plant_issues_xref_base where PIX_SAP_ID=000000000053832274 and PIX_BRANCH_CODE in ('BRA220') for update
select * from plant_issues_xref_base where PIX_SAP_ID=000000000053832274 and PIX_BRANCH_CODE in ('BRA850','BRA790')--and PIX_LEGACY_TITLE=4249--000000000486720001
update plant_issues_xref_base t set t.pix_main_legacy_title=5383 
where t.pix_main_legacy_title=4249 --PIX_SAP_ID=000000000053832274 and PIX_BRANCH_CODE in ('BRA220') for update
select * from plant_issues_xref_base where PIX_SAP_ID=000000000053832274 and PIX_BRANCH_CODE in ('BRA790','BRA310')--and PIX_LEGACY_TITLE=4249--000000000486720001

select * from plant_issues_xref_base where PIX_SAP_ID=000000000053832274

------------------------------------------------------------------------------------------------
update plant_issues_xref_base t set t.pix_main_legacy_title = 90777 
where PIX_SAP_ID=000000000486720001

update plant_issues_xref_base t 
--set t.pix_legacy_ean =977205894800918--to_number('3' || lpad(90776, 6, '0') || substr(2015, 3, 2) || lpad( 18 , 2, '0') || 0 || '01'),pix_source_flag3 = '0'-- 90776 
set t.pix_legacy_ean ='3'||lpad(90776,6,'0')||substr(2015,3,2)||lpad(18,2,'0')||0||'01',  pix_source_flag3 = '0'
where PIX_SAP_ID=000000000486720001
and t.pix_legacy_title=90776;

update plant_issues_xref_base t 
--set t.pix_legacy_ean =977205894800918--to_number('3' || lpad(90778, 6, '0') || substr(2015, 3, 2) || lpad( 18 , 2, '0') || 0 || '01'),pix_source_flag3 = '0'-- 90776 
set t.pix_legacy_ean ='3'||lpad(90778,6,'0')||substr(2015,3,2)||lpad(18,2,'0')||0||'01',  pix_source_flag3 = '0'
where PIX_SAP_ID=000000000486720001
and t.pix_legacy_title=90778


pix_legacy_ean = '3'||lpad(v_leg_title,6,'0')||substr(v_year,3,2)||lpad(v_week,2,'0')||v_day||'01',
        pix_source_flag3 = '0'
--DUAL
select '3'||lpad(4249,6,'0')||substr(2015,3,2)||lpad(21,2,'0')||0||'01' from dual ,  pix_source_flag3 = '0' 
