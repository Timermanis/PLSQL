select b.bris_ean,b.bris_title_code,b.bris_issue_week, b.bris_issue_year,n.niss_ean,n.niss_title_code,n.niss_issue_week,n.niss_issue_year from branch_issues b, normal_issues n
where b.bris_link_ean = n.niss_ean and b.bris_link_issue_year = n.niss_issue_year
and b.bris_title_code = 40122
and b.bris_issue_year in (2015,2014,2013)  
and b.bris_title_code != n.niss_title_code
order by b.bris_issue_week desc

select b.bris_ean,b.bris_issue_week,b.bris_title_code,x.PIX_LEGACY_EAN,x.PIX_WEEK,x.PIX_LEGACY_YEAR,x.PIX_LEGACY_TITLE from branch_issues b, plant_issues_xref x 
where b.bris_title_code = x.PIX_LEGACY_TITLE
and b.bris_issue_week = x.PIX_WEEK
and b.bris_issue_year = nvl(x.PIX_LEGACY_YEAR,x.PIX_YEAR)
--and b.bris_ean = x.PIX_EAN
--and b.bris_ean = x.PIX_LEGACY_EAN
and x.PIX_LEGACY_TITLE = 40122
and b.bris_issue_year = 2015

and b.bris_ean != x.PIX_LEGACY_EAN




update normal_issues n set n.niss_title_code = 40122 where  
(n.niss_ean,n.niss_issue_week,n.niss_issue_year) in 
(select n.niss_ean,n.niss_issue_week,n.niss_issue_year from branch_issues b, normal_issues n
where b.bris_link_ean = n.niss_ean and b.bris_link_issue_year = n.niss_issue_year
and b.bris_title_code = 40122
and b.bris_issue_year = 2015 
and b.bris_title_code != n.niss_title_code)
---------------------------------------------------UPDATED NORMAL_ISSUES---------------------------------
update normal_issues n set n.niss_title_code = 40122 where  
(n.niss_ean,n.niss_issue_week,n.niss_issue_year) in 
(select n.niss_ean,n.niss_issue_week,n.niss_issue_year from branch_issues b, normal_issues n
where b.bris_link_ean = n.niss_ean and b.bris_link_issue_year = n.niss_issue_year
and b.bris_title_code = 40122
and b.bris_issue_year in (2015,2014,2013) 
and b.bris_title_code != n.niss_title_code);
-------------------------------------------------------UPDATED plant_issues_xref_base IN REFMAST------------------
update plant_issues_xref_base x set x.PIX_LEGACY_EAN = 
(select b.bris_ean
 from plant_issues_xref_base xx, branch_issues@mis.world b 
where b.bris_title_code = xx.PIX_LEGACY_TITLE
and b.bris_issue_week = xx.PIX_WEEK
and b.bris_issue_year = nvl(xx.PIX_LEGACY_YEAR,xx.PIX_YEAR)
and xx.PIX_LEGACY_TITLE = 40122
and xx.pix_year in (2015,2014,2013) 
and b.bris_ean != xx.PIX_LEGACY_EAN
and x.PIX_LEGACY_EAN = xx.pix_legacy_ean
and nvl(xx.PIX_LEGACY_YEAR,xx.PIX_YEAR) = nvl(x.PIX_LEGACY_YEAR,x.PIX_YEAR))
where exists 
(select 1
 from plant_issues_xref_base xx, branch_issues@mis.world b 
where b.bris_title_code = xx.PIX_LEGACY_TITLE
and b.bris_issue_week = xx.PIX_WEEK
and b.bris_issue_year = nvl(xx.PIX_LEGACY_YEAR,xx.PIX_YEAR)
and xx.PIX_LEGACY_TITLE = 40122
and xx.pix_year in (2015,2014,2013) 
and b.bris_ean != xx.PIX_LEGACY_EAN
and x.PIX_LEGACY_EAN = xx.pix_legacy_ean
and nvl(xx.PIX_LEGACY_YEAR,xx.PIX_YEAR) = nvl(x.PIX_LEGACY_YEAR,x.PIX_YEAR))

