select * from archive.ZPX_CUS_DTLS_STG_BAK t where t.CUSTOMER_ID = 139480
delete from archive.ZPX_CUS_DTLS_STG_BAK t where t.CUSTOMER_ID = 139480
--
create table jt_zpx_cus_xrf_stg_bak_191015 as
select * from archive.zpx_cus_xrf_stg_bak t where t.CUSTOMER_ID in (123809,123845,123855,123862,123865,123888,124320,124520,135502,138992,88680) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
create table jt_zpx_cus_hrs_stg_bak_191015 as
select * from archive.zpx_cus_hrs_stg_bak t where t.CUSTOMER_ID in (123809,123845,123855,123862,123865,123888,124320,124520,135502,138992,88680) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
create table jt_zpx_cus_deli_stg_bak_191015 as
select * from archive.zpx_cus_deli_stg_bak t where t.CUSTOMER_ID in (123809,123845,123855,123862,123865,123888,124320,124520,135502,138992,88680) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
create table jt_zpx_cus_supi_stg_bak_191015 as
select * from archive.zpx_cus_supi_stg_bak t where t.CUSTOMER_ID in (123809,123845,123855,123862,123865,123888,124320,124520,135502,138992,88680) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
create table jt_zpx_cus_dtls_stg_bak_191015 as
select * from archive.zpx_cus_dtls_stg_bak t where t.CUSTOMER_ID in (123809,123845,123855,123862,123865,123888,124320,124520,135502,138992,88680) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
--
insert into jt_zpx_cus_xrf_stg_bak_191015 
select * from archive.zpx_cus_xrf_stg_bak t where t.CUSTOMER_ID in (123713) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
insert into jt_zpx_cus_hrs_stg_bak_191015 
select * from archive.zpx_cus_hrs_stg_bak t where t.CUSTOMER_ID in (123713) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
insert into jt_zpx_cus_deli_stg_bak_191015 
select * from archive.zpx_cus_deli_stg_bak t where t.CUSTOMER_ID in (123713) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
insert into jt_zpx_cus_supi_stg_bak_191015 
select * from archive.zpx_cus_supi_stg_bak t where t.CUSTOMER_ID in (123713) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
insert into jt_zpx_cus_dtls_stg_bak_191015 
select * from archive.zpx_cus_dtls_stg_bak t where t.CUSTOMER_ID in (123713) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;

insert into jt_zpx_cus_xrf_stg_bak_191015 
select * from archive.zpx_cus_xrf_stg_bak t where t.CUSTOMER_ID in (123690) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
insert into jt_zpx_cus_hrs_stg_bak_191015 
select * from archive.zpx_cus_hrs_stg_bak t where t.CUSTOMER_ID in (123690) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
insert into jt_zpx_cus_deli_stg_bak_191015 
select * from archive.zpx_cus_deli_stg_bak t where t.CUSTOMER_ID in (123690) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
insert into jt_zpx_cus_supi_stg_bak_191015 
select * from archive.zpx_cus_supi_stg_bak t where t.CUSTOMER_ID in (123690) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;
insert into jt_zpx_cus_dtls_stg_bak_191015 
select * from archive.zpx_cus_dtls_stg_bak t where t.CUSTOMER_ID in (123690) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;

delete   from archive.zpx_cus_xrf_stg_bak t where t.CUSTOMER_ID in (123809,123845,123855,123862,123865,123888,124320,124520,135502,138992,88680) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;

delete   from archive.zpx_cus_hrs_stg_bak t where t.CUSTOMER_ID in (123809,123845,123855,123862,123865,123888,124320,124520,135502,138992,88680) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;

delete   from archive.zpx_cus_deli_stg_bak t where t.CUSTOMER_ID in (123809,123845,123855,123862,123865,123888,124320,124520,135502,138992,88680) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;

delete   from archive.zpx_cus_supi_stg_bak t where t.CUSTOMER_ID in (123809,123845,123855,123862,123865,123888,124320,124520,135502,138992,88680) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;

delete   from archive.zpx_cus_dtls_stg_bak t where t.CUSTOMER_ID in (123809,123845,123855,123862,123865,123888,124320,124520,135502,138992,88680) and t.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_cus_dtls_stg_bak)  ;

delete  from archive.zpx_cus_xrf_stg_bak t where t.CUSTOMER_ID in 139480 ;123713;0000123690
delete from archive.zpx_cus_hrs_stg_bak t where t.CUSTOMER_ID = 139480;
delete from archive.zpx_cus_deli_stg_bak t where t.CUSTOMER_ID = 139480;
delete from archive.zpx_cus_supi_stg_bak t where t.CUSTOMER_ID = 139480;
delete from archive.zpx_cus_dtls_stg_bak t where t.CUSTOMER_ID = 139480

delete  from archive.zpx_cus_xrf_stg_bak t where t.CUSTOMER_ID in 123713 ;
delete from archive.zpx_cus_hrs_stg_bak t where t.CUSTOMER_ID = 123713;
delete from archive.zpx_cus_deli_stg_bak t where t.CUSTOMER_ID = 123713;
delete from archive.zpx_cus_supi_stg_bak t where t.CUSTOMER_ID = 123713;
delete from archive.zpx_cus_dtls_stg_bak t where t.CUSTOMER_ID = 123713

delete  from archive.zpx_cus_xrf_stg_bak t where t.CUSTOMER_ID in 123690 ;
delete from archive.zpx_cus_hrs_stg_bak t where t.CUSTOMER_ID = 123690;
delete from archive.zpx_cus_deli_stg_bak t where t.CUSTOMER_ID = 123690;
delete from archive.zpx_cus_supi_stg_bak t where t.CUSTOMER_ID = 123690;
delete from archive.zpx_cus_dtls_stg_bak t where t.CUSTOMER_ID = 123690
