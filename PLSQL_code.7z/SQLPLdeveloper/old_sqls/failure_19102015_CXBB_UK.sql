update customer_x_ref c
set c.ccr_legacy_box_no= get_box_number(550), 
    c.ccr_branch_code = 'BRA550'
where c.ccr_bus_partner_id =0000139480
and c.ccr_branch_code = 'BRA680'

insert into new_box_numbers t
values
(
680, --Dundee branch code
1061 --Old Dundee Box
);

--Get the new box from this query
select *
  from customer_x_ref c
 where c.ccr_bus_partner_id = '0000139480';

--Updated the customers table with the new branch/box and URN  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
update customers c
  set c.cus_box_number     = 13998
    , c.cus_branch_code    = 'BRA550'
where c.cus_account_number = 680139480000900;

select * from customers c where c.cus_account_number = 680139480000900
