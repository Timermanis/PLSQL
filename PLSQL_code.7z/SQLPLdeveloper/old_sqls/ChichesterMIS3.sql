create table jt_branch_issues_241015 as
select * from branch_issues b where b.bris_title_code = 40122 and b.bris_issue_year=2015 --for update
select * from normal_issues n where n.niss_title_code = 40122 and n.niss_issue_year=2015 --for update 30401221540001
select * from normal_issues n where n.niss_ean= 977096337219340 and n.niss_issue_year=2015
select * from branch_issues b where b.bris_ean=30401221541001 and b.bris_issue_year=2015 for update
select * from plant_issues_xref x where x.PIX_LEGACY_TITLE = 40122 and x.PIX_YEAR = 2015
30401221541001
30401221543001
30401221541001
30401221541001
30401221541001
select * from issues i where i.ISSU_EAN like '3040122154_001' for update 030401221541001
select * from issues i where i.ISSU_EAN = 030401221541001
select * from issues i where i.issu_ean = 30401221541001
030401221541001

select 

delete from branch_issues b where  b.bris_ean=30401221541001 and b.bris_issue_year=2015

select t.bris_branch_code,t.bris_issue_week,t.bris_issue_year,t.bris_title_code,t.bris_ean,t.bris_link_ean from branch_issues t
where t.BRIS_BRANCH_CODE = 'BRA220'
and t.BRIS_LINK_ISSUE_YEAR in (2014,2015)
and t.BRIS_TITLE_CODE in (40122)
and t.bris_issue_year = 2015
order by BRIS_ISSUE_WEEK desc;
