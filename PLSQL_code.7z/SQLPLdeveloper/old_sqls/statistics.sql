select v.OSUSER
    --   ,s.sql_id
       ,s.rows_processed
     , s.plan_hash_value
     --, s.last_active_time
     , s.executions
     --, round(100 * s.parse_calls/nullif(s.executions,0),1)  as "Parsed%"
     , s.parse_calls
     , cast(numtodsinterval(s.elapsed_time/1e6,'SECOND')  as interval day(0) to second(0)) as elapsed_total
     , cast(numtodsinterval(s.elapsed_time / nullif(s.executions,0) / 1e6,'SECOND') as interval day(0) to second(0)) as elapsed_per_exec
     , round(100 * s.cpu_time / s.elapsed_time,1) "CPU%"
     , a.SQL_TEXT
     , round(100 * s.user_io_wait_time / s.elapsed_time,1) "IO%"
     , round(100 * s.concurrency_wait_time / s.elapsed_time,1) "CONCURRRENCY%"
    -- , round(100 * s.application_wait_time / s.elapsed_time,1) "APPLICATION%"
    -- , round(100 * s.plsql_exec_time / s.elapsed_time,1) "PL/SQL%"
    -- , s.buffer_gets buffer_gets_total
     , round(s.buffer_gets / nullif(s.executions,0))        as buffer_gets_per_exec
     , s.disk_reads
     , round(s.rows_processed / nullif(s.fetches,0),1)      as rows_per_fetch
     , round(s.rows_processed / nullif(s.executions,0),1)   as rows_per_exec
     --, s.direct_writes
     , s.rows_processed
     , s.fetches
     , s.end_of_fetch_count
     , s.loads
     , s.version_count
     , s.invalidations
     , round(s.avg_hard_parse_time / 1e6,2)               as avg_hard_parse_secs
     , s.cluster_wait_time
     , cast(numtodsinterval(s.plsql_exec_time/1e6,'SECOND') as interval day(0) to second(0)) as plsql_exec_time
     , cast(numtodsinterval(s.java_exec_time/1e6,'SECOND') as interval day(0) to second(0)) as java_exec_time
     , s.sorts
     , s.sharable_mem
     , s.total_sharable_mem
     , s.last_active_child_address
  
from   v$sqlstats s,v$session v,V$SQLAREA A
where  s.sql_id = v.sql_id
and v.sql_id = a.sql_id
and v.STATUS = 'ACTIVE'
order by s.rows_processed desc
