--create table outer_postcode_summ_010515 as
delete from outer_postcode_summaries s--39 rows
where exists
  (select 1
    from JT_FIX_030515 j -- ones trying to ins/upd
   where j.BRAN_BRANCH_CODE = s.opos_branch_code
   and j.cus_postcode_outer = s.opos_postout_outer_code
   and j.EAN = s.opos_issue_ean
   and j.hamo_issue_year = s.opos_issue_issue_year)
   
create table outer_postcode_summ_030515 as
   select *
from outer_postcode_summaries s
where exists
  (select *
   from JT_FIX_030515 j -- ones trying to ins/upd
   where j.BRAN_BRANCH_CODE = s.opos_branch_code
   and j.cus_postcode_outer = s.opos_postout_outer_code
   and j.EAN = s.opos_issue_ean
   and j.hamo_issue_year = s.opos_issue_issue_year)

insert into OUTER_POSTCODE_SUMMARIES 
select * from jt_ops_already_exist_010515--outer_postcode_summ_010515

select * from jt_ops_already_exist_010515 a, OUTER_POSTCODE_SUMMARIES b
where a.opos_branch_code=b.opos_branch_code
and a.opos_issue_ean=b.opos_issue_ean
and a.opos_issue_issue_year = b.opos_issue_issue_year
and a.opos_postout_outer_code = b.opos_postout_outer_code 

select * from outer_postcode_summ_030515 w
