select * from hk_2015_ans_2011_2012_driver
select * from hk_2015_cas_ans_2007_backup
--CREATE BACKUP TABLE

create table hk_2015_ans_2008_cas 
tablespace archive_temp 
nologging as
select * from cas_agent_net_sales
where net_issue_year = 2008;

create table hk_2015_ans_740_cas 
tablespace archive_temp 
nologging as
select * from cas_agent_net_sales
where NET_BRANCH_CODE = 'BRA740';

create table hk_2015_cas_ans_2007_backup 
tablespace archive_temp 
nologging as
select a.* from cas_agent_net_sales a,HK_BRANCH_EAN_YR where 
a.net_branch_code = hk_branch_code
      and   a.net_issue_ean   = hk_ean
      and   a.net_issue_year  = hk_issue_year;

create table hk_2015_cas_ans_2011_12_backup 
tablespace archive_temp
nologging as
select a.* from cas_agent_net_sales a,HK_BRANCH_EAN_YR where 
a.net_branch_code = hk_branch_code
      and   a.net_issue_ean   = hk_ean
      and   a.net_issue_year  = hk_issue_year;

--INSERT INTO UNION
insert into HK_BRANCH_EAN_YR (HK_BRANCH_CODE,HK_EAN,HK_ISSUE_YEAR)--added union below
select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from branch_issues where  BRIS_LINK_ISSUE_YEAR = 2010 union 
select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from cas_branch_issues where  BRIS_LINK_ISSUE_YEAR = 2010



insert into HK_BRANCH_EAN_YR (HK_BRANCH_CODE,HK_EAN,HK_ISSUE_YEAR)--added union below for 2011,2012
select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from cas_branch_issues b,FOUR_YEAR_TITLES f 
where  b.BRIS_TITLE_CODE= f.TITL_CODE(+)
and f.TITL_CODE is null
and b.BRIS_LINK_ISSUE_YEAR in (2011,2012) 
union 
select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from branch_issues b,FOUR_YEAR_TITLES f 
where  b.BRIS_TITLE_CODE= f.TITL_CODE(+)
and f.TITL_CODE is null
and b.BRIS_LINK_ISSUE_YEAR in (2011,2012)




insert into HK_BRANCH_EAN_YR (HK_BRANCH_CODE,HK_EAN,HK_ISSUE_YEAR)--added union below
select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from cas_branch_issues where  BRIS_ISSUE_YEAR = 2009 union select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from branch_issues where  BRIS_ISSUE_YEAR = 2009

insert into HK_BRANCH_EAN_YR (HK_BRANCH_CODE,HK_EAN,HK_ISSUE_YEAR)--branch issues seperately
select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from branch_issues where  BRIS_ISSUE_YEAR = 2007

select count (select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from cas_branch_issues) from dual union select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from branch_issues where  BRIS_ISSUE_YEAR = 2007
--INSERT INTO HK_BRANCH_EAN_YR 2011 and 2012
insert into HK_BRANCH_EAN_YR (HK_BRANCH_CODE,HK_EAN,HK_ISSUE_YEAR)

(select  distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from cas_BRANCH_ISSUES b, FOUR_YEAR_TITLES f 
where b.BRIS_TITLE_CODE= f.TITL_CODE(+) 
and f.TITL_CODE is null  
and b.BRIS_LINK_ISSUE_YEAR in (2011,2012))



select b.BRIS_TITLE_CODE,f.TITL_CODE,h.hk_ean,b.bris_ean,h.hk_issue_year,b.bris_issue_year from HK_BRANCH_EAN_YR h, BRANCH_ISSUES b, FOUR_YEAR_TITLES f where b.BRIS_TITLE_CODE=f.TITL_CODE and h.hk_ean = b.bris_ean 
and h.hk_issue_year=b.bris_issue_year
and b.BRIS_LINK_ISSUE_YEAR in (2011);


--INSERT INTO BY LINK YEAR
insert into HK_BRANCH_EAN_YR (HK_BRANCH_CODE,HK_EAN,HK_ISSUE_YEAR)
select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from branch_issues where  BRIS_LINK_ISSUE_YEAR = 2010

select *
from dba_tables where TABLESPACE_NAME = 'ARCHIVE_TEMP'
--RENAME TABLE
create table  HK_BRAN_EAN_YR_cas_2007_020415 as (select *  from HK_BRANCH_EAN_YR)
 
truncate table HK_BRANCH_EAN_YR


select distinct HK_BRANCH_CODE from HK_BRANCH_EAN_YR_2009
select HK_BRANCH_CODE,count(*) HK_BRANCH_CODE from HK_BRANCH_EAN_YR group by HK_BRANCH_CODE
select count(*),HK_BRANCH_CODE from HK_BRANCH_EAN_YR group by HK_BRANCH_CODE 

with count_per_branch as
(select count(*) as AAA from HK_BRANCH_EAN_YR group by HK_BRANCH_CODE)
select avg(AAA) from count_per_branch

create table HK_BRANCH_EAN_YR_2011_12 as 
select * from HK_BRANCH_EAN_YR where 1=0

CREATE INDEX HK_BRANCH_EAN_YR_2009_INDEX ON HK_BRANCH_EAN_YR_2009(HK_BRANCH_CODE, HK_EAN, HK_ISSUE_YEAR)
      TABLESPACE archive_temp
--rebuld indexes     
ALTER INDEX hk_branch_ean_yr_index REBUILD; 

RENAME hk_branch_ean_yr_2009 TO hk_branch_ean_yr
create table hk_branch_ean_yr_2009 as select * from hk_branch_ean_yr
truncate table hk_branch_ean_yr

--test
select cas.* from cas_agent_net_sales cas, branch_issues bra where cas.net_issue_year = 2007 --test does something left regarding driver table
and bra.bris_ean = cas.net_issue_ean 
and bra.bris_issue_year=cas.net_issue_year 
and bra.bris_branch_code=cas.net_branch_code

select count(*) from cas_agent_net_sales cas where  cas.net_issue_year <= 2006 --andcas.net_issue_ean=10002540742101--10002540742101--
select count(*) from agent_net_sales cas where  net_issue_year = 2006
select * from HK_BRANCH_EAN_YR 

select * from HK_BRANCH_EAN_YR where HK_AGNS_IND is null--check does the housekeeping finished for the driver

insert into HK_BRANCH_EAN_YR (HK_BRANCH_CODE,HK_EAN,HK_ISSUE_YEAR)--added union below
--remove records with cas_ans driver
insert into HK_BRANCH_EAN_YR (HK_BRANCH_CODE,HK_EAN,HK_ISSUE_YEAR)
select distinct net_branch_code, net_issue_ean,net_issue_year from cas_agent_net_sales where  net_ISSUE_YEAR <= 2005

select HK_ISSUE_YEAR,count(*) from HK_BRANCH_EAN_YR where HK_AGNS_IND = 'Y' group by HK_ISSUE_YEAR;
select HK_ISSUE_YEAR,count(*) from HK_BRANCH_EAN_YR   where HK_AGNS_IND is null group by HK_ISSUE_YEAR;

select * from branch_issues c where c.bris_issue_year = 2012 and c.bris_link_issue_year=2010

--delete from cas_agent_net_sales ---- Removed all records for 740 from CAS due to Peter's request.
where NET_BRANCH_CODE = 'BRA740';


----------------------------Peter staff----------------------------------------------
insert into HK_BRANCH_EAN_YR_IPSWICH (HK_BRANCH_CODE,HK_EAN,HK_ISSUE_YEAR)--added union below

--delete from cas_agent_net_sales  where (net_branch_code,net_issue_ean,net_issue_year) in
(select distinct     BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from cas_branch_issues b where BRIS_BRANCH_CODE='BRA120' and BRIS_ON_SALE_DATE >= to_date ('20/10/2014','dd/mm/yyyy') 
union select distinct BRIS_BRANCH_CODE,BRIS_EAN,BRIS_ISSUE_YEAR from branch_issues where BRIS_BRANCH_CODE='BRA120' and BRIS_ON_SALE_DATE >= to_date ('20/10/2014','dd/mm/yyyy')   )

select net_BRANCH_CODE,count(*) from cas_agent_net_sales a where a.net_issue_year = 2015 --and BRIS_BRANCH_CODE='BRA120'
group by net_BRANCH_CODE
--------------------------------------------------------------------------------------------
select LOCALTIMESTAMP  from dual
