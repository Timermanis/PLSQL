select * from titles where TITL_CODE in (4249,5383,4242)
select * from titles where TITL_CODE in (631,35482,35484)
select * from titles where TITL_CODE in (90791,90790)
select * from titles where TITL_CODE in (48808)

select * from titles where  TITL_LONG_NAME like '%BRENTWOOD%'--488080001
select * from titles where  TITL_CODE in (90790,90791,13725) --orTITL_LONG_NAME like '%BRENTWOOD%'--

select * from plant_issues_xref where PIX_EAN = 977204412005120--000000000488080001
select * from plant_issues_xref where PIX_SAP_ID=000000000488080001
