select *
from sap_extract_log l
where  log_time in 
(select max(log_time) from sap_extract_log 
where BRANCH_ID != 'BRA000'
and TASK != 'No new SAP staging table data found'
group by BRANCH_ID  )
order by run_seq_no,log_time desc;

select *
  from sap_extract_log l
 where BRANCH_ID in ('BRA120') order by log_time desc;
   --and l.log_time >= (select max(log_time) from sap_extract_log where task = 'Started SAP transaction extract' and branch_id = '&<name="Branch ID (From drop down list)">')
 order by l.log_time desc;

select *
from sap_extract_log l where BRANCH_ID in( 'BRA560','BRA220') and TASK ='Completed SAP transaction extract'
order by log_time desc;

select * from sap_branches 
select * from msg_files where MSG_COUNTERPARTY = 'BRA220' order by MSG_TIMESTAMP desc for update
select * from ctl_files where ctl_COUNTERPARTY = 'BRA220' 
select *
  from sap_extract_log l
 where BRANCH_ID in ('BRA120') and task like 'K%' order by log_time desc;
