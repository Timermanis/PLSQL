select t.iss_original_year, count (*) from jt_driver_table t group by  t.iss_original_year minus
select t.iss_original_year, count (*) from jt_driver_issue_level t group by  t.iss_original_year


select * from jt_driver_table t  minus
select * from jt_driver_table_261015_v2 t 
