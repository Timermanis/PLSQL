create table jt_TEST_del_ins_4000 as
 select   DIMENSION_KEY,PLIS_ID,PLIS_ISSUE_NUM,ISS_ORIGINAL_YEAR from  dw.MEDIA w,termsprd.latest_media_issue t
           where  (w.iss_type_code in ('Z7','Z8') or w.iss_type_code = 'Z5' and trim(t.parent_prod_id) is not null)
           and t.id = w.plis_issue_num
           and w.ISS_ORIGINAL_YEAR = 2003;   --602 for the join
           
 select unique z.* from jt_test_del_ins_4000 t ,dw.retailer_transaction z where t.dimension_key=z.plant_issue_id --3500
 
 update JT_DRIVER_TABLE_2002 t set INDICAT = null;
commit;
