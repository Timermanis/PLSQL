create table jt_fix_020515 as
select
a.hamo_issue_ean,  ------------------------------------------------
                    a.hamo_issue_year, -------------------------------------
                   
                    c.cus_postcode_outer,--------------------------------
                    bt.bran_branch_code----------------------------------
                   
                    
  --select *                  
    FROM
                    agent_movements            a,
                    customers                  c,
                    branch_terms               bt,
                    titles                     t,
                    issues                     i,
                    multiple                   m,
                    agent_retailer_band_groups arbg,
                    agent_variable_terms       avt,
                    title_variable_term_bands  tvb
    WHERE 
                  a.hamo_agent_number = c.cus_account_number
            and   a.hamo_issue_invoice_date between c.cus_from_date and 
                                                    c.cus_to_date
            and   a.hamo_issue_invoice_date between bt.bran_date_from and
                                                    bt.bran_date_to   
            and   a.hamo_title_code = bt.bran_title_code 
            and   'BRA220' = bt.bran_branch_code
            and   t.titl_code       =  a.hamo_title_code
            and   i.issu_ean        =  a.hamo_issue_ean
            and   i.issu_issue_year =  a.hamo_issue_year
            and   c.cus_multiple_code = m.mult_multiple_code(+)
            and   arbg.arbg_account_number(+) = a.hamo_agent_number
            and   arbg.arbg_titl_code(+) = a.hamo_title_code
            and   a.hamo_issue_invoice_date between arbg.arbg_date_from(+) and
                                                    arbg.arbg_date_to(+)
            and   a.hamo_agent_number = avt.agent_account_number(+) 
            and   a.hamo_title_code   = avt.title_code(+) 
            and   a.hamo_issue_invoice_date between avt.date_from(+) and
                                                    avt.date_to(+)   
            and   avt.titvarbnd_titv_band = tvb.titv_title_band(+)
            and   avt.title_code          = tvb.titv_title_code(+)
            and   ((a.hamo_issue_invoice_date between tvb.titv_date_from and
                                                      tvb.titv_date_to) OR 
                    avt.title_code IS NULL);
