select distinct
a.tablespace_name,
CAST (SUM(a.bytes)/1073741824 as decimal (9,2)) "Curr Gb",
CAST (SUM(decode(b.maxextend, null, A.BYTES/1073741824, b.maxextend*8192/1073741824)) as decimal (9,2)) "Max Gb",
CAST ((SUM(a.bytes)/1073741824 - round(c."Free"/1073741824)) as decimal (9,2)) "Total Used",
CAST ((SUM(decode(b.maxextend, null, A.BYTES/1073741824, b.maxextend*8192/1073741824)) - (SUM(a.bytes)/1073741824 - round(c."Free"/1073741824))) as decimal (9,2)) "Total Free",
round(100*(SUM(a.bytes)/1073741824 - round(c."Free"/1073741824))/(SUM(decode(b.maxextend, null, A.BYTES/1073741824, b.maxextend*8192/1073741824)))) "% Used"
from
dba_data_files a,
sys.filext$ b,
(SELECT d.tablespace_name , sum(nvl(c.bytes,0)) "Free" FROM dba_tablespaces d,DBA_FREE_SPACE c where d.tablespace_name = c.tablespace_name(+) group by d.tablespace_name) c
where a.file_id = b.file#(+)
and a.tablespace_name = c.tablespace_name
and A.TABLESPACE_NAME LIKE 'RTRN_%4000%'
GROUP by a.tablespace_name, c."Free"
order by a.tablespace_name
