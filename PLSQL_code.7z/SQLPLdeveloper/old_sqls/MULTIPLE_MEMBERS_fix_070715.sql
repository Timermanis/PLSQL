create table jt_MIS_fix_MULT_MEM_070715 as
select * from multiple_members m where m.mmem_cust_account_number = 502963099955800 and m.mmem_date_to = to_date('31/12/4000','DD/MM/YYYY') for update

with a as
(
select * from multiple_members m ,she_wak_customer_xref s  
where m.mmem_cust_account_number=s.prm_new_urn
and trunc(MMEM_DATE_TO)='11/JUL/2015' --1635 only with this
--and trunc(MMEM_DATE_TO)='31/DEC/4000' --1640 only with this
--and trunc(MMEM_DATE_FROM)='12/JUL/2015' --1634 only with this
)
select * from a where 

select * from multiple_members m where m.mmem_cust_account_number = 502963050870501 

select * from customers c where c.cus_account_number=502963050870501
------------------Ian Porter fix---------------------------------------------------------
delete from multiple_members
where mmem_date_from > to_date('05-JUL-2015','DD-MON-YYYY')
and mmem_cust_account_number in (select prm_new_urn from she_wak_customer_xref) 
 
 -- 1634 records

 
 -- note that the update will also pick up the record that you already fixed.
update 
multiple_members
set mmem_date_to  =  to_date('31-DEC-4000','DD-MON-YYYY')
where trunc(mmem_date_to)  =  to_date('11-JUL-2015','DD-MON-YYYY')
and mmem_cust_account_number in (select prm_new_urn from she_wak_customer_xref) 
