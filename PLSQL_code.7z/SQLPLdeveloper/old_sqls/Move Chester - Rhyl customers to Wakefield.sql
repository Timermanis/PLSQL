-- Move Chester/Rhyl customers to Wakefield
-- 1)  Before run this check from date of the current record is in the past for customers going to update
-- i.e. none of customers moving should have a cus_from_date >=17/08/2015 before start 
-- If they have (which is possible as if get multiple changes of customet in week, the next chnage takes effect from folloiwng week)
-- you need adjust the dates accordingly as from 17/08/2015 these customers belong to 740 rather than 320 branch
-- Also check multiple_members from_date for customers in che_rhy_wak_customer_xref donnot have a from_date >= 17/08/2015 before start
--if count(*) need makee sure aren't i.e. adjust accordingly  

select count(*)
from customers c
where c.cus_account_number in (select x.prm_old_urn from che_rhy_wak_customer_xref x)
and c.cus_branch_code = 'BRA320'
AND CUS_SPOKE_CODE is null
and c.cus_from_date >= to_date('17/08/2015','DD/MM/YYYY')     

-- Step 1 backup data 
  create table por_customers_orig_170815
  as select *
  from customers c
  where c.cus_branch_code in ('BRA320');
  
  create table por_customers_xref_orig_170815
  as select *
  from customer_x_ref x
  where x.ccr_branch_code in ('BRA320');
  
  
--Step 2
--Close the old customer records

update customers c
   set c.cus_to_date = to_date('16/08/2015 23:59:59','dd/mm/yyyy hh24:mi:ss')
where c.cus_branch_code in ('BRA320')
   and c.cus_to_date = to_date('31/12/4000','dd/mm/yyyy') --(i.e. chester/rhyl customers)
   and c.cus_account_number in (select x.prm_old_urn from che_rhy_wak_customer_xref x) -- moving to Wakefield
                              
commit;

-- Step 3
--copy them to the new hub branch
insert into customers c
select  CUS_BILL_SHOW,
        CUS_ACCOUNT_NUMBER,
       to_date('17/08/2015','dd/mm/yyyy') CUS_FROM_DATE,
        to_date('31/12/4000','dd/mm/yyyy')CUS_TO_DATE,
        CUS_ACCOUNT_STATUS,
        CUS_REALLOCATION_FLAG,
        CUS_ADDRESS_LINE_1,
        CUS_ADDRESS_LINE_2,
        CUS_ADDRESS_LINE_3,
        CUS_ADDRESS_LINE_4,
        x.prm_new_box_number CUS_BOX_NUMBER,
        CUS_DAILIES_HANDLED,
        CUS_EPOS_TILL_IN_USE,
        CUS_DAILIES_BOX_OUTS_HANDLED,
        CUS_SUNDAYS_BOX_OUTS_HANDLED,
        CUS_SUB_POST_OFFICE,
        CUS_POSTCODE_OUTER,
        CUS_POSTCODE_INNER,
        CUS_PERIODICALS_HANDLED,
        CUS_PERIODICALS_BOX_OUTS_HAND,
        CUS_NFRN_MEMBER,
        CUS_NEWSFORCE_MEMBER,
        CUS_MAGAZINES_HANDLED,
        'BRA740' CUS_BRANCH_CODE,  --- wakefield is 740
        CUS_TRADING_NAME,
       CUS_SUNDAYS_HANDLED,
        CUS_MAGAZINES_BOX_OUTS_HANDLE,
        CUS_FRIDAY_TIME_CLOSED,
        CUS_FRONTAGE,
        CUS_MONDAY_TIME_OPEN,
        CUS_MONDAY_TIME_CLOSED,
        CUS_WEDNESDAY_TIME_OPEN,
        CUS_WEDNESDAY_TIME_CLOSED,
        CUS_TURNOVER,
        CUS_TUESDAY_TIME_OPEN,
        CUS_TUESDAY_TIME_CLOSED,
        CUS_THURSDAY_TIME_OPEN,
        CUS_THURSDAY_TIME_CLOSED,
        CUS_TELEPHONE_NUMBER,
        CUS_SUNDAY_TIME_OPEN,
        CUS_SUNDAY_TIME_CLOSED,
        CUS_STATUS_DATE,
        CUS_SATURDAY_TIME_OPEN,
        CUS_SATURDAY_TIME_CLOSED,
        CUS_PROFIT,
        CUS_KNOWN_AS_NAME,
        CUS_GRANT_DATE,
        CUS_FRIDAY_TIME_OPEN,
        CUS_FAX_NUMBER,
        CUS_CONTACT_NAME,
        CUS_DEPOT_NUMBER,
        CUS_CLOSED_SINCE_DATE,
        CUS_SELECTED_AGENT_NET_SALES,
        CUS_ANMW_CODE,
        CUS_MULTIPLE_CODE,
        CUS_MULTIPLE_GRADE_CODE,
        CUS_POSTCODE,
        CUS_TYPE,
        CUS_TELEGRAPH_CODE,
        x.prm_new_spoke_number CUS_SPOKE_CODE,
        CUS_IPC,
        CUS_NATIONAL_LOTTERY,
        CUS_DELETE_FLAG,
        CUS_BUDGET_CENTRE,
        CUS_MULT_ACCOUNT_INDICATOR,
        CUS_PAYMENT_TYPE,
        CUS_BOARD_NUMBER_1,
        CUS_RUN_NUMBER_1,
        CUS_DROP_NUMBER_1,
        CUS_BOARD_NUMBER_2,
        CUS_RUN_NUMBER_2,
        CUS_DROP_NUMBER_2,
        CUS_BOARD_NUMBER_3,
        CUS_RUN_NUMBER_3,
        CUS_DROP_NUMBER_3,
        CUS_BOARD_NUMBER_4,
        CUS_RUN_NUMBER_4,
        CUS_DROP_NUMBER_4,
        CUS_REALLOCATION_PARAMETER,
        CUS_OUTLET_REFERENCE,
        CUS_MINIMUM_ENTRY_LEVEL,
        CUS_DEFERRED_INDICATOR,
        CUS_OWNER_TITLE,
        CUS_OWNER_FIRST_NAME,
        CUS_OWNER_SURNAME,
        CUS_MANAGER_TITLE,
        CUS_MANAGER_FIRST_NAME,
        CUS_MANAGER_SURNAME,
        CUS_PROMOTION,
        CUS_HOME_DELIVERY,
        CUS_SHOP_SAVES,
        CUS_NIGHT_SALES,
        CUS_COLLECTION_DAY_MON,
        CUS_COLLECTION_DAY_TUE,
        CUS_COLLECTION_DAY_WED,
        CUS_COLLECTION_DAY_THU,
        CUS_COLLECTION_DAY_FRI,
        CUS_COLLECTION_DAY_SAT,
        CUS_COLLECTION_DAY_SUN,
        CUS_SL_ACCOUNT_TYPE,
        CUS_SL_ACCOUNT_STATUS,
        CUS_PAYMENT_TERMS,
        CUS_PAYMENT_METHOD,
        CUS_STMNT_INTERVAL,
        CUS_RACK_ONLY,
        CUS_INVOICE_SEQ,
        CUS_INVOICE_FORMAT,
        CUS_PRINT_FLAG,
        CUS_MAG_DEFERRED_IND,
        CUS_MAGS_START_DATE,
        CUS_PERIOS_START_DATE,
        CUS_MAGS_STOP_DATE,
        CUS_PERIOS_STOP_DATE
   from customers c
   join  che_rhy_wak_customer_xref x
     on c.cus_account_number = x.prm_new_urn
  where cus_to_date = to_date('16/08/2015 23:59:59','dd/mm/yyyy hh24:mi:ss')
    and cus_branch_code in ('BRA320');

--Step 4
--update the customer x ref to pick up the new details
update customer_x_ref x
   set (x.ccr_branch_code, x.ccr_legacy_box_no) = (select icx.prm_new_branch, icx.prm_new_box_number
                                                     from che_rhy_wak_customer_xref icx
                                                    where icx.prm_bp_number = x.ccr_bus_partner_id )
                                                    
where exists (select 1
                 from che_rhy_wak_customer_xref icx
                 where icx.prm_bp_number = x.ccr_bus_partner_id);
