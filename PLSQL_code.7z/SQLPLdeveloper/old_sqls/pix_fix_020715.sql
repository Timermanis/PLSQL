select b.* from refmast.plant_issues_xref_base b where exists
(select 1 from TWSD_740_20150630033324345786 t,refmast.plant_issues_xref_base b 
where t.twsd_spoke_id=790
and b.pix_branch_code='BRA790' 
and t.twsd_issue_id = b.pix_sap_id)

update plant_issues_xref_base b set 
(pix_year,b.pix_week,b.pix_year,b.pix_plant_on_sale_date,b.pix_status_flag)
(b.pix_orig_year,b.pix_orig_week,b.pix_orig_day,b.pix_official_on_sale_date,'LS')

select * from refmast.plant_issues_xref_base b
where PIX_SPOKE_CODE = 'BRA740'
and PIX_PLANT_ON_SALE_DATE is null
and b.pix_sap_id in
(select r.TWSD_ISSUE_ID from JT_UPD_PIX_300615 r)

select  count(*) from TWSD_740_20150630033324345786 t
where t.twsd_spoke_id=790

select  distinct r.twsd_issue_id from TWSD_740_20150630033324345786 r
where r.twsd_spoke_id=790

000000000034982062
000000000073632061
000000000373300001
000000000072862061
000000000038722058

select * from refmast.plant_issues_xref_base b where PIX_SAP_ID in 
('000000000034982062',
'000000000073632061',
'000000000373300001',
'000000000072862061',
'000000000038722058')
and b.pix_spoke_code in ('BRA740','BRA790') for update
