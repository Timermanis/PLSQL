create table jt_280115_cleanup_MU_FI_HI as --MULTIPLE_FINANCIAL_HISTORIES
select * from  MULTIPLE_FINANCIAL_HISTORIES a
where MFH_ACCOUNT_NUMBER  not  in (select  c.cus_account_number from jt_280115_customers c  )

create table jt_020215_cle_agt_ret_band_grp as --agent_retailer_band_groups
select * from  agent_retailer_band_groups a
where a.ARBG_ACCOUNT_NUMBER  not  in (select  c.cus_account_number from jt_280115_customers c  )

--AGENT_RETAILER_BAND_GROUPS
--drop table jt_020215_cle_agt_ret_band_grp
create table jt_020215_cle_agt_ret_band_grp as --agent_retailer_band_groups MUTCH QUICKER !!!!!!!!!!!!!!!!!!!!!!!!!
select * from  agent_retailer_band_groups a
where not  exists (select 1  from jt_280115_customers c where c.cus_account_number= a.ARBG_ACCOUNT_NUMBER)

delete from agent_retailer_band_groups a where exists (select 1  from jt_020215_cle_agt_ret_band_grp c where c.ARBG_ACCOUNT_NUMBER= a.ARBG_ACCOUNT_NUMBER)

select * from customers where cus_account_number=502963047230301




--PUBLISHER_AGENT_MATRIX
create table jt_020215_PUBL_AGENT_MATRIX as --agent_retailer_band_groups MUTCH QUICKER !!!!!!!!!!!!!!!!!!!!!!!!!
select * from  PUBLISHER_AGENT_MATRIX a
where not  exists (select 1  from jt_280115_customers c where c.cus_account_number= a.PUBA_AGENT_ACCOUNT_NUMBER)


delete from PUBLISHER_AGENT_MATRIX a where exists (select 1  from jt_020215_PUBL_AGENT_MATRIX c where c.PUBA_AGENT_ACCOUNT_NUMBER= a.PUBA_AGENT_ACCOUNT_NUMBER)



--NSSO_MOVEMENTS--
create table jt_020215_NSSO_MOVEMENTS as --agent_retailer_band_groups MUTCH QUICKER !!!!!!!!!!!!!!!!!!!!!!!!!
select * from  NSSO_MOVEMENTS a
where not  exists (select 1  from jt_280115_customers c where c.cus_account_number= a.NSSO_AGENT_ACCOUNT_NUMBER)


delete from NSSO_MOVEMENTS a where exists (select 1  from jt_020215_NSSO_MOVEMENTS c where c.NSSO_AGENT_ACCOUNT_NUMBER= a.NSSO_AGENT_ACCOUNT_NUMBER)



--REFUSED_CREDIT--
create table jt_020215_REFUSED_CREDIT as --MUTCH QUICKER using exists !!!!!!!!!!!!!!!!!!!!!!!!!
select * from  REFUSED_CREDIT a
where not  exists (select 1  from jt_280115_customers c where c.cus_account_number= a.RC_CUSTOMER_ACCOUNT_NUMBER)


delete from REFUSED_CREDIT a where exists (select 1  from jt_020215_REFUSED_CREDIT c where c.RC_CUSTOMER_ACCOUNT_NUMBER= a.RC_CUSTOMER_ACCOUNT_NUMBER)


--MULTIPLE_FINANCIAL_HISTORIES--
create table jt_020215_MULT_FINAN_HIST as --MUTCH QUICKER using exists !!!!!!!!!!!!!!!!!!!!!!!!!
select * from  MULTIPLE_FINANCIAL_HISTORIES a
where not  exists (select 1  from jt_280115_customers c where c.cus_account_number= a.MFH_ACCOUNT_NUMBER)


delete from MULTIPLE_FINANCIAL_HISTORIES a where exists (select 1  from jt_020215_MULT_FINAN_HIST c where c.MFH_ACCOUNT_NUMBER= a.MFH_ACCOUNT_NUMBER)




--drop table jt_020215_customers
create table jt_020215_customers as (select distinct c.cus_account_number from customers c  )

 --Have to test
 
TABLE	NUMBER OF RECORDS 
MULTIPLE_FINANCIAL_HISTORIES	151664439
REFUSED_CREDIT	58342466
NSSO_MOVEMENTS	28050476
PUBLISHER_AGENT_MATRIX	4003812
agent_retailer_band_groups	3649270 -- created 020215 jt_020215_cle_agt_ret_band_grp

select * from customers where cus_account_number in (503103134488201)
)
select * from jt_020215_customers
select * from jt_020215_MULT_FINAN_HIST
select count(*) from jt_020215_MULT_FINAN_HIST
