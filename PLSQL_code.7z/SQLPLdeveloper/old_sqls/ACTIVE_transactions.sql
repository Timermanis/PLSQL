
SELECT username, terminal, osuser,
       t.start_time, r.name, t.used_ublk "PROGRESS",
       DECODE(t.SPACE, 'YES', 'SPACE TX',
          DECODE(t.recursive, 'YES', 'RECURSIVE TX',
             DECODE(t.noundo, 'YES', 'NO UNDO TX', t.status)
       )) status
FROM sys.v_$transaction t, sys.v_$rollname r, sys.v_$session s
WHERE t.xidusn = r.usn
  AND t.ses_addr = s.saddr
 ;

select--it shows users using resources
   t.START_TIME,
   s.OSUSER,
   substr(s.username,1,18) username,
   substr(s.program,1,15) program,
   z.name action
   
from 
   v$session     s,
   v$process     p,
   v$transaction t,
   v$rollstat    r,
   v$rollname    n,
   activity_name z 
where s.paddr = p.addr
and s.taddr = t.addr (+)
and t.xidusn = r.usn (+)
and r.usn = n.usn (+)
and z.action = s.COMMAND
order by t.START_TIME desc nulls last;
