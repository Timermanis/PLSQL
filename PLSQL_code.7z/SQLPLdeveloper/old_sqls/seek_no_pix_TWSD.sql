create table jt_upd_pix_300615 as
SELECT DISTINCT twsd_spoke_id, twsd_issue_id 
 FROM  TWSD_740_20150630033324345786 
 WHERE
  twsd_issue_id IS NOT NULL
AND twsd_title_code IS NULL
  and not exists (select 1
  from refmast.plant_issues_xref_base
  where pix_spoke_code = 'BRA'||twsd_spoke_id
  and pix_sap_id = twsd_issue_id
  and pix_week is not null)
