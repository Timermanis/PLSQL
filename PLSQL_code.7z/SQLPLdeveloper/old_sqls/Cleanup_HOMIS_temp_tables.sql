--select * from agent_net_sales a where a.net_issue_year = 2014 and a.net_agent_account_number = 502963045158200
select table_name from user_tables 
where  
(table_name like 'ICSD_____20%'--3456 records
or table_name like 'BISD_____20%'--1707 records
or table_name like 'ISUD_____20%'--1765 records
or table_name like 'KPSD_____20%'--1687 records
or table_name like 'MFHD_____20%'--0 records
or table_name like 'TWSD_____20%')--0 records
AND (substr(table_name,10,4) = 2013) ;


SELECT 'DROP TABLE ' || table_name || ';'
FROM user_tables
where  
(table_name like 'ICSD_____20%'--3456 records
or table_name like 'BISD_____20%'--1707 records
or table_name like 'ISUD_____20%'--1765 records
or table_name like 'KPSD_____20%'--1687 records
or table_name like 'MFHD_____20%'--0 records
or table_name like 'TWSD_____20%')--0 records
AND (substr(table_name,10,6) < 201505) ;
