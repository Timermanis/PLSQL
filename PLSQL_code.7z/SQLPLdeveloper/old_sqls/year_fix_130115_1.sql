select * from PLANT_ISSUES_XREF where PIX_YEAR !=PIX_orig_YEAR and PIX_YEAR = 2015
select * from PLANT_ISSUES_XREF where  PIX_YEAR = 2015
select * from PLANT_ISSUES_XREF where PIX_YEAR is null and PIX_ORIG_YEAR = 2014
select * from PLANT_ISSUES_XREF where PIX_YEAR =2014 and PIX_legacy_YEAR =2013
select * from PLANT_ISSUES_XREF where PIX_EAN = 977136458846602
977136458846602
