Insert into zpx_del_trans_stg
Select *
From hist_zpx_del_trans_stg
Where planned_delivery_date between '31-MAY-2015' AND '15-JUL-2015'

Insert into zpx_del_trans_stg
Select *
From hist_zpx_del_trans_stg
Where planned_delivery_date = '07-SEP-2015';

Insert into zpx_parcel_uplift_stg
Select *
From hist_zpx_parcel_uplift_stg
Where load_date  between '31-MAY-2015' AND '15-JUL-2015';

Insert into zpx_parcel_uplift_stg
Select *
From hist_zpx_parcel_uplift_stg
Where load_date = '07-SEP-2015';

Update datain.zic_flags
 Set complete = 1
Where icjob = 'DTRANS'



