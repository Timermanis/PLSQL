select * from branch_issues t
where t.BRIS_BRANCH_CODE = 'BRA320' and t.BRIS_TITLE_CODE in (49165,90860,90881,90882,90883,90884,90885,90886,90887,90888,90889,90890)
and t.BRIS_ISSUE_WEEK = 29;

select * from normal_issues t
--where t.NISS_EAN in (977135927104529,30908861529001)
where t.NISS_TITLE_CODE in (49165,90860,90881,90882,90883,90884,90885,90886,90887,90888,90889,90890)
and t.NISS_ISSUE_YEAR = 2015
and t.NISS_ISSUE_WEEK = 29;


select * from titles where TITL_CODE in (49165,90860,90881,90882,90883,90884,90885,90886,90887,90888,90889,90890)

90885 Z6
90886 Z7

select * from  branch_issues a, normal_issues b, titles c where
a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year
and b.niss_title_code = c.titl_code
--and a.bris_branch_code = 'BRA320'
and c.titl_code in (90887)--(90885)

select * from jt_170805_problem_backup

create table jt_180805_problem_90885 as
select * from branch_issues d where d.bris_title_code = 90885 --for update
create table jt_170805_problem_back_york as
select *from branch_issues d where d.bris_title_code = 90887 --for update
create table jt_170805_pl_xref_backup as
select * from plant_issues_xref where PIX_LEGACY_TITLE = 90885 --for update
