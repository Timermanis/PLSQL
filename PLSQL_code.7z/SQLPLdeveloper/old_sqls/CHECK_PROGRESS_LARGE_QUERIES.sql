select plan_line_id, plan_operation || ' ' || plan_options operation, starts, output_rows 
from v$sql_plan_monitor where sql_id = '8jftd1q4updxa' and  OUTPUT_ROWS > 0
 --and key = 21474843838
order by plan_line_id;
