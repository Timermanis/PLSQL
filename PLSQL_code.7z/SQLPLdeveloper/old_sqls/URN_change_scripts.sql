truncate table dc_ans;

insert into dc_ans


select *
  from agent_net_sales d
 where d.net_agent_account_number in (340142474000300,
340142496000500,
340142541000400,
340142642000200,
340142645000900,
502963025895200,
340142979000300,
340142980000900,
340142997000900,
340143138000100,
790156128000500,
550156181000800,
790156180000500,
310156177000900

)
   and not exists (SELECT 1
                     FROM title_history_2, titles, branch_issues, customers
                    WHERE cus_branch_code = bris_branch_code
                      AND bris_invoice_date BETWEEN cus_from_date AND cus_to_date
                      AND titl_code = bris_title_code
                      AND th_code(+) = bris_title_code
                      AND bris_invoice_date BETWEEN th_from_date(+) AND th_to_date(+)
                      AND bris_ean = d.net_issue_ean
                      AND bris_issue_year = d.net_issue_year
                      AND cus_account_number = d.net_agent_account_number);


delete from agent_net_sales s
 where (s.net_agent_account_number, s.net_issue_ean, s.net_issue_year) in (select s1.net_agent_account_number, s1.net_issue_ean, s1.net_issue_year
                                                                             from dc_ans s1);

commit;

--INSERT

insert into agent_net_sales s
select &new_urn,
       NET_ISSUE_EAN,
       NET_ISSUE_YEAR,
       NET_BOX_OUT_QUANTITY,
       NET_CREDIT_QUANTITY,
       NET_OTHER_SALES_QUANTITY,
       NET_COMMITED_QUANTITY,
       NET_CASUAL_QUANTITY,
       NET_RETURN_QUANTITY,
       NET_NOTE_KEYED_FLAG,
       NET_CTB_FLAG,
       NET_BRANCH_CODE,
       NET_BOX_NUMBER,
       NET_MULTIPLE_CODE,
       NET_MULTIPLE_GRADE_CODE,
       NET_ANMW_CODE,
       NET_RETAILER_BAND,
       NET_POSTCODE_OUTER,
       NET_PUBLISHER_CODE,
       NET_TITLE_CODE
  from dc_ans
 where NET_AGENT_ACCOUNT_NUMBER = &old_urn;

commit;
