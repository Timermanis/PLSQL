select * from refstg.RETAILER_INVOICE_ITEMS_SUS

select * from refstg.retailer_invoice_headers_sus
