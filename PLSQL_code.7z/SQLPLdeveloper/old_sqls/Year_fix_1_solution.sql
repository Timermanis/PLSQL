select pix_spoke_code from plant_issues_xref pix where PIX_BRANCH_CODE = 'BRA850' and 
nvl( pix.pix_legacy_year, nvl( pix.pix_year, pix.pix_orig_year ))  = (select min (nvl( pix.pix_legacy_year, nvl( pix.pix_year, pix.pix_orig_year )) ) 
from plant_issues_xref pix where pix_sap_id     = 000000000455960015)
and pix_sap_id     = 000000000455960015;



SELECT nvl( pix.pix_legacy_ean, pix.pix_ean ),pix.pix_spoke_code,
             nvl( pix.pix_legacy_year, nvl( pix.pix_year, pix.pix_orig_year ) ),
             pix.pix_legacy_title,
             pix.pix_orig_day,
             trunc( next_day(pix.pix_plant_on_sale_date-1,'Saturday') ),
             pix.pix_plant_on_sale_date
      FROM   plant_issues_xref pix -- use the view
      WHERE  pix.pix_spoke_code =
      (select pix_spoke_code from plant_issues_xref pix where PIX_BRANCH_CODE = 'BRA850' and 
nvl( pix.pix_legacy_year, nvl( pix.pix_year, pix.pix_orig_year ))  = (select min (nvl( pix.pix_legacy_year, nvl( pix.pix_year, pix.pix_orig_year )) ) 
from plant_issues_xref pix where pix_sap_id     = 000000000455960015)
and pix_sap_id     = 000000000455960015)
      AND    pix.pix_sap_id     = 000000000455960015;
