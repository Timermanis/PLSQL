create table jt_customers_06072015 as
select *
from customers c
where c.cus_account_number in (select x.prm_old_urn from she_wak_customer_xref x)
and c.cus_branch_code = 'BRA790'

and c.cus_from_date >= to_date('05/07/2015','DD/MM/YYYY')  

delete
from customers c
where c.cus_account_number in (select x.prm_old_urn from she_wak_customer_xref x)
and c.cus_branch_code = 'BRA790'

and c.cus_from_date >= to_date('05/07/2015','DD/MM/YYYY') 


update customers set cus_to_date = to_date('31/12/4000','DD/MM/YYYY')
select * from customers--for test
where  CUS_ACCOUNT_NUMBER in (select  CUS_ACCOUNT_NUMBER from jt_customers_06072015 )
and cus_branch_code = 'BRA790'
and cus_to_date >= to_date('04/07/2015','DD/MM/YYYY') 




