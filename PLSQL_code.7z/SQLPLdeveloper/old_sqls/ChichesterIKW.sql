select * from refmast.plant_issues_xref x where x.PIX_LEGACY_TITLE in(34527,40122) order by x.PIX_YEAR,x.PIX_WEEK 
select * from refmast.plant_issues_xref x where x.PIX_LEGACY_TITLE in(4315) order by x.PIX_YEAR,x.PIX_WEEK
--update refmast.plant_issues_xref_base set PIX_MAIN_LEGACY_TITLE = 4315 where PIX_LEGACY_TITLE in(34527,40122)

select d.early_returns from dw.plant_mult_iss_rtrn_summaries	d  PLANT_ISS_SUMMARIES
select * from dw.PLANT_ISS_SUMMARIES

select * from archive.zpx_plnt_iss_stg_bak a where a.spoke_id in () 
