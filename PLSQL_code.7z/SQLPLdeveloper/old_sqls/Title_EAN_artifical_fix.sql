insert into branch_issues select * from jt_branch_issues_070515 t where  BRIS_TITLE_CODE = 4249 and t.bris_issue_year=2015 and t.bris_issue_week=19

create table jt_branch_issues_070515 as
select * from branch_issues t where   t.bris_issue_year=2015 and t.bris_issue_week=19  and BRIS_EAN = 977003373682519 for update--30042491519001-- for update BRIS_TITLE_CODE = 4249 and
--select * from normal_issues where nisS_EAN = 977003373682519
select * from all_issues a where ISSU_TITLE_CODE in (4249, 5383) and ISSU_ISSUE_YEAR=2015 and a.issu_issue_week=19 for update a.issu_ean = 977003373682519--ISSU_TITLE_CODE = 4249 and ISSU_ISSUE_YEAR = 2015 and ISSU_ISSUE_WEEK = 18 --for update

select * from agent_net_sales t where NET_ISSUE_EAN=977003373682519 and t.net_issue_year=2015 and NET_BRANCH_CODE = 'BRA220'
--1.Plant issues xref
select * from plant_issues_xref where PIX_EAN = 977003373682520 and PIX_BRANCH_CODE = 'BRA850'--have to change PIX_MAIN_LEGACY_TITLE
--2. Branch issues
select * from branch_issues t where   t.bris_issue_year=2015 and t.bris_issue_week=20  and BRIS_TITLE_CODE = 4249--BRIS_EAN = 977003373682520 for update
--3. All issues
select * from all_issues a where ISSU_TITLE_CODE in (4249, 5383) and ISSU_ISSUE_YEAR=2015 and a.issu_issue_week=19; ---977003373682519;
select * from all_issues a where ISSU_TITLE_CODE in (4249, 5383) and ISSU_ISSUE_YEAR=2015 and a.issu_issue_week=20 for update

icsd_850_20150513030406158601
SELECT icsd_issue_ean, COUNT(*)
   FROM ( SELECT DISTINCT t.icsd_issue_ean, t.icsd_title_code
          FROM  icsd_850_20150513030406158601  t )
   GROUP BY icsd_issue_ean
   HAVING COUNT(*) > 1;
--977003373682520

SELECT t.icsd_title_code, COUNT(*) 
   FROM   icsd_850_20150513030406158601 t
   WHERE  t.icsd_issue_ean in (977003373682520)  -- the EAN(s) found from the above script
   GROUP BY t.icsd_title_code;
--4249
--5383
