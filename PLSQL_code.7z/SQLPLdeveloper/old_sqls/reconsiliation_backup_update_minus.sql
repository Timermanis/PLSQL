create table ret_trans_signs_110515_101 as select *
from 
dw.retailer_transaction rt
where
rt.reporting_trn_type_id  = 101
and rt.COST_VALUE_VAT > 0
and rt.plant_issue_id in (select m.dimension_key
                                    from dw.media m
                                   where m.iss_type_code in  
('MZ',
'SA',
'WE',
'MO',
'FR',
'TU',
'TH',
'SU'
) )


update retailer_transaction rt set 
--TRANSACTION_QUANTITY = abs(TRANSACTION_QUANTITY) ,
--RETAIL_VALUE_EXCL_VAT = abs(RETAIL_VALUE_EXCL_VAT)  ,
--RETAIL_VALUE_VAT = abs(RETAIL_VALUE_VAT)  ,
--COST_VALUE_EXCL_VAT = abs(COST_VALUE_EXCL_VAT)  
COST_VALUE_VAT = abs(COST_VALUE_VAT)*(-1)  
--TRADE_VALUE_EXCL_VAT = abs(TRADE_VALUE_EXCL_VAT)  ,
--TRADE_VALUE_VAT = abs(TRADE_VALUE_VAT)  
where dwh_num in(
select dwh_num from ret_trans_signs_110515_101)


select * from jt_rt_analys_vat_allyears_bip minus
select * from jt_rt_ana_vat_allyears_bip_v2
