select mult_multiple_code,m.mult_name,mult_link_multiple_code,CONNECT_BY_ISCYCLE from multiple m 
start with mult_link_multiple_code = 9002
CONNECT BY
NOCYCLE
PRIOR m.mult_multiple_code = m.mult_link_multiple_code

order by CONNECT_BY_ISCYCLE desc
