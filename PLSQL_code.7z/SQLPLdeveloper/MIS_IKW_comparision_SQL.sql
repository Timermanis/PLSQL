select round(sum(t.delivery_diff)/sum(t.delivery),3)*100,round(sum(t.return_diff)/sum(t.delivery),3)*100, t.onsales_date,t.run_num,max(t.checked) from JT_MIS_IKW_CHECKS_TEST_sch t
group by t.onsales_date,t.run_num 
