create table customers_131115_1hr as

select *
from customers  as of  timestamp systimestamp - interval '1' hour 
minus
select *
from customers  as of timestamp systimestamp hour 

insert into agent_net_sales
SELECT * FROM agent_net_sales  as of  timestamp systimestamp - interval '1' hour 
 WHERE net_issue_year = 2016 and net_issue_ean = 10326021652601 and net_agent_account_number = 502963009726100 
 union all
 SELECT * FROM agent_net_sales  
 WHERE net_issue_year = 2016 and net_issue_ean = 10326021652601 and net_agent_account_number = 502963009726100 
 


insert into archive.zpx_cus_dtls_stg_bak
select *
from archive.zpx_cus_dtls_stg_bak as of timestamp TO_TIMESTAMP('2015-04-27 06:30:00', 'YYYY-MM-DD HH:MI:SS') minus
select *
from archive.zpx_cus_dtls_stg_bak as of timestamp TO_TIMESTAMP('2015-04-27 12:30:00', 'YYYY-MM-DD HH:MI:SS')


select *
from archive.zpx_cus_supi_stg_bak as of timestamp TO_TIMESTAMP('2015-09-07 01:01:00', 'YYYY-MM-DD HH:MI:SS') 

select * from branch_issues  as of timestamp TO_TIMESTAMP('2016-03-11 10:30:00', 'YYYY-MM-DD HH:MI:SS') 
where bris_ean=977174208704809 

select *
from archive.zpx_cus_supi_stg_bak as of timestamp TO_TIMESTAMP('2015-09-07 01:30:00', 'YYYY-MM-DD HH:MI:SS') 
where ETL_RUN_NUM_SEQ = (select max(ETL_RUN_NUM_SEQ) from zpx_cus_supi_stg_bak)
