select * from PUBLISHER_AGENT_MATRIX t where t.puba_agent_account_number=502963010284200 and t.puba_supply_org_code = 1006 for update

select * from customer_x_ref x where x.ccr_bus_partner_id = 119921--502963010284200--130736--503103120627200
