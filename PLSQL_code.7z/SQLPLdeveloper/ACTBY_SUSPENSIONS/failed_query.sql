select
  ORA_ERR_NUMBER$,
  ORA_ERR_MESG$,
  ORA_ERR_ROWID$,
  ORA_ERR_OPTYP$,
  ORA_ERR_TAG$,
  ORA_ERR_TIMESTAMP$,
SALESDOC_NUMBER,
SALESDOC_ITEM,
MEDIA_ISSUE,
PLANT,
SALES_ORG,
CUSTOMER,
SECURE_CHECK,
CREATE_DATE,
CREATE_TIME,
CONTRACT_NUMBER,
CONTRACT_ITEM,
BILLING_BLOCK,
REJECT_REASON,
REJECT_TEXT,
USAGE,
ITEM_CAT,
BILLING_DATE,
PARCEL_ID,
PACKER_ID,
PACKER_NAME,
ROUTE,
QUERY_QTY,
NET_VALUE,
DEL_QTY_QUERIED,
QRY_RETAIL_VALUE,
TOT_INVOICED,
TOT_CREDITED,
MISC_SALES,
CLAIMS_REPL,
MISSING_PARCEL,
REPL_QTY,
CLAIM_NO_REPL,
OVERPACKS,
DAMAGED_QTY,
QUERY,
UNDER_CREDIT_QTY,
OVER_CREDIT_QTY,
REQUERY_QTY,
TOT_SUB_QTY,
CANCEL_CLM_QTY,
EARLY_RETURNS,
STD_RETURNS,
LATE_REJ_RETURNS,
FIRM_REJ_RETURNS,
EXC_REJ_RETURNS,
EXCSOR_REJ_RET,
NOSUP_REJ_RET,
RETURNS_ADJ,
SBR_REPL,
TOTAL_RETURNS,
TOTAL_NET_VALUE,
SYSTEM_RECOMMENDATION,
ACCEPT,
REJECT,
NET_SALE,
ALERT,
CLAIMABLE,
PROCESS_DATE,
PROCESS_TIME,
PROCESSED_BY,
ACC_COMMENTS,
CIC_COMMENTS,
REPLY_COMMENT,
DB_TIMESTAMP,
(select
        distinct max(so.sois_sas_code) keep (dense_rank first order by i.iss_publication_date desc)        sois_sas_code
         from refmast.sales_organisation_issues so,refmast.issues i, (select distinct a.media_issue from   refstg.accountability_sus a) k
         where so.sois_issue_num = i.iss_num
         and substr(trim(media_issue),2,6) = i.iss_product_num
         and  regexp_like(media_issue, '^[[:digit:]]') -- added 08/10/15 to ensure only joins on numerics
     group by so.sois_issue_num
) sois_sas_code
,ETL_RUN_DATE_NUM,
ETL_RUN_NUM_SEQ


-- Created 05/10/2015 Need these transactions where no associated plant issue
-- in warehouse and as have referential integrity on accountability_transaction to media
-- load into dw.inavlid_accountability_transaction
from accountability_sus s
, dw.wholesaler w
where s.plant = w.spo_num
and s.create_date between w.spo_eff_date and w.spo_exp_date
and  regexp_like(media_issue, '^[[:digit:]]') -- added 08/10/15 to ensure only joins on numerics    '^[[:digit:]]+$'
;

