select * from accountability_sus for update

select * from accountability_bin4
create table accountability_bin4 as
select * from accountability_bin4 where 1=2
delete from accountability_bin

insert into accountability_bin4 
select * from accountability_sus where media_issue like 'R%'

delete from accountability_sus where media_issue like 'R%'

select MEDIA_ISSUE,CUSTOMER from accountability_bin union all
select MEDIA_ISSUE,CUSTOMER from accountability_bin2

insert into accountability_sus select * from accountability_bin where media_issue = 'R41918'
R56048
R41918
53912330
select f.salesdoc_number,f.salesdoc_item,f.media_issue,f.plant,f.customer,f.item_cat,f.db_timestamp from
(select * from accountability_bin2 union
select * from accountability_bin3 union
select * from accountability_sus) f
where ORA_ERR_MESG$ like '%Plant or Customer or Issue non-numeric%'

select * from ACCOUNTABILITY_SUS_NO_ISS

select * from INVALID_ACCOUNTABILITY_SUS
create table accountability_bin4_test1 as
select * from accountability_bin4 b 
select distinct b.* from accountability_bin4 b 

delete from accountability_bin4 b where b.create_time in (select a.create_time from accountability_bin4 a  where b.create_time = a.create_time and a.rowid > b.rowid) 
select rowid,rownum from accountability_bin4_test1
