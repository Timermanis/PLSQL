   with c as     
(
select distinct max(to_number(i.iss_num)) sap_id ,sum(MAIN_SUPPLY_QTY)+  sum(EXTRA_SUPPLY_QTY) delivery, 
--(select distinct max(to_number(nvl(i.iss_parent_iss_num,i.iss_num))) sap_id ,sum(MAIN_SUPPLY_QTY)+  sum(EXTRA_SUPPLY_QTY) delivery,   
sum(case when MAIN_SUPPLY_QTY + EXTRA_SUPPLY_QTY !=0 then ( RETURN_QTY)else 0 end) return,
min(ISS_TYPE_CODE) ISS_TYPE, min(ISS_NAME) ISS_NAME
from dw.plant_cust_iss_rtrn_sum_a p,REFMAST.ISSUES  i where p.plis_issue_num = i.iss_num and p.plis_issue_num in (46702361,391620116)
 
union all

select distinct max(to_number(x.pix)) sap_id ,-sum(NET_COMMITED_QUANTITY) - sum(NET_OTHER_SALES_QUANTITY),
-sum(case when NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY !=0 then ( NET_RETURN_QUANTITY)else 0 end),'1','1'
 from agent_net_sales@mis.world b,customer_x_ref@mis.world c,
 (select unique nvl(z.pix_parent_id,z.pix_sap_id) pix,pix_legacy_ean,PIX_YEAR,PIX_BRANCH_CODE  from refmast.plant_issues_xref_base z) x
where b.NET_AGENT_ACCOUNT_NUMBER = c.CCR_CUST_URN
and b.net_issue_ean = x.pix_legacy_ean
and b.net_issue_year = x.PIX_YEAR
and b.net_branch_code = x.PIX_BRANCH_CODE
and x.pix in (46702361,391620116)--

)
select max(sap_id) ,max(delivery) ,sum(delivery) ,sum(return) ,ROUND(abs(sum(delivery))/max(delivery)*100,2) ,ROUND(abs(sum(return))/max(delivery)*100,2),sysdate,
max(ISS_TYPE),max(ISS_NAME)
from c;
--------------------------------------
  with c as
(select distinct max(to_number(p.plis_issue_num)) sap_id ,sum(MAIN_SUPPLY_QTY)+  sum(EXTRA_SUPPLY_QTY) delivery,  --sum(RETURN_QTY) return,
sum(case when MAIN_SUPPLY_QTY + EXTRA_SUPPLY_QTY !=0 then ( RETURN_QTY)else 0 end) return,
max(ISS_TYPE_CODE) ISS_TYPE, max(ISS_NAME) ISS_NAME
 from dw.plant_cust_iss_rtrn_sum_a p,REFMAST.ISSUES  i where p.plis_issue_num = i.iss_num and p.plis_issue_num in (46702361,391620116)
union all
select distinct max(to_number(x.pix_sap_id)) sap_id ,-sum(NET_COMMITED_QUANTITY) - sum(NET_OTHER_SALES_QUANTITY),
-sum(case when NET_COMMITED_QUANTITY + NET_OTHER_SALES_QUANTITY !=0 then ( NET_RETURN_QUANTITY)else 0 end),'1','1'
 from agent_net_sales@mis.world b,customer_x_ref@mis.world c,
 (select unique pix_sap_id,pix_legacy_ean,PIX_YEAR,PIX_BRANCH_CODE  from refmast.plant_issues_xref_base) x
where b.NET_AGENT_ACCOUNT_NUMBER = c.CCR_CUST_URN
and b.net_issue_ean = x.pix_legacy_ean
and b.net_issue_year = x.PIX_YEAR
and b.net_branch_code = x.PIX_BRANCH_CODE
and x.pix_sap_id in (46702361,391620116))
select max(sap_id) ,max(delivery) ,sum(delivery) ,sum(return) ,ROUND(abs(sum(delivery))/max(delivery)*100,2) ,ROUND(abs(sum(return))/max(delivery)*100,2),sysdate,
max(ISS_TYPE),max(ISS_NAME)
from c;
