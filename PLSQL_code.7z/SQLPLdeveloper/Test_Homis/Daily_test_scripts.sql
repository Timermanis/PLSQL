--SAP branches  NEED TO RUN THIS EVERY DAY TO CHECK
select t.*, decode(run_seq_no - latest_seq,0,'OK','ERROR') "Load Status"
  from sap_branches@homis t
 cross join (select max(t.aa_etl_run_num_seq) latest_seq
               from archive.archive_audit@bisapprd.world t)
 order by run_seq_no, branch_id;


   select *                 -- This to check for Ipswich closing into Maisstone.
   from ips_nor_che_maid_log l
   order by log_time desc ;
   select *
  from cans_whats_on_tv_mergr_ans_log
  order by log_time desc;
  select *
  from CANS_WAKEFIELD_CONTROL_LOG
  order by 1 desc;
   select *
  from LEE_WAK_LOG
  order by log_time desc ;
  select *
  from SHE_WAK_LOG
  order by log_time desc ;
  select *
  from pre_ken_WAK_LOG
  order by log_time desc ;
  select *
  from car_lin_LOG
  order by log_time desc ;
select *
  from che_rhy_wak_log
  order by log_time desc ;
  SELECT *
  FROM YOR_HUL_STO_WAK_LOG L
  ORDER BY 1 DESC;
  select *
from CANS_TV_ULSTER_ANS_log
order by 1 desc;
 select *
from newb_lin_log
order by 1 desc;
 select *
from berw_lin_log
order by 1 desc;
select *
from bel_der_log
order by 1 desc;

-- Added 30/03/2016 - for record/sunday mail split 
 select *
 from rec_split_log
 order by 1 desc;

-- Added 30/03/2016 - for record Edinburgh newbridge customers using different title code 
 select *
 from CANS_REC_EDIN_ANS_LOG
 order by 1 desc;



-------------------------------------------------------------------------------------------------------------------------------------------------------------------------  
  select count(*) from lee_wak_ans;--check if any records left unprocessed. If any record left when MIS loads have run we need to get them processed.
    select count(*) from she_wak_ans;
      select count(*) from pre_ken_wak_ans;
        select count(*) from car_lin_ans;
          select count(*) from che_rhy_wak_ans;
            select count(*) from yor_hul_sto_wak_ans;
              select count(*) from newb_lin_ans --LAST added to reset run 2d update
           

 --  cans_wakefield_control has the peace of update code have to run manually
update CANS_wak_LASTNUM s
          set s.last_msg_num_processed = (SELECT max(m.msg_seq_no)-2
                                       FROM MSG_FILES m
                                      where m.msg_counterparty = 'BRA740'  -- Only run if wakefield done
                                      and m.msg_status = 'P');
                                      
update CANS_lin_LASTNUM s
          set s.last_msg_num_processed = (SELECT max(m.msg_seq_no)-2
                                       FROM MSG_FILES m
                                      where m.msg_counterparty = 'BRA550'  
                                      and m.msg_status = 'P');
---------------------------------------------------------------------------------------------                                      
update cans_bel_lastnum s
          set s.last_msg_num_processed = (SELECT max(m.msg_seq_no)-2
                                       FROM MSG_FILES m
                                      where m.msg_counterparty = 'BRA020'  
                                      and m.msg_status = 'P');

  
   


