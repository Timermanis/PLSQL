--If return any data need sent to

--Claire McLuckie; Fraser Munro; Iain Morrison; Paul Kratky; Jacqui Anderson; Iain McDowall;Group.mis.loads

-- 1
-- sql to look for Covermount issues with a legacy Title different to that against its parent issue
-- filtered to those officially on sale +/- 20 days 
select 
m.pix_plant_on_sale_date "On Sale Date",
m.pix_sap_id "SAP ID", 
m.pix_legacy_title "Legacy Title code", 
(select max(titl_long_name) from titles t where titl_code = m.PIX_LEGACY_TITLE) "Title Name",
m.pix_spoke_code "Plant", 
m.pix_issue_type "Issue Type", 
m.pix_official_on_sale_date "Official On Sale Date", 
cm.pix_sap_id "SAP ID", 
cm.pix_legacy_title "Legacy Title code", 
(select max(titl_long_name) from titles where titl_code = cm.PIX_LEGACY_TITLE) "Title Name",
cm.pix_issue_type "Issue Type"
from plant_issues_xref cm, plant_issues_xref m
where cm.pix_issue_type = 'Z4'
and m.pix_issue_type != 'Z4'
and cm.pix_parent_id = m.pix_sap_id
and cm.pix_legacy_title != m.pix_legacy_title
and m.pix_spoke_code = cm.pix_spoke_code
and m.pix_official_on_sale_date > sysdate-20
and m.pix_official_on_sale_date < sysdate+28
order by  m.pix_legacy_title, m.pix_sap_id;


-- 2
-- mv issues in SAP with the same legacy title as the main, but different EAN's
-- filtered to those officially on sale +/- 20 days and not yet on sale
--insert into dummy_eans_reported select distinct x1.pix_sap_id, x2.pix_sap_id  /*
select 
x1.pix_official_on_sale_date "Official on sale date",
x1.pix_sap_id "SAP id",
x1.pix_issue_type "Type",
x1.pix_branch_code "Branch",
x1.pix_spoke_code "Plant",
x1.pix_legacy_title "Legacy Title", 
titl_long_name "Title name",
x1.pix_ean "EAN",
x2.pix_legacy_title "Legacy title" ,
x2.pix_official_on_sale_date "On sale date",
x2.pix_sap_id "SAP id", 
x2.pix_ean "EAN"   --*/
from plant_issues_xref x1, plant_issues_xref x2, titles
where x1.pix_sap_id = x2.pix_parent_id
and x1.pix_spoke_code = x2.pix_spoke_code
and x1.pix_legacy_title = x2.pix_legacy_title
and x1.pix_issue_type != 'Z2'
and x2.pix_ean not like '999999%'--newly added
and x2.pix_ean not like '97799%'--newly added
and x2.pix_issue_type = 'Z2'
and x1.pix_ean != x2.pix_ean
and x1.pix_official_on_sale_date > sysdate-20 
and x1.pix_official_on_sale_date < sysdate+28
and x1.pix_plant_on_sale_date is null
and X1.pix_legacy_title = titl_code
and (x1.PIX_SAP_ID, x2.PIX_SAP_ID) not in (select main_sap_id, mv_sap_id from dummy_eans_reported)
and x2.PIX_LEGACY_EAN not like '999%'
and x2.PIX_EAN not like '999%'
order by  x1.pix_sap_id, x2.pix_sap_id
;
/*
delete from dummy_eans_reported
 where (main_sap_id, mv_sap_id) not in (select x1.pix_sap_id ,x2.pix_sap_id
                                          from plant_issues_xref x1, plant_issues_xref x2, titles
                                         where x1.pix_sap_id = x2.pix_parent_id
                                           and x1.pix_spoke_code = x2.pix_spoke_code
                                           and x1.pix_legacy_title = x2.pix_legacy_title
                                           and x1.pix_issue_type != 'Z2'
                                           and x2.pix_issue_type = 'Z2'
                                           and x1.pix_ean != x2.pix_ean
                                           and x1.pix_official_on_sale_date > sysdate-20 
                                           and x1.pix_official_on_sale_date < sysdate+28
                                           and x1.pix_plant_on_sale_date is null
                                           and X1.pix_legacy_title = titl_code);
*/

-- 3
-- mv issues in SAP with the same EAN as the main, but different legacy Title codes
-- filtered to those officially on sale +/- 20 days and not yet on sale
select  /*+ RULE */
x1.pix_official_on_sale_date "Official On Sale Date",
x1.pix_sap_id "SAP ID" ,
x1.pix_issue_type "Issue Type" ,
x1.pix_branch_code "Branch",
x1.pix_spoke_code "Spoke",
x1.pix_legacy_title "Legacy Title Code", 
t1.titl_long_name "Title Name",
x1.pix_ean "EAN",
x2.pix_legacy_title  "Legacy Title Code",
t2.titl_long_name "Title Name",
x2.pix_official_on_sale_date "On Sale Date" ,
x2.pix_sap_id "SAP ID" , 
x2.pix_ean "EAN" 
from plant_issues_xref x1, plant_issues_xref x2, titles t1, titles t2
where x1.pix_sap_id = x2.pix_parent_id
and x1.pix_spoke_code = x2.pix_spoke_code
and x1.pix_legacy_title != x2.pix_legacy_title
and x1.pix_issue_type != 'Z2'
and x2.pix_issue_type = 'Z2'
and x1.pix_ean = x2.pix_ean
and x1.pix_legacy_title = t1.titl_code(+)
and x2.pix_legacy_title = t2.titl_code(+)
and x1.pix_official_on_sale_date > sysdate-20
and x1.pix_official_on_sale_date < sysdate+28
and x1.pix_plant_on_sale_date is null
and not (x1.PIX_SAP_ID = '000000000021852035' and x2.pix_sap_id = '000000000384840005')
order by x1.pix_legacy_title, x1.pix_official_on_sale_date, x1.pix_branch_code, x1.pix_spoke_code;


-- 4
--issues in SAP with the same EAN , but different legacy Title codes
-- filtered to those officially on salein future and not yet on sale
select  /*+ RULE */ distinct 
x1.pix_legacy_ean EAN,
x1.pix_legacy_title title_code1, 
t1.titl_long_name title_name1, 
x1.pix_sap_id SAP_ID1, 
x1.pix_issue_type Type1,
x1.pix_official_on_sale_date,
x2.pix_official_on_sale_date,
x2.pix_legacy_title title_code2, 
t2.titl_long_name title_name2,
x2.pix_sap_id SAP_ID2,
x2.pix_issue_type type2
from plant_issues_xref x1, plant_issues_xref x2, titles t1, titles t2
where x1.pix_legacy_ean = x2.pix_legacy_ean
and x1.pix_spoke_code != x2.pix_spoke_code
and x1.pix_plant_on_sale_date is null
and x2.pix_plant_on_sale_date is null
and x1.pix_legacy_title < x2.pix_legacy_title
and x1.pix_sap_id != x2.pix_sap_id
and t1.titl_code = x1.pix_legacy_title
and t2.titl_code = x2.pix_legacy_title
and x1.pix_official_on_sale_date > sysdate
and x2.pix_official_on_sale_date > sysdate
and x1.PIX_LEGACY_TITLE not in (4394,4396)
--Exclude titles that ought to be JM'd when they are handled.
and not exists (  select 1
                  from plant_issues_xref p
                  where pix_legacy_title != pix_main_legacy_title
                  and pix_branch_code != pix_spoke_code
                  and pix_legacy_title is not null
                  and length(pix_legacy_ean) = 15     -- ie not a jm
                  and pix_freq_code = 19              -- weekly
                  and pix_ean = x1.pix_legacy_ean
                  and p.PIX_BRANCH_CODE IN (x1.PIX_BRANCH_CODE, x2.PIX_BRANCH_CODE) 
                  and p.PIX_SAP_ID      in (x1.PIX_SAP_ID,x2.PIX_SAP_ID))
and not exists (  select 1
                  FROM  plant_issues_xref x11, 
                        plant_issues_xref x22
                  WHERE x11.pix_legacy_ean         = x22.pix_legacy_ean
                  AND   x11.pix_branch_code        = x22.pix_branch_code
                  AND   x11.pix_legacy_title       < x22.pix_legacy_title
                  AND   x11.pix_sap_id            != x22.pix_sap_id
                  and x11.pix_sap_id in ( x1.PIX_SAP_ID, x2.PIX_SAP_ID)
                  and x11.pix_branch_code in (x1.PIX_BRANCH_CODE, x2.PIX_BRANCH_CODE)
                  and x22.pix_sap_id in ( x1.PIX_SAP_ID, x2.PIX_SAP_ID)
                  and x22.pix_branch_code in (x1.PIX_BRANCH_CODE, x2.PIX_BRANCH_CODE))--*/
--Filter out titles matching their bulks  
/*
and not (x1.PIX_LEGACY_TITLE =  4014 and x2.PIX_LEGACY_TITLE = 38940) --AIRDRIE ADVERTISER
and not (x1.PIX_LEGACY_TITLE =  4496 and x2.PIX_LEGACY_TITLE = 38942) --DUMF GAL ST FRI
and not (x1.PIX_LEGACY_TITLE =  4497 and x2.PIX_LEGACY_TITLE = 38941) --DUMF GAL ST WED
and not (x1.PIX_LEGACY_TITLE =  4531 and x2.PIX_LEGACY_TITLE = 38943) --EAST KILBRIDE NEWS
and not (x1.PIX_LEGACY_TITLE =  4726 and x2.PIX_LEGACY_TITLE = 38947) --LANARK CARLUKE ADV
and not (x1.PIX_LEGACY_TITLE =  4727 and x2.PIX_LEGACY_TITLE = 38944) --HAMILTON ADVERTISER
and not (x1.PIX_LEGACY_TITLE =  4946 and x2.PIX_LEGACY_TITLE = 38946) --KILMARNOCK STANDARD
and not (x1.PIX_LEGACY_TITLE =  5052 and x2.PIX_LEGACY_TITLE = 38939) --WEST LOTHIAN COURIER
and not (x1.PIX_LEGACY_TITLE =  5927 and x2.PIX_LEGACY_TITLE = 38948) --WISHAW PRESS
and not (x1.PIX_LEGACY_TITLE =  9103 and x2.PIX_LEGACY_TITLE = 38950) --PERTH ADVERTISER FRI
and not (x1.PIX_LEGACY_TITLE =  9104 and x2.PIX_LEGACY_TITLE = 38949) --PERTH ADVERTISER TUE
and not (x1.PIX_LEGACY_TITLE =  9105 and x2.PIX_LEGACY_TITLE = 38936) --STIRLING OBSERVER FRI
and not (x1.PIX_LEGACY_TITLE =  9106 and x2.PIX_LEGACY_TITLE = 38935) --STIRLING OBSERVER WED
and not (x1.PIX_LEGACY_TITLE = 11219 and x2.PIX_LEGACY_TITLE = 36293) --SELBY POST
and not (x1.PIX_LEGACY_TITLE = 12674 and x2.PIX_LEGACY_TITLE = 38940) --SURREY MIRROR REIGATE RED
and not (x1.PIX_LEGACY_TITLE = 13425 and x2.PIX_LEGACY_TITLE = 38538) --NORTH WALES WEEKLY NEWS
and not (x1.PIX_LEGACY_TITLE = 13486 and x2.PIX_LEGACY_TITLE = 30121) --HOLYHEAD & A ML
and not (x1.PIX_LEGACY_TITLE = 13742 and x2.PIX_LEGACY_TITLE = 31407) --IMAGE
and not (x1.PIX_LEGACY_TITLE = 13743 and x2.PIX_LEGACY_TITLE = 31408) --IMAGE INTERIORS LIVING IRELA
and not (x1.PIX_LEGACY_TITLE = 16067 and x2.PIX_LEGACY_TITLE = 38536) --CAERNARFON HERALD ARFON
and not (x1.PIX_LEGACY_TITLE = 16068 and x2.PIX_LEGACY_TITLE = 38537) --CAERNARFON DENBIGH HLD STH
and not (x1.PIX_LEGACY_TITLE = 21446 and x2.PIX_LEGACY_TITLE = 36724) --BANGOR MAIL
and not (x1.PIX_LEGACY_TITLE = 22104 and x2.PIX_LEGACY_TITLE = 38538) --NORTH WALES WEEKLY NEWS  Z1
and not (x1.PIX_LEGACY_TITLE = 22105 and x2.PIX_LEGACY_TITLE = 38618) --NORTH WALES WEEKLY NEWS  Z2
and not (x1.PIX_LEGACY_TITLE = 22125 and x2.PIX_LEGACY_TITLE = 38537) --CAERNARFON DENBIGH HLD STH  Z1
and not (x1.PIX_LEGACY_TITLE = 22126 and x2.PIX_LEGACY_TITLE = 38616) --CAERNARFON DENBIGH HLD STH  Z2
and not (x1.PIX_LEGACY_TITLE = 22127 and x2.PIX_LEGACY_TITLE = 38536) --CAERNARFON HERALD ARFON  Z1
and not (x1.PIX_LEGACY_TITLE = 22128 and x2.PIX_LEGACY_TITLE = 38617) --CAERNARFON HERALD ARFON  Z2
and not (x1.PIX_LEGACY_TITLE = 24166 and x2.PIX_LEGACY_TITLE = 36293) --SELBY POST  Z2
and not (x1.PIX_LEGACY_TITLE = 33202 and x2.PIX_LEGACY_TITLE = 38941) --DUMF GAL ST WED  Z2
and not (x1.PIX_LEGACY_TITLE = 33210 and x2.PIX_LEGACY_TITLE = 38942) --DUMF GAL ST FRI  Z2
and not (x1.PIX_LEGACY_TITLE = 34901 and x2.PIX_LEGACY_TITLE = 35007) --INSHORE IRELAND
and not (x1.PIX_LEGACY_TITLE = 36556 and x2.PIX_LEGACY_TITLE = 43469) --SCUNTHORPE TEL WKLY DD
and not (x1.PIX_LEGACY_TITLE = 12674 and x2.PIX_LEGACY_TITLE = 36278) --SURREY MIRROR REIGATE RED
and not (x1.PIX_LEGACY_TITLE = 13425 and x2.PIX_LEGACY_TITLE = 38618) --NORTH WALES WEEKLY NEWS
and not (x1.PIX_LEGACY_TITLE = 16067 and x2.PIX_LEGACY_TITLE = 38617) --CAERNARFON HERALD ARFON
and not (x1.PIX_LEGACY_TITLE = 16068 and x2.PIX_LEGACY_TITLE = 38616) --CAERNARFON DENBIGH HLD STH
and not (x1.PIX_LEGACY_TITLE =  6866 and x2.PIX_LEGACY_TITLE = 29675) --JOURNAL YORKSHIRE
and not (x1.PIX_LEGACY_TITLE =  6922 and x2.PIX_LEGACY_TITLE = 34585) --HASLEMERE HERALD
and not (x1.PIX_LEGACY_TITLE =  6922 and x2.PIX_LEGACY_TITLE = 34587) --HASLEMERE HERALD -v- Liphook Herald
and not (x1.PIX_LEGACY_TITLE = 18712 and x2.PIX_LEGACY_TITLE = 34528) --FARNHAM HERALD DIR
and not (x1.PIX_LEGACY_TITLE = 18713 and x2.PIX_LEGACY_TITLE = 34552) --HASLEMERE HERALD DIR
and not (x1.PIX_LEGACY_TITLE = 18713 and x2.PIX_LEGACY_TITLE = 34587) --HASLEMERE HERALD DIR
and not (x1.PIX_LEGACY_TITLE = 22729 and x2.PIX_LEGACY_TITLE = 33220) --CUMBERLAND WESTMORLAND HLD  Z3
and not (x1.PIX_LEGACY_TITLE = 24347 and x2.PIX_LEGACY_TITLE = 33220) --CUMBERLAND WESTMORLAND HLD  Z1
and not (x1.PIX_LEGACY_TITLE = 27709 and x2.PIX_LEGACY_TITLE = 34117) --WITHAM TIMES (BRAINTREE)
and not (x1.PIX_LEGACY_TITLE = 31310 and x2.PIX_LEGACY_TITLE = 31585) --DARTFORD MESSENGER
and not (x1.PIX_LEGACY_TITLE = 22729 and x2.PIX_LEGACY_TITLE = 33282) --CUMBERLAND WESTMORLAND HLD  Z3
and not (x1.PIX_LEGACY_TITLE = 19544 and x2.PIX_LEGACY_TITLE = 22659) --TIMES ED SUPP
and not (x1.PIX_LEGACY_TITLE = 19544 and x2.PIX_LEGACY_TITLE = 22740) --TIMES ED SUPP
and not (x1.PIX_LEGACY_TITLE = 19544 and x2.PIX_LEGACY_TITLE = 24168) --TIMES ED SUPP
and not (x1.PIX_LEGACY_TITLE = 19544 and x2.PIX_LEGACY_TITLE = 34015) --TIMES ED SUPP
and not (x1.PIX_LEGACY_TITLE = 19544 and x2.PIX_LEGACY_TITLE = 34489) --TIMES ED SUPP
and not (x1.PIX_LEGACY_TITLE =  7074 and x2.PIX_LEGACY_TITLE = 43562) --BRITISH RAILWAY MODELLING
and not (x1.PIX_LEGACY_TITLE = 31310 and x2.PIX_LEGACY_TITLE = 31587) --DARTFORD MESSENGER
and not (x1.PIX_LEGACY_TITLE = 31310 and x2.PIX_LEGACY_TITLE = 31590) --DARTFORD MESSENGER
and not (x1.PIX_LEGACY_TITLE = 33254 and x2.PIX_LEGACY_TITLE = 33282) --CUMBERLAND WESTMORLAND HLD  Z2
and not (x1.PIX_LEGACY_TITLE = 36394 and x2.PIX_LEGACY_TITLE = 36556) --SCUNTHORPE TELEGRAPH WKLY  Z1   Caused a KPI failure during loads.
and not (x1.PIX_LEGACY_TITLE = 37033 and x2.PIX_LEGACY_TITLE = 37093) --LINCOLNSHIRE ECHO
and not (x1.PIX_LEGACY_TITLE = 37034 and x2.PIX_LEGACY_TITLE = 37092) --LINCOLNSHIRE ECHO  Z1
and not (x1.PIX_LEGACY_TITLE = 39312 and x2.PIX_LEGACY_TITLE = 39332) --LINCOLNSHIRE ECHO WEST LIN
and not (x1.PIX_LEGACY_TITLE = 39313 and x2.PIX_LEGACY_TITLE = 39331) --LINCOLNSHIRE ECHO WEST LIN  Z1
and not (x1.PIX_LEGACY_TITLE = 39528 and x2.PIX_LEGACY_TITLE = 43135) --VWT
and not (x1.PIX_LEGACY_TITLE = 19544 and x2.PIX_LEGACY_TITLE = 40024) --TIMES ED SUPP
and not (x1.PIX_LEGACY_TITLE = 19544 and x2.PIX_LEGACY_TITLE = 40025) --TIMES ED SUPP
and not (x1.PIX_LEGACY_TITLE = 19544 and x2.PIX_LEGACY_TITLE = 40026) --TIMES ED SUPP
and not (x1.PIX_LEGACY_TITLE = 19544 and x2.PIX_LEGACY_TITLE = 40027) --TIMES ED SUPP
and not (x1.PIX_LEGACY_TITLE = 19544 and x2.PIX_LEGACY_TITLE = 40028) --TIMES ED SUPP
and not (x1.PIX_LEGACY_TITLE = 19544 and x2.PIX_LEGACY_TITLE = 43926) --TIMES ED SUPP
and not (x1.PIX_LEGACY_TITLE = 22659 and x2.PIX_LEGACY_TITLE = 40024) --TIMES ED SUPP  Z1
and not (x1.PIX_LEGACY_TITLE = 22659 and x2.PIX_LEGACY_TITLE = 40025) --TIMES ED SUPP  Z1
and not (x1.PIX_LEGACY_TITLE = 22659 and x2.PIX_LEGACY_TITLE = 40026) --TIMES ED SUPP  Z1
and not (x1.PIX_LEGACY_TITLE = 22659 and x2.PIX_LEGACY_TITLE = 40027) --TIMES ED SUPP  Z1
and not (x1.PIX_LEGACY_TITLE = 22659 and x2.PIX_LEGACY_TITLE = 40028) --TIMES ED SUPP  Z1
and not (x1.PIX_LEGACY_TITLE = 22659 and x2.PIX_LEGACY_TITLE = 43926) --TIMES ED SUPP  Z1
and not (x1.PIX_LEGACY_TITLE = 22740 and x2.PIX_LEGACY_TITLE = 40024) --TIMES ED SUPP  Z3
and not (x1.PIX_LEGACY_TITLE = 22740 and x2.PIX_LEGACY_TITLE = 40025) --TIMES ED SUPP  Z3
and not (x1.PIX_LEGACY_TITLE = 22740 and x2.PIX_LEGACY_TITLE = 40026) --TIMES ED SUPP  Z3
and not (x1.PIX_LEGACY_TITLE = 22740 and x2.PIX_LEGACY_TITLE = 40027) --TIMES ED SUPP  Z3
and not (x1.PIX_LEGACY_TITLE = 22740 and x2.PIX_LEGACY_TITLE = 40028) --TIMES ED SUPP  Z3
and not (x1.PIX_LEGACY_TITLE = 22740 and x2.PIX_LEGACY_TITLE = 43926) --TIMES ED SUPP  Z3
and not (x1.PIX_LEGACY_TITLE = 24168 and x2.PIX_LEGACY_TITLE = 40024) --TIMES ED SUPP  Z2
and not (x1.PIX_LEGACY_TITLE = 24168 and x2.PIX_LEGACY_TITLE = 40025) --TIMES ED SUPP  Z2
and not (x1.PIX_LEGACY_TITLE = 24168 and x2.PIX_LEGACY_TITLE = 40026) --TIMES ED SUPP  Z2
and not (x1.PIX_LEGACY_TITLE = 24168 and x2.PIX_LEGACY_TITLE = 40027) --TIMES ED SUPP  Z2
and not (x1.PIX_LEGACY_TITLE = 24168 and x2.PIX_LEGACY_TITLE = 40028) --TIMES ED SUPP  Z2
and not (x1.PIX_LEGACY_TITLE = 24168 and x2.PIX_LEGACY_TITLE = 43926) --TIMES ED SUPP  Z2
and not (x1.PIX_LEGACY_TITLE = 34015 and x2.PIX_LEGACY_TITLE = 40024) --TIMES ED SUPP  Z4
and not (x1.PIX_LEGACY_TITLE = 34015 and x2.PIX_LEGACY_TITLE = 40025) --TIMES ED SUPP  Z4
and not (x1.PIX_LEGACY_TITLE = 34015 and x2.PIX_LEGACY_TITLE = 40026) --TIMES ED SUPP  Z4
and not (x1.PIX_LEGACY_TITLE = 34015 and x2.PIX_LEGACY_TITLE = 40027) --TIMES ED SUPP  Z4
and not (x1.PIX_LEGACY_TITLE = 34015 and x2.PIX_LEGACY_TITLE = 40028) --TIMES ED SUPP  Z4
and not (x1.PIX_LEGACY_TITLE = 34015 and x2.PIX_LEGACY_TITLE = 43926) --TIMES ED SUPP  Z4
and not (x1.PIX_LEGACY_TITLE = 34489 and x2.PIX_LEGACY_TITLE = 40024) --TIMES ED SUPP  Z5
and not (x1.PIX_LEGACY_TITLE = 34489 and x2.PIX_LEGACY_TITLE = 40025) --TIMES ED SUPP  Z5
and not (x1.PIX_LEGACY_TITLE = 34489 and x2.PIX_LEGACY_TITLE = 40026) --TIMES ED SUPP  Z5
and not (x1.PIX_LEGACY_TITLE = 34489 and x2.PIX_LEGACY_TITLE = 40027) --TIMES ED SUPP  Z5
and not (x1.PIX_LEGACY_TITLE = 34489 and x2.PIX_LEGACY_TITLE = 40028) --TIMES ED SUPP  Z5
and not (x1.PIX_LEGACY_TITLE = 34489 and x2.PIX_LEGACY_TITLE = 43926) --TIMES ED SUPP  Z5
and not (x1.PIX_LEGACY_TITLE = 1240 and x2.PIX_LEGACY_TITLE = 35461) -- Ayrshire Post
and not (x1.PIX_LEGACY_TITLE = 4072 and x2.PIX_LEGACY_TITLE = 35460) -- Ayrshire Post
and not (x1.PIX_LEGACY_TITLE = 31407 and x2.PIX_LEGACY_TITLE = 34776) --BULK IMAGE
and not (x1.PIX_LEGACY_TITLE = 30758 and x2.PIX_LEGACY_TITLE = 30759) --UK TIME
and not (x1.PIX_LEGACY_TITLE = 30758 and x2.PIX_LEGACY_TITLE = 38784) --UK TIME
and not (x1.PIX_LEGACY_TITLE = 30759 and x2.PIX_LEGACY_TITLE = 38784) --UK TIME  Z1
and not (x1.PIX_LEGACY_TITLE = 4043 and x2.PIX_LEGACY_TITLE = 5147) --MOFFAT NEWS
and not (x1.PIX_LEGACY_TITLE = 5147 and x2.PIX_LEGACY_TITLE = 33231) --ANNANDALE HERALD & RECORD  Z2
and not (x1.PIX_SAP_ID = '000000000302482037' and x2.PIX_SAP_ID = '000000000375210006')
and not (x1.PIX_SAP_ID = '000000000414140018' and x2.PIX_SAP_ID = '000000000420200005')
/*
and not (x1.PIX_LEGACY_TITLE = 4014 and x2.PIX_LEGACY_TITLE = 38940) --
*/
--Done filtering titles against their bulks */
order by x1.pix_legacy_title,x2.pix_legacy_title,x1.pix_sap_id;


-- 5
-- BI Team check
-- Something similar to above but to check same sap id to find where fix gen wkly not fixed!
-- filtered to those on sale in the last 20 days.
select  /*+ RULE */ distinct 
x1.pix_legacy_ean EAN,
x1.pix_legacy_title title_code1, 
t1.titl_long_name title_name1, 
x1.pix_sap_id SAP_ID1, 
x1.pix_issue_type Type1,
x1.pix_official_on_sale_date,
x2.pix_official_on_sale_date,
x2.pix_legacy_title title_code2, 
t2.titl_long_name title_name2,
x2.pix_sap_id SAP_ID2,
x2.pix_issue_type type2
from plant_issues_xref x1, plant_issues_xref x2, titles t1, titles t2
where x1.pix_legacy_ean = x2.pix_legacy_ean
and x1.pix_spoke_code != x2.pix_spoke_code
and x1.pix_plant_on_sale_date > sysdate -20 
and x2.pix_plant_on_sale_date > sysdate -20 
and x1.pix_legacy_title < x2.pix_legacy_title
and x1.pix_sap_id = x2.pix_sap_id
and t1.titl_code = x1.pix_legacy_title
and t2.titl_code = x2.pix_legacy_title
and x1.pix_issue_type != 'Z7' -- packing titles donot go into homis
order by x1.pix_legacy_title,x2.pix_legacy_title,x1.pix_sap_id;




