update branch_issues
set bris_link_ean = 977204846300001,
bris_link_issue_year = 2012
where bris_branch_code = 'BRA270'
and bris_link_issue_year = 2013
and bris_link_ean =  977204846300001;

exec create_normal_issue('L', 977204846300001,2013);

exec create_normal_issue('L', 977204846300001,2013);

update normal_issues 
set niss_manual_update_flag = sysdate 
where niss_ean = 977204846300001
and niss_issue_year = 2012;
