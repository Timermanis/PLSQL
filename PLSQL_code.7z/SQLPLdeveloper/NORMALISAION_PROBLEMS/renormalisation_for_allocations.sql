update branch_issues
set bris_link_ean = 977204846300001,
bris_link_issue_year = 2012
where bris_branch_code = 'BRA270'
and bris_link_issue_year = 2013
and bris_link_ean =  977204846300001;

exec create_normal_issue('L', 977204846300001,2012);

exec create_normal_issue('L', 977204846300001,2013);

update normal_issues 
set niss_manual_update_flag = sysdate 
where niss_ean = 977204846300001
and niss_issue_year = 2012;
--------------------------------------------------------------
select 
bris_branch_code branch,
bris_title_code, bris_on_sale_date,bris_link_reliability, bris_title_code,bris_ean,bris_issue_year,bris_issue_week,bris_issue_day,
niss_ean,niss_title_code ni_title, niss_type_flag ni_type, niss_issue_year ni_yr, niss_issue_week ni_wk, niss_issue_day ni_day,
br_commited_sales_quantity + br_casual_sales_quantity + br_box_out_quantity + br_other_sales_quantity br_sales,
br_credit_quantity
from branch_issues,normal_issues, branch_summaries
where  bris_link_ean = niss_ean(+)
and bris_link_issue_year = niss_issue_year(+)
and br_branch_code = bris_branch_code
and br_ean = bris_ean
and br_issue_year = bris_issue_year
--
--and bris_title_code = 4510
and niss_title_code = 4510
--
and bris_issue_week > 40
and bris_issue_year = 2015
order by bris_issue_week
