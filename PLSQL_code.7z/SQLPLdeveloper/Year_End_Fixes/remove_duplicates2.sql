select distinct titl_long_name, b.bris_branch_code,b.bris_issue_year,b.bris_issue_week,b.bris_ean,n.niss_issue_year,n.niss_issue_week,n.niss_ean,s.br_net_sales_value, t.titl_code
from branch_issues b,normal_issues n, branch_summaries s, titles t
where  bris_link_ean = niss_ean(+)
and bris_link_issue_year = niss_issue_year(+)
and br_branch_code = bris_branch_code
and br_ean = bris_ean
and br_issue_year = bris_issue_year
and (niss_title_code, niss_issue_year, niss_issue_week, niss_issue_day) in (
select n2.niss_title_code, n2.niss_issue_year, n2.niss_issue_week, n2.niss_issue_day,count(*),max(rownum)
from normal_issues n2
where n2.niss_issue_year = 2015
and n2.niss_issue_week > 35
and length(n2.niss_ean) = 14
group by n2.niss_title_code, n2.niss_issue_year, n2.niss_issue_week, n2.niss_issue_day
having count(*) > 1)
and titl_code = niss_title_code

delete from normal_issues where (niss_title_code, niss_issue_year, niss_issue_week, niss_issue_day, rownum) in
(select n2.niss_title_code, n2.niss_issue_year, n2.niss_issue_week, n2.niss_issue_day,max(rownum)
from normal_issues n2
where n2.niss_issue_year = 2015
and n2.niss_issue_week > 35
and length(n2.niss_ean) = 14
group by n2.niss_title_code, n2.niss_issue_year, n2.niss_issue_week, n2.niss_issue_day
having count(*) > 1)
