select distinct titl_long_name,b.bris_title_code,b.bris_ean--just 3 set for week54
from branch_issues b, titles
where bris_title_code = titl_code
and bris_issue_year = 2016
and bris_issue_week > 30

HUNTLY EXPRESS	4842	977000032690953
BULK STAR ENG	10537	10105371552601
UNCUT ULT MUSIC GUIDE WHS	49193	501079159500005

select * from branch_issues b where b.bris_ean = 501079159500005 for update
------------------------------------
select niss_title_code, niss_issue_year, niss_issue_week, niss_issue_day, count(*)--skeleton issues
from normal_issues
where niss_issue_year = 2016
and niss_issue_week > 35
group by niss_title_code, niss_issue_year, niss_issue_week, niss_issue_day
having count(*) > 1

2752  2016  53  0 2
3426  2016  40  0 2
6306  2016  42  0 2
8475  2016  36  0 2
9708  2016  42  0 2
23243 2016  46  0 2
36077 2016  44  0 2
48868 2016  39  0 2

select *
from normal_issues n where n.niss_issue_week = 40 and n.niss_title_code = 3426
---------------------------------------------
