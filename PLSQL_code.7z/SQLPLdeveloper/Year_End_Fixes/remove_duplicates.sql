create table jt_210116_NI_backup  as
select n.*,rowid row_id from normal_issues n where 
(niss_title_code, niss_issue_year, niss_issue_week, niss_issue_day, rowid) in
(select n2.niss_title_code, n2.niss_issue_year, n2.niss_issue_week, n2.niss_issue_day,max(rowid)
from normal_issues n2
where n2.niss_issue_year = 2015
and n2.niss_issue_week > 35
and length(n2.niss_ean) = 14
group by n2.niss_title_code, n2.niss_issue_year, n2.niss_issue_week, n2.niss_issue_day
having count(*) > 1)


delete from normal_issues where (niss_title_code, niss_issue_year, niss_issue_week, niss_issue_day, rowid) in
(select n2.niss_title_code, n2.niss_issue_year, n2.niss_issue_week, n2.niss_issue_day,max(rowid)
from normal_issues n2
where n2.niss_issue_year = 2015
and n2.niss_issue_week > 35
and length(n2.niss_ean) = 14
group by n2.niss_title_code, n2.niss_issue_year, n2.niss_issue_week, n2.niss_issue_day
having count(*) > 1)

select distinct titl_long_name
from branch_issues,normal_issues, branch_summaries, titles
where  bris_link_ean = niss_ean(+)
and bris_link_issue_year = niss_issue_year(+)
and br_branch_code = bris_branch_code
and br_ean = bris_ean
and br_issue_year = bris_issue_year
and (niss_title_code, niss_issue_year, niss_issue_week, niss_issue_day) in (
select n2.niss_title_code, n2.niss_issue_year, n2.niss_issue_week, n2.niss_issue_day
from normal_issues n2
where n2.niss_issue_year = 2015
and n2.niss_issue_week > 35
and length(n2.niss_ean) = 14
group by n2.niss_title_code, n2.niss_issue_year, n2.niss_issue_week, n2.niss_issue_day
having count(*) > 1)
and titl_code = niss_title_code

select t.titl_long_name,b.* from jt_210116_NI_backup b,titles t
where t.titl_code=b.niss_title_code

