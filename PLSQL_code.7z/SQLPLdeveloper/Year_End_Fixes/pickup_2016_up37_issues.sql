
select * from agent_net_sales a, branch_issues b where 
a.net_issue_ean = b.bris_ean and
a.net_issue_year = b.bris_issue_year and
a.net_branch_code = b.bris_branch_code and
a.net_issue_year = 2000 and 
--b.bris_ean = 10360461553601 and--10006391553601
a.net_title_code = b.bris_title_code and
b.bris_issue_week > 35

select b.bris_ean,count(*) from agent_net_sales a, branch_issues b where 
a.net_issue_ean = b.bris_ean and
a.net_issue_year = b.bris_issue_year and
a.net_branch_code = b.bris_branch_code and
a.net_issue_year = 2000 and 
b.bris_ean = 10403261553601 and--10006391553601
a.net_title_code = b.bris_title_code 
--b.bris_issue_week > 35
group by b.bris_ean order by count(*) desc
--create table EAN_end_2016 as

select * from branch_issues b where b.bris_ean=10403261553601 and b.bris_issue_year = 2015
select * from branch_issues b where b.bris_ean=10403261553601 and b.bris_issue_year = 2016
select *from agent_net_sales a  where a.net_issue_ean=10403261553601 and a.net_issue_year=2015 union
select *from agent_net_sales a  where a.net_issue_ean=10403261553601 and a.net_issue_year=2016 union


select distinct c.* from EAN_end_2016 c,titles t   -- branch_issues b where b.bris_issue_year = 2016 and b.bris_issue_week > 35
where c.bris_title_code = t.titl_code
and t.titl_title_issue_frequency !=1

select a.net_issue_ean,c.bris_title_code,count(*),sum(a.net_commited_quantity) from agent_net_sales a,EAN_end_2016 c where --136
a.net_issue_ean = c.bris_ean and
a.net_issue_year = c.bris_issue_year and
a.net_branch_code = c.bris_branch_code and
a.net_issue_year = 2016 and 
c.bris_issue_year = 2016 and
a.net_title_code = c.bris_title_code and
c.bris_issue_week > 35
group by a.net_issue_ean,c.bris_title_code

--create table EAN_END_2016_for_change as19/04/16 1st.test(10360461553601)  20/04/16 10 move xls doc 
select a.net_issue_ean,c.bris_title_code,count(*) coun,sum(a.net_commited_quantity) su from agent_net_sales a,EAN_end_2016 c where --136
a.net_issue_ean = c.bris_ean and
a.net_issue_year = c.bris_issue_year and
a.net_branch_code = c.bris_branch_code and
a.net_issue_year = 2016 and 
c.bris_issue_year = 2016 and
--a.net_title_code = c.bris_title_code and
c.bris_issue_week > 35 AND
c.bris_title_code not in (select x.title_code from TITLES_X_REF_REC_SPLIT x) and-- -6
c.bris_title_code not in (40219,90955) 
group by a.net_issue_ean,c.bris_title_code



select b.bris_ean,count(*) from agent_net_sales a, branch_issues b where 
a.net_issue_ean = b.bris_ean and
a.net_issue_year = b.bris_issue_year and
a.net_branch_code = b.bris_branch_code and
a.net_issue_year = 2000 and 
b.bris_ean = 10403261553601 and--10006391553601
a.net_title_code = b.bris_title_code 
--b.bris_issue_week > 35
group by b.bris_ean order by count(*) desc
--create table EAN_end_2016 as

select * from branch_issues b where b.bris_ean=10339361553401
 and b.bris_issue_year = 2015
select * from branch_issues b where b.bris_ean=10339361553401
 and b.bris_issue_year = 2016
select *from agent_net_sales a  where a.net_issue_ean=10339361553401 and a.net_issue_year=2015 union
select *from agent_net_sales a  where a.net_issue_ean=10339361553401 and a.net_issue_year=2016 
select *from normal_issues n  where n.niss_ean=10339361553401 and n.net_issue_year=2016 
delete from normal_issues n  where n.niss_ean=10339361553401

select * from agent_net_sales where net_issue_ean=10339361553401 and net_issue_year=2015 
update agent_net_sales set net_issue_year=2015 where net_issue_ean=10263031553601 and net_issue_year=2016 

10271221553601
