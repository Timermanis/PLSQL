select * from plant_issues_xref_base x where x.pix_legacy_title = 15421 and x.pix_year = 2016 and x.pix_week = 2 order by x.pix_week
select * from plant_issues_xref_base x where x.pix_sap_id = 000000000154212035
977152952503902
