select * from branch_issues b where b.bris_ean = 660154211602001 for update
select * from normal_issues n where n.niss_ean = 660154211602001 for update
select distinct n.niss_issue_week from normal_issues n where n.niss_title_code = 15421 and n.niss_issue_year = 2014


update agent_net_sales a set a.net_issue_year = 2015
where a.net_issue_ean = 660154211602001 and a.net_issue_year = 2016

select * from agent_net_sales a where a.net_issue_ean = 660154211602001 and a.net_issue_year = 2015
select * from agent_net_sales a where a.net_title_code = 15421 and a.net_issue_year = 2015
