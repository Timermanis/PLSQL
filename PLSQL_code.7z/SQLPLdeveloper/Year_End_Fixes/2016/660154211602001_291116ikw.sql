select * from zpx_plnt_iss_stg_bak p where p.issue_id = 000000000154212035

select * from zpx_plnt_iss_stg_bak p where p.issue_id = 000000000490870003

select * from zpx_plnt_iss_stg_bak p where p.etl_run_num_seq = 2324 and p.legacy_titl_code = '15421'

select max(p.etl_run_num_seq) from zpx_plnt_iss_stg_bak p 

select * from zpx_rtrn_stg_bak p where p.issue_id = '000000000154212035'
