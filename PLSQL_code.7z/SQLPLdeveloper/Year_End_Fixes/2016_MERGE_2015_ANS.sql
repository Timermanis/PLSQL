MERGE INTO agent_net_sales n
    USING (SELECT * FROM agent_net_sales a WHERE a.net_issue_ean = 977026223827501 and a.net_branch_code = 'BRA740' and a.net_issue_year = 2015)  h
    ON (n.net_issue_ean = h.net_issue_ean
    and n.net_branch_code = h.net_branch_code
    and n.NET_AGENT_ACCOUNT_NUMBER = h.NET_AGENT_ACCOUNT_NUMBER
    and n.net_issue_year = h.net_issue_year+1)
  WHEN MATCHED THEN
    UPDATE SET n.net_box_out_quantity = n.net_box_out_quantity + h.net_box_out_quantity,
    n.NET_CREDIT_QUANTITY = n.NET_CREDIT_QUANTITY + h.NET_CREDIT_QUANTITY,
    n.NET_OTHER_SALES_QUANTITY = n.NET_OTHER_SALES_QUANTITY + h.NET_OTHER_SALES_QUANTITY,
    n.NET_COMMITED_QUANTITY = n.NET_COMMITED_QUANTITY + h.NET_COMMITED_QUANTITY,
    n.NET_CASUAL_QUANTITY = n.NET_CASUAL_QUANTITY + h.NET_CASUAL_QUANTITY,
    n.NET_RETURN_QUANTITY = n.NET_RETURN_QUANTITY + h.NET_RETURN_QUANTITY
   
  WHEN NOT MATCHED THEN
    INSERT (NET_AGENT_ACCOUNT_NUMBER,
NET_ISSUE_EAN,
NET_ISSUE_YEAR,
NET_BOX_OUT_QUANTITY,
NET_CREDIT_QUANTITY,
NET_OTHER_SALES_QUANTITY,
NET_COMMITED_QUANTITY,
NET_CASUAL_QUANTITY,
NET_RETURN_QUANTITY,
NET_NOTE_KEYED_FLAG,
NET_CTB_FLAG,
NET_BRANCH_CODE,
NET_BOX_NUMBER,
NET_MULTIPLE_CODE,
NET_MULTIPLE_GRADE_CODE,
NET_ANMW_CODE,
NET_RETAILER_BAND,
NET_POSTCODE_OUTER,
NET_PUBLISHER_CODE,
NET_TITLE_CODE
)
    VALUES (h.NET_AGENT_ACCOUNT_NUMBER,
h.NET_ISSUE_EAN,
'2016',
h.NET_BOX_OUT_QUANTITY,
h.NET_CREDIT_QUANTITY,
h.NET_OTHER_SALES_QUANTITY,
h.NET_COMMITED_QUANTITY,
h.NET_CASUAL_QUANTITY,
h.NET_RETURN_QUANTITY,
h.NET_NOTE_KEYED_FLAG,
h.NET_CTB_FLAG,
h.NET_BRANCH_CODE,
h.NET_BOX_NUMBER,
h.NET_MULTIPLE_CODE,
h.NET_MULTIPLE_GRADE_CODE,
h.NET_ANMW_CODE,
h.NET_RETAILER_BAND,
h.NET_POSTCODE_OUTER,
h.NET_PUBLISHER_CODE,
h.NET_TITLE_CODE);
    

---------------------------------
create table jt_211116_977026224624901_16 as
SELECT * FROM agent_net_sales a WHERE a.net_issue_ean = 977026223827501 and a.net_branch_code = 'BRA740' and a.net_issue_year = 2015;
create table jt_211116_977026224624901_15 as 
delete from 
agent_net_sales a where a.net_issue_ean = 977026223827501 and a.net_branch_code = 'BRA740' and a.net_issue_year = 2015

SELECT * FROM agent_net_sales a WHERE a.net_issue_ean = 977026224624901 and a.net_branch_code = 'BRA740' and a.net_issue_year = 2016 minus
SELECT * FROM jt_211116_977026224624901_16 a WHERE a.net_issue_ean = 977026224624901 and a.net_branch_code = 'BRA740' and a.net_issue_year = 2016 
310145501000600

SELECT * FROM agent_net_sales a WHERE a.net_issue_ean = 977026223827501 and a.net_branch_code = 'BRA740' and a.net_issue_year = 2016 and a.net_agent_account_number = 502963011335000
union all
SELECT * FROM agent_net_sales a WHERE a.net_issue_ean = 977026223827501 and a.net_branch_code = 'BRA740' and a.net_issue_year = 2015 and a.net_agent_account_number = 502963011335000

502963011335000	977026223827501
2	310142554000700	977026223827501
3	310143945000200	977026223827501
4	310143948000900	977026223827501
5	310143971000700	977026223827501


SELECT a.net_agent_account_number,a.net_issue_ean FROM agent_net_sales a WHERE a.net_issue_ean = 977026223827501 and a.net_branch_code = 'BRA740' and a.net_issue_year = 2016 
minus
SELECT a.net_agent_account_number,a.net_issue_ean FROM agent_net_sales a WHERE a.net_issue_ean = 977026223827501 and a.net_branch_code = 'BRA740' and a.net_issue_year = 2015 
