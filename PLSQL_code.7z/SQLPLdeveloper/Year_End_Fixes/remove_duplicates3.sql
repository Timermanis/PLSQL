select distinct bris_branch_code,bris_issue_year,bris_ean,b.bris_link_issue_year,b.bris_link_ean
     from branch_issues b, titles
     where bris_title_code = titl_code
     and bris_issue_year = 2016
     and bris_link_issue_year = 2016
     and bris_issue_week > 30
     and substr(bris_link_issue_year,3,2) != substr(bris_ean, -7,2) order by bris_ean;
   
select distinct bris_branch_code,bris_issue_year,bris_ean,b.bris_link_issue_year,b.bris_link_ean,b.bris_title_code,t.titl_long_name
     from branch_issues b, titles t
     where bris_title_code = titl_code
     and bris_issue_year = 2016
     and bris_link_issue_year = 2015
     and bris_issue_week > 30
     --and substr(bris_link_issue_year,3,2) != substr(bris_ean, -7,2) order by bris_ean;
     
select bris_branch_code,bris_issue_year,bris_ean,b.bris_link_issue_year,b.bris_link_ean from JT_2016_BRIS_YEAR b union all    
select distinct bris_branch_code,bris_issue_year,bris_ean,b.bris_link_issue_year+1,b.bris_link_ean
     from branch_issues b, titles
     where bris_title_code = titl_code
     and bris_issue_year = 2016
     and bris_link_issue_year = 2015
     and bris_issue_week > 30
     
select bris_branch_code,bris_issue_year,bris_ean,b.bris_link_issue_year,b.bris_link_ean, count(*) from JT_2016_BRIS_YEAR b 
group by bris_branch_code,bris_issue_year,bris_ean,b.bris_link_issue_year,b.bris_link_ean having count(*)>1
