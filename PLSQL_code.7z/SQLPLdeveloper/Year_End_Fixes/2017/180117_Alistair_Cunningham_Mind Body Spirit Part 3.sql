select * from normal_issues t
where t.NISS_TITLE_CODE in (58681) order by t.niss_issue_year desc, t.niss_issue_week desc;

select * from branch_issues b
where b.BRIS_TITLE_CODE in (58681)
and b.BRIS_ISSUE_YEAR in (2016,2017) order by b.bris_issue_year desc, b.bris_issue_week desc 
and b.BRIS_ISSUE_WEEK = 52;

drop table
create table  jt_180117_nis_58681 as
select *  from normal_issues n where n.niss_title_code =  58681   and n.niss_issue_year >= 2016 order by n.niss_issue_year desc , n.niss_issue_week desc for update --removed issue no sales 977147786649952 17/01/17

--select * from customer_x_ref x where x.ccr_bus_partner_id = 128665 --502963014272500
create table jt_180117_bris_58681 as
select * from branch_issues b where b.bris_title_code = 58681 and b.bris_issue_year >= 2016 for update --removed issue no sales 977147786649952 17/01/17

select * from jt_180117_bris_58681 b where b.bris_link_ean = 977239978101352
999060540499901
999060540499901
999060540499901
999060540499901
999060540499901



create table jt_160117_bris_977239978101301 as
select * from branch_issues b where b.bris_ean = 977239978101301 for update
create table jt_160117_niss_977239978101301 as
select * from normal_issues n where n.niss_ean = 977239978101301 for update
create table jt_160117_ans_977239978101301 as
select * from agent_net_sales  where net_issue_ean = 977147786648252 and NET_ISSUE_YEAR = 2016
select * from agent_net_sales  where net_issue_ean = 977147786649952 and NET_ISSUE_YEAR = 2016
update agent_net_sales set net_issue_ean =  977239978101301 where net_issue_ean = 977239978101352 and NET_ISSUE_YEAR = 2017
------

insert into agent_net_sales 
select * from agent_net_sales   as of timestamp TO_TIMESTAMP('2017-01-16 08:00:00', 'YYYY-MM-DD HH:MI:SS') 
where net_issue_ean = 977239978101352 and NET_ISSUE_YEAR = 2017
minus
select * from agent_net_sales  
where net_issue_ean = 977239978101352 and NET_ISSUE_YEAR = 2017

---------------
create table test_test as
select * from agent_net_sales a where a.net_issue_ean = 977239978101301 and a.net_issue_year > 2015

select * from test_test

drop table test_test

select * from agent_net_sales a where a.net_title_code = 30300 and a.net_agent_account_number = 502963014272500--a.net_issue_year > 2015

select PIX_SPOKE_CODE,z.* from plant_issues_xref z where z.PIX_LEGACY_TITLE = 4207 and z.PIX_YEAR >= 2016 order by z.PIX_YEAR desc, z.PIX_WEEK desc
select * from plant_issues_xref z where z.PIX_EAN = 977239978101352 and z.PIX_YEAR >= 2016 order by z.PIX_YEAR desc, z.PIX_YEAR desc

update agent_net_sales set net_issue_year = 2016 where net_issue_ean = 977146718778852 and net_issue_year = 2017 and net_agent_account_number != 550997704041500
--------------------------------

select max(x.ccr_bus_partner_id) cust_no,a.bris_branch_code,c.titl_code title,b.niss_issue_day "WEEK DAY",b.niss_issue_week WEEK,b.niss_issue_year YEAR,ag.net_issue_year,b.niss_ean,sum(ag.NET_COMMITED_QUANTITY) sales,sum(ag.NET_COMMITED_QUANTITY - ag.net_credit_quantity) "TOTAL SALES - CREDIT",sum(ag.net_credit_quantity) 
from  agent_net_sales ag, branch_issues a, normal_issues b, titles c,customer_x_ref x where
ag.net_agent_account_number = x.ccr_cust_urn
and a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year

and b.niss_title_code = c.titl_code

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code
and b.niss_title_code = 58681 
and b.niss_issue_year in (2016,2017)
--and b.niss_ean = 977174280705901
--and a.bris_branch_code = 'BRA550'
--and ag.net_agent_account_number = 502963014272500
group by a.bris_branch_code,a.bris_title_code,c.titl_code, b.niss_issue_day,b.niss_issue_week,b.niss_issue_year,b.niss_ean,ag.net_issue_year
order by ag.net_issue_year desc, b.niss_issue_week desc

---------------------------------------------


Buchanie  28/12 title code 4207 missing all date except Newbridge 
