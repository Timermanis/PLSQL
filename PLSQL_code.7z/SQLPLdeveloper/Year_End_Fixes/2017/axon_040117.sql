select * from ARCHIVE.TXT_LOAD_CONTROL t 

create table  jt_TXT_LOAD_CONTROL_axon as
select * from ARCHIVE.TXT_LOAD_CONTROL t where t.tlc_type = 'CRU_DATA' order by t.tlc_run_num desc
delete from ARCHIVE.TXT_LOAD_CONTROL t where t.tlc_run_num = 83

create table  jt_txt_axon_cru_data_bak_axon as
select * from archive.txt_axon_cru_data_bak a where a.etl_run_num_seq = 83 order by a.yearwk desc
delete from archive.txt_axon_cru_data_bak a where a.etl_run_num_seq = 83

create table  jt_axon_stats_axon as
select * from dw.axon_stats x  order by  x.PF_RUN_NUM desc
delete from dw.axon_stats x   where x.pf_run_num = 83
