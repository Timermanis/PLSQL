--502963009726100
MERGE INTO agent_net_sales a
    USING (SELECT * FROM agent_net_sales b WHERE b.net_issue_year = 2017 and b.net_issue_ean = &ean) h
    ON (a.net_agent_account_number = h.net_agent_account_number and a.net_issue_ean = h.net_issue_ean and a.net_issue_year + 1 = h.net_issue_year)
  WHEN MATCHED THEN
    UPDATE SET 
               a.net_box_out_quantity = a.net_box_out_quantity + h.net_box_out_quantity,
               a.NET_CREDIT_QUANTITY = a.NET_CREDIT_QUANTITY + h.NET_CREDIT_QUANTITY,
               a.NET_OTHER_SALES_QUANTITY = a.NET_OTHER_SALES_QUANTITY + h.NET_OTHER_SALES_QUANTITY,
               a.net_commited_quantity = a.net_commited_quantity + h.net_commited_quantity,
               a.NET_CASUAL_QUANTITY = a.NET_CASUAL_QUANTITY + h.NET_CASUAL_QUANTITY,
               a.NET_RETURN_QUANTITY = a.NET_RETURN_QUANTITY + h.NET_RETURN_QUANTITY
  --  DELETE where a.net_agent_account_number = h.net_agent_account_number and a.net_issue_ean = h.net_issue_ean and a.net_issue_year = 2017

  WHEN NOT MATCHED THEN
    insert (
    a.NET_AGENT_ACCOUNT_NUMBER,
a.NET_ISSUE_EAN,
a.NET_ISSUE_YEAR,
a.NET_BOX_OUT_QUANTITY,
a.NET_CREDIT_QUANTITY,
a.NET_OTHER_SALES_QUANTITY,
a.NET_COMMITED_QUANTITY,
a.NET_CASUAL_QUANTITY,
a.NET_RETURN_QUANTITY,
a.NET_NOTE_KEYED_FLAG,
a.NET_CTB_FLAG,
a.NET_BRANCH_CODE,
a.NET_BOX_NUMBER,
a.NET_MULTIPLE_CODE,
a.NET_MULTIPLE_GRADE_CODE,
a.NET_ANMW_CODE,
a.NET_RETAILER_BAND,
a.NET_POSTCODE_OUTER,
a.NET_PUBLISHER_CODE,
a.NET_TITLE_CODE
    )

VALUES ( h.NET_AGENT_ACCOUNT_NUMBER,
h.NET_ISSUE_EAN,
2016,
h.NET_BOX_OUT_QUANTITY,
h.NET_CREDIT_QUANTITY,
h.NET_OTHER_SALES_QUANTITY,
h.NET_COMMITED_QUANTITY,
h.NET_CASUAL_QUANTITY,
h.NET_RETURN_QUANTITY,
h.NET_NOTE_KEYED_FLAG,
h.NET_CTB_FLAG,
h.NET_BRANCH_CODE,
h.NET_BOX_NUMBER,
h.NET_MULTIPLE_CODE,
h.NET_MULTIPLE_GRADE_CODE,
h.NET_ANMW_CODE,
h.NET_RETAILER_BAND,
h.NET_POSTCODE_OUTER,
h.NET_PUBLISHER_CODE,
h.NET_TITLE_CODE);

delete from agent_net_sales a where a.net_issue_ean = &ean and a.net_issue_year = 2017;
