select * from agent_net_sales a, branch_issues b where 
a.net_issue_ean = b.bris_ean and
a.net_issue_year = b.bris_issue_year and 
a.net_branch_code = b.bris_branch_code and

a.net_agent_account_number = 502963007739300 and a.net_title_code = 32602 and a.net_issue_year = 2016 and b.bris_title_code = 32602  and b.bris_issue_week = 52 
union all


select * from agent_net_sales a, branch_issues b where 
a.net_issue_ean = b.bris_ean and
a.net_issue_year = b.bris_issue_year and 
a.net_branch_code = b.bris_branch_code and

a.net_agent_account_number = 502963007739300 and a.net_title_code = 32602 and a.net_issue_year = 2017 and b.bris_title_code = 32602  --and b.bris_issue_week = 51 
and b.bris_issue_day = 6

select * from plant_issues_xref x where x.PIX_LEGACY_EAN = 10326021651601

select * from branch_issues b where b.bris_ean = 10326021652601

create table jt_10326021652601_year_040116 as
update agent_net_sales set net_issue_year = 2016 where net_issue_ean = 10326021652601 and net_issue_year = 2017 and net_agent_account_number != 550997704041500



select * from agent_net_sales a, agent_net_sales n where a.net_agent_account_number = n.net_agent_account_number and a.net_issue_ean = n.net_issue_ean 
and a.net_issue_year != n.net_issue_year and a.net_issue_ean = 10326021652601 for update


select * from agent_net_sales a where a.net_issue_ean = 10326021652601 and a.net_agent_account_number = 550997704041500 for update

select * from normal_issues n where n.niss_ean = 10326021652601 for update
------------------------------------------
select * from branch_issues b where b.bris_ean = 977204039311452 for update
select * from normal_issues n where n.niss_ean = 977204039311452 for update
select * from agent_net_sales a where a.net_issue_ean = 977204039311452 and a.net_issue_year > 2015

create table jt_10326021652601_year_040116 as
update agent_net_sales set net_issue_year = 2016 where net_issue_ean = 977204039311452 and net_issue_year = 2017 and net_agent_account_number != 550997704041500
select * from agent_net_sales where net_issue_ean = 977204039311452 and net_issue_year = 2017 


insert into archive.zpx_cus_dtls_stg_bak
select *
from agent_net_sales as of timestamp TO_TIMESTAMP('2017-01-13 06:30:00', 'YYYY-MM-DD HH:MI:SS') minus
select *
from agent_net_sales as of timestamp TO_TIMESTAMP('2015-04-27 12:30:00', 'YYYY-MM-DD HH:MI:SS')

create table jt_977204039311452_year_130117 as
select * from agent_net_sales as of timestamp TO_TIMESTAMP('2017-01-13 06:30:00', 'YYYY-MM-DD HH:MI:SS') where net_issue_ean = 977204039311452 and net_issue_year = 2017 
