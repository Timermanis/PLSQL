create table jt_010117_bi_bkp as
select * from branch_issues b where b.bris_ean = 010326021652601 for update

select * from agent_net_sales a where a.net_issue_ean = 010326021652601

create table jt_010117_all_iss_bkp as
select * from all_issues i where i.issu_ean = 010326021652601 for update

create table jt_010117_norm_iss_bkp as
select * from normal_issues n where n.niss_ean = 010326021652601 for update

select * from plant_issues_xref x where x.PIX_EAN = 010326021652601
---------------------
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 977135496420152 and b.bris_issue_year = 2016 for update

create table jt_010117_ans_bkp as
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 977135496420152
select * from agent_net_sales a where a.net_issue_ean = 977135496420152

insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 977135496420152 and i.issu_issue_year =2016 for update

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 977135496420152 and n.niss_issue_year = 2016 for update

select * from plant_issues_xref x where x.PIX_EAN = 977135496420152

---------------------
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 977136934801052  for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 977136934801052 and a.net_issue_year =2016
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 977136934801052 and net_issue_year =2016
select * from agent_net_sales a where a.net_issue_ean = 977136934801052 and a.net_issue_year =2016

insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 977136934801052 for update

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 977136934801052  for update

select * from plant_issues_xref x where x.PIX_EAN = 977136934801052

---------------------
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 977136934801052 and b.bris_issue_year = 2016 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 977136934801052 and a.net_issue_year =2016
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 977136934801052 and net_issue_year =2016
select * from agent_net_sales a where a.net_issue_ean = 977136934801052 and a.net_issue_year =2016

insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 977136934801052 and i.issu_issue_year =2016 for update

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 977136934801052 and n.niss_issue_year = 2016 for update


select * from plant_issues_xref x where x.PIX_EAN = 977136934801052
select * from jt_010117_all_iss_bkp

---------------------
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 010326021652601 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 010326021652601 and a.net_issue_year =2016
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 010326021652601 and net_issue_year =2016
select * from agent_net_sales a where a.net_issue_ean = 010326021652601 and a.net_issue_year =2016

insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 010326021652601 for update

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 010326021652601 for update
----BRA550------10339511652501--050117--10403201652601
create table jt_010117_bi_bkp as
select * from branch_issues b where b.bris_ean = 10339511652501 for update

select * from agent_net_sales a where a.net_issue_ean = 10339511652501

create table jt_010117_all_iss_bkp as
select * from all_issues i where i.issu_ean = 10339511652501 for update

create table jt_010117_norm_iss_bkp as
select * from normal_issues n where n.niss_ean = 10339511652501 for update

select * from plant_issues_xref x where x.PIX_EAN = 10339511652501
----------------------------
select * from branch_issues b where b.bris_ean = 10403201652601 for update

select * from agent_net_sales a where a.net_issue_ean = 10403201652601

create table jt_010117_all_iss_bkp as
select * from all_issues i where i.issu_ean = 10403201652601 for update

create table jt_010117_norm_iss_bkp as
select * from normal_issues n where n.niss_ean = 10403201652601 for update

select * from plant_issues_xref x where x.PIX_EAN = 10403201652601
--10339361652501
select * from branch_issues b where b.bris_ean = 10339361652501 for update

select * from agent_net_sales a where a.net_issue_ean = 10339361652501

create table jt_010117_all_iss_bkp as
select * from all_issues i where i.issu_ean = 10339361652501 for update

create table jt_010117_norm_iss_bkp as
select * from normal_issues n where n.niss_ean = 10339361652501 for update

select * from plant_issues_xref x where x.PIX_EAN = 10339361652501
--10007221652501--060117
select * from branch_issues b where b.bris_ean = 10007221652501 for update

select * from agent_net_sales a where a.net_issue_ean = 10007221652501

create table jt_010117_all_iss_bkp as
select * from all_issues i where i.issu_ean = 10007221652501 for update

create table jt_010117_norm_iss_bkp as
select * from normal_issues n where n.niss_ean = 10007221652501 for update

select * from plant_issues_xref x where x.PIX_EAN = 10007221652501
--030376721701001
select * from branch_issues b where b.bris_ean = 030376721701001 for update

select * from agent_net_sales a where a.net_issue_ean = 030376721701001

create table jt_010117_all_iss_bkp as
select * from all_issues i where i.issu_ean = 030376721701001 for update

create table jt_010117_norm_iss_bkp as
select * from normal_issues n where n.niss_ean = 030376721701001 for update

select * from plant_issues_xref x where x.PIX_EAN = 030376721701001
--BRA390--------050117
select * from branch_issues b where b.bris_ean = 10271221652501 for update

select * from agent_net_sales a where a.net_issue_ean = 10271221652501

create table jt_010117_all_iss_bkp as
select * from all_issues i where i.issu_ean = 10271221652501 for update

create table jt_010117_norm_iss_bkp as
select * from normal_issues n where n.niss_ean = 10271221652501 for update

select * from plant_issues_xref x where x.PIX_EAN = 10271221652501


---------------------020112--------------------------------------------------------------------------------------
--BRA740
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 10908001652601 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 10908001652601 and a.net_issue_year =2016
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 10908001652601 and net_issue_year =2016
select * from agent_net_sales a where a.net_issue_ean = 10908001652601 and a.net_issue_year =2016

insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 10908001652601 for update --90800

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 10908001652601 for update

select * from plant_issues_xref x where x.PIX_EAN = 010326021652601--32602
select * from plant_issues_xref x where x.PIX_LEGACY_TITLE = 90800
select * from jt_010117_all_iss_bkp
select * from titles c where c.titl_code in (90800,32602)

--10002851652601
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 10002851652601 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 10002851652601 and a.net_issue_year =2016
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 10002851652601 and net_issue_year =2016
select * from agent_net_sales a where a.net_issue_ean = 10002851652601 and a.net_issue_year =2016

insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 10002851652601 for update --90800

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 10002851652601 for update

select * from plant_issues_xref x where x.PIX_EAN = 10002851652601

--10908031652601
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 10908031652601 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 10908031652601 and a.net_issue_year =2016
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 10908031652601 and net_issue_year =2016
select * from agent_net_sales a where a.net_issue_ean = 10908031652601 and a.net_issue_year =2016

insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 10908031652601 for update --90800

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 10908031652601 for update

select * from plant_issues_xref x where x.PIX_EAN = 10908031652601
/*977204039311452
010403191652601
010004461652501
010132091652501
010222961652601
010002001652501
010219241652601
010403201652601
010222971652601
010223131652601
010096491652601
010096501652601
010908041652601
010001801652501
010162091652601
010001281652601
010096481652601
010002541652601
010006031652501
010222821652601
010378311652601
010002861652501
010004561652601
010908061652601
*/

select * from branch_issues b where b.bris_ean = 977204039311452 for update

select * from all_issues i where i.issu_ean = 977204039311452 for update 

select * from plant_issues_xref x where x.PIX_EAN = 977204039311452

--BRA350    010004561652501
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 010004561652501 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 010004561652501 and a.net_issue_year =2016
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 010004561652501 and net_issue_year =2016
select * from agent_net_sales a where a.net_issue_ean = 010004561652501 and a.net_issue_year =2016

insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 010004561652501 for update --90800

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 010004561652501 for update

select * from plant_issues_xref x where x.PIX_EAN = 10560511652601--010004561652501--32602
--010005181652501
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 010005181652501 for update--inserted brand new issue in 220

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 010005181652501 and a.net_issue_year =2016
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 010005181652501 and net_issue_year =2016
select * from agent_net_sales a where a.net_issue_ean = 010005181652501 and a.net_issue_year =2016

insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 010005181652501 for update --

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 010005181652501 for update

select * from plant_issues_xref x where x.PIX_EAN = 010005181652501--
--010560511652601
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 010560511652601 for update--inserted brand new issue for 220

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 010560511652601 and a.net_issue_year =2016
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 010560511652601 and net_issue_year =2016
select * from agent_net_sales a where a.net_issue_ean = 010560511652601 and a.net_issue_year =2016

insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 010560511652601 for update --

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 010560511652601 for update

select * from plant_issues_xref x where x.PIX_EAN = 010560511652601--
--BRA220 10910331652601
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 10910331652601 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 10910331652601 and a.net_issue_year =2016
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 10910331652601 and net_issue_year =2016
select * from agent_net_sales a where a.net_issue_ean = 10910331652601 and a.net_issue_year =2016

insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 10910331652601 for update --

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 10910331652601 for update

select * from plant_issues_xref x where x.PIX_EAN = 10910331652601--
/*010910271652601--
010910281652601--
010910301652601--
010910361652601--
010910321652601
*/
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 010910321652601 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 010910281652601 and a.net_issue_year =2016
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 010910281652601 and net_issue_year =2016


insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 010910321652601 for update --

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 010910281652601 for update

select * from plant_issues_xref x where x.PIX_EAN = 010910321652601--
--BRA550

10003701652501
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 10003701652501 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 10003701652501 and a.net_issue_year =2017 and a.net_branch_code = 'BRA550'
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 10003701652501 and net_issue_year =2016


insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 10003701652501 for update --

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 10003701652501 for update

select * from plant_issues_xref x where x.PIX_EAN = 10003701652501--
-------------------------------------------------120117-----------550
select * from branch_issues b where b.bris_ean = 10002191652501 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 10002191652501 and a.net_issue_year =2017 and a.net_branch_code = 'BRA550'
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 10002191652501 and net_issue_year =2016


insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 10002191652501 for update --

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 10002191652501 for update

select * from plant_issues_xref x where x.PIX_EAN = 10002191652501--
-------------------------------------------------120117-----------220
select * from branch_issues b where b.bris_ean = 977205685301501 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 977205685301501 and a.net_issue_year =2017 and a.net_branch_code = 'BRA550'
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 977205685301501 and net_issue_year =2016


insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 977205685301501 for update --

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 977205685301501 for update

select * from plant_issues_xref x where x.PIX_EAN = 977205685301501--

977205685301501

-----------------------------------------------------------------------------------040117-----
--BRA740
insert into jt_010117_bi_bkp 
select * from branch_issues b where b.bris_ean = 10907971652501 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 10907971652501 and a.net_issue_year =2016 and a.net_branch_code = 'BRA740'
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 10907971652501 and net_issue_year =2016


insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 10907971652501 for update --

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 10907971652501 for update

select * from plant_issues_xref x where x.PIX_EAN = 10907971652501
-----------------------------------------099117-----------------------------------------------
--BRA220
977205972300102
select * from branch_issues b where b.bris_ean = 977205972300102 for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 977205972300102 and a.net_issue_year =2017 and a.net_branch_code = 'BRA740'
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 977205972300102 and net_issue_year =2016


insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 977205972300102 for update --

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 977205972300102 for update

select * from plant_issues_xref x where x.PIX_EAN = 977205972300102

select * from plant_issues_xref x where x.PIX_SAP_ID = '000000000493830003'

select * from titles t where t.titl_code = 49383
--------------------------------------150117----
977205673900501
select * from branch_issues b where b.bris_ean = 977205673900501 and b.bris_branch_code = 'BRA220' for update

insert into  jt_010117_ans_bkp 
select * from agent_net_sales a where a.net_issue_ean = 977205673900501 and a.net_issue_year =2017 and a.net_branch_code = 'BRA740'
update  agent_net_sales set NET_ISSUE_YEAR = 2017 where net_issue_ean = 977205673900501 and net_issue_year =2016


insert into  jt_010117_all_iss_bkp 
select * from all_issues i where i.issu_ean = 977205673900501 for update --

insert into  jt_010117_norm_iss_bkp 
select * from normal_issues n where n.niss_ean = 977205673900501 for update

select * from plant_issues_xref x where x.PIX_EAN = 977205673900501

select * from plant_issues_xref x where x.PIX_SAP_ID = '977205673900501'

select * from titles t where t.titl_code = 
