select * from titles t where t.titl_code = 21848

select *  from branch_issues b where b.bris_title_code =  21848   and BRIS_BRANCH_CODE = 'BRA740' and b.bris_issue_year >= 2016 order by b.bris_issue_year desc, b.bris_issue_week desc,BRIS_ISSUE_DAY desc;-- for update;
select *  from normal_issues n where n.niss_title_code =  21848   and n.niss_issue_year >= 2016 order by n.niss_issue_year desc, n.niss_issue_week desc for update
10218481652501
10218481652601

select * from customer_x_ref x where x.ccr_bus_partner_id = 0000128535 --502963014272500

select *  from branch_issues b where b.bris_title_code =  4759  and b.bris_issue_year >= 2016 order by b.bris_issue_year desc, b.bris_issue_week desc for update

select * from branch_issues b where b.bris_ean  = 10218481701601--niss 10218481701601
select * from normal_issues n where n.niss_ean  = 10218481652601

10218481701601
select * from agent_net_sales a where  net_issue_ean = 10218481701601 and net_issue_year = 2017 and NET_AGENT_ACCOUNT_NUMBER = 502963023666000 for update
select * from agent_net_sales a where  net_issue_ean = 977096314906101 and net_issue_year = 2017 and NET_AGENT_ACCOUNT_NUMBER = 502963009263100 



select a.bris_branch_code,c.titl_code title,b.niss_issue_day "WEEK DAY",b.niss_issue_week WEEK,b.niss_issue_year niss_YEAR,ag.net_issue_year,max(a.bris_on_sale_date),b.niss_ean,sum(ag.NET_COMMITED_QUANTITY) sales,sum(ag.NET_COMMITED_QUANTITY - ag.net_credit_quantity) "TOTAL SALES - CREDIT",sum(ag.net_credit_quantity) 
from  agent_net_sales ag, branch_issues a, normal_issues b, titles c,customer_x_ref x where
ag.net_agent_account_number = x.ccr_cust_urn
and a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year

and b.niss_title_code = c.titl_code

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code
and b.niss_title_code = 21848 
and b.niss_issue_year in (2016,2017)
--and b.niss_ean = 977174280705901
and a.bris_branch_code = 'BRA740'
--and ag.net_agent_account_number = 502963014272500
group by a.bris_branch_code,a.bris_title_code,c.titl_code, b.niss_issue_day,b.niss_issue_week,b.niss_issue_year,b.niss_ean,ag.net_issue_year
order by ag.net_issue_year desc, b.niss_issue_week desc, b.niss_issue_day desc

---------------------------------------------
--delete from agent_net_sales a  where  net_issue_ean = 977135460989852 and net_issue_year = 2017 and NET_AGENT_ACCOUNT_NUMBER = 502963009263100


Hawick News 31/12 title code 4759 missing all data except Linwood
