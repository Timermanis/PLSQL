select * from customers c where c.cus_account_number in 
(503103100659900,
503103124131000,
502963099536900,
503103124136500,
503103124135800,
503103124133400,
503103121464200,
503103124763301,
503103124146400
) and c.cus_to_date > sysdate

update customers c set c.cus_box_number = (select get_box_number(220) from dual) and c.cus_branch_code = 'BRA220' where
c.cus_account_number in 
(503103100659900,
503103124131000,
502963099536900,
503103124136500,
503103124135800,
503103124133400,
503103121464200,
503103124763301,
503103124146400
) and c.cus_to_date > sysdate


SELECT branch_code, MIN(box_number)
                                      FROM new_box_numbers
                                     WHERE branch_code=220
                                     group by branch_code
                                     
                                     
update customers c set c.cus_box_number = (select get_box_number(220) from dual),  c.cus_branch_code = 'BRA220' where
c.cus_account_number in 
(--503103100659900
--503103124131000
--502963099536900
--503103124136500
--503103124135800
--503103124133400
--503103121464200
--503103124763301
503103124146400
) and c.cus_to_date > sysdate


select * from customers c where
c.cus_account_number in 
(503103100659900,
503103124131000,
502963099536900,
503103124136500,
503103124135800,
503103124133400,
503103121464200,
503103124763301,
503103124146400
) and c.cus_to_date > sysdate and c.cus_branch_code = 'BRA220'
