with a
as
(SELECT CUS_BRANCH_CODE, CUS_BOX_NUMBER, COUNT(*)
from customers c
where c.cus_to_date = '31-DEC-4000' and c.cus_account_status != 3
group by CUS_BRANCH_CODE, CUS_BOX_NUMBER
having count(*) > 1
)

select *
from a, customers c
where a.cus_branch_code = c.cus_branch_code
and a.cus_box_number = c.cus_box_number
and c.cus_to_date = '31-DEC-4000'


select * from agent_net_sales a where a.net_agent_account_number = 503103107408602 and a.net_issue_year = 2017
select max(a.net_issue_year) from agent_net_sales a where a.net_agent_account_number = 740998897041200

create table jt_260117_cus_bkp as
select * from customers c where c.cus_account_number in 
(503103117897510,
502963006755400,
560138785000100,
560138786000000,
560138789000700
)

delete from customers c where c.cus_account_number in 
(503103117897510,
502963006755400,
560138785000100,
560138786000000,
560138789000700
)

with a
as
(SELECT CUS_BRANCH_CODE, CUS_BOX_NUMBER, COUNT(*)
from customers c
where c.cus_to_date = '31-DEC-4000'
group by CUS_BRANCH_CODE, CUS_BOX_NUMBER
having count(*) > 1
)

select *
from a, customers c
where a.cus_branch_code = c.cus_branch_code
and a.cus_box_number = c.cus_box_number
and c.cus_to_date = '31-DEC-4000'

select * from customers c where c.cus_account_number in 
(740998897041200,
503103107408602,
502963050870504
) and c.cus_to_date = '31-DEC-4000'

select * from customer_x_ref x where x.ccr_cust_urn in 
(740998897041200,
503103107408602,
502963050870504
)

create table jt_260117_cus_2d_bkp as
select * from customers c where c.cus_account_number in 
(740998897041200,
502963050870504
) and c.cus_to_date = '31-DEC-4000'

update customers c set c.cus_account_status = 3 where c.cus_account_number in 
(740998897041200,
502963050870504
) and c.cus_to_date = '31-DEC-4000'

