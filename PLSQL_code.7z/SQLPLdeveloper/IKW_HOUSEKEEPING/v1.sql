--Create driver tables
create index jt_backup_MEDIA_index on jt_backup_MEDIA(plis_issue_num)--recreate for every run
create index jt_backup_MEDIA_index1 on jt_backup_MEDIA(plis_id)


create table jt_backup_MEDIA
as select * from  dw.MEDIA w
where  w.iss_type_code in ('Z5','Z7','Z8')
and to_char (iss_partitioning_date,'yyyy')=2009
rename jt_backup_MEDIA to jt_backup_MEDIA_set1 --rename before next run

----
create table jt_backup_MEDIA_set2
as select * from  dw.MEDIA w
where  w.iss_type_code in ('Z5','Z7','Z8')
and PLIS_BRANCH_NUM = '220'
rename table jt_backup_MEDIA to jt_backup_MEDIA_set2--rename before next run
----
create table jt_backup_MEDIA_set3
as select * from  dw.MEDIA w
where  w.iss_type_code in ('Z5','Z7','Z8')
and PLIS_BRANCH_NUM in (790,850)
rename table jt_backup_MEDIA to jt_backup_MEDIA_set3--rename before next run
----create table jt_backup_MEDIA_set1
create table jt_backup_MEDIA_set4
as select * from  dw.MEDIA w
where  w.iss_type_code in ('Z5','Z7','Z8')
and PLIS_BRANCH_NUM in (550,310)
rename table jt_backup_MEDIA to jt_backup_MEDIA_set4--rename before next run
----create table jt_backup_MEDIA_set1
create table jt_backup_MEDIA_set5
as select * from  dw.MEDIA w
where  w.iss_type_code in ('Z5','Z7','Z8')
and PLIS_BRANCH_NUM in (120,320)
rename table jt_backup_MEDIA to jt_backup_MEDIA_set5--rename before next run
----create table jt_backup_MEDIA_set1
create table jt_backup_MEDIA_set6
as select * from  dw.MEDIA w
where  w.iss_type_code in ('Z5','Z7','Z8')
and PLIS_BRANCH_NUM in (020,340) or PLIS_BRANCH_NUM is null
rename table jt_backup_MEDIA to jt_backup_MEDIA_set6--rename before next run
----create table jt_backup_MEDIA_set1
create table jt_backup_MEDIA_set7
as select * from  dw.MEDIA w
where  w.iss_type_code in ('Z5','Z7','Z8')
and PLIS_BRANCH_NUM in 
(350,
610,
270,
280,
90,
390,
680,
590,
740
)
rename table jt_backup_MEDIA to jt_backup_MEDIA_set7--rename before next run
----

--1----------------------------------MEDIA


create table jt_4000_MEDIA as select * from jt_backup_MEDIA; --235m

update jt_4000_MEDIA r set r.iss_partitioning_date = to_date('31/12/4000','dd/mm/yyyy')

delete from dw.MEDIA r where r.dimension_key in (select dimension_key from jt_4000_MEDIA)

insert into dw.MEDIA r select * from jt_4000_MEDIA
--2---------------------------------PLANT_CUST_ISS_RTRN_SUMMARIES
create table jt_backup_cus_iss_sum 
as select unique i.* from  dw.PLANT_CUST_ISS_RTRN_SUMMARIES i,jt_backup_MEDIA w --80123rec  22.11min
where i.plis_issue_num = w.plis_issue_num

create table jt_4000_cus_iss_sum as select * from jt_backup_cus_iss_sum  --46s

update jt_4000_cus_iss_sum r set r.partitioning_date = to_date('31/12/4000','dd/mm/yyyy') --2.39m

delete from dw.PLANT_CUST_ISS_RTRN_SUMMARIES r where (r.out_num,r.PLIS_ISSUE_NUM) in (select out_num,PLIS_ISSUE_NUM from jt_4000_cus_iss_sum)

insert into dw.PLANT_CUST_ISS_RTRN_SUMMARIES r select * from jt_4000_cus_iss_sum

select PF_RUN_NUM,count(*) from jt_4000_cus_iss_sum group by PF_RUN_NUM
select count(*) from jt_4000_cus_iss_sum 
--3--------------------------------RTRN
create table jt_backup_RT
as select r.* from dw.RETAILER_TRANSACTION r, jt_backup_MEDIA w --9.33min
where  r.plant_issue_id=w.plis_id


create table jt_4000_RT as select * from jt_backup_RT

update jt_4000_RT r set r.partitioning_date = to_date('31/12/4000','dd/mm/yyyy')

delete from dw.RETAILER_TRANSACTION r where DWH_NUM in (select DWH_NUM from jt_4000_RT)

insert into dw.RETAILER_TRANSACTION r select * from jt_4000_RT 

--4-----------------------------ISSUES
update  refmast.issues i set ISS_PARTITIONING_DATE = to_date('31/12/4000','dd/mm/yyyy') where exists
(select * from ISSUES i,jt_backup_MEDIA w
where i.iss_num=w.plis_issue_num
)


--5----------------------------------MULT_RTRN_SUM
create table jt_backup_MULT_RTRN_SUM
as select unique i.* from  dw.PLANT_MULT_ISS_RTRN_SUMMARIES i,jt_backup_MEDIA w 
where i.plis_issue_num = w.plis_issue_num


create table jt_4000_MULT_RTRN_SUM as select * from jt_backup_MULT_RTRN_SUM

update jt_4000_MULT_RTRN_SUM r set r.partitioning_date = to_date('31/12/4000','dd/mm/yyyy')

delete from dw.PLANT_MULT_ISS_RTRN_SUMMARIES r where (r.MULT_NUM,r.plis_issue_num,r.cus_plant_num) in (select MULT_NUM,plis_issue_num,cus_plant_num from jt_4000_MULT_RTRN_SUM)

insert into dw.PLANT_MULT_ISS_RTRN_SUMMARIES r select * from jt_4000_MULT_RTRN_SUM


--6----------------------------------------------------------stock_transaction
create table jt_backup_stock_tran
as select unique i.* from  dw.STOCK_TRANSACTION i,jt_backup_MEDIA w 
where i.PLANT_ISSUE_ID = w.plis_id



delete from dw.STOCK_TRANSACTION r where (r.SRC_DOCUMENT_NUM,r.SRC_ITEM_NUM) in (select SRC_DOCUMENT_NUM,SRC_ITEM_NUM from jt_backup_stock_tran)

insert into dw.STOCK_TRANSACTION r select * from jt_backup_stock_tran
--7----------------------------------------------------------vendor_transaction
create table jt_backup_vendor_tran
as select unique i.* from  dw.VENDOR_TRANSACTION i,jt_backup_MEDIA w 
where i.PLANT_ISSUE_ID = w.plis_id



delete from dw.VENDOR_TRANSACTION r where (r.SRC_DOCUMENT_NUM,r.SRC_ITEM_NUM) in (select SRC_DOCUMENT_NUM,SRC_ITEM_NUM from jt_backup_vendor_tran)

insert into dw.VENDOR_TRANSACTION r select * from jt_backup_vendor_tran
--8----------------------------------------------------------refstg.retailer_transactions_cc 
create table jt_backup_REF_RTRN_CC
as select unique i.* from  refstg.RETAILER_TRANSACTIONS_CC i,jt_backup_MEDIA w--RTRN_TRANS_PLANT_NUM, RTRN_ISSUE_NUM RETAILER_TRANSACTIONS_CC
where i.RTRN_TRANS_PLANT_NUM = w.PLIS_PLANT_NUM
and i.RTRN_ISSUE_NUM = w.plis_issue_num



delete from refstg.RETAILER_TRANSACTIONS_CC r where (r.RTRN_TRANS_PLANT_NUM,r.RTRN_ISSUE_NUM) in (select RTRN_TRANS_PLANT_NUM,RTRN_ISSUE_NUM from jt_backup_REF_RTRN_CC)


--9-------------------------------------------------------refstg.stock_transactions_cc
create table jt_backup_REF_STRN_CC
as select unique i.* from  refstg.STOCK_TRANSACTIONS_CC i,jt_backup_MEDIA w--RTRN_TRANS_PLANT_NUM, RTRN_ISSUE_NUM RETAILER_TRANSACTIONS_CC
where i.STRN_SPOKE_NUM = w.PLIS_PLANT_NUM
and i.STRN_ISSUE_NUM = w.PLIS_ISSUE_NUM

select * from jt_backup_REF_STRN_CC

delete from refstg.STOCK_TRANSACTIONS_CC r where (r.STRN_SPOKE_NUM,r.sTRN_ISSUE_NUM) in (select STRN_SPOKE_NUM,RTRN_ISSUE_NUM from jt_backup_REF_RTRN_CC)



--10----------------------------------------------------refstg.vendor_transactions_cc
create table jt_backup_REF_vTRN_CC
as select unique i.* from  refstg.VENDOR_TRANSACTIONS_CC i,jt_backup_MEDIA w--RTRN_TRANS_PLANT_NUM, RTRN_ISSUE_NUM RETAILER_TRANSACTIONS_CC
where i.VTRN_SPOKE_NUM = w.PLIS_PLANT_NUM
and i.VTRN_ISSUE_NUM = w.PLIS_ISSUE_NUM

select * from jt_backup_REF_vTRN_CC

delete from refstg.VENDOR_TRANSACTIONS_CC r where (r.vTRN_SPOKE_NUM,r.vTRN_ISSUE_NUM) in (select vTRN_SPOKE_NUM,vTRN_ISSUE_NUM from jt_backup_REF_RTRN_CC)







