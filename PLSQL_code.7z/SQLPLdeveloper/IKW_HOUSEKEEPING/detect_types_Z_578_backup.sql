select t.iss_name,t.iss_partitioning_date from dw.media t where t.iss_type_code = 'Z8'
select * from dw.media t where t.iss_type_code = 'Z7'
select * from dw.retailer_transaction t where t.iss_type_code = 'Z8'

select trunc(r.partitioning_date,'yyyy'),count(*) from dw.retailer_transaction r, media w
where r.plant_issue_id=w.plis_id
and w.iss_type_code = 'Z8'
group by trunc(r.partitioning_date,'yyyy')
2	01/01/2010	21607
1	01/01/2012	8578
3	01/01/2013	620
5	01/01/2014	17698
4	01/01/2015	60
------------------------------------------------------




select r.*,w.plis_plant_num,w.plis_branch_num,w.iss_name from dw.retailer_transaction r, media w, calendar c
where r.plant_issue_id=w.plis_id
and c.day_id = r.day_id
and c.day_dte - r.partitioning_date >728
and w.iss_type_code in ('MO')
----------------------------------
select r.* from dw.retailer_transaction r, dw.media w
where  r.plant_issue_id=w.plis_id
and w.iss_type_code in ('MO')

