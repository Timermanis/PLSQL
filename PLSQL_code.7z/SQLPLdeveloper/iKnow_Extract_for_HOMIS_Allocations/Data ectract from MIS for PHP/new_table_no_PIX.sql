select x.pix_main_legacy_title,a.bris_issue_day day,a.bris_issue_week WEEK,a.bris_issue_year YEAR,sum(ag.NET_COMMITED_QUANTITY) sales,sum(ag.net_return_quantity) returns, sum(ag.NET_COMMITED_QUANTITY - ag.net_return_quantity) total  
from  agent_net_sales ag, branch_issues a, titles c,jt_pix_main_legacy_titles x 
where

a.bris_title_code = c.titl_code
and x.PIX_LEGACY_TITLE = c.titl_code
and a.bris_title_code = x.pix_legacy_title

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code

-----------------------
and x.pix_legacy_title in (select unique x.PIX_LEGACY_TITLE from jt_pix_main_legacy_titles x where x.PIX_MAIN_LEGACY_TITLE in 
(select y.PIX_MAIN_LEGACY_TITLE from plant_issues_xref y where y.PIX_LEGACY_TITLE = 90976))
and a.bris_issue_year = 2015
group by x.pix_main_legacy_title ,a.bris_issue_day ,a.bris_issue_week ,a.bris_issue_year 
order by a.bris_issue_year,a.bris_issue_week
