select r.out_hub_num branch, R.OUT_NUM, r.out_urn urn, m.iss_ean, m.iss_original_year, m.iss_original_week, m.iss_official_on_sale_date, w.bra_ana_num,  sum(p.invoiced_QTY) invoiced_qty, sum(p.credit_QTY) crdit_qty,
sum(p.return_QTY) return_qty,sum(p.invoiced_QTY) - sum(p.return_QTY) 
from dw.plant_cust_iss_rtrn_summaries p
, dw.retailer r
, dw.media m
, dw.latest_wholesaler_mv w
where p.plis_issue_num IN (000000000368310006)
and p.plant_issue_id = m.dimension_key
and p.outlet_id = r.dimension_key
and r.out_spoke_num = w.spo_num
--and r.out_hub_num  = 740
--and R.OUT_NUM = 124996
group by r.out_hub_num, R.OUT_NUM,r.out_urn,m.iss_ean, m.iss_original_year, m.iss_original_week, m.iss_official_on_sale_date, w.bra_ana_num


select * from refmast.plant_issues_xref_base x where x.pix_ean = 977204202701703
 and x.pix_year = 2016

select m.prod_num,r.out_hub_num branch, R.OUT_NUM,r.out_name, r.out_urn urn, m.iss_ean, m.iss_original_year, m.iss_original_week, m.iss_official_on_sale_date, w.bra_ana_num,  sum(p.invoiced_QTY) invoiced_qty, sum(p.credit_QTY) crdit_qty,
sum(p.return_QTY) return_qty
from dw.plant_cust_iss_rtrn_summaries p
, dw.retailer r
, dw.media m
, dw.latest_wholesaler_mv w
where --p.plis_issue_num IN(000000000492980007)
--and 
p.plant_issue_id = m.dimension_key
and p.outlet_id = r.dimension_key
and r.out_spoke_num = w.spo_num
and m.prod_num = 9019
and m.iss_original_year = 2016
and m.iss_original_week in (10)
and R.OUT_NUM = 144609
--and r.out_num = 77220
group by r.out_hub_num, R.OUT_NUM,r.out_urn,m.iss_ean, m.iss_original_year, m.iss_original_week, m.iss_official_on_sale_date, w.bra_ana_num, m.prod_num,r.out_name


000000000383660024
000000000385970007
000000000376780031
000000000383640034
