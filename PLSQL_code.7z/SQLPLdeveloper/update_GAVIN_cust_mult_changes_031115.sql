select * from customer_mult_changes minus
select * from customer_mult_changes_ba031115 ;
select * from cust_mult_changes_upd_031115  

--customer_mult_changes_ba031115 BACKUP
--cust_mult_changes_upd_031115   UPDATE table from spreadsheet
--cust_mult_changes_upd_160216
create table customer_mult_changes_ba031115 as
select * --from customer_mult_changes_ba300915
from customer_mult_changes

select * from customer_mult_changes f
where f.cmc_account_number in
(select g.cmc_account_number
from customer_mult_changes f, cust_mult_changes_upd_031115 g
where f.cmc_account_number = g.cmc_account_number) --for update
and f.cmc_date_to = to_date('31-DEC-4000','DD-MON-YYYY')

update customer_mult_changes f set f.cmc_date_to = to_date('20-NOV-2015','DD-MON-YYYY')
where f.cmc_account_number in
(select g.cmc_account_number
from customer_mult_changes f, cust_mult_changes_upd_031115 g
where f.cmc_account_number = g.cmc_account_number) --for update
and f.cmc_date_to = to_date('31-DEC-4000','DD-MON-YYYY')


insert into customer_mult_changes
select CMC_BRANCH_CODE,cmc_account_number,to_date('21-NOV-2015','DD-MON-YYYY'),to_date('31-DEC-4000','DD-MON-YYYY'),cmc_multiple_code,cmc_grade_code
from cust_mult_changes_upd_031115;
--------------test-----------------------
select * from customer_mult_changes f
where f.cmc_account_number in
(select g.cmc_account_number
from customer_mult_changes f, cust_mult_changes_upd_031115 g
where f.cmc_account_number = g.cmc_account_number) --for update
and f.cmc_date_to = to_date('31-DEC-4000','DD-MON-YYYY')


select f.cmc_account_number from customer_mult_changes f where f.cmc_date_from = to_date('21-NOV-2015','DD-MON-YYYY') minus
select f.cmc_account_number from customer_mult_changes f where f.cmc_date_to = to_date('20-NOV-2015','DD-MON-YYYY')--476

select * from customer_mult_changes f where f.cmc_date_to = to_date('20-NOV-2015','DD-MON-YYYY') and f.cmc_date_to != to_date('31-DEC-4000','DD-MON-YYYY')--476

select f.cmc_account_number,count(*)
from customer_mult_changes f, cust_mult_changes_upd_031115 g
where f.cmc_account_number = g.cmc_account_number
group by f.cmc_account_number 
having count(*)>1  --471

select * from customer_mult_changes f where f.cmc_account_number in 
(502963050784500,
502963094033800,
502963098085300,
503103100710700,
502963029493600
)
select * from customer_mult_changes f where f.cmc_account_number = 502963096792200
