CREATE OR REPLACE VIEW ZPX_RTRN_STG_BAK_BKP AS
SELECT spoke_id,
       customer_id,
       pix_issue_type  issue_type,
       issue_id,
       transaction_date,
       document_type,
       item_type,
       reason_code,
       blocked_for_bill,
       currency_code,
       document_id,
       item_id,
       quantity,
       retail_net_value,
       retail_vat_value,
       cost_net_value,
       cost_vat_value,
       trade_net_value,
       trade_vat_value,
       conversion_rate,
       enh_conv_rate,
       legacy_titl_code,
       db_timestamp,
       etl_run_date_num,
       etl_run_num_seq,
       x.pix_parent_id,
       x.pix_parent_prod_id,
       nvl( x.pix_legacy_ean, x.pix_ean )                            pix_ean,
       nvl( x.pix_legacy_year, nvl( x.pix_year, x.pix_orig_year ) )  pix_year,
       nvl( x.pix_day, x.pix_orig_day )                              pix_day,
       x.pix_legacy_title,
       lpad( x.pix_sas_code, 2, 0 )                                  pix_sas_code,
       x.pix_plant_on_sale_date
--FROM   archive.ps_rtrn_missing_838_data@bisapprd.world r
FROM   archive.zpx_rtrn_stg_bak@bisapprd.world r
LEFT OUTER JOIN plant_issues_xref x
ON   x.pix_spoke_code = 'BRA'||lpad(r.spoke_id,3,'0')
AND  x.pix_sap_id     = r.issue_id
and x.PIX_spoke_code != 'BRA745'
;
