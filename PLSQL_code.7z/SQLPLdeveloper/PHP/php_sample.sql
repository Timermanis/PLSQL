select c.titl_code title,b.niss_issue_day "WEEK DAY",b.niss_issue_week WEEK,b.niss_issue_year YEAR,b.niss_ean,sum(ag.NET_COMMITED_QUANTITY) sales,sum(ag.NET_COMMITED_QUANTITY - ag.net_credit_quantity) "TOTAL SALES - CREDIT" 
from  agent_net_sales ag, branch_issues a, normal_issues b, titles c where
a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year

and b.niss_title_code = c.titl_code

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code
-----------------------
--and b.niss_title_code = 5561
--and a.bris_issue_year in (2016)
--and a.bris_branch_code = 'BRA220'
group by c.titl_code, b.niss_issue_day,b.niss_issue_week,b.niss_issue_year,b.niss_ean
order by b.niss_issue_year,b.niss_issue_week

select * from titles
