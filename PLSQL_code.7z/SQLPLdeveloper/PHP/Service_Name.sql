select value from v$parameter where name like '%service_name%';
