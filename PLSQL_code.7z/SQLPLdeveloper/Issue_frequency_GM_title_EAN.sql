select*
from issue_classifications i;
select*
from issue_frequencies if

SELECT t.title_code, GENERIC_TITLE_CODE, t.long_name, t.title_main_cat, t.title_sub_cat, t.issue_frequency
FROM TERMSPRD.JM_TITLES  t
where 
t.title_code in (36485,4770)

