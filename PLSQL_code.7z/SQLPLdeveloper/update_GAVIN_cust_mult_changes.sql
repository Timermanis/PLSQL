
create table must_stock_lists_upd_020916 as select * from must_stock_lists where 1=2--load from spreadsheets
--create table cust_mult_changes_upd_020916 as select * from cust_mult_changes_upd_300915 where 1=2--load from spreadsheets

create table cust_mult_changes_bkp240216 as
select * --from customer_mult_changes_ba300915
from customer_mult_changes
select * from cust_mult_changes_bkp240216--7930rows

insert into customer_mult_changes_ba300915
select CMC_BRANCH_CODE,cmc_account_number,to_date('03-OCT-2015','DD-MON-YYYY'),to_date('31-DEC-4000','DD-MON-YYYY'),cmc_multiple_code,cmc_grade_code
from cust_mult_changes_upd_300915;

--update to close current records for year 4000
update customer_mult_changes f set CMC_DATE_TO = to_date('24-FEB-2016','DD-MON-YYYY')
where f.cmc_account_number in
(select g.cmc_account_number
from  cust_mult_changes_upd_240216 g
where f.cmc_account_number = g.cmc_account_number)
and f.cmc_date_to = to_date('31-DEC-4000','DD-MON-YYYY')
--check
select * from customer_mult_changes f where f.cmc_account_number in
(select g.cmc_account_number
from  cust_mult_changes_upd_240216 g
where f.cmc_account_number = g.cmc_account_number)
and f.cmc_date_to = to_date('31-DEC-4000','DD-MON-YYYY')

select * from customer_mult_changes f where CMC_DATE_TO = to_date('24-FEB-2016','DD-MON-YYYY')

------insert records from update table
insert into customer_mult_changes
select CMC_BRANCH_CODE,cmc_account_number,to_date('25-FEB-2016','DD-MON-YYYY'),to_date('31-DEC-4000','DD-MON-YYYY'),cmc_multiple_code,cmc_grade_code
from cust_mult_changes_upd_240216;



select CMC_BRANCH_CODE,cmc_account_number,to_date('03-OCT-2015','DD-MON-YYYY'),to_date('31-DEC-4000','DD-MON-YYYY'),cmc_multiple_code,cmc_grade_code 
from customer_mult_changes_ba300915 intersect
select * from customer_mult_changes  where cmc_account_number = 502963036455400 union
select * from customer_mult_changes_ba300915 where cmc_account_number = 502963036455400

select  cmc_account_number from customer_mult_changes_ba300915--cust_mult_changes_upd_300915
group by cmc_account_number
having count(cmc_account_number) > 3

448 BRA220  503103124399400 09/01/2015  02/10/2015  29  S43
447 BRA850  502963049969000 16/02/2015  02/10/2015  29  S10
446 BRA220  502963058683300 03/08/2015  02/10/2015  723 J72
451 BRA790  502963011393000 10/01/2015  02/10/2015  29  S40
450 BRA850  502963003017600 27/01/2015  02/10/2015  29  S61
449 BRA850  502963014234300 09/03/2015  02/10/2015  29  S10

select * from customer_mult_changes  where cmc_account_number = 503103124399400



--create table cus_mult_changes_ba300915_orig as
select * from cus_mult_changes_ba300915_orig where cmc_account_number = 502963025144100


select * from customer_mult_changes_ba300915 f
where f.cmc_account_number in
(select g.cmc_account_number
from customer_mult_changes f, cust_mult_changes_upd_300915 g
where f.cmc_account_number = g.cmc_account_number) --for update
and f.cmc_date_to = to_date('31-DEC-4000','DD-MON-YYYY')

update customer_mult_changes_ba300915 f set f.cmc_date_to = to_date('02-OCT-2015','DD-MON-YYYY')
where f.cmc_account_number in
(select g.cmc_account_number
from customer_mult_changes f, cust_mult_changes_upd_300915 g
where f.cmc_account_number = g.cmc_account_number) --for update
and f.cmc_date_to = to_date('31-DEC-4000','DD-MON-YYYY')

rename customer_mult_changes to customer_mult_changes_v2

rename customer_mult_changes_ba300915 to customer_mult_changes
