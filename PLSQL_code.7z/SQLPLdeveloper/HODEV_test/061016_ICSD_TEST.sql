select * from ICSD_350_20160914143731015718 t


create table por_orig_350_ans_140916
as
select a.*
from agent_net_sales a,ICSD_350_20160914143731015718 t
where a.net_agent_account_number = t.icsd_cust_account_no
and a.net_issue_ean = t.icsd_issue_ean
and a.net_issue_year = t.icsd_issue_year;

create table por_orig_350_bms_140916
as
select *
from branch_mult_summaries bms
where bms.bms_branch_code = 'BRA350'
and exists
(select 1
 from ICSD_350_20160914143731015718 k
 where --k.bms_branch_code = bms.bms_branch_code
 --and 
 k.icsd_issue_ean = bms.bms_ean
 AND K.ICSD_ISSUE_YEAR = BMS.BMS_ISSUE_YEAR);
 
 CREATE table por_orig_350_bs_140916
 as
 select *
 from branch_summaries j
 where j.br_branch_code = 'BRA350'
 and exists
 (select 1
  from ICSD_350_20160914143731015718 n
  where n.icsd_issue_ean = j.br_ean
  and n.icsd_issue_year = j.br_issue_year)
  
  
  delete from agent_net_sales a -- 28749 rows 28777 in the ctaul temp tabel but the ones with > 1 get aggregated
  where exists
  (select 1
   from por_orig_350_ans_140916 b
   where b.net_agent_account_number = a.net_agent_account_number
   and b.net_issue_ean = a.net_issue_ean
   and b.net_issue_year = a.net_issue_year);
   
   
   delete from branch_mult_summaries bms -- 5519 rows
   where exists
   (select 1
    from  por_orig_350_bms_140916 v
    where v.bms_branch_code = bms.bms_branch_code
    and v.bms_ean = bms.bms_ean
    and v.bms_issue_year = bms.bms_issue_year);
    
    
    delete from branch_summaries bs  -- 1475 rows
    where exists
    (select 1
     from  por_orig_350_bs_140916 a
     where a.br_branch_code = bs.br_branch_code
     and a.br_ean = bs.br_ean
     and a.br_issue_year = bs.br_issue_year)   
     
     
     select n.net_agent_account_number, n.net_issue_ean, n.net_issue_year
     from por_orig_350_ans_140916_new n
     minus
     select m.net_agent_account_number, m.net_issue_ean, m.net_issue_year
     from por_orig_350_ans_140916 m
     


