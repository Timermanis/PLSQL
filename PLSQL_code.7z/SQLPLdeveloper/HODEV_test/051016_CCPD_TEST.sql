--select * from jt_051016_cus_xref_test_orig x where x.ccr_cust_urn in 
create table jt_051016_cus_xref_test_orig as
select x.* from customer_x_ref x , zpx_cus_dtls_stg_bak z where x.ccr_cust_urn = z.URN and z.HUB_ID = 220 and z.ETL_RUN_NUM_SEQ = 1670

--backup current customer records
create table jt_051016_AGUD_test_orig as
select c.* from customers c, zpx_cus_dtls_stg_bak z where c.cus_account_number = z.URN and z.HUB_ID = 220 and z.ETL_RUN_NUM_SEQ = 1670-- and c.cus_to_date = '31-DEC-4000'
--run package agud_5dig_box_extract
create table jt_051016_AGUD_test_1v as
select c.* from customers c, zpx_cus_dtls_stg_bak z where c.cus_account_number = z.URN and z.HUB_ID = 220 and z.ETL_RUN_NUM_SEQ = 1670-- and c.cus_to_date = '31-DEC-4000'

delete from customers c where c.cus_account_number in (select cus_account_number from jt_051016_AGUD_test_1v)
insert into customers select * from jt_051016_AGUD_test_orig
--run package pl_agud_extract
create table jt_051016_AGUD_test_2v as
select c.* from customers c, zpx_cus_dtls_stg_bak z where c.cus_account_number = z.URN and z.HUB_ID = 220 and z.ETL_RUN_NUM_SEQ = 1670
--compare datasets
select * from jt_051016_AGUD_test_1v minus
select * from jt_051016_AGUD_test_2v
--reset changes
delete from customers c where c.cus_account_number in (select cus_account_number from jt_051016_AGUD_test_2v)
insert into customers select * from jt_051016_AGUD_test_orig
