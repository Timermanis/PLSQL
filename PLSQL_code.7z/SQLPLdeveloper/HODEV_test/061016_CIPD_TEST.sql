select * from zpx_plnt_iss_stg_bak z where z.ETL_RUN_NUM_SEQ = (select max (ETL_RUN_NUM_SEQ) from zpx_plnt_iss_stg_bak) and z.SPOKE_ID = 220--1663 
-------------------

  SELECT DISTINCT pix.pix_legacy_ean, pix.pix_official_on_sale_date, pix.PIX_PARENT_ID ,pix.PIX_ISSUE_TYPE, pix.PIX_LEGACY_YEAR
  FROM   zpx_plnt_iss_stg_bak iss,
         plant_issues_xref pix
  WHERE  iss.spoke_id IN ( SELECT nvl(spo_num,0)
                           FROM   latest_spokes_mv@bisapprd.world
                           WHERE  bra_num = 220 )
  AND    iss.etl_run_num_seq   BETWEEN 1663     AND 1663
  AND    pix.pix_branch_code   = 'BRA220'
  AND    pix.pix_sap_id        = to_number( iss.issue_id )
  AND    pix.pix_legacy_title  = to_number(trim(iss.legacy_titl_code))
  AND    pix.pix_issue_type    NOT IN ( 'MO','TU','WE','TH','FR','SA','SU','XX','Z1','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' )
  AND EXISTS ( SELECT 1
               FROM   plant_issues_xref b
               WHERE  b.pix_legacy_ean                      = pix.pix_legacy_ean
               AND    b.pix_branch_code                     = pix.pix_branch_code
               AND    nvl( b.pix_legacy_year, b.pix_year )  = nvl( pix.pix_legacy_year, pix.pix_year )
               AND    nvl( b.pix_parent_id, b.pix_sap_id ) != nvl( pix.pix_parent_id, pix.pix_sap_id )
               AND    b.pix_plant_on_sale_date             IS NOT NULL );

------------------
--IN REFMAST inserted one more 220 record with different pix_parent_id
select * from PLANT_ISSUES_XREF_BASE x where x.PIX_LEGACY_EAN = 977036415411401 and x.pix_year = 2015 for update
----------
select * from plant_issues_xref x where x.PIX_LEGACY_EAN = 977036415411401 and x.PIX_YEAR = 2015

select * from plant_issues_xref x where x.PIX_sap_id = '000000000028262060' and x.PIX_YEAR = 2015

SELECT * from branch_issues v where v.bris_title_code = 2826 and v.bris_issue_year = 2015 and v.bris_branch_code = 'BRA220'

SELECT * from all_issues a where a.issu_title_code = 2826 and a.issu_issue_year = 2015

SELECT * from agent_net_sales s where s.net_issue_year = 2015 and s.net_branch_code = 'BRA220' and s.net_issue_ean = 660028261502001   --s.net_title_code = 2826 an

SELECT * from branch_summaries d where d.br_ean = 660028261502001

SELECT bi.bris_title_code,
           bi.bris_issue_year,
           bi.bris_issue_week,
           bi.bris_issue_day,
           bi.bris_ean,
           bi.bris_official_on_sale_date
           , bi.bris_link_ean -- #AMT 01
           , bi.bris_link_issue_year -- #AMT 01
    FROM   branch_issues bi
    WHERE  bi.bris_branch_code            = 'BRA220'
    AND    bi.bris_issue_year             = 2015
    AND    bi.bris_ean                    = 977036415411401
    AND    bi.bris_official_on_sale_date != p_official_on_sale_date;
