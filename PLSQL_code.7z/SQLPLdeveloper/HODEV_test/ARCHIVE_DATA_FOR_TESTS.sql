select distinct b.pix_ean  from zpx_rtrn_stg_bak r, refmast.plant_issues_xref_base b where r.etl_run_num_seq = 2292 and r.issue_id = b.pix_sap_id and b.pix_branch_code  = 'BRA220'
and 'BRA'||r.spoke_id = b.pix_spoke_code and r.cost_net_value != 0; 
