create table jt_MISTEST_ANS as 
select count(*) from agent_net_sales@HOMIS_JM_RO.WORLD  where net_branch_code = 'BRA350' and NET_ISSUE_YEAR = 2016

select * from zpx_rtrn_stg_bak z where z.etl_run_num_seq = (select max(etl_run_num_seq) from zpx_rtrn_stg_bak z) and z.issue_id = '000000000053232352'
select * from zpx_rtrn_stg_bak z where z.etl_run_num_seq = (select max(etl_run_num_seq) from zpx_rtrn_stg_bak z) and z.issue_id = '000000000053032347'
select * from zpx_rtrn_stg_bak z where z.etl_run_num_seq = (select max(etl_run_num_seq) from zpx_rtrn_stg_bak z) and z.issue_id = '000000000053232352'

select * from zpx_rtrn_stg_bak z where z.etl_run_num_seq = (select max(etl_run_num_seq) from zpx_rtrn_stg_bak z) and z.transaction_date = '12-OCT-2016'


select * from plant_issues_xref x where x.PIX_SAP_ID = 000000000040802172

create table jt_MISTEST_ANS5964132 as 
select a.* from agent_net_sales a, plant_issues_xref x
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR
and x.PIX_SAP_ID = z.issue_id 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA020'
and x.PIX_BRANCH_CODE = 'BRA020'

and x.PIX_SAP_ID in (select z.issue_id from zpx_rtrn_stg_bak z where z.etl_run_num_seq > (select max(etl_run_num_seq)-3 from zpx_rtrn_stg_bak z) )
--and x.PIX_SAP_ID = '000000000005964132'

drop table jt_HODEVTEST_ANS5964132

create table jt_HODEVTEST_ANS5964132 as 
select a.* from agent_net_sales@HOMIS_JM_RO.WORLD a, plant_issues_xref x  
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA020'
and x.PIX_BRANCH_CODE = 'BRA020'

and x.PIX_SAP_ID = '000000000005964132'--'000000000324432350'

select * from jt_MISTEST_ANS5964132 --401 rows
minus
select * from jt_HODEVTEST_ANS5964132
--minus
--select * from jt_MISTEST_ANS53232352 --43 rows

select * from jt_MISTEST_ANS5964132 where NET_AGENT_ACCOUNT_NUMBER = 502963004010600
union all
select * from jt_HODEVTEST_ANS5964132 where NET_AGENT_ACCOUNT_NUMBER = 502963004010600

select * from jt_MISTEST_ANS5964132 where NET_CTB_FLAG != '~'
union all
select * from jt_HODEVTEST_ANS5964132 

select * from jt_MISTEST_ANS324432350 where NET_AGENT_ACCOUNT_NUMBER = 350139905000500
union all
select * from jt_HODEVTEST_ANS324432350 where NET_AGENT_ACCOUNT_NUMBER = 350139905000500

select 
NET_AGENT_ACCOUNT_NUMBER,
NET_ISSUE_EAN,
NET_ISSUE_YEAR,
NET_BOX_OUT_QUANTITY,
NET_CREDIT_QUANTITY,
NET_OTHER_SALES_QUANTITY,
NET_COMMITED_QUANTITY,
NET_CASUAL_QUANTITY,
NET_RETURN_QUANTITY,
NET_NOTE_KEYED_FLAG,
--NET_CTB_FLAG,
NET_BRANCH_CODE,
NET_BOX_NUMBER,
NET_MULTIPLE_CODE,
NET_MULTIPLE_GRADE_CODE,
NET_ANMW_CODE,
NET_RETAILER_BAND,
NET_POSTCODE_OUTER,
--NET_PUBLISHER_CODE,
NET_TITLE_CODE
 from jt_MISTEST_ANS324432350
minus
select 
NET_AGENT_ACCOUNT_NUMBER,
NET_ISSUE_EAN,
NET_ISSUE_YEAR,
NET_BOX_OUT_QUANTITY,
NET_CREDIT_QUANTITY,
NET_OTHER_SALES_QUANTITY,
NET_COMMITED_QUANTITY,
NET_CASUAL_QUANTITY,
NET_RETURN_QUANTITY,
NET_NOTE_KEYED_FLAG,
--NET_CTB_FLAG,
NET_BRANCH_CODE,
NET_BOX_NUMBER,
NET_MULTIPLE_CODE,
NET_MULTIPLE_GRADE_CODE,
NET_ANMW_CODE,
NET_RETAILER_BAND,
NET_POSTCODE_OUTER,
--NET_PUBLISHER_CODE,
NET_TITLE_CODE
 from jt_HODEVTEST_ANS324432350

select * from icsd_350_20161013103216695334 t where t.icsd_cust_account_no = 502963053356100 and t.icsd_issue_ean = 977135513312541

-------------------------------------CTB flag check----------------------------------------------------------------------------------------------------------------
select a.net_agent_account_number,a.net_issue_ean,a.net_ctb_flag from agent_net_sales a, plant_issues_xref x  
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA350'
and x.PIX_BRANCH_CODE = 'BRA350'
and a.net_ctb_flag = '~'
and x.PIX_PLANT_ON_SALE_DATE > '10-OCT-2016'

minus

select a.net_agent_account_number,a.net_issue_ean,a.net_ctb_flag from agent_net_sales@HOMIS_JM_RO.WORLD a, plant_issues_xref x  --16272 rows
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA350'
and x.PIX_BRANCH_CODE = 'BRA350'
and a.net_ctb_flag = '~'
and x.PIX_PLANT_ON_SALE_DATE > '10-OCT-2016'

NET_AGENT_ACCOUNT_NUMBER	NET_ISSUE_EAN	NET_CTB_FLAG
503103110134800	977204787123341	1
503103115462700	10006511641201	E
503103123710800	10090221641201	5
503103123710800	10348041641201	S

---------------------
select a.net_agent_account_number,a.net_issue_ean,a.net_ctb_flag from agent_net_sales a, plant_issues_xref x  
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA350'
and x.PIX_BRANCH_CODE = 'BRA350'
and a.net_ctb_flag != '~'
and x.PIX_PLANT_ON_SALE_DATE > '10-OCT-2016'
and a.net_agent_account_number = 503103110134800
and a.net_issue_ean = 977204787123341

union all

select a.net_agent_account_number,a.net_issue_ean,a.net_ctb_flag from agent_net_sales@HOMIS_JM_RO.WORLD a, plant_issues_xref x  --16272 rows
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA350'
and x.PIX_BRANCH_CODE = 'BRA350'
--and a.net_ctb_flag != '~'
and x.PIX_PLANT_ON_SALE_DATE > '10-OCT-2016'
and a.net_agent_account_number = 503103110134800
and a.net_issue_ean = 977204787123341
---------------------------------2
select a.net_agent_account_number,a.net_issue_ean,a.net_ctb_flag from agent_net_sales a, plant_issues_xref x  
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA350'
and x.PIX_BRANCH_CODE = 'BRA350'
and a.net_ctb_flag != '~'
and x.PIX_PLANT_ON_SALE_DATE > '10-OCT-2016'
and a.net_agent_account_number = 503103115462700	
and a.net_issue_ean = 10006511641201

union all

select a.net_agent_account_number,a.net_issue_ean,a.net_ctb_flag from agent_net_sales@HOMIS_JM_RO.WORLD a, plant_issues_xref x  --16272 rows
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA350'
and x.PIX_BRANCH_CODE = 'BRA350'
--and a.net_ctb_flag != '~'
and x.PIX_PLANT_ON_SALE_DATE > '10-OCT-2016'
and a.net_agent_account_number = 503103115462700	
and a.net_issue_ean = 10006511641201
------------------------------------3
select a.net_agent_account_number,a.net_issue_ean,a.net_ctb_flag from agent_net_sales a, plant_issues_xref x  
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA350'
and x.PIX_BRANCH_CODE = 'BRA350'
and a.net_ctb_flag != '~'
and x.PIX_PLANT_ON_SALE_DATE > '10-OCT-2016'
and a.net_agent_account_number = 503103123710800	
and a.net_issue_ean = 10090221641201

union all

select a.net_agent_account_number,a.net_issue_ean,a.net_ctb_flag from agent_net_sales@HOMIS_JM_RO.WORLD a, plant_issues_xref x  --16272 rows
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA350'
and x.PIX_BRANCH_CODE = 'BRA350'
--and a.net_ctb_flag != '~'
and x.PIX_PLANT_ON_SALE_DATE > '10-OCT-2016'
and a.net_agent_account_number = 503103123710800	
and a.net_issue_ean = 10090221641201
---------------------------------4
select a.net_agent_account_number,a.net_issue_ean,a.net_ctb_flag from agent_net_sales a, plant_issues_xref x  
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA350'
and x.PIX_BRANCH_CODE = 'BRA350'
and a.net_ctb_flag != '~'
and x.PIX_PLANT_ON_SALE_DATE > '10-OCT-2016'
and a.net_agent_account_number = 503103123710800	
and a.net_issue_ean = 10090221641201

union all

select a.net_agent_account_number,a.net_issue_ean,a.net_ctb_flag from agent_net_sales@HOMIS_JM_RO.WORLD a, plant_issues_xref x  --16272 rows
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA350'
and x.PIX_BRANCH_CODE = 'BRA350'
--and a.net_ctb_flag != '~'
and x.PIX_PLANT_ON_SALE_DATE > '10-OCT-2016'
and a.net_agent_account_number = 503103123710800	
and a.net_issue_ean = 10090221641201
--------------------------------------------------------------------------------------
create table  jt_HODEVTEST_ANS191016 as --86672
select a.* from agent_net_sales a, plant_issues_xref x
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA020'
and x.PIX_BRANCH_CODE = 'BRA020'
and x.PIX_OFFICIAL_ON_SALE_DATE > sysdate - 3
--and x.PIX_SAP_ID = '000000000005964132'

create table jt_MISTEST_ANS191016 as 
select a.* from agent_net_sales@HOMIS_JM_RO.WORLD a, plant_issues_xref x  
where NET_ISSUE_EAN = x.PIX_EAN 
and NET_ISSUE_YEAR = x.PIX_YEAR 
and NET_ISSUE_YEAR = 2016 
and net_branch_code = 'BRA020'
and x.PIX_BRANCH_CODE = 'BRA020'
and x.PIX_OFFICIAL_ON_SALE_DATE > sysdate - 3

-------------------------------------------------------------

select * from jt_HODEVTEST_ANS191016 h where h.net_agent_account_number = 20161712000000 and h.net_issue_ean = 977004372238243
 
union all
select * from jt_MISTEST_ANS191016 h where h.net_agent_account_number = 20161712000000 and h.net_issue_ean = 977004372238243

---------------------------------------------------
select NET_AGENT_ACCOUNT_NUMBER,
NET_ISSUE_EAN,
NET_ISSUE_YEAR,
NET_BOX_OUT_QUANTITY,
NET_CREDIT_QUANTITY,
NET_OTHER_SALES_QUANTITY,
NET_COMMITED_QUANTITY,
NET_CASUAL_QUANTITY,
NET_RETURN_QUANTITY,
NET_NOTE_KEYED_FLAG,
NET_BRANCH_CODE,
NET_BOX_NUMBER,
NET_MULTIPLE_CODE,
NET_MULTIPLE_GRADE_CODE,
NET_ANMW_CODE,
NET_RETAILER_BAND,
NET_POSTCODE_OUTER,
NET_TITLE_CODE from agent_net_sales@HOMIS_JM_RO.WORLD b  where b.NET_ISSUE_EAN = 977135755320444
minus 
select NET_AGENT_ACCOUNT_NUMBER,
NET_ISSUE_EAN,
NET_ISSUE_YEAR,
NET_BOX_OUT_QUANTITY,
NET_CREDIT_QUANTITY,
NET_OTHER_SALES_QUANTITY,
NET_COMMITED_QUANTITY,
NET_CASUAL_QUANTITY,
NET_RETURN_QUANTITY,
NET_NOTE_KEYED_FLAG,
NET_BRANCH_CODE,
NET_BOX_NUMBER,
NET_MULTIPLE_CODE,
NET_MULTIPLE_GRADE_CODE,
NET_ANMW_CODE,
NET_RETAILER_BAND,
NET_POSTCODE_OUTER,
NET_TITLE_CODE from agent_net_sales a  where a.NET_ISSUE_EAN = 977135755320444
------------------------------------
select NET_AGENT_ACCOUNT_NUMBER,
NET_ISSUE_EAN,
NET_ISSUE_YEAR,
NET_BOX_OUT_QUANTITY,
NET_CREDIT_QUANTITY,
NET_OTHER_SALES_QUANTITY,
NET_COMMITED_QUANTITY,
NET_CASUAL_QUANTITY,
NET_RETURN_QUANTITY,
NET_NOTE_KEYED_FLAG,
NET_BRANCH_CODE,
NET_BOX_NUMBER,
NET_MULTIPLE_CODE,
NET_MULTIPLE_GRADE_CODE,
NET_ANMW_CODE,
NET_RETAILER_BAND,
NET_POSTCODE_OUTER,
NET_TITLE_CODE from agent_net_sales@HOMIS_JM_RO.WORLD b  where b.NET_ISSUE_EAN = 977135755320444 and b.NET_AGENT_ACCOUNT_NUMBER = 390163238000300
--minus 
union all
select NET_AGENT_ACCOUNT_NUMBER,
NET_ISSUE_EAN,
NET_ISSUE_YEAR,
NET_BOX_OUT_QUANTITY,
NET_CREDIT_QUANTITY,
NET_OTHER_SALES_QUANTITY,
NET_COMMITED_QUANTITY,
NET_CASUAL_QUANTITY,
NET_RETURN_QUANTITY,
NET_NOTE_KEYED_FLAG,
NET_BRANCH_CODE,
NET_BOX_NUMBER,
NET_MULTIPLE_CODE,
NET_MULTIPLE_GRADE_CODE,
NET_ANMW_CODE,
NET_RETAILER_BAND,
NET_POSTCODE_OUTER,
NET_TITLE_CODE from agent_net_sales a  where a.NET_ISSUE_EAN = 977135755320444 and a.NET_AGENT_ACCOUNT_NUMBER = 390163238000300
















