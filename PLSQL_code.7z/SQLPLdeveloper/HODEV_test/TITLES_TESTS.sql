/*select titl_code
from titles@HOMIS_JM_RO.WORLD
minus
select titl_code
from titles

select *
from titles@HOMIS_JM_RO.WORLD h where titl_code not in (select title_code from por_diffs_111016)
minus
select *
from titles where titl_code not in (select title_code from por_diffs_111016)
*/
select TITL_CODE,
                            TITL_AGENT_HANDLING_ALLOWANCE ,
                            TITL_COVER_PRICE,
                           TITL_CUBIC_VOLUME,
                           TITL_DELETE_FLAG,
                           --TITL_EXCEPTION_DAY,--58169
                           TITL_ISSUE_EAN_LATEST,
                            TITL_ISSUE_FREQUENCY,
                           TITL_ISSUE_YEAR_LATEST,
                           --TITL_LAST_UPDATE,--58169
                            TITL_LONG_NAME,
                            TITL_MAIN_CAT,
                            TITL_NET_ITEM_INDICATOR,
                            TITL_NUMBER_ISSUES_PER_YEAR,
                            --TITL_PORTFOLIO_CODE,--spreadsheet
                            TITL_REALLOCATION_FLAG,
                           --TITL_RETAIL_PRICE_EXCEPTION,--58169
                            TITL_SELECTED_ANMW,
                            TITL_SHORT_NAME,
                            TITL_STANDARD_COST_DISCOUNT,
                            TITL_STANDARD_TRADE_DISCOUNT,
                            TITL_STATUS,
                            TITL_SUB_CAT,
                           TITL_SUPPLIER_SELECTED_ANMW,
                            TITL_SUPPLY_ORG_CODE_DISTRIBUT,
                            TITL_SUPPLY_ORG_CODE_PUBLISHED,
                            TITL_TIME_SEN_FLAG,
                            TITL_TITLE_BANDING_FLAG,
                            TITL_TITLE_GROUPING,
                            TITL_TITLE_ISSUE_FREQUENCY,
                            TITL_TITLE_NAME_KEY,
                            TITL_VAT_CODE_CODE    

from titles@HOMIS_JM_RO.WORLD a --where titl_code = 100--49534
minus
--union all
select  TITL_CODE,
                            TITL_AGENT_HANDLING_ALLOWANCE ,
                            TITL_COVER_PRICE,
                           TITL_CUBIC_VOLUME,
                           TITL_DELETE_FLAG,
                           --TITL_EXCEPTION_DAY,
                           TITL_ISSUE_EAN_LATEST,
                            TITL_ISSUE_FREQUENCY,
                           TITL_ISSUE_YEAR_LATEST,
                           --TITL_LAST_UPDATE,
                            TITL_LONG_NAME,
                            TITL_MAIN_CAT,
                            TITL_NET_ITEM_INDICATOR,
                            TITL_NUMBER_ISSUES_PER_YEAR,
                            --TITL_PORTFOLIO_CODE,
                            TITL_REALLOCATION_FLAG,
                           --TITL_RETAIL_PRICE_EXCEPTION,
                            TITL_SELECTED_ANMW,
                            TITL_SHORT_NAME,
                            TITL_STANDARD_COST_DISCOUNT,
                            TITL_STANDARD_TRADE_DISCOUNT,
                            TITL_STATUS,
                            TITL_SUB_CAT,
                           TITL_SUPPLIER_SELECTED_ANMW,
                            TITL_SUPPLY_ORG_CODE_DISTRIBUT,
                            TITL_SUPPLY_ORG_CODE_PUBLISHED,
                            TITL_TIME_SEN_FLAG,
                            TITL_TITLE_BANDING_FLAG,
                            TITL_TITLE_GROUPING,
                            TITL_TITLE_ISSUE_FREQUENCY,
                            TITL_TITLE_NAME_KEY,
                            TITL_VAT_CODE_CODE    

from titles a --where  titl_code = 100--49534
-----------------------
select *
from titles a  where titl_code = 1739
--minus
union all
select *
from  titles@HOMIS_JM_RO.WORLD a  where titl_code = 1739




