drop table jt_bris_issues_070916_020_v1;
create table jt_bris_issues_070916_020_v1
as
select *
from branch_issues r
where r.bris_branch_code = 'BRA020'
and exists
(select 1
 from isud_020_20160928152155167582 a--ISUD_350_20160907095749392985 a--ISUD_350_20160907095211100317 a
 where a.bris_ean = r.bris_ean
 and a.bris_issue_year = r.bris_issue_year);
 
 
 
delete
from branch_issues r
where r.bris_branch_code = 'BRA020'
and exists
(select 1
 from isud_020_20160928152155167582 a--ISUD_350_20160907095749392985 a--ISUD_350_20160907095211100317 a
 where a.bris_ean = r.bris_ean
 and a.bris_issue_year = r.bris_issue_year);
 
 create table jt_bris_issues_070916_020_v2
as
select *
from branch_issues r
where r.bris_branch_code = 'BRA020'
and exists
(select 1
 from isud_020_20160928145127798200 a--ISUD_350_20160907095749392985 a--ISUD_350_20160907095211100317 a
 where a.bris_ean = r.bris_ean
 and a.bris_issue_year = r.bris_issue_year);
 
 select * from jt_bris_issues_070916_020_v1 minus
 select * from jt_bris_issues_070916_020_v2 --3404 rec
 
  select * from jt_bris_issues_070916_020_v1 a where a.bris_ean = 977093187613503 union
 select * from jt_bris_issues_070916_020_v2 b where b.bris_ean = 977093187613503
 
 select  t.bris_ean,t.bris_issue_day, t.bris_issue_week,t.bris_issue_year,t.bris_title_code,t.bris_cost_price,t.bris_vat_code_code,t.bris_cover_mount_flag 
,t.bris_terms_of_sale,t.bris_invoice_date,t.bris_bar_code,t.bris_official_on_sale_date,t.bris_keep,t.bris_cover_mount_vat_code,t.bris_reference  
,t.bris_publisher_reference,t.bris_recall_date,t.bris_order_by_date,t.bris_on_sale_date,t.bris_claim_end_date,t.bris_handling_unit
,t.bris_handling_allowance,t.bris_cover_mount_price,t.bris_supplements,t.bris_claim_start_date
,t.bris_napier_realloc_flag,t.bris_year_of_publication,t.bris_daily_collection_flag,t.bris_trade_counter_stock,t.bris_stock_transfers--  
from jt_bris_issues_070916_020_v1 t minus
select  t.bris_ean,t.bris_issue_day, t.bris_issue_week,t.bris_issue_year,t.bris_title_code,t.bris_cost_price,t.bris_vat_code_code,t.bris_cover_mount_flag 
,t.bris_terms_of_sale,t.bris_invoice_date,t.bris_bar_code,t.bris_official_on_sale_date,t.bris_keep,t.bris_cover_mount_vat_code,t.bris_reference   
,t.bris_publisher_reference,t.bris_recall_date,t.bris_order_by_date,t.bris_on_sale_date,t.bris_claim_end_date,t.bris_handling_unit   
,t.bris_handling_allowance,t.bris_cover_mount_price,t.bris_supplements,t.bris_claim_start_date    
,t.bris_napier_realloc_flag,t.bris_year_of_publication,t.bris_daily_collection_flag,t.bris_trade_counter_stock,t.bris_stock_transfers --
from jt_bris_issues_070916_020_v2 t

 

