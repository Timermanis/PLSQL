select * from jt_071016_ICSD_020_ANS1 t
select max (ETL_RUN_NUM_SEQ) from zpx_rtrn_stg_bak --1663
drop table jt_071016_ICSD_020_ANS1
---------------------------------------------------------
create table jt_071016_ICSD_020_ANS--63032
as
select a.*
from agent_net_sales a,icsd_020_20161007093731685029 t
where a.net_agent_account_number = t.icsd_cust_account_no
and a.net_issue_ean = t.icsd_issue_ean
and a.net_issue_year = t.icsd_issue_year;
------------
create table jt_071016_ICSD_020_BMS--9758
as
select *
from branch_mult_summaries bms
where bms.bms_branch_code = 'BRA020'
and exists
(select 1
 from icsd_020_20161007093731685029 k
 where 
 k.icsd_issue_ean = bms.bms_ean
 AND K.ICSD_ISSUE_YEAR = BMS.BMS_ISSUE_YEAR);
------------
 CREATE table jt_071016_ICSD_020_BrSu--2104
 as
 select *
 from branch_summaries j
 where j.br_branch_code = 'BRA020'
 and exists
 (select 1
  from icsd_020_20161007093731685029 n
  where n.icsd_issue_ean = j.br_ean
  and n.icsd_issue_year = j.br_issue_year)
  
-------------------------------------------------
  delete from agent_net_sales a --62953                 28749 rows 28777 in the ctaul temp tabel but the ones with > 1 get aggregated
  where exists
  (select 1
   from jt_071016_ICSD_020_ANS b
   where b.net_agent_account_number = a.net_agent_account_number
   and b.net_issue_ean = a.net_issue_ean
   and b.net_issue_year = a.net_issue_year);
   
------------
   delete from branch_mult_summaries bms --9758 5519 rows
   where exists
   (select 1
    from  jt_071016_ICSD_020_BMS v
    where v.bms_branch_code = bms.bms_branch_code
    and v.bms_ean = bms.bms_ean
    and v.bms_issue_year = bms.bms_issue_year);
    
------------   
    delete from branch_summaries bs--2104  -- 1475 rows
    where exists
    (select 1
     from  jt_071016_ICSD_020_BrSu a
     where a.br_branch_code = bs.br_branch_code
     and a.br_ean = bs.br_ean
     and a.br_issue_year = bs.br_issue_year)   
 --------------------------------------------------------------------------------------------------------
 create table jt_071016_ICSD_020_ANS1--63032
as
select a.*
from agent_net_sales a,icsd_020_20161007155105271713 t
where a.net_agent_account_number = t.icsd_cust_account_no
and a.net_issue_ean = t.icsd_issue_ean
and a.net_issue_year = t.icsd_issue_year;
------------
create table jt_071016_ICSD_020_BMS1--9758
as
select *
from branch_mult_summaries bms
where bms.bms_branch_code = 'BRA020'
and exists
(select 1
 from icsd_020_20161007155105271713 k
 where 
 k.icsd_issue_ean = bms.bms_ean
 AND K.ICSD_ISSUE_YEAR = BMS.BMS_ISSUE_YEAR);
------------
 CREATE table jt_071016_ICSD_020_BrSu1--2104
 as
 select *
 from branch_summaries j
 where j.br_branch_code = 'BRA020'
 and exists
 (select 1
  from icsd_020_20161007155105271713 n
  where n.icsd_issue_ean = j.br_ean
  and n.icsd_issue_year = j.br_issue_year)
 --------------------------------------------------------------------------------------------------------    
     
     select n.net_agent_account_number, n.net_issue_ean, n.net_issue_year
     from jt_071016_ICSD_020_ANS n
     minus
     select m.net_agent_account_number, m.net_issue_ean, m.net_issue_year
     from jt_071016_ICSD_020_ANS1 m
     

    select *
     from icsd_020_20161007155105271713 m minus
     select *
     from icsd_020_20161007093731684917 n
     
     
select * from pl_icsd_sus i where i.branch_code = 'BRA020' order by i.branch_code
