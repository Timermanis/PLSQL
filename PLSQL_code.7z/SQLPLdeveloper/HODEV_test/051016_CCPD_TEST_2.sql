
--updated 503103101449500 to 503103101449502
create table jt_011016_CCPD_upd_CUS
as
select *
from customers c--as of timestamp systimestamp - interval '1' day c
where c.cus_account_number = 503103101449500 --36 

create table jt_011016_CCPD_upd_ANS
as
select *
from agent_net_sales a--as of timestamp systimestamp - interval '1' day a
where a.net_agent_account_number = 503103101449500 --22036 
--------------------------------------------------

update zpx_cus_dtls_stg_bak z set z.URN = 503103101449502 where z.URN = 503103101449500 and z.HUB_ID = 220 and z.ETL_RUN_NUM_SEQ = 1670
select * from  zpx_cus_dtls_stg_bak z  where z.URN = 503103101449500 and z.HUB_ID = 220 and z.ETL_RUN_NUM_SEQ = 1670

-------------------------------------------------- check same content on after ccpd update
--drop table jt_011016_CCPD_upd_ANS_aft
create table jt_011016_CCPD_upd_CUS_aft
as
select *
from customers  c
where c.cus_account_number = 503103101449502 --old_urn 502963091937200;

create table jt_011016_CCPD_upd_ANS_aft
as
select *
from agent_net_sales  a
where a.net_agent_account_number = 503103101449502 --old_urn 502963091937200;

--test cus
select c.cus_account_number, d.cus_account_number
from jt_011016_CCPD_upd_CUS  c,jt_011016_CCPD_upd_CUS_aft d 
where c.cus_box_number = d.cus_box_number and c.cus_branch_code = d.cus_branch_code and c.cus_from_date = d.cus_from_date

--test ans
select a.net_commited_quantity - b.net_commited_quantity, a.net_commited_quantity
from jt_011016_CCPD_upd_ANS  a, jt_011016_CCPD_upd_ANS_aft b where a.net_agent_account_number = 503103101449500 and a.net_issue_ean = b.net_issue_ean
and a.net_issue_year = b.net_issue_year



