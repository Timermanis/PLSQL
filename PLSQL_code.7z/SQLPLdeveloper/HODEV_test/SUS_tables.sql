select *
from user_tables u
where u.table_name like '%SUS';--pl_agent_net_sales_sus s
