select * from ISUD_220_20160928134243931680 minus
select * from isud_220_20160928134024143317 

select * from isud_220_20160928134024143317 minus
select * from ISUD_220_20160928134243931680
---------------------------------------------------
select t.bris_issue_day, t.bris_issue_week, t.bris_ean,t.bris_issue_year,t.bris_title_code,t.bris_cost_price,t.bris_vat_code_code,t.bris_cover_mount_flag 
,t.bris_terms_of_sale,t.bris_invoice_date,t.bris_bar_code,t.bris_official_on_sale_date,t.bris_keep,t.bris_cover_mount_vat_code,t.bris_reference  
,t.bris_publisher_reference,t.bris_recall_date,t.bris_order_by_date,t.bris_on_sale_date,t.bris_claim_end_date,t.bris_handling_unit
,t.bris_handling_allowance,t.bris_cover_mount_price,t.bris_supplements,t.bris_claim_start_date
,t.bris_napier_realloc_flag,t.bris_year_of_publication,t.bris_daily_collection_flag,t.bris_trade_counter_stock,t.bris_stock_transfers--  
from ISUD_220_20160928134243931680 t minus
select t.bris_issue_day, t.bris_issue_week, t.bris_ean,t.bris_issue_year,t.bris_title_code,t.bris_cost_price,t.bris_vat_code_code,t.bris_cover_mount_flag 
,t.bris_terms_of_sale,t.bris_invoice_date,t.bris_bar_code,t.bris_official_on_sale_date,t.bris_keep,t.bris_cover_mount_vat_code,t.bris_reference   
,t.bris_publisher_reference,t.bris_recall_date,t.bris_order_by_date,t.bris_on_sale_date,t.bris_claim_end_date,t.bris_handling_unit   
,t.bris_handling_allowance,t.bris_cover_mount_price,t.bris_supplements,t.bris_claim_start_date    
,t.bris_napier_realloc_flag,t.bris_year_of_publication,t.bris_daily_collection_flag,t.bris_trade_counter_stock,t.bris_stock_transfers --
from isud_220_20160928134024143317 t


select * from isud_550_20160928143013617887 t minus
select * from isud_550_20160928143042124325 t


select * from isud_390_20160928143231454724 t minus
select * from isud_390_20160928143223455386 t 

select * from isud_350_20160928143528856607 t minus
select * from isud_350_20160928143545238164 t 


select * from isud_350_20160928143743641250 t minus
 select * from isud_350_20160928143735206281 t 
 
 select * from isud_020_20160928144221984056 t minus
 select * from isud_020_20160928144237350947 t 
 

 select * from isud_020_20160928145159781187 t minus
   select * from isud_020_20160928145127798200 t 
 
