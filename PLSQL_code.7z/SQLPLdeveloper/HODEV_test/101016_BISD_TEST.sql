create table jt_bsum_orig_101016_BRA220 
as
select bs.*
from bisd_220_201610101224old1657 a, branch_summaries bs
where a.br_branch_code = bs.br_branch_code
and a.br_ean = bs.br_ean
and a.br_issue_year = bs.br_issue_year
and bs.br_branch_code = 'BRA220';


select k.br_branch_code, k.br_ean, k.br_issue_year
from jt_bsum_orig_101016_BRA220  k
minus
select bs.br_branch_code, bs.br_ean, bs.br_issue_year
from  branch_summaries bs
where exists 
(select 1
 from bisd_220_201610101224old1657 p
 where p.br_branch_code = bs.br_branch_code
and p.br_ean = bs.br_ean
and p.br_issue_year = bs.br_issue_year)
and bs.br_branch_code = 'BRA220';

DELETE
from  branch_summaries bs
where exists 
(select 1
 from bisd_220_201610101224old1657 p
 where p.br_branch_code = bs.br_branch_code
and p.br_ean = bs.br_ean
and p.br_issue_year = bs.br_issue_year)
and bs.br_branch_code = 'BRA220';

--run PL version
--compare temp tables OK
select t.br_branch_code, t.br_ean,t.br_issue_year from bisd_220_20161010105240208253 t minus
select t.br_branch_code, t.br_ean,t.br_issue_year  from BISD_220_20161010105922176429 t
---
create table jt_bsum_orig_101016_BRA220 
as
select bs.*
from bisd_220_20161010105240208253 a, branch_summaries bs
where a.br_branch_code = bs.br_branch_code
and a.br_ean = bs.br_ean
and a.br_issue_year = bs.br_issue_year
and bs.br_branch_code = 'BRA220';



