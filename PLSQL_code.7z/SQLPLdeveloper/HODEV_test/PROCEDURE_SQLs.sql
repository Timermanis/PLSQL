create table pl_agent_net_sales_icsd_bin as

select bi.*,sysdate as WHEN_BINNED 
from pl_agent_net_sales_icsd_sus bi where 1=2
---------------------------------------------------------------------------------------------------------------------------
create table PL_BRANCH_SUMMARIES_BISD_BIN as

insert into PL_BRANCH_SUMMARIES_BISD_BIN
select bi.*,sysdate as WHEN_BINNED 
from PL_BRANCH_SUMMARIES_BISD_SUS bi, pl_branch_issues_sus b where bi.br_issue_year = b.bris_issue_year and bi.br_ean = b.bris_issue_year and bi.br_branch_code = b.bris_branch_code 
and b.bris_title_code is null;

delete from PL_BRANCH_SUMMARIES_BISD_SUS bi where (bi.br_issue_year,bi.br_ean,bi.br_branch_code) 
in (select  br_issue_year,br_ean,br_branch_code from PL_BRANCH_SUMMARIES_BISD_BIN)
--
insert into PL_BRANCH_SUMMARIES_BISD_BIN
select bi.*,sysdate as WHEN_BINNED 
from PL_BRANCH_SUMMARIES_BISD_SUS bi, branch_issues b, titles t where  
b.bris_title_code = t.titl_code 
and bi.br_issue_year = b.bris_issue_year 
and bi.br_ean = b.bris_ean 
and bi.br_branch_code = b.bris_branch_code 
and  t.titl_long_name like '%BULK%';

delete from PL_BRANCH_SUMMARIES_BISD_SUS
--
drop table pl_branch_mult_summaries_bin
------------------------
create table pl_branch_mult_summaries_bin as

select bi.*,sysdate as WHEN_BINNED 
from pl_branch_mult_summaries_sus bi where 1=2

select *
from pl_agent_net_sales_icsd_sus i  where i.icsd_title_code is null;

select distinct i.*
from pl_agent_net_sales_icsd_sus i, titles t  where i.icsd_title_code = t.titl_code 
and  t.titl_long_name like '%BULK%';
-----------------------
select *
from pl_agent_net_sales_sus k where k.net_title_code is null;

select *
from pl_agent_net_sales_sus k, titles t  where k.net_title_code = t.titl_code 
and  t.titl_long_name like '%BULK%';
-----------------------
select *
from pl_branch_issues_sus h where h.bris_title_code is null;

select *
from pl_branch_issues_sus h,  titles t  where h.bris_title_code = t.titl_code 
and  t.titl_long_name like '%BULK%';
-----------------------
select *
from pl_branch_summaries_sus bs,pl_branch_issues_sus b  where bs.br_issue_year = b.bris_issue_year and bs.br_ean = b.bris_issue_year and bs.br_branch_code = b.bris_branch_code 
and b.bris_title_code is null;

select *
from pl_branch_summaries_sus bs, branch_issues b, titles t where  
b.bris_title_code = t.titl_code 
and bs.br_issue_year = b.bris_issue_year 
and bs.br_ean = b.bris_ean 
and bs.br_branch_code = b.bris_branch_code 
and  t.titl_long_name like '%BULK%';
----------------------
select *
from pl_branch_mult_summaries_sus bm,pl_branch_issues_sus b where bm.bms_issue_year = b.bris_issue_year and bm.bms_ean = b.bris_issue_year and bm.bms_branch_code = b.bris_branch_code 
and b.bris_title_code is null;

select *
from pl_branch_mult_summaries_sus bm, branch_issues b, titles t where  
b.bris_title_code = t.titl_code 
and bm.bms_issue_year = b.bris_issue_year 
and bm.bms_ean = b.bris_issue_year 
and bm.bms_branch_code = b.bris_branch_code 
and  t.titl_long_name like '%BULK%';
-----------------------
select *
from PL_BRANCH_ISSUES_SUS br where br.bris_title_code is null;

select *
from PL_BRANCH_ISSUES_SUS br, titles t  where br.bris_title_code = t.titl_code 
and  t.titl_long_name like '%BULK%';
-----------------------------------------------------------------------------------------------------
