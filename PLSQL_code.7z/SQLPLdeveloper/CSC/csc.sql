select b.*
   
    from dw.csc_data b, DW.CALENDAR C
    where b.yearwk = c.fwk_num
    and c.dimension_key = c.fwk_id
    and inbound_calls is not null order by b.yearwk desc
    --and trunc(sysdate-7) between c.fwk_start_date and c.fwk_end_date;
    
    select nvl(max(O.ETL_RUN_NUM)+1,1)
                          -- into v_seq_num_to_use
                           FROM archive.operations_control_process o
                           where o.extract_stream = 'CSC_DATA'
                           AND O.COMPLETE_FLAG = 'Y';
                           
                           
 select count(*)
  
    from dw.csc_data b, DW.CALENDAR C
    where b.yearwk = c.fwk_num
    and c.dimension_key = c.fwk_id
    and inbound_calls is not null
    and trunc(sysdate-7) between c.fwk_start_date and c.fwk_end_date;
