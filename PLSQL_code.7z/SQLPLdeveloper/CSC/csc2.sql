 select *

        from txt_load_control a
        where a.tlc_type = 'CSC_DATA'
        and a.tlc_status like 'Failed%'
        and a.tlc_run_num = v_last_run_number;
