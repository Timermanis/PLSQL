begin
dbms_scheduler.DEFINE_PROGRAM_ARGUMENT(
program_name=>'summaries_run',
argument_position=>1,
argument_type=> 'NUMBER',
DEFAULT_VALUE=> 7);
end;

begin
dbms_scheduler.DEFINE_PROGRAM_ARGUMENT(
program_name=>'summaries_run',
argument_position=>2,
argument_type=>'VARCHAR2',
DEFAULT_VALUE=>'FALSE');
end;

begin
dbms_scheduler.DEFINE_PROGRAM_ARGUMENT(
program_name=>'summaries_run',
argument_position=>3,
argument_type=>'NUMBER',
DEFAULT_VALUE=>0);
end;

begin
dbms_scheduler.DEFINE_PROGRAM_ARGUMENT(
program_name=>'summaries_run',
argument_position=>4,
argument_type=>'VARCHAR2',
DEFAULT_VALUE=>'TRUE');
end;
begin
dbms_scheduler.enable('summaries_run');
end;



-- create a job pointing to a program and set both argument values
begin
dbms_scheduler.create_job('job_summaries_run',program_name=>'summaries_run');end;
dbms_scheduler.set_job_argument_value('job_summaries_run',1,7);
dbms_scheduler.set_job_argument_value('job_summaries_run',2,FALSE);
dbms_scheduler.set_job_argument_value('job_summaries_run',3,7);
dbms_scheduler.set_job_argument_value('job_summaries_run',2,TRUE);
dbms_scheduler.enable('job_summaries_run');


select * from all_scheduler_programs

-----------------------------------------------------------------------------------
begin
dbms_scheduler.create_program
(
program_name=>'dw.summaries_run',
program_action=>'NSSUMMARY_UTILS.REBUILD_ISSUE_SUMMARIES',
program_type=>'STORED_PROCEDURE',
number_of_arguments=>4, enabled=>FALSE) ;

end;
