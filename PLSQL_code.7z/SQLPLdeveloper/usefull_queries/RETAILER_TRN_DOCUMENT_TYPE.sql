select * from dw.RETAILER_TRN_DOCUMENT_TYPE t
