create table MIS_LOADS_RECIPIEN_bkp_060217 as
truncate table  MIS_LOADS_RECIPIENTS 

select * from MIS_LOADS_RECIPIENTS for update
truncate table MIS_LOADS_RECIPIENTS

insert into MIS_LOADS_RECIPIENTS select * from MIS_LOADS_RECIPIEN_bkp_060217
