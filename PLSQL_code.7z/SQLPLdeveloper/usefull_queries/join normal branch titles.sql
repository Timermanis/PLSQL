
select * from  branch_issues a, normal_issues b, titles c where
a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year
and BRIS_ISSUE_WEEK = NISS_ISSUE_WEEK
and b.niss_title_code = c.titl_code
and c.titl_code in (4270,
4767,
37955)
and a.bris_issue_year = 2015
4053
33148
37953
37951
37333
select a.bris_branch_code,a.bris_issue_week,a.bris_title_code,a.bris_ean,b.niss_ean from  branch_issues a, normal_issues b, titles c where
a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year
and BRIS_ISSUE_WEEK = NISS_ISSUE_WEEK
and b.niss_title_code = c.titl_code
and c.titl_code in (4285)
and a.bris_issue_year = 2016

select * agent_net_sales
000000000042702299
