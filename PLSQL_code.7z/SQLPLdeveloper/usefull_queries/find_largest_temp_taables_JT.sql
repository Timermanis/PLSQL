select t.owner, s.segment_name,s.segment_type,s.partition_name,s.tablespace_name, CAST((s.bytes/1073741824)as decimal (8,2)) Giggies, t.created 
from dba_segments s, dba_objects t
where s.segment_name = t.object_name
and t.object_type != 'SYNONYM'
and s.segment_name not like 'BIN%'
and t.object_type != 'MATERIALIZED VIEW'
--and t.object_name like '%JT%' 
and t.object_name like '%POR%'
order by s.bytes desc
