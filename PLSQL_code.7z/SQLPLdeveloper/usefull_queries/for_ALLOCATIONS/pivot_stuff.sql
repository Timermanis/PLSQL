select * from (
select  distinct R.OUT_NUM, r.out_urn urn,  m.iss_original_week week,(p.invoiced_QTY - p.return_QTY) total
from dw.plant_cust_iss_rtrn_summaries p
, dw.retailer r
, dw.media m
, dw.latest_wholesaler_mv w
, refmast.plant_issues_xref_base x
where x.pix_sap_id = m.plis_issue_num
and x.pix_orig_year = m.iss_original_year
and m.iss_partitioning_date = p.partitioning_date
and p.plant_issue_id = m.dimension_key
and p.outlet_id = r.dimension_key
and r.out_spoke_num = w.spo_num
and m.iss_original_year = 2016
and x.pix_legacy_title = 4062
and m.iss_handled_week_m in (10,9,8,7,6)
and r.out_urn  = 200649100831800
and r.OUT_NUM >= 100000
--and r.OUT_NUM <= 200000
order by urn,m.iss_original_week )
pivot 
(
   sum(total)
   for week in (10,9,8,7,6)
)
order by urn
-----------------------------------------

select  distinct R.OUT_NUM, r.out_urn urn,  m.iss_original_week week,nvl(p.invoiced_QTY,'0') - nvl(p.return_QTY ,'0') total
from dw.plant_cust_iss_rtrn_summaries p
, dw.retailer r
, dw.media m
, dw.latest_wholesaler_mv w
, refmast.plant_issues_xref_base x
where x.pix_sap_id = m.plis_issue_num
and x.pix_orig_year = m.iss_original_year
and m.iss_partitioning_date = p.partitioning_date
and p.plant_issue_id = m.dimension_key
and p.outlet_id = r.dimension_key
and r.out_spoke_num = w.spo_num
and m.iss_original_year = 2016
and x.pix_legacy_title = 4062
and m.iss_handled_week_m in (10,9,8,7,6)
and r.out_urn  = 200649100831800
and r.OUT_NUM >= 100000
--and r.OUT_NUM <= 200000
order by urn,m.iss_original_week
