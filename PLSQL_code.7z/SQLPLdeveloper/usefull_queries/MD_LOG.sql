select * from md_log m  order by m.logging_timestamp desc 

select * from md_log m where m.logging_text1 like '%Rows inserted (plant_iss_summ_driver)%' order by m.logging_timestamp desc 

select * from md_log m where m.logging_timestamp = '16-FEB-17 09.02.49.683248' order by m.logging_timestamp desc 

select * from summary_rebuild_audit for update and 

select * from ISSUE_SUMMARY_REBUILD_CONTROL t

SELECT * FROM DBA_source WHERE (text) LIKE '%PARTITION_START_DATE%'

SELECT * FROM PLANT_ISS_SUM_B s where s.pf_run_num = 2403
