
select c.titl_code title,b.niss_issue_day "WEEK DAY",b.niss_issue_week WEEK,b.niss_issue_year YEAR,b.niss_ean,sum(ag.NET_COMMITED_QUANTITY) sales,sum(ag.NET_COMMITED_QUANTITY - ag.net_credit_quantity) "TOTAL (SALES - CREDIT)",
NISS_COVER_MOUNT_FLAG 
from  agent_net_sales ag, branch_issues a, normal_issues b, titles c where

a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year

and b.niss_title_code = c.titl_code

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code
-----------------------
--and ag.net_issue_ean = 10909591708201
and c.titl_code = 5323
and b.niss_issue_year in (2017)
--and a.bris_issue_week = 52

group by c.titl_code, b.niss_issue_day,b.niss_issue_week,b.niss_issue_year,b.niss_ean,NISS_COVER_MOUNT_FLAG 
--order by b.niss_ean
order by b.niss_issue_year,b.niss_issue_week,b.niss_issue_day

--------------------------------------------------------------------------



-----------------------------------------------------------------------------------------------------------------------------

SELECT 
t.titl_code, n.niss_issue_day,n.niss_issue_week,n.niss_issue_year,n.niss_ean,n.NISS_COVER_MOUNT_FLAG 
FROM  agent_net_sales a

 --inner join  customers c  on
 --       c.cus_account_number = a.net_agent_account_number
 inner join BRANCH_ISSUES b on
        a.NET_ISSUE_EAN=b.BRIS_EAN
        and a.NET_ISSUE_YEAR=b.BRIS_ISSUE_YEAR
        and a.NET_BRANCH_CODE=b.BRIS_BRANCH_CODE  
 inner join normal_issues  n on
        n.niss_ean = b.bris_link_ean
        and n.niss_issue_year = b.bris_link_issue_year
 inner join titles t on
        t.titl_code = n.niss_title_code
---------------------------------------------------------------
 where t.titl_code = 14276
and n.niss_issue_year = 2016       
        group by t.titl_code, n.niss_issue_day,n.niss_issue_week,n.niss_issue_year,n.niss_ean,n.NISS_COVER_MOUNT_FLAG 
order by n.niss_ean;

-----------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------


SELECT 
t.titl_code, n.niss_issue_day,n.niss_issue_week,n.niss_issue_year,n.niss_ean,n.NISS_COVER_MOUNT_FLAG 
FROM  agent_net_sales a

 inner join  customers c  on
        c.cus_account_number = a.net_agent_account_number
 inner join BRANCH_ISSUES b on
        a.NET_ISSUE_EAN=b.BRIS_EAN
        and a.NET_ISSUE_YEAR=b.BRIS_ISSUE_YEAR
        and a.NET_BRANCH_CODE=b.BRIS_BRANCH_CODE  
 inner join normal_issues  n on
        n.niss_ean = b.bris_link_ean
        and n.niss_issue_year = b.bris_link_issue_year
 inner join titles t on
        t.titl_code = n.niss_title_code
---------------------------------------------------------------
 where t.titl_code = 16435
and n.niss_issue_year = 2016       
        group by t.titl_code, n.niss_issue_day,n.niss_issue_week,n.niss_issue_year,n.niss_ean,n.NISS_COVER_MOUNT_FLAG 
order by n.niss_ean
------------------------------------------------------

select c.titl_code title,b.niss_issue_day "WEEK DAY",b.niss_issue_week WEEK,b.niss_issue_year YEAR,b.niss_ean,sum(ag.NET_COMMITED_QUANTITY) sales,sum(ag.NET_COMMITED_QUANTITY - ag.net_credit_quantity) "TOTAL SALES - CREDIT",
NISS_COVER_MOUNT_FLAG 
from  agent_net_sales ag, branch_issues a, normal_issues b, titles c where

a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year

and b.niss_title_code = c.titl_code

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code
-----------------------
and ag.net_branch_code = 'BRA550'
and ag.net_issue_ean = 977174260110703
--and c.titl_code = 90959
and b.niss_issue_year in (2016,2017)
--and a.bris_issue_week = 52

group by c.titl_code, b.niss_issue_day,b.niss_issue_week,b.niss_issue_year,b.niss_ean,NISS_COVER_MOUNT_FLAG 
--order by b.niss_ean
order by b.niss_issue_year,b.niss_issue_week,b.niss_issue_day
-----------------------------
--977135942316109
select c.titl_code title,b.niss_issue_day "WEEK DAY",b.niss_issue_week WEEK,b.niss_issue_year YEAR,b.niss_ean,sum(ag.NET_COMMITED_QUANTITY) sales,sum(ag.NET_COMMITED_QUANTITY - ag.net_credit_quantity) "TOTAL SALES - CREDIT",
NISS_COVER_MOUNT_FLAG 
from  agent_net_sales ag, branch_issues a, normal_issues b, titles c where

a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year

and b.niss_title_code = c.titl_code

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code
-----------------------
and ag.net_branch_code = 'BRA550'
and ag.net_issue_ean = 977135942316109
--and c.titl_code = 90959
and b.niss_issue_year in (2016,2017)
--and a.bris_issue_week = 52

group by c.titl_code, b.niss_issue_day,b.niss_issue_week,b.niss_issue_year,b.niss_ean,NISS_COVER_MOUNT_FLAG 
--order by b.niss_ean
order by b.niss_issue_year,b.niss_issue_week,b.niss_issue_day
