create table jt_issues_missing_BRIS as
select distinct i.iss_name, i.iss_num,z.barcode from archive.Zpx_Plnt_Iss_Stg_Bak z,refmast.issues i where z.issue_id = i.iss_num
and z.legacy_titl_code = ' ' and z.act_on_sale_date is not null
