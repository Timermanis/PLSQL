SELECT --PIX_LEGACY_EAN,
       LTRIM(MAX(SYS_CONNECT_BY_PATH(PIX_SAP_ID,', '))
       KEEP (DENSE_RANK LAST ORDER BY curr),', ') AS compos
FROM   (SELECT PIX_LEGACY_EAN,
               PIX_SAP_ID,
               ROW_NUMBER() OVER (PARTITION BY PIX_LEGACY_EAN ORDER BY PIX_SAP_ID) AS curr,
               ROW_NUMBER() OVER (PARTITION BY PIX_LEGACY_EAN ORDER BY PIX_SAP_ID) -1 AS prev
        FROM   (

select p.PIX_SAP_ID, p.PIX_LEGACY_EAN, p.PIX_YEAR,p.PIX_BRANCH_CODE from refmast.plant_issues_xref_base p, titles@mis.world t
where
p.PIX_LEGACY_TITLE = t.titl_code and
-- p.pix_ean = p.pix_legacy_ean and
 p.PIX_LEGACY_TITLE IS NOT NULL  and
 p.pix_plant_on_sale_date IS NOT NULL and
 p.pix_issue_type not in  ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
 p.pix_spoke_code != '745' and
 p.PIX_BRANCH_CODE = 'BRA350' and
 p.pix_official_on_sale_date in (to_date(trim(to_char(sysdate)))-1) and
   t.titl_long_name  not like '%BULK%'  
   and p.PIX_LEGACY_EAN in (select PIX_LEGACY_EAN from (select count (p.PIX_SAP_ID) count, p.PIX_LEGACY_EAN, p.PIX_YEAR,p.PIX_BRANCH_CODE from refmast.plant_issues_xref_base p, titles@mis.world t
where
p.PIX_LEGACY_TITLE = t.titl_code and
-- p.pix_ean = p.pix_legacy_ean and
 p.PIX_LEGACY_TITLE IS NOT NULL  and
 p.pix_plant_on_sale_date IS NOT NULL and
 p.pix_issue_type not in  ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
 p.pix_spoke_code != '745' and
 p.PIX_BRANCH_CODE = 'BRA350' and
 p.pix_official_on_sale_date in (to_date(trim(to_char(sysdate)))-1) and
   t.titl_long_name  not like '%BULK%'   
   group by p.PIX_LEGACY_EAN, p.PIX_YEAR,p.PIX_BRANCH_CODE
   having count (p.PIX_SAP_ID) > 1)) 
   
   )) --where PIX_LEGACY_EAN = 977001645919206
GROUP BY PIX_LEGACY_EAN
CONNECT BY prev = PRIOR curr AND PIX_LEGACY_EAN = PRIOR PIX_LEGACY_EAN
START WITH curr = 1;
