
select BRANCH_ID,task,max(log_time) "LAST LOG"
 from sap_extract_log l
where l.log_time >= (select max(log_time) from sap_extract_log where task = 'ERR' ) --and branch_id = 'BRA560'
group by BRANCH_ID,task
order by max(log_time)desc,BRANCH_ID 

select *
 from sap_extract_log l
where branch_id in ('BRA550')
--and task like '%TWSD%'
--and l.log_time >= (select max(log_time) from sap_extract_log where task = 'Started SAP transaction extract' ) 
order by (log_time) desc

select distinct MULTIPLE from SE_CAL_MULTIPLE_SSS order by MULTIPLE

AGUD - Customer/URN Error: 0000162046, 220162046000900

--Issue ID: 000000000383740015 not found for Spoke ID: 550
select *
 from sap_extract_log l --where TASK like 'ICSD - Issue Customer Sales completed'
where  TASK like '%Error' and l.log_time > ('16-08-2015')--BRANCH_ID  in('BRA320') and 
order by (log_time) desc 

select * from customers h where h.CUS_TRADING_NAME like '%EARLS SUPERMARKET%'

select * from customer_x_ref where CCR_CUST_URN = 550162876000000;--162876

select * from customers h where h.cus_account_number =  550162876000000 
select * from agent_net_sales a where a.net_agent_account_number = 502963010627700
 
select * from customer_x_ref x where x.ccr_legacy_box_no = 5083

select * from customer_x_ref x where x.ccr_bus_partner_id=162046;
select * from customer_x_ref where CCR_CUST_URN = 502963010627700;
select * from customer_x_ref where CCR_CUST_URN = 850156867000800

503103119837900
503103126342800
850156867000800


select *
 from sap_extract_log l --where TASK like 'ICSD - Issue Customer Sales completed'
--where  task like '%URNs found to process%'
order by (log_time) desc 

select last_number - 1
from user_sequences u
where u.SEQUENCE_NAME = 'ETL_RUN_NUM_SEQ'

select * from plant_issues_xref x where x.PIX_SAP_ID = 000000000491880003 

select * from titles t where t.titl_code = 49188
