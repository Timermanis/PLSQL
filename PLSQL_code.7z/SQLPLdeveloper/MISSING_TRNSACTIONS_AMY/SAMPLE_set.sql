create table jt_mising_tran_061216 as
select r.customer_id,r.issue_id,r.document_type,r.item_type,r.quantity,c.document_type ikw_document_type,c.item_type ikw_item_type,c.quantity ikw_quantity from archive.zpx_rtrn_cdn_stg_bak c,archive.zpx_rtrn_stg_bak r
where r.issue_id = c.issue_id
and r.customer_id = c.customer_id
and r.document_type = c.document_type
--and r.issue_id = '000000000374781879'
and r.document_type = 'ZCLC'
and c.item_type = 'ZRUC'--MIS
and r.item_type != 'ZRUC'
and r.item_type != 'ZROC'
and r.transaction_date > '01-NOV-2016'
and r.transaction_date < '10-NOV-2016'
order by r.customer_id

select * from archive.zpx_rtrn_stg_bak t where (t.customer_id, t.issue_id) in 
(select t.customer_id, t.issue_id from jt_mising_tran_061216) order by t.issue_id, t.customer_id

select t.issue_id, count(*) from jt_mising_tran_061216 t
group by issue_id


select distinct z.customer_id from jt_mising_tran_061216 z where z.issue_id = 000100000003990013
0000132483
0000106975

select * from archive.zpx_rtrn_stg_bak t where t.issue_id = '000100000003990013' and t.customer_id in (132483,106975)
