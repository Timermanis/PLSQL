select * from JT_MISING_TRAN_061216 t

select * from archive.zpx_rtrn_cdn_stg_bak r where r.issue_id = '000000000410090059' and r.customer_id = 100423;
select * from archive.zpx_rtrn_stg_bak r where r.issue_id = '000000000410090059'  and r.customer_id = 100423

select * from archive.zpx_rtrn_cdn_stg_bak r where r.issue_id = '410090059' and r.customer_id = 105801;
select * from archive.zpx_rtrn_stg_bak r where r.issue_id = '000000000566230001'  and r.customer_id = 105801

10	0000105801	000000000566230001	ZCLC	ZROC	74.000	ZCLC	ZRUC	-49.000


select r.*,t.typ_copies_invoiced_flag,t.typ_credit_flag, t.typ_document_type_code, t.typ_item_type_code, c.day_dte 
from retailer_transaction r,media m,retailer z,retailer_trn_report_type t, calendar c where
c.dimension_key = r.day_id and
t.dimension_key = r.reporting_trn_type_id and
r.plant_issue_id = m.plis_id and
z.out_id = r.outlet_id and
m.plis_issue_num = 000000000008364152 and
z.out_num = 100423

select * from dw.plant_cust_iss_rtrn_sum_a p where p.out_num = 100423 and p.plant_issue_id = '000000000008364152'
