select * from JT_TESCO_041116 t;

select * from jt_tesco_041116_ikw

select * from dw.retailer_transaction r where r. = 123567  and r.plant_issue_id = '000000000572140002' 

select * from dw.


select * from archive.zpx_rtrn_cdn_stg_bak r where r.customer_id = 123567  and r.issue_id = '000000000572140002'
