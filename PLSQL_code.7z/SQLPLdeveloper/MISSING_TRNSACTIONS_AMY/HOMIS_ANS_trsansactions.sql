select * from agent_net_sales a where a.net_issue_ean = 977239799000402 and a.net_agent_account_number = 502963068211500
 
 create table jt_bkp_ANS_04112016_amy as
 select * from agent_net_sales a where a.net_issue_ean = 977239799000402 and a.net_agent_account_number = 502963068211500 for update



select * from plant_issues_xref x where x.PIX_EAN = 977239799000402--000000000572140002

select * from customer_x_ref c where c.ccr_cust_urn = 502963068211500--123567
