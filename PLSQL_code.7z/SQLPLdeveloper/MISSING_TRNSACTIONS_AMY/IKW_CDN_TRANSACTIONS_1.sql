create table jt_tesco_041116 as
select * from archive.zpx_rtrn_stg_bak r where r.customer_id = 123567  and r.issue_id = '000000000572140002'

select * from support.jt_tesco_041116
select * from plant_issues_xref x where x.PIX_EAN = 977239799000402--000000000572140002

select * from customer_x_ref c where c.ccr_cust_urn = 502963068211500--123567


create table jt_tesco_041116_ikw  as

select * from archive.zpx_rtrn_cdn_stg_bak r where r.customer_id = 123567  and r.issue_id = '000000000572140002';--IKW
select * from archive.zpx_rtrn_stg_bak r where r.customer_id = 123567  and r.issue_id = '000000000572140002'--MIS
