select * from archive.zpx_rtrn_stg_bak z where-- z.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_rtrn_stg_bak z) 
--and 
z.issue_id = '000000000572140002' and z.customer_id = 123567

select * from archive.zpx_rtrn_cdn_stg_bak z where-- z.etl_run_num_seq = (select max(etl_run_num_seq) from archive.zpx_rtrn_stg_bak z) 
--and 
z.issue_id = '000000000572140002' and z.customer_id = 123567

select r.* from retailer_transaction r,media m,retailer z where
r.plant_issue_id = m.plis_id and
z.out_id = r.outlet_id and
m.plis_issue_num = 000000000572140002 and
z.out_num = 123567

  where r.out_num is not null

select * from media where OUT_NUM = 123567
select * from retailer where OUT_NUM = 123567

select * from plant_cust_iss_rtrn_sum_a p where p.out_num = 123567 and p.plant_issue_id = 55869303

select * from refmast.plant_issues_xref_base x where x.pix_sap_id = '000000000572140002'

select * from refmast.plant_issues_xref_base x where x.pix_sap_id = '000000000572140002'
--archive transactions
select * from bkp_arc_cus_123567;
select * from bkp_arc_cus_123567_MIS
