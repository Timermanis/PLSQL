select * from archive.zpx_rtrn_cdn_stg_bak r where r.document_type = 'ZCLC' and r.item_type = 'ZROC' and r.transaction_date > '01-DEC-2016'
0000104358 000000000090014233
0000139100 000000000374781879

select * from archive.zpx_rtrn_cdn_stg_bak r where r.issue_id = '000000000090014233' and r.customer_id = 104358
select * from archive.zpx_rtrn_cdn_stg_bak r where r.issue_id = '410090059' and r.customer_id = 139100;
select * from archive.zpx_rtrn_stg_bak r where r.issue_id = '410090059'  and r.customer_id = 139100
select * from archive.zpx_rtrn_stg_bak r where r.issue_id =  '000000000090014233' and r.customer_id =  104358

with a as
(select r.customer_id,r.issue_id,r.document_type,r.item_type,r.quantity,c.document_type,c.item_type,c.quantity from archive.zpx_rtrn_cdn_stg_bak c,archive.zpx_rtrn_stg_bak r 
where r.issue_id = c.issue_id 
and r.customer_id = c.customer_id
and r.document_type = c.document_type
--and r.issue_id = '000000000374781879' 
and r.document_type = 'ZCLC'
and c.item_type = 'ZRUC'
and r.item_type != 'ZRUC'
and r.transaction_date > '01-NOV-2016'
and r.transaction_date < '10-NOV-2016'
order by r.customer_id)
select count(distinct a.customer_id||a.issue_id),a.customer_id,a.issue_id from a
group by a.customer_id,a.issue_id having count(distinct a.customer_id||a.issue_id) >1



select * from archive.zpx_rtrn_stg_bak r where r.customer_id = 122070 and r.issue_id in
(000000000380550001,
000000000473360001,
000000000243090001,
000000000473370001
)
