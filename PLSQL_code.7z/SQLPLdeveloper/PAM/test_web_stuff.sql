delete from LOG_PUBLISHER_AGENT_MATRIX t where DATES < '30-MAY-2016'

select * from PUBLISHER_AGENT_MATRIX t where t.puba_date_to between '29-MAY-16' and '31-MAY-16'

select * from PUBLISHER_AGENT_MATRIX z where z.puba_agent_account_number = 503103123709200 and z.puba_supply_org_code = 3532

select PUBA_AGENT_ACCOUNT_NUMBER,PUBA_SUPPLY_ORG_CODE,PUBA_DATE_TO from publisher_agent_matrix t,customer_x_ref x   where 
t.puba_agent_account_number = x.ccr_cust_urn and
t.puba_supply_org_code=3532  
and  x.ccr_bus_partner_id in (134536)
and t.puba_date_to = (select max(t.puba_date_to) from dual)

update publisher_agent_matrix set PUBA_DATE_TO = sysdate - 1 where (PUBA_AGENT_ACCOUNT_NUMBER,PUBA_SUPPLY_ORG_CODE,PUBA_DATE_TO) in
(
select PUBA_AGENT_ACCOUNT_NUMBER,PUBA_SUPPLY_ORG_CODE,PUBA_DATE_TO from publisher_agent_matrix t,customer_x_ref x   where 
t.puba_agent_account_number = x.ccr_cust_urn and
t.puba_supply_org_code=3532 
and  x.ccr_bus_partner_id in (134536)
and t.puba_date_to = (select max(t.puba_date_to) from dual ) )

update publisher_agent_matrix set PUBA_DATE_TO = sysdate - 1 where (PUBA_AGENT_ACCOUNT_NUMBER,PUBA_SUPPLY_ORG_CODE,PUBA_DATE_TO) in ( select PUBA_AGENT_ACCOUNT_NUMBER,PUBA_SUPPLY_ORG_CODE,PUBA_DATE_TO from publisher_agent_matrix t,customer_x_ref x where t.puba_agent_account_number = x.ccr_cust_urn and t.puba_supply_org_code=3532 and x.ccr_bus_partner_id in (134536) and t.puba_date_to = (select max(t.puba_date_to) from dual ) )
