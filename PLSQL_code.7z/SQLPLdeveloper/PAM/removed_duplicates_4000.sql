select * from publisher_agent_matrix t where PUBA_DATE_TO > sysdate and t.puba_supply_org_code=2413     and t.puba_agent_account_number in 
(select x.ccr_cust_urn from customer_x_ref x 
where x.ccr_bus_partner_id in (158534 )) 

update publisher_agent_matrix t set t.puba_date_to = sysdate - 1 where t.puba_supply_org_code=2413 and t.puba_agent_account_number in 
(select x.ccr_cust_urn from customer_x_ref x 
where x.ccr_bus_partner_id in (158534 )) 

2413	502963031442900
2413	502963085700100
2413	502963072153100
2413	502963085521200
3092	502963085521200
3092	502963085700100
3092	502963031442900
3092	502963072153100
3092	502963031440500

select * from publisher_agent_matrix t where PUBA_DATE_TO > sysdate and PUBA_DATE_TO < '30-DEC-4000' and PUBA_DATE_TO > sysdate

select puba_supply_org_code,puba_agent_account_number,count(*) from publisher_agent_matrix t where  PUBA_DATE_TO > sysdate 
group by puba_supply_org_code,puba_agent_account_number having count(*)>1

select * from publisher_agent_matrix t where PUBA_DATE_TO > sysdate and t.puba_supply_org_code in (2413,3092)     and t.puba_agent_account_number in 
(502963072153100,
502963085521200,
502963031442900,
502963072153100,
502963031440500,
502963085700100,
502963031442900,
502963085700100,
502963085521200)


delete from publisher_agent_matrix where (puba_supply_org_code,puba_agent_account_number,PUBA_DATE_FROM) in (
select puba_supply_org_code,puba_agent_account_number,max(PUBA_DATE_FROM) from publisher_agent_matrix t where PUBA_DATE_TO > sysdate and t.puba_supply_org_code in (2413,3092)     and t.puba_agent_account_number in 
(502963072153100,
502963085521200,
502963031442900,
502963072153100,
502963031440500,
502963085700100,
502963031442900,
502963085700100,
502963085521200) group by puba_supply_org_code,puba_agent_account_number)

create table jt_publisher_agent_matrix_DUP as
select puba_supply_org_code,puba_agent_account_number,max(PUBA_DATE_FROM) PUBA_DATE_FROM from publisher_agent_matrix t where PUBA_DATE_TO > sysdate and t.puba_supply_org_code in (2413,3092)     and t.puba_agent_account_number in 
(502963072153100,
502963085521200,
502963031442900,
502963072153100,
502963031440500,
502963085700100,
502963031442900,
502963085700100,
502963085521200) group by puba_supply_org_code,puba_agent_account_number

select * from jt_publisher_agent_matrix_DUP
