select * from TXT_FINANCE_GL_BAK t where t.etl_run_date_num in( 20151127,20160209);-- to_char((sysdate-422),'YYYYMMDD');
select * from TXT_CSC_DATA_BAK t where t.etl_run_date_num in (20151102,20160218);--<  to_char((sysdate-170),'YYYYMMDD');
select * from TXT_AXON_CRU_DATA_BAK t where t.etl_run_date_num in (20151109,20160218,20160505)--<  to_char((sysdate-170),'YYYYMMDD')

select distinct t.etl_run_date_num from TXT_FINANCE_GL_BAK t where t.etl_run_date_num like '2015%'
select distinct t.etl_run_date_num from TXT_CSC_DATA_BAK t where t.etl_run_date_num like '2015%'
select distinct t.etl_run_date_num from TXT_AXON_CRU_DATA_BAK t where t.etl_run_date_num like '2015%'
