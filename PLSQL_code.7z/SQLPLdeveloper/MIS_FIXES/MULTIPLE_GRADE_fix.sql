select c.* from customers c where c.cus_multiple_grade_code = 'INQ3'

update customers c set CUS_MULTIPLE_GRADE_CODE = 'INQ3' where c.CUS_MULTIPLE_GRADE_CODE = 'INQ' and c.cus_account_number in 
(select x.ccr_cust_urn from customer_x_ref x where x.ccr_bus_partner_id in (113362,
136604,
142252,
154623
))

select * from customers w
