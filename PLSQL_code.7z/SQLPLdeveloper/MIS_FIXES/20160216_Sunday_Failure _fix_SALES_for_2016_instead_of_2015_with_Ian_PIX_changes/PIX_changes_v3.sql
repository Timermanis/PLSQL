select * from refmast.plant_issues_xref_base x where x.PIX_LEGACY_TITLE = 40124 and x.PIX_YEAR = 2016--977096337320601--977096337320607
select z.issue_id,sum(z.quantity) from archive.zpx_rtrn_stg_bak z where  z.issue_id like '00000000005135231%' and z.customer_id = 106515 and z.document_type in ('JLF','ZRE')
group by z.issue_id
CAWT_TITLE_CODE
34535
40124 --the same sap id for both
select * from refmast.plant_issues_xref_base x where x.PIX_LEGACY_TITLE = 34535 and x.PIX_YEAR = 2016--977096337320601--977096337320607
select z.issue_id,sum(z.quantity) from archive.zpx_rtrn_stg_bak z where  z.issue_id like '00000000005135231%' and z.customer_id = 106515 and z.document_type in ('JLF','ZRE')
group by z.issue_id
select * from refmast.plant_issues_xref_base x where x.PIX_LEGACY_TITLE = 34535 and x.PIX_YEAR = 2016

select * from archive.zpx_rtrn_stg_bak z where z.transaction_date >  '10-FEB-2016' and z.customer_id = 106515 

select * from archive.zpx_rtrn_stg_bak z where  z.issue_id like '00000000005135231%' and z.customer_id = 106515 and z.document_type in ('JLF','ZRE') --BRA270
-----------------------------------------
select * from refmast.plant_issues_xref_base x where x.PIX_LEGACY_TITLE in (40124,34535) and x.PIX_YEAR = 2016--977096337320601--977096337320607

--this customer 106515 should have zone title 40124


select * from refmast.plant_issues_xref_base x where x.PIX_ean = 843161800412801

843161800412801
843161800415901
843161800418001
843161800421001
