-- PIX needs to have the main legacy title code updated with 5135 and the maintenance package for PIX needs to be altered (fix_gen_wkly) to prevent history from being corrupted.

update  refmast.plant_issues_xref_base x set PIX_MAIN_LEGACY_TITLE = 5135 where x.PIX_LEGACY_TITLE in (40124,34535) and x.PIX_MAIN_LEGACY_TITLE is null


select * from refmast.plant_issues_xref_base x where x.PIX_LEGACY_TITLE in (40124,34535,5135) and x.PIX_YEAR in (2015,2016)
