--select * from normal_issues n where n.niss_title_code = 40124 and n.niss_issue_year = 2016; !!!!!!!!!!!!!!!!!!!!!!!!!!!   NO ISSUES 2016
select * from normal_issues n where n.niss_title_code = 5135  and n.niss_issue_year in (2015,2016)
select * from normal_issues n where n.niss_title_code = 40124  and n.niss_issue_year = 2016;
select * from normal_issues n where n.niss_title_code = 5135  and n.niss_issue_year = 2016;

--Basically, if, linking on the ean and year, if the title code is 40124 in branch issues, then the normal issues title code must be the same.

update normal_issues n set n.niss_title_code = 40124 where 
exists
(select 1 from branch_issues b
where b.bris_link_ean = n.niss_ean
and b.bris_link_issue_year = n.niss_issue_year
and b.bris_title_code = 40124)

select * from branch_issues b where b.bris_title_code = 34535 and b.bris_issue_year = 2016

select * from agent_net_sales a where a.net_issue_ean = 30345351601001
-------------------Executed-----------------------------
---Ian email----
update normal_issues n2
set n2.niss_title_code = 40124
where (n2.niss_ean, n2.niss_issue_year) in 
(select n1.niss_ean, n1.niss_issue_year
from branch_issues bi, normal_issues n1
where bi.bris_link_ean = n1.niss_ean
and bi.bris_link_issue_year = n1.niss_issue_year
and bi.bris_title_code = 40124 
and bi.bris_title_code != n1.niss_title_code)
------
select * from plant_issues_xref x where x.PIX_LEGACY_TITLE in (40124,34535) and x.PIX_LEGACY_YEAR in (2015,2016)


plant_issues_xref
   
/*
Jan,
It seems all the data in ANS and Branch issues are for the 977 EAN with the Z4 title code (40124).
The Hub does not handle the title so what has happened here is that the Normal issue skeletons have been created for the EANs with the MAIN title code (5135).

Normally, when the hub handles the title, any spoke attempting to use the same EAN for a different (zone) title code, would cause the EAN to be translated into a JM one., resulting in a normal issue for the main title and one for the zone (or spoke).

When the hub doesn�t handle, the spoke EAN remains the same and as a skeleton exists for the EAN, it links to it. The problem there is that the NISS_TITLE_CODE does not get updated with the zone code.

The fix for this is to update the title code on normal issues for all the issues needed.

The issue generation will continue to created with the main title code.

I also noticed that the pix_main_legacy_title is not populated in plant_issues_xref_base.
This would then be the reason why the issues are not being generated as JM ones.


In summary,
The normal issues need to have their title codes updated from 5135 to 40124, PIX needs to have the main legacy title code updated with 5135 and the maintenance package for PIX needs to be altered (fix_gen_wkly) to prevent history from being corrupted.

Let me knoe if you need any further info.

Ian


*/
