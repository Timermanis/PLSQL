
select * from refmast.plant_issues_xref_base x where x.PIX_ean = 843161800421001 for update

--843161800412801
--843161800415901
--843161800418001
--843161800421001
