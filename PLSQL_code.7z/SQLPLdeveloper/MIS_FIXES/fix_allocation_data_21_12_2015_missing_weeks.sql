select * from titles t where t.titl_long_name like '%Strathspey & Badenock Herald%'
select * from titles t where t.titl_long_name like '%STRATHSPEY%'



select * from customer_x_ref x where x.ccr_bus_partner_id=124179 --133324
select * from plant_issues_xref p where p.PIX_EAN in   --
--create table jt_bkup_211215_bris as
select b.bris_branch_code,b.bris_issue_week,b.bris_ean,b.bris_title_code,b.bris_link_ean from branch_issues b where b.bris_title_code = 5615 and b.bris_issue_year = 2015 --for update
--create table jt_bkup_211215_nis as
select n.niss_issue_week,n.niss_ean, n.niss_issue_year,n.niss_title_code from normal_issues n where n.NISS_TITLE_CODE = 5615 and n.niss_issue_year = 2015 --for update



select * from agent_net_sales a where a.net_agent_account_number = 502963014581800 and a.net_issue_year=2015 and a.net_issue_ean =  977004372238249


