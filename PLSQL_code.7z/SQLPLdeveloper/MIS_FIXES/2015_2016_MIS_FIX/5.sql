select * from titles t where t.titl_long_name like upper('%Edinburgh Evening News%')-- Fraserburgh Herald
select * from titles t where t.titl_long_name like '%ARGYLLSHIRE%ADVER%'
select * from titles t where t.titl_code = 138

4048

select * from customer_x_ref x where x.ccr_bus_partner_id=124179 --133324
select * from plant_issues_xref p where p.PIX_EAN in   --

select * from branch_issues b where b.bris_title_code = 138     and b.bris_issue_year = 2015  and b.bris_branch_code = 'BRA550' order by BRIS_ISSUE_WEEK,briS_ISSUE_day for update
select * from normal_issues n where n.niss_title_code = 138 and n.niss_issue_year = 2015  order by nisS_ISSUE_WEEK,nisS_ISSUE_day for update

select * from normal_issues n where n.niss_title_code = 32602 and n.niss_issue_year = 2014  order by nisS_ISSUE_WEEK,nisS_ISSUE_day 

select * from agent_net_sales a where  a.NET_BRANCH_CODE='BRA550' and a.net_issue_ean =  977174078016352--a.net_agent_account_number = 977136075256453 and
select * from agent_net_sales a where  a.net_issue_ean =  977174078016352

select * from normal_issues n where n.niss_ean = 10326021452601
select * from branch_issues b where b.bris_ean = 10326021452601 

select * from branch_issues b where b.bris_title_code = 138 and b.bris_issue_year >= 2014   order by BRIS_ISSUE_year,BRIS_ISSUE_WEEK,briS_ISSUE_day 
select * from normal_issues n where n.niss_title_code = 138 and n.niss_issue_year >= 2014  order by n.niss_issue_year,nisS_ISSUE_WEEK,nisS_ISSUE_day

