select * from branch_issues b where b.bris_title_code = 26991 and b.bris_issue_year in (2015,2016) and b.bris_branch_code = 'BRA740' order by b.bris_issue_year, b.bris_issue_week for update; -- moved br_is away to week 2016/54 and related ans to 2015
select * from branch_issues b where b.bris_ean = 977175662502153 and b.bris_branch_code = 'BRA740' and b.bris_issue_year = 2015 order by b.bris_issue_year, b.bris_issue_week 
select * from normal_issues n where n.niss_title_code = 26991 and n.niss_issue_year in (2015,2016) for update
select * from normal_issues n where n.niss_ean =  977175662502153 and n.niss_issue_year = 2015
select * from titles t where t.titl_long_name like '%MATCH OF THE DAY%'

select * from branch_issues b where b.bris_title_code = 42897 and b.bris_issue_year in (2015,2016) and b.bris_branch_code = 'BRA740' order by b.bris_issue_year, b.bris_issue_week for update; -- moved br_is away to week 2016/54 and related ans to 2015
select * from branch_issues b where b.bris_ean = 977175662502153 and b.bris_branch_code = 'BRA740' order by b.bris_issue_year, b.bris_issue_week 
select * from normal_issues n where n.niss_title_code = 26991 and n.niss_issue_year in (2015,2016) for update
select * from normal_issues n where n.niss_ean =  977175662502153
select * from agent_net_sales a where a.net_issue_ean =977175662594649  and a.net_branch_code = 'BRA740' and a.net_issue_year = 2015
3760	CEASED MATCH OF THE DAY  (FRTL
9900	MATCH OF THE DAY ANNUAL
26991	MATCH OF THE DAY
980575	*MATCH OF THE DAY
32285	MATCH OF THE DAY M/V
42897	MATCH OF THE DAY TESCO MV


create table jt_290116_mising_sales_ans as
select * from agent_net_sales a where a.net_issue_ean =977175662502153  and a.net_branch_code = 'BRA740' and a.net_issue_year = 2015

create table jt_290116_misin_sales_all_rtrn as
select * from zpx_rtrn_stg_bak b where b.issue_id = '000000000269912304' and b.spoke_id = 740 and b.document_type = 'JLF'

 create table jt_290116_misin_sales_rtrn_exi as
select unique z.* from jt_290116_mising_sales_ans a,zpx_rtrn_stg_bak z,customer_x_ref x
where z.customer_id = x.ccr_bus_partner_id
and a.net_agent_account_number = x.ccr_cust_urn
and a.net_issue_ean = z.pix_ean
and a.net_issue_year = 2015
and z.issue_id = '000000000269912304'
and z.document_type = 'JLF'


select * from jt_290116_misin_sales_all_rtrn
minus
select * from jt_290116_misin_sales_rtrn_exi

 create table jt_290116_misin_sales_rtrn_rec as
(select * from jt_290116_misin_sales_all_rtrn
minus
select * from jt_290116_misin_sales_rtrn_exi)

select * from jt_290116_misin_sales_all_rtrn
intersect
select * from jt_290116_misin_sales_rtrn_exi

select * from  jt_290116_misin_sales_rtrn_rec 
select * from jt_290116_misin_sales_rtrn_exi

select sum(a.net_commited_quantity) from agent_net_sales a where a.net_issue_ean =977175662502153  and a.net_branch_code = 'BRA740' and a.net_issue_year = 2015
select sum(QUANTITY) from zpx_rtrn_stg_bak b where b.issue_id = '000000000269912304' and b.spoke_id = 740 and b.document_type = 'JLF' 
select * from zpx_rtrn_stg_bak b where b.issue_id = '000000000269912304' and b.spoke_id = 740 and b.document_type = 'JLF' and ETL_RUN_NUM_SEQ = 1988


select sum(tot) from
(select sum(t.icsd_quantity) tot from icsd_740_20151229032944664860 t where ICSD_ISSUE_ean =977175662502153 union--29/12/15 2029 2760
select sum(t.icsd_quantity) tot from icsd_740_20151230030231826864 t where ICSD_ISSUE_ean =977175662502153)--30/12/15 1931
