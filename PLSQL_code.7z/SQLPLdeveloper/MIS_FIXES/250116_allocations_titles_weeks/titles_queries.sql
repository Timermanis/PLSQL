select * from titles t where t.titl_long_name like upper('%Badenock Herald%')--5615
select * from titles t where t.titl_long_name like upper('%Huntly Express%')--4842
select * from titles t where t.titl_long_name like upper('%Inverness Courier Friday%')--4867 37702
select * from titles t where t.titl_long_name like upper('%Groats Journal%')--4911
select * from titles t where t.titl_long_name like upper('%Northern Scot%')--5250
select * from titles t where t.titl_long_name like upper('%Northern Times%')--5251Rosshire Journal
select * from titles t where t.titl_long_name like upper('%Rosshire Journal%')
select * from titles t where t.titl_long_name like upper('%Campbeltown Courier%')--4270
select * from titles t where t.titl_long_name like upper('%Match of the Day%')--26991


select * from branch_issues b where b.bris_title_code = 37708 and b.bris_issue_year in (2015,2016) for update; -- moved br_is away to week 2016/54 and related ans to 2015
select * from normal_issues n where n.niss_title_code = 37708 and n.niss_issue_year in (2015,2016) for update

select * from branch_issues b where b.bris_title_code = 5615 and b.bris_issue_year in (2015,2016) for update; -- moved br_is away to week 2016/54 and related ans to 2015
select * from normal_issues n where n.niss_title_code = 5615 and n.niss_issue_year in (2015,2016) for update

select * from branch_issues b where b.bris_title_code = 4842 and b.bris_issue_year in (2015,2016) for update; -- moved br_is away to week 2016/54 and related ans to 2015
select * from normal_issues n where n.niss_title_code = 4842 and n.niss_issue_year in (2015,2016) for update
select * from agent_net_sales a where a.net_issue_ean = 977000032690953 and a.net_issue_year = 2016 for update

select * from branch_issues b where b.bris_title_code = 4867 and b.bris_issue_year in (2015,2016) for update; --
select * from normal_issues n where n.niss_title_code = 4867 and n.niss_issue_year in (2015,2016) for update -- 977002099205002 niss_ean delated due to duplicate for w2 but no branch issue
select * from agent_net_sales a where a.net_issue_ean = 977002099205002 and a.net_issue_year = 2016 for update

select * from branch_issues b where b.bris_title_code = 4911 and b.bris_issue_year in (2015,2016) for update; --
select * from normal_issues n where n.niss_title_code = 4911 and n.niss_issue_year in (2015,2016) for update 
select * from agent_net_sales a where a.net_issue_ean = 977135496770752 and a.net_issue_year = 2015 
select * from agent_net_sales a where a.net_issue_ean = 977135496770701 and a.net_issue_year = 2015 

select * from branch_issues b where b.bris_title_code = 5250 and b.bris_issue_year in (2015,2016) for update; --
select * from normal_issues n where n.niss_title_code = 5250 and n.niss_issue_year in (2015,2016) for update 
select * from agent_net_sales a where a.net_issue_ean =  and a.net_issue_year = 2016 

select * from branch_issues b where b.bris_title_code = 5251 and b.bris_issue_year in (2015,2016) for update; --
select * from normal_issues n where n.niss_title_code = 5251 and n.niss_issue_year in (2015,2016) for update 
select * from normal_issues n where n.niss_ean = 977136291101352  and n.niss_issue_year in (2015,2016) 
select * from agent_net_sales a where a.net_issue_ean = 977136291101352  and a.net_issue_year in (2015,2016) 

select * from branch_issues b where b.bris_title_code = 5435 and b.bris_issue_year in (2015,2016) and b.bris_branch_code = 'BRA550' order by b.bris_issue_year, b.bris_issue_week for update; --
select * from normal_issues n where n.niss_title_code = 5435 and n.niss_issue_year in (2015,2016) for update 
select * from normal_issues n where n.niss_ean =   and n.niss_issue_year in (2015,2016) 

select * from branch_issues b where b.bris_title_code = 4270 and b.bris_issue_year in (2015,2016) and b.bris_branch_code = 'BRA550' order by b.bris_issue_year, b.bris_issue_week for update; --
select * from normal_issues n where n.niss_title_code = 4270 and n.niss_issue_year in (2015,2016) for update 
select * from normal_issues n where n.niss_ean =   and n.niss_issue_year in (2015,2016) 

select * from branch_issues b where b.bris_title_code = 26991 and b.bris_issue_year in (2015,2016) and b.bris_branch_code = 'BRA740' order by b.bris_issue_year, b.bris_issue_week for update; -- moved br_is away to week 2016/54 and related ans to 2015
select * from branch_issues b where b.bris_ean = 977175662502153 and b.bris_branch_code = 'BRA740' order by b.bris_issue_year, b.bris_issue_week 
select * from normal_issues n where n.niss_title_code = 26991 and n.niss_issue_year in (2015,2016) for update
select * from normal_issues n where n.niss_ean =  977175662502153
select sum(a.net_commited_quantity) from agent_net_sales a where a.net_issue_ean =977175662502153  and a.net_branch_code = 'BRA740' and a.net_issue_year = 2015
select sum(QUANTITY) from zpx_rtrn_stg_bak b where b.issue_id = '000000000269912304' and b.spoke_id = 740 and b.document_type = 'JLF' and ETL_RUN_NUM_SEQ = 1988
select * from zpx_rtrn_stg_bak b where b.issue_id = '000000000269912304' and b.spoke_id = 740 and b.document_type = 'JLF' 
