select * from bisd_740_20160421031850086451 t where t.br_make_up_overs < 0 t.br_ean = 502195600107616
