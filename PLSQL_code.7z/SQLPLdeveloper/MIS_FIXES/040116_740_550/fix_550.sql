--create table jt_KPI_TOTALS_040116 as
select * from KPI_TOTALS t where KPT_EAN = 977001306122001 
delete from KPI_TOTALS t where KPT_EAN = 977001306122001
