select to_char( h.hamo_id )                             REC,
          decode( i.issu_ean, NULL, 'X', NULL )            I,
          lpad( to_char( h.hamo_issue_ean ), 15, '0' )     EAN,
          to_char( h.hamo_issue_year )                     YEAR,
          decode( t.titl_code, NULL, 'X', NULL )           T,
          to_char( h.hamo_title_code )                     TITLE,
          decode( c.cus_account_number,  NULL, 'X', NULL ) C,
          to_char( h.hamo_agent_number )                   CUSTOMER_ACCT,
          to_char( h.hamo_issue_invoice_date, 'YYMMDD' )   INVOICE,
          decode( b.bran_branch_code,  NULL, 'X', NULL )   B,
          to_char( h.hamo_title_code )                     TITLE,
          to_char( h.hamo_issue_invoice_date, 'YYMMDD' )   INVOICE_DATE
   from   issues i,
          titles t,
          customers c,
          branch_terms b,
          agent_movements h
   where  h.hamo_issue_ean           = i.issu_ean(+)
   and    h.hamo_issue_year          = i.issu_issue_year(+)
   and    h.hamo_title_code          = t.titl_code(+)
   and    h.hamo_agent_number        = c.cus_account_number(+)
   and    h.hamo_issue_invoice_date >= c.cus_from_date(+)
   and    h.hamo_issue_invoice_date <= c.cus_to_date(+)
   and    'BRA740'        = b.bran_branch_code(+)
   and    h.hamo_title_code          = b.bran_title_code(+)
   and    h.hamo_issue_invoice_date >= b.bran_date_from(+)
   and    h.hamo_issue_invoice_date <= b.bran_date_to(+)
   and  ( i.issu_ean is null
     or   t.titl_code is null
     or   c.cus_account_number is null
     or   b.bran_branch_code is null
        )
   order by 1
--005060385034156
