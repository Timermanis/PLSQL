--create table jt_all_issues_040116 as
select * from all_issues where ISSU_EAN  = 977135721685753 for update
--create table jt_branch_issues_040116 as
select * from branch_issues where BRIS_EAN = 977135721685753 for update
--insert into branch_issues select * from jt_branch_issues_040116

--create table jt_all_issues_040116_2 as
select * from all_issues where ISSU_EAN  = 010326021553601 for update
select * from all_issues where ISSU_TITLE_CODE  = 32602 and ISSU_ISSUE_YEAR in (2015,2016) for update
--create table jt_branch_issues_040116_2 as
select * from branch_issues where BRIS_EAN = 010326021553601 for update
010326021553601

--create table jt_all_issues_050116 as
select * from all_issues where ISSU_EAN  = 010395491553601 for update
select * from all_issues where ISSU_TITLE_CODE  = 39549 and ISSU_ISSUE_YEAR in (2015,2016) for update
--create table jt_branch_issues_050116 as
select * from branch_issues where BRIS_EAN = 010395491553601 for update
977001306122001

--create table jt_all_issues_050116_2 as
select * from all_issues where ISSU_EAN  = 977001306122001 for update
select * from all_issues where ISSU_TITLE_CODE  = 39549 and ISSU_ISSUE_YEAR in (2015,2016) for update
--create  table jt_branch_issues_050116_2 as
select * from branch_issues where BRIS_EAN = 977001306122001 for update
--------------------------------------------------------------------No backups. Added record for the ean for 2016 w1 and changed 2015 to w53

select * from all_issues where ISSU_EAN  = 977096388361353 for update
select * from all_issues where ISSU_TITLE_CODE  = 4072 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977096388361353 for update


select * from all_issues where ISSU_EAN  = 977135006961053 for update
select * from all_issues where ISSU_TITLE_CODE  = 39549 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977135006961053 for update


select * from all_issues where ISSU_EAN  = 977136075256453 for update
select * from all_issues where ISSU_TITLE_CODE  = 39549 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977136075256453 for update

select * from all_issues where ISSU_EAN  = 977136934801053 for update
select * from all_issues where ISSU_TITLE_CODE  = 39549 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977136934801053 for update
----------------------------------------------
977096956515501
select * from all_issues where ISSU_EAN  = 977096956515501 for update
select * from all_issues where ISSU_TITLE_CODE  = 5495 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977096956515501 for update

select * from all_issues where ISSU_EAN  = 977135496340253 for update
select * from all_issues where ISSU_TITLE_CODE  = 4086 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977135496340253 for update

select * from all_issues where ISSU_EAN  = 977000032690953 for update
select * from all_issues where ISSU_TITLE_CODE  = 4842 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977000032690953 for update
-------------------------------------------------060116---------------------
select * from all_issues where ISSU_EAN  = 977000032680053 for update
select * from all_issues where ISSU_TITLE_CODE  = 5495 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977000032680053 for update

select * from all_issues where ISSU_EAN  = 977002099202953 for update
select * from all_issues where ISSU_TITLE_CODE  = 4086 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977002099202953 for update

select * from all_issues where ISSU_EAN  = 977096438985553 for update
select * from all_issues where ISSU_TITLE_CODE  = 4842 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977096438985553 for update
--
select * from all_issues where ISSU_EAN  = 977135213172853 for update
select * from all_issues where ISSU_TITLE_CODE  = 5495 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977135213172853 for update

select * from all_issues where ISSU_EAN  = 977135343561053 for update
select * from all_issues where ISSU_TITLE_CODE  = 4086 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977135343561053 for update
--
select * from all_issues where ISSU_EAN  = 977135508675953 for update
select * from all_issues where ISSU_TITLE_CODE  = 4842 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977135508675953 for update

select * from all_issues where ISSU_EAN  = 977135686614553 for update
select * from all_issues where ISSU_TITLE_CODE  = 5495 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977135686614553 for update
--
select * from all_issues where ISSU_EAN  = 977136934801001 for update
select * from all_issues where ISSU_TITLE_CODE  = 4086 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977136934801001 for update

select * from all_issues where ISSU_EAN  = 977146505449553 for update
select * from all_issues where ISSU_TITLE_CODE  = 4842 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977146505449553 for update
-------
select * from all_issues where ISSU_EAN  = 977146505449553 for update
select * from all_issues where ISSU_TITLE_CODE  = 5495 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977146505449553 for update

select * from all_issues where ISSU_EAN  = 977146505542352 for update
select * from all_issues where ISSU_TITLE_CODE  = 9105 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977146505542352 for update

select * from all_issues where ISSU_EAN  = 977146863809853 for update
select * from all_issues where ISSU_TITLE_CODE  = 4842 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977146863809853 for update
--
select * from all_issues where ISSU_EAN  = 977147075870853 for update
select * from all_issues where ISSU_TITLE_CODE  = 4842 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977147075870853 for update

select * from all_issues where ISSU_EAN  = 977174340201701 for update
select * from all_issues where ISSU_TITLE_CODE  = 5495 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977174340201701 and BRIS_BRANCH_CODE = 'BRA550'  for update
-------070116-----------------
select * from all_issues where ISSU_EAN  = 009780993224096 for update--550
select * from all_issues where ISSU_TITLE_CODE  = 49022 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 009780993224096 and BRIS_BRANCH_CODE = 'BRA550'  for update

select * from all_issues where ISSU_EAN  = 977135721685701 for update--740
select * from all_issues where ISSU_TITLE_CODE  = 49022 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977135721685701 and BRIS_BRANCH_CODE = 'BRA740'  for update
------080116----------------
select * from all_issues where ISSU_EAN  = 977136502311951 for update--550
select * from all_issues where ISSU_TITLE_CODE  = 49022 and ISSU_ISSUE_YEAR in (2015,2016) for update

select * from branch_issues where BRIS_EAN = 977136502311951 and BRIS_BRANCH_CODE = 'BRA550'  for update

select * from all_issues where ISSU_EAN  = 009780993224096 for update--550
select * from all_issues where ISSU_TITLE_CODE  = 49022 and ISSU_ISSUE_YEAR in (2015,2016) for update --fixed 070116 changing year to 1016 w1 but next day got transactions for 2015

select * from branch_issues where BRIS_EAN = 009780993224096 and BRIS_BRANCH_CODE = 'BRA550'  for update
----------proc_CIPD-F-Update_Branch_Link failure----
select * from branch_issues where BRIS_EAN = 030401621601001 and BRIS_BRANCH_CODE = 'BRA550' for update--changed link year to 2015 due to CPID error  cannot insert NULL into ("JM"."NORMAL_ISSUES"."NISS_ISSUE_W
select * from normal_issues n where niss_EAN = 660401621653001 
/*Field by field dump of record: 8 from file /work4/dataprocess/misfile.013966.BRA550
Field: rec_type                         Value: CIPD
Field: old_ean                          Value: 030401621601001
Field: old_year                         Value: 2016
Field: new_ean                          Value: 660401621653001
Field: new_year                         Value: 2016
*/
select * from normal_issues 
fetch first 10 rows only;
