
select ag.net_agent_account_number,ag.net_branch_code,c.titl_code title,c.titl_long_name name,a.bris_on_sale_date,b.niss_issue_day "WEEK DAY",b.niss_issue_week WEEK,b.niss_issue_year YEAR,b.niss_ean,sum(ag.NET_COMMITED_QUANTITY) sales,sum(ag.net_credit_quantity) credits,sum(ag.NET_COMMITED_QUANTITY - ag.net_credit_quantity) "TOTAL (SALES - CREDITS)" 
from  agent_net_sales ag, branch_issues a, normal_issues b, titles c where
a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year

and b.niss_title_code = c.titl_code

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code
-----------------------
--and a.bris_on_sale_date = '12-FEB-16'
and ag.net_agent_account_number =  502963061848099
--and b.niss_title_code = 5250
and b.niss_issue_year in (2016)
--and b.niss_ean = 977135497070701
--and a.bris_branch_code in ( 'BRA550')
group by c.titl_code, b.niss_issue_day,b.niss_issue_week,b.niss_issue_year,b.niss_ean,c.titl_long_name,ag.net_branch_code,a.bris_on_sale_date,ag.net_agent_account_number





select * from customer_x_ref h where h.ccr_bus_partner_id in (132943,132779,132038,132064)
select * from agent_net_sales s where s.net_agent_account_number = 977135497070701 and s.net_issue_year = 2015 

select * from customer_x_ref f where f.ccr_bus_partner_id = 109762 --502963061848099
--------------------------------------------------------------------------
