select * from msg_files where trim(MSG_TIMESTAMP)= (select max(trim(MSG_TIMESTAMP)) from msg_files) 

select to_date(MSG_TIMESTAMP),to_date(sysdate) from msg_files where to_date(sysdate)= (select max(to_date(MSG_TIMESTAMP)) from msg_files) 
select to_date(MSG_TIMESTAMP),to_date(sysdate) from msg_files where to_timestamp(sysdate)= (select to_timestamp(max(MSG_TIMESTAMP)) from msg_files) 
select to_date(MSG_TIMESTAMP),to_date(sysdate) from msg_files where to_char(MSG_TIMESTAMP) = to_char(sysdate)
select count(*) from msg_files where 
to_char(MSG_TIMESTAMP) = to_char(sysdate) and msg_status = 'X'

select * from msg_files where msg_status = 'X'

select max(to_date(MSG_TIMESTAMP)) from msg_files ;
select to_date(sysdate) from dual

select to_char(max(to_date(MSG_TIMESTAMP))) from msg_files ;
select to_char(sysdate) from dual

select to_timestamp(sysdate) from dual
select to_timestamp(max(to_date(MSG_TIMESTAMP))) from msg_files ;
select to_timestamp(max((MSG_TIMESTAMP))) from msg_files ;


select count(*) 

  from msg_files where 
  to_char(MSG_TIMESTAMP) = to_char(sysdate) and msg_status = 'X';
