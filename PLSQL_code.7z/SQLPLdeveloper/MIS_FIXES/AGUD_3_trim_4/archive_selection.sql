select * from zpx_cus_dtls_stg_bak c where c.customer_id = 136604
