--select * from LATEST_MULTIPLE_MV t where t.out_grade_code  like 'IN%'

select t.out_grade_code,t.* from LATEST_RETAILER_MV t where length (t.out_grade_code ) > 3

select t.out_grade_code,t.* from LATEST_RETAILER_MV t where t.out_grade_code like 'INQ%'
