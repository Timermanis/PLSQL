select * from titles t where t.titl_long_name like '%BUXTON%' 13372 

select * from plant_issues_xref xr where xr.PIX_MAIN_LEGACY_TITLE = 13372 and  xr.PIX_YEAR>=2015 and xr.PIX_BRANCH_CODE = 'BRA740' order by xr.PIX_YEAR, xr.PIX_WEEK
select * from plant_issues_xref xr where xr.PIX_EAN=977096658616025--977096658616032
select * from plant_issues_xref xr where xr.PIX_EAN=977096658616045

select b.* from branch_issues b, plant_issues_xref xr where b.bris_issue_year = xr.PIX_YEAR and b.bris_ean = xr.PIX_EAN 
and xr.PIX_MAIN_LEGACY_TITLE = 13372  and  xr.PIX_YEAR>=2015 and xr.PIX_BRANCH_CODE = 'BRA740' order by b.bris_issue_year, b.bris_issue_week
 
select xr.PIX_SAP_ID,a.net_issue_year,b.bris_issue_week,sum (a.net_commited_quantity),sum(a.net_credit_quantity) from branch_issues b, plant_issues_xref xr,agent_net_sales a 
where b.bris_issue_year = xr.PIX_YEAR and b.bris_ean = xr.PIX_EAN 
and a.net_issue_ean = b.bris_ean and a.net_issue_year = b.bris_issue_year and a.net_branch_code = b.bris_branch_code
and xr.PIX_MAIN_LEGACY_TITLE = 13372  and  xr.PIX_YEAR>=2015 and xr.PIX_BRANCH_CODE in ('BRA740', 'BRA790')
group by xr.PIX_SAP_ID,a.net_issue_year,b.bris_issue_week
order by a.net_issue_year,b.bris_issue_week

select a.net_issue_ean,a.net_issue_year,b.bris_issue_week,sum (a.net_commited_quantity),sum(a.net_credit_quantity) from branch_issues b, plant_issues_xref xr,agent_net_sales a 
where b.bris_issue_year = xr.PIX_YEAR and b.bris_ean = xr.PIX_EAN 
and a.net_issue_ean = b.bris_ean and a.net_issue_year = b.bris_issue_year and a.net_branch_code = b.bris_branch_code
and xr.PIX_MAIN_LEGACY_TITLE = 13372  and  xr.PIX_YEAR>=2015 and xr.PIX_BRANCH_CODE = 'BRA790' 
group by a.net_issue_ean,a.net_issue_year,b.bris_issue_week
order by a.net_issue_year,b.bris_issue_week

------------------
select a.net_issue_ean,a.net_issue_year,b.bris_issue_week,sum (a.net_commited_quantity),sum(a.net_credit_quantity) from cas_branch_issues b, plant_issues_xref xr,cas_agent_net_sales a 
where b.bris_issue_year = xr.PIX_YEAR and b.bris_ean = xr.PIX_EAN 
and a.net_issue_ean = b.bris_ean and a.net_issue_year = b.bris_issue_year and a.net_branch_code = b.bris_branch_code
and xr.PIX_MAIN_LEGACY_TITLE = 13372  and  xr.PIX_YEAR>=2015-- and xr.PIX_BRANCH_CODE = 'BRA790' 
group by a.net_issue_ean,a.net_issue_year,b.bris_issue_week
order by a.net_issue_year,b.bris_issue_week

select * from cas_agent_net_sales c where c.net_issue_ean=977096658616032
