select * from titles t where t.titl_long_name like '%GUARDIAN%SAT%' 9009 
select * from titles t where t.titl_code=22101
select * from titles t where t.titl_code=37888
select * from plant_issues_xref xr where xr.PIX_MAIN_LEGACY_TITLE = 9009 and xr.PIX_LEGACY_TITLE = 22101 and xr.PIX_YEAR=2016 
select * from plant_issues_xref xr where xr.PIX_MAIN_LEGACY_TITLE = 9009 and xr.PIX_LEGACY_TITLE = 37888 and xr.PIX_YEAR=2016 

select * from agent_net_sales a where a.net_title_code = 22101 and a.net_issue_year = 2016


select t.titl_code, t.titl_long_name from titles t where t.titl_code=22101
select * from customer_x_ref x where x.ccr_bus_partner_id = 110076--502963003307899

select * from titles t where t.titl_long_name like '%GUARDIAN%SAT%' 9009 
select * from titles t where t.titl_code=22101
select * from titles t where t.titl_code=37888
select * from plant_issues_xref xr where xr.PIX_MAIN_LEGACY_TITLE = 9009 and xr.PIX_LEGACY_TITLE = 22101 and xr.PIX_YEAR=2016------------------
select * from plant_issues_xref xr where xr.PIX_MAIN_LEGACY_TITLE = 9009 and xr.PIX_LEGACY_TITLE = 37888 and xr.PIX_YEAR=2016 and xr.PIX_BRANCH_CODE = 'BRA220' 

select * from agent_net_sales a where a.net_issue_ean = 10378881601601 and a.net_agent_account_number = 502963003307899 and a.net_issue_year = 2016 --110076

