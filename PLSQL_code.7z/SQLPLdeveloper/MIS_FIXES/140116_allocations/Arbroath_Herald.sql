select * from titles t where t.titl_long_name like upper('%Fraserburgh Herald%')-- Fraserburgh Herald
select * from titles t where t.titl_long_name like '%ARGYLLSHIRE%ADVER%'

4270
4767
37955
1935

select * from customer_x_ref x where x.ccr_bus_partner_id=124179 --133324
select * from plant_issues_xref p where p.PIX_EAN in   --

select * from branch_issues b where b.bris_title_code = 4652 and b.bris_issue_year = 2015 order by BRIS_ISSUE_WEEK --for update
select * from normal_issues n where n.niss_title_code = 4652 and n.niss_issue_year = 2015  order by nisS_ISSUE_WEEK --for update
select * from agent_net_sales a where  a.net_issue_year=2016 and a.net_issue_ean =  977136075256453--a.net_agent_account_number = 977136075256453 and
select * from all_issues b where b.bris_title_code = 4652 and b.bris_issue_year = 2016 

select * from plant_issues_xref d where d.PIX_EAN = 977146148509546 and d.PIX_YEAR = 2015;
select * from plant_issues_xref d where d.PIX_EAN = 977146148509545 and d.PIX_YEAR = 2015;
select * from plant_issues_xref d where d.PIX_EAN = 977146148509544 and d.PIX_YEAR = 2015
select * from plant_issues_xref d where d.PIX_EAN = 977146148509512 and d.PIX_YEAR = 2015;
select * from plant_issues_xref d where d.PIX_EAN = 977146148509511 and d.PIX_YEAR = 2015

select * from plant_issues_xref d where d.PIX_EAN in (977146148509543,977146148509544,977146148509545,977146148509546,977146148509547) and d.PIX_YEAR = 2015;
select * from branch_issues b where b.bris_ean in (977146148509543,977146148509544,977146148509545,977146148509546,977146148509547,977146148509548,977146148509549) and b.bris_issue_year = 2015;

select * from branch_issues b where b.bris_title_code = 4652 and b.bris_issue_year in (2015,2016) order by BRIS_ISSUE_year,BRIS_ISSUE_WEEK 


