select * from titles t where t.titl_long_name like '%MOF%' --5147
select * from titles t where t.titl_long_name like '%DUMFRIES C%'Dumfries Courier --4510
select * from titles t where t.titl_long_name like '%WHITEHAVEN NEWS%'
select * from titles t where t.titl_long_name like '%PRESS (%'
select * from titles t where t.titl_long_name like '%MARVEL FA%'
select  * from titles t where t.titl_code=24340 --THE PRESS

select * from normal_issues n where n.niss_title_code=44098 and n.niss_issue_year =2015; --for update;

select * from branch_issues b 
where b.bris_title_code=44098 and b.bris_issue_year=2015 and b.bris_issue_week>47 --for update-- for update


30051471541001  999135686714241 2015  41
977135686714242 977135686714242 2015  42
977135686714243 977135686714243 2015  43
30051471544001  999135686714244 2015  44
977135686714245 977135686714245 2015  45
977135686714246 977135686714246 2015  46
30051471547001  999135686714247 2015  47
30051471548001  999135686714248 2015  48
977135686714249 977135686714249 2015  49
30051471550001  999135686714250 2015  50
30051471551001  999135686714250 2015  50
977135686714251 977135686714251 2015  51
30051471553001  999135686714252 2015  52
30051471552001  999135686714252 2015  52
977135686714253 977135686714253 2015  53

create_normal_issue('L', 977135686714242,2015);
create_normal_issue('L', 977135686714243,2015);
create_normal_issue('L', 977135686714245,2015);
create_normal_issue('L', 977135686714246,2015);
create_normal_issue('L', 977135686714249,2015);
create_normal_issue('L', 977135686714251,2015);
create_normal_issue('L', 977135686714253,2015);

create_normal_issue('L', 999135686714242,2015);
create_normal_issue('L', 999135686714243,2015);
create_normal_issue('L', 999135686714245,2015);
create_normal_issue('L', 999135686714246,2015);
create_normal_issue('L', 999135686714249,2015);
create_normal_issue('L', 999135686714251,2015);
create_normal_issue('L', 999135686714253,2015);




select * from normal_issues n where n.niss_title_code=5902 and n.niss_issue_year =2015 and n.niss_issue_day= 3;

select * from branch_issues b where b.bris_title_code=5902 and b.bris_issue_year=2015 for update--and b.bris_branch_code = 'BRA850' --and b.bris_issue_week = 42 

select 
bris_branch_code branch,
bris_title_code, bris_on_sale_date,bris_link_reliability, bris_title_code,bris_ean,bris_issue_year,bris_issue_week,bris_issue_day,
niss_ean,niss_title_code ni_title, niss_type_flag ni_type, niss_issue_year ni_yr, niss_issue_week ni_wk, niss_issue_day ni_day,
br_commited_sales_quantity + br_casual_sales_quantity + br_box_out_quantity + br_other_sales_quantity br_sales,
br_credit_quantity
from branch_issues,normal_issues, branch_summaries
where  bris_link_ean = niss_ean(+)
and bris_link_issue_year = niss_issue_year(+)
and br_branch_code = bris_branch_code
and br_ean = bris_ean
and br_issue_year = bris_issue_year
--
and bris_title_code = 5147
--and niss_title_code = 4043
--
and ((bris_issue_week > 40
and bris_issue_year = 2015) or (bris_issue_year = 2016))
order by bris_issue_week 

update normal_issues 
set niss_manual_update_flag = sysdate 
where niss_ean in (977135686714242,977135686714243,977135686714245,977135686714246,977135686714249,977135686714251,977135686714253,999135686714242,999135686714243,999135686714245,999135686714246,
999135686714249,999135686714251,999135686714253 )
and niss_issue_year = 2015;


select * from normal_issues 
--set niss_manual_update_flag = sysdate 
where niss_ean in (977135686714242,977135686714243,977135686714245,977135686714246,977135686714249,977135686714251,977135686714253,999135686714242,999135686714243,999135686714245,999135686714246,
999135686714249,999135686714251,999135686714253 )
and niss_issue_year = 2015;

create_normal_issue('L', 977135686714242,2015);
create_normal_issue('L', 977135686714243,2015);
create_normal_issue('L', 977135686714245,2015);
create_normal_issue('L', 977135686714246,2015);
create_normal_issue('L', 977135686714249,2015);
create_normal_issue('L', 977135686714251,2015);
create_normal_issue('L', 977135686714253,2015);

create_normal_issue('L', 999135686714242,2015);
create_normal_issue('L', 999135686714243,2015);
create_normal_issue('L', 999135686714245,2015);
create_normal_issue('L', 999135686714246,2015);
create_normal_issue('L', 999135686714249,2015);
create_normal_issue('L', 999135686714251,2015);
create_normal_issue('L', 999135686714253,2015);
