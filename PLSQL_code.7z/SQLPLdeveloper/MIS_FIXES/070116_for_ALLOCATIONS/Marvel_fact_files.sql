select 
bris_branch_code branch,
bris_title_code, bris_on_sale_date,bris_link_reliability, bris_title_code,bris_ean,bris_issue_year,bris_issue_week,bris_issue_day,
niss_ean,niss_title_code ni_title, niss_type_flag ni_type, niss_issue_year ni_yr, niss_issue_week ni_wk, niss_issue_day ni_day,
br_commited_sales_quantity + br_casual_sales_quantity + br_box_out_quantity + br_other_sales_quantity br_sales,
br_credit_quantity
from branch_issues,normal_issues, branch_summaries
where  bris_link_ean = niss_ean--(+)
and bris_link_issue_year = niss_issue_year--(+)
and br_branch_code = bris_branch_code
and br_ean = bris_ean
and br_issue_year = bris_issue_year
--and bris_branch_code = 'BRA020'
and bris_title_code = 4503

and ((bris_issue_week > 40
and bris_issue_year = 2015) or (bris_issue_year = 2016))
order by bris_issue_week 
