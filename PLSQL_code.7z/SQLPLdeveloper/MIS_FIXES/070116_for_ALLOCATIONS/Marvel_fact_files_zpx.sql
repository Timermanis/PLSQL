select * from archive.ZPX_PLNT_ISS_STG_BAK t where t.issue_id in (000000000440980141,000000000440980142,000000000440980143) and spoke_id in (020,030)
and t.act_on_sale_date is not null
