select * from normal_issues n where n.niss_title_code=44098 and n.niss_issue_year =2015 and n.niss_issue_week>=40 for update; 

select * from branch_issues b 
where b.bris_title_code=44098 and b.bris_issue_year=2015 and b.bris_issue_week>=40 and b.bris_branch_code = 'BRA020' for update

select * from branch_issues b 
where b.bris_title_code=44098 and b.bris_issue_year=2015 and b.bris_issue_week in (45,46) and b.bris_branch_code = 'BRA020' 

977205089602593  977205089602589

select * from branch_issues b 
where b.bris_ean = 977205089602593

