select * from plant_issues_xref x where x.PIX_EAN in (977205089603240,977205089603238,977205089603239) and x.PIX_BRANCH_CODE = 'BRA020'
select * from agent_net_sales a where a.net_issue_ean in (977205089603240,977205089603238,977205089603239) and a.net_issue_year = 2015
select * from agent_net_sales a where a.net_issue_ean = 977205089603240 and a.net_issue_year = 2015 and a.net_branch_code = 'BRA020'  intersect
select * from agent_net_sales a where a.net_issue_ean = 977205089603239 and a.net_issue_year = 2015 and a.net_branch_code = 'BRA020'  intersect --1002
select * from agent_net_sales a where a.net_issue_ean = 977205089603238 and a.net_issue_year = 2015 and a.net_branch_code = 'BRA020'  --1002 977205089602593

select * from agent_net_sales a where a.net_issue_ean = 977205089602593 and a.net_issue_year = 2015 and a.net_branch_code = 'BRA020'
select * from branch_issues b where b.bris_link_ean = 977205089602593 and b.bris_issue_year = 2015 and b.bris_branch_code = 'BRA020'

select * from plant_issues_xref x where x.PIX_EAN in (977205089603240,977205089603238,977205089603239) and x.PIX_BRANCH_CODE = 'BRA020'
