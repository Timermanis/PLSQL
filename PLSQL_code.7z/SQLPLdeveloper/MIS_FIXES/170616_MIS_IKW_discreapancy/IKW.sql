--STAR ENG

select * from zpx_rtrn_stg_bak r where r.issue_id = '000000000090124025' and r.customer_id = 109817 and r.etl_run_num_seq = 2151 --220 (340)

select * from zpx_plnt_iss_stg_bak p where p.issue_id = '000000000090124025' and p.spoke_id = 340

select * from refmast.plant_issues_xref_base x where x.PIX_LEGACY_TITLE in(
853,
836,
19019,
19020,
18572,
22716,
33967,
31765,
32549,
34344,
40109,
36989,
36990,
40238,
40237,
90469,
90470,
90468) and x.PIX_YEAR =2016 and x.pix_week = 23 and x.pix_day = 5

select * from refmast.plant_issues_xref_base x where x.PIX_LEGACY_TITLE in(
494,
260,
266,
268,
272,
412,
406,
238,
9012,
8543,
9011,
17688,
18566,
9005,
269,
21835,
22284,
26482,
33986,
31759,
34459,
32535,
32543,
40106,
40271,
40272,
90518,
90519,
90517
) and x.PIX_YEAR =2016 and x.pix_week = 23 and x.pix_day = 5


select * from zpx_rtrn_stg_bak r where r.issue_id =   '000000000008364026' and r.customer_id = 124996
select * from zpx_rtrn_cdn_stg_bak r where r.issue_id =   '000000000008364026' and r.customer_id = 124996
