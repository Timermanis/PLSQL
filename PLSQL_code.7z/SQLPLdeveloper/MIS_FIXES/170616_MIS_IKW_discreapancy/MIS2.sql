select * from titles t where t.titl_code in (31765)

select * from customer_x_ref c where c.ccr_cust_urn = 503103102855302--109817

select * from plant_issues_xref x where x.PIX_EAN = 10008361623501--000000000008364026

