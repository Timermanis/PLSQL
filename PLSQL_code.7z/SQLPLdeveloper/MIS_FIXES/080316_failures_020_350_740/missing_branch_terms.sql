select * from branch_terms t where t.bran_title_code = 50275 for update
select * from branch_issues b where b.bris_ean = 977152848200501
select * from titles a where a.titl_long_name like '%SEVENTEEN%'

select * from zpx_plnt_iss_stg_bak p where p.legacy_titl_code = '50294' and p.etl_run_date_num = 20160307
