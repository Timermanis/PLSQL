--create table jt_080316_fin_hist_bkp as
select * from jt_080316_fin_hist_bkp
select * from financial_histories f where f.fin__title_code = 912 and f.fin__year = 2016 and f.fin__branch_code = 'BRA020' and f.fin__week_number = 09  and f.fin__day_number = 1 
delete from financial_histories f where f.fin__title_code = 912and f.fin__year = 2016 and f.fin__branch_code = 'BRA020' and f.fin__week_number = 09  and f.fin__day_number = 1 
select * from all_all_tables a where a.table_name = 'FINANCIAL_HISTORIES'

insert into financial_histories select * from jt_080316_fin_hist_bkp where FIN__DAY_NUMBER = 1
