SELECT 
   PIX_BRANCH_CODE, PIX_SAP_ID, PIX_LEGACY_TITLE, 
   PIX_EAN, PIX_YEAR, PIX_WEEK, 
   PIX_DAY, PIX_ORIG_YEAR, PIX_ORIG_WEEK, 
   PIX_ORIG_DAY, PIX_INITIAL_EAN, PIX_UK_VAT, 
   PIX_EIRE_VAT, PIX_PUB_REF, PIX_JM_REF, 
   PIX_FREQ_CODE, PIX_SAS_CODE, PIX_SOURCE_FLAG, 
   PIX_SPOKE_CODE, PIX_MAIN_LEGACY_TITLE, PIX_PLANT_ON_SALE_DATE, 
   PIX_OFFICIAL_ON_SALE_DATE, PIX_ISSUE_TYPE, PIX_PARENT_ID, 
   PIX_STATUS_FLAG, PIX_ORIG_LEGACY_TITLE, PIX_MIGRATED_SAP_ID, 
   PIX_LEGACY_EAN, PIX_LEGACY_YEAR, PIX_SOURCE_FLAG2, 
   PIX_SOURCE_FLAG3, PIX_MANUAL_FIX_FLAG, PIX_IKNOW_ONLY_FLAG, 
   PIX_PARENT_PROD_ID
FROM REFMAST.PLANT_ISSUES_XREF_BASE
Where pix_main_legacy_title = 4911
AND PIX_orig_YEAR = 2016
AND PIX_BRANCH_CODE = 'BRA550'
and pix_week is not null
ORDER BY PIX_ORIG_YEAR ASC NULLS LAST, PIX_ORIG_WEEK ASC NULLS LAST

select 
bris_branch_code branch,bris_official_on_sale_date, bris_recall_date,
bris_title_code, bris_on_sale_date,bris_link_reliability, bris_ean,bris_issue_year,bris_issue_week,bris_issue_day,
niss_ean,niss_title_code ni_title, niss_type_flag ni_type, niss_issue_year ni_yr, niss_issue_week ni_wk, niss_issue_day ni_day,
br_commited_sales_quantity + br_casual_sales_quantity + br_box_out_quantity + br_other_sales_quantity br_sales,
br_credit_quantity, niss_manual_update_flag
from branch_issues,normal_issues, branch_summaries
where  bris_link_ean = niss_ean(+)
and bris_link_issue_year = niss_issue_year(+)
and br_branch_code = bris_branch_code
and br_ean = bris_ean
and br_issue_year = bris_issue_year
--
and bris_title_code in (4911,37704)
-- (5615,23636,23119,37710,37697,38029) 
--and bris_ean = 977135497230501
and bris_issue_year = 2016

