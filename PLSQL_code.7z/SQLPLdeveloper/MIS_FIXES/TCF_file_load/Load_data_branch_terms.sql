create table jt_180316_bran_term_missing as
select TITLE_CODE title,replace('BRA'||to_char(BRANCH_CODE,'000' ),' ','') branch from archive_jm_terms_log@termsprd.world t where last_update > '01-JAN-2015' and TERMS_UPDATE_TYPE != 2
minus
select BRAN_TITLE_CODE,BRAN_BRANCH_CODE from branch_terms where BRAN_DATE_TO >'01-JAN-3000' 


select a.* from jm_title_terms@termsprd.world a,jt_180316_bran_term_missing b where 
a.TITLE_CODE = b.title and
a.BRANCH_CODE = replace(b.branch,'BRA','')

select * from JT_170316_BRAN_TERM_MISSING t, branch_terms z
where t.title = z.bran_title_code

insert into branch_terms select 
'01-FEB-2016',
replace('BRA'||to_char(BRANCH_CODE,'000' ),' ',''),
a.title_code,--50304,--50306,--50307,--47340,--50295,50328,50329,50330,50331,50332
'N',
nvl(COST_DISCOUNT_PERCENT_STD,0),
'31-DEC-4000',
TRADE_DISCOUNT_PERCENT_STD,--BRAN_TRADE_DISCOUNT,
THIS_WK_RETAIL_PRICE_STD,--BRAN_COVERMOUNT_PRICE,
0,--BRAN_COVER_PRICE,
0,--BRAN_AGENT_HANDLING_ALLOWANCE,
0,--BRAN_WHOLESALER_HANDLING_ALLOW,
null,--BRAN_RETAIL_PRICE_EXCEPTION,
null--BRAN_RETAIL_PRICE_EXCEPT_DAY
from jm_title_terms@termsprd.world a,jt_180316_bran_term_missing b where 
a.TITLE_CODE = b.title and
a.BRANCH_CODE = replace(b.branch,'BRA','')


select f.* from branch_terms f,JT_180316_BRAN_TERM_MISSING t
where f.bran_branch_code = t.branch
and f.bran_title_code = t.title

s
