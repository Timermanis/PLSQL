select * from titles t where t.titl_long_name like '%STAR WARS HELMET%'--50017

select * from branch_issues b where b.bris_title_code = 45858 and b.bris_ean=977205204704345--50017 
select * from agent_net_sales a where a.net_issue_ean=977205204704345
select * from cas_branch_issues b where b.bris_title_code = 45858 and b.bris_ean=977205204704345--50017
select * from cas_agent_net_sales b where a.net_issue_ean=977205204704345

select unique c.* from agent_net_sales a , cas_agent_net_sales c 
where a.net_issue_ean=977205204704345
and a.net_agent_account_number=c.net_agent_account_number
and a.net_issue_year = c.net_issue_year
