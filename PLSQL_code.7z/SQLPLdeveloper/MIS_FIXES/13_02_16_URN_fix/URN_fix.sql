select * from customers c where c.cus_account_number = 502963096654300
create table jt_130216_fix_ans as
delete from agent_net_sales a where a.net_agent_account_number = 502963096654300-- and a.net_branch_code not in ('BRA340','BRA220')

select count(*) from jt_130216_fix_ans
