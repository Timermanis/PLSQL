select * from JT_241115_ALLOC t where t.issue_id=000000000090443855 for update
select * from JT_241115_ALLOC t where t.issue_id=000000000497050001 for update

select * from JT_241115_ALLOC t where t.issue_id !=000000000090443855 and t.quantity !=36
select * from JT_241115_ALLOC t where t.issue_id !=000000000090443855 
select * from JT_241115_ALLOC t where t.quantity !=36

select * from branch_issues b where b.bris_branch_code = 'BRA745'
