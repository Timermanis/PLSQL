SELECT spoke_id,
           issue_id,
           location_from,
           location_to,
           movement_code,
           pix_year,
           SUM( quantity ) total_qty,
           pix_ean,
           zpx_seq_no
    FROM   (select *
              from zpx_strn_stg_bak z
             where etl_run_num_seq  BETWEEN 2101 AND 2101
             and z.issue_id = 000000000314042318
             /*UNION ALL
            select *
              from stock_trn_gr_not_handled_view s*/)
    WHERE  spoke_id IN ( SELECT nvl(spo_num,0)
                         FROM   latest_spokes_mv@bisapprd.world
                         WHERE  bra_num = 740 )
                
    AND  ( movement_code IN ( '101', 
                              '122', 
                              '102', 
                              '123',
                              '311', 
                              '312',
                              'Z99',
                              'Z01',
                              '641' )
-- code change 01/11/2011 - final overs posting
           OR ( movement_code IN ( '343' )  AND  credit_flag ='H' ) 
           OR ( movement_code IN ( '344' ) AND  credit_flag ='S' ) )
    AND    issue_type       NOT IN ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' )
    AND    pix_inv_date     IS NOT NULL
    AND    pix_ean          IS NOT NULL
    
    GROUP BY spoke_id,
             issue_id,
             location_from,
             location_to,
             movement_code,
             pix_year,
             pix_ean,
             zpx_seq_no
    ORDER BY issue_id, movement_code;
