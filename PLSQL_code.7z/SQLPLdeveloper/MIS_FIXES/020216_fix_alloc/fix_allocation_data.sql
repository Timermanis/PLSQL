select * from titles t where t.titl_long_name like upper('%lennox herald%')
select * from titles t where t.titl_long_name like upper ('%OBSERVER SCOTLAND%')--5250-37695
select * from titles t where t.titl_code = 21870--1003
select * from titles t where t.titl_code = 1003--1003

Southern Reporter
select * from branch_issues b where b.bris_title_code = 9032 and b.bris_issue_year in (2016) and b.bris_branch_code = 'BRA220' order by b.bris_issue_year, b.bris_issue_week for update; -- moved br_is away to week 2016/54 and related ans to 2015
select * from branch_issues b where b.bris_ean = 977135497070701 and b.bris_branch_code = 'BRA550' and b.bris_issue_year = 2015 order by b.bris_issue_year, b.bris_issue_week 
select * from normal_issues n where n.niss_title_code = 4988 and n.niss_issue_year in (2016) for update
select * from normal_issues n where n.niss_ean =  977026723915412 and n.niss_issue_year = 2015

select * from customer_x_ref x where x.ccr_bus_partner_id=130736 --124014  --502963007119300
select * from plant_issues_xref p where p.PIX_EAN in  (977135593458603,977135593458604) and PIX_YEAR = 2016

select * from branch_issues b where b.bris_ean = 977135497070702
select * from normal_issues n where n.NISS_EAN in (977135942315401,660042101501001)
select * from agent_net_sales a where a.net_issue_year=2016 and a.net_issue_ean =  977135497070799
select * from agent_net_sales a where a.net_issue_year=2016 and a.net_agent_account_number=502963007119300 and a.net_issue_ean =  977135497070799

select distinct(d.PIX_MAIN_LEGACY_TITLE) from plant_issues_xref d where d.PIX_LEGACY_TITLE = 90976--1003jt_pix_main_legacy_titles
select distinct(j.PIX_MAIN_LEGACY_TITLE) from jt_pix_main_legacy_titles j where j.PIX_LEGACY_TITLE = 90976

select * from plant_issues_xref d where d.PIX_EAN = 977205198604615 and d.PIX_YEAR = 2015;
select * from plant_issues_xref d where d.PIX_EAN = 977026723915412 and d.PIX_YEAR = 2015;
select * from plant_issues_xref d where d.PIX_EAN = 977146148509544 and d.PIX_YEAR = 2015
select * from plant_issues_xref d where d.PIX_EAN = 977146148509512 and d.PIX_YEAR = 2015;
select * from plant_issues_xref d where d.PIX_EAN = 977146148509511 and d.PIX_YEAR = 2015

select * from plant_issues_xref d where d.PIX_EAN in (977146148509543,977146148509544,977146148509545,977146148509546,977146148509547) and d.PIX_YEAR = 2015;
select * from branch_issues b where b.bris_ean in (977146148509543,977146148509544,977146148509545,977146148509546,977146148509547,977146148509548,977146148509549) and b.bris_issue_year = 2015;

select b.bris_branch_code,b.bris_issue_week,b.bris_issue_year,b.bris_title_code,b.bris_ean,b.bris_link_ean, b.bris_invoice_date from branch_issues b where b.bris_ean in (977146148509541,977146148509542,977146148509543,977146148509544,977146148509545,977146148509546,977146148509547,
977146148509548,977146148509549) and b.bris_issue_year = 2015;

--create table jt_031215_bckp1 as
select b.bris_branch_code,b.bris_issue_week,b.bris_issue_year,b.bris_title_code,b.bris_ean,b.bris_link_ean, b.bris_invoice_date from branch_issues b where 
b.bris_ean like '97714614850954%'
and b.bris_issue_year = 2015 for update;

