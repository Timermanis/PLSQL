select x.ccr_branch_code, t.*
  from zpx_cus_dtls_stg_bak t
  join customer_x_ref x
    on t.CUSTOMER_ID = x.ccr_bus_partner_id
 where t.ETL_RUN_NUM_SEQ = (select max(ETL_RUN_NUM_SEQ) from zpx_cus_dtls_stg_bak)
   and x.ccr_branch_code != 'BRA'||t.HUB_ID;
 
 select * from customer_x_ref c where c.ccr_cust_urn = 202030060301300 --120
   
update customer_x_ref c
set c.ccr_legacy_box_no= get_box_number(220), 
    c.ccr_branch_code = 'BRA220'
where c.ccr_bus_partner_id =0000104658
and c.ccr_branch_code = 'BRA680';

insert into new_box_numbers t
values
(
680, --Dundee branch code
5147 --Old Dundee Box
);

--Get the new box from this query
select *
  from customer_x_ref c
 where c.ccr_bus_partner_id = '0000123901';

--Updated the customers table with the new branch/box
update customers c
  set c.cus_box_number     = 4790
    , c.cus_branch_code    = 'BRA560'
where c.cus_account_number = 503103119740200;

select * from customers c where c.cus_account_number = 202030060301300 for update --200
select * from jt_230116_fix
create table jt_230116_fix as
select *
  from zpx_cus_dtls_stg_bak t
 
 where t.ETL_RUN_NUM_SEQ = (select max(ETL_RUN_NUM_SEQ) from zpx_cus_dtls_stg_bak)
   and t.URN = 202030060301300 for update
   
 select z.* from archive.zpx_cus_dtls_stg_bak z
    where ETL_RUN_NUM_SEQ = (select max (AA_ETL_RUN_NUM_SEQ) from archive.archive_audit)
    and z.urn = 202030060301300
    
    name_array(1) := 'zpx_cus_dtls_stg_bak';
name_array(2) :=zpx_cus_supi_stg_bak';
name_array(3) := 'zpx_cus_deli_stg_bak';
name_array(4) := 'zpx_cus_hrs_stg_bak';
name_array(5) := 'zpx_cus_xrf_stg_bak';
