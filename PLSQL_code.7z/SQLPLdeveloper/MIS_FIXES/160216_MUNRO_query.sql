SELECT    *
FROM      branch_issues b
WHERE     b.bris_branch_code = 'BRA550'
AND       b.bris_title_code =  49655

SELECT    *
FROM      normal_issues n
WHERE     n.niss_ean = 5060385034156
AND       b.bris_title_code =  49655

select * from plant_issues_xref x where x.PIX_EAN = 5060385034156
select * from zpx_plnt_iss_stg_bak z where z.ISSUE_ID = 000000000496550001 and z.SPOKE_ID = 550
select * from zpx_rtrn_stg_bak r where r.issue_id = '000000000496550001' and r.spoke_id = 550
select * from 
