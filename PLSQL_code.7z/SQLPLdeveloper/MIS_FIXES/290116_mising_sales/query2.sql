
select c.titl_code title,c.titl_long_name,a.bris_branch_code,b.niss_issue_day "WEEK DAY",b.niss_issue_week WEEK,b.niss_issue_year YEAR,b.niss_ean,sum(ag.NET_COMMITED_QUANTITY) sales,sum(ag.NET_COMMITED_QUANTITY - ag.net_credit_quantity) "TOTAL SALES - CREDIT" 
from  agent_net_sales ag, branch_issues a, normal_issues b, titles c where
a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year

and b.niss_title_code = c.titl_code

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code
-----------------------
and b.niss_ean in (

977175662502101,
977175662502102,
977175662502103,
977175662502104
)
and a.bris_issue_year in (2016)
and a.bris_branch_code = 'BRA740'
group by c.titl_code, b.niss_issue_day,b.niss_issue_week,b.niss_issue_year,b.niss_ean,c.titl_long_name,a.bris_branch_code
--order by b.niss_ean
union

select c.titl_code title,c.titl_long_name,a.bris_branch_code,b.niss_issue_day "WEEK DAY",b.niss_issue_week WEEK,b.niss_issue_year YEAR,b.niss_ean,sum(ag.NET_COMMITED_QUANTITY) sales,sum(ag.NET_COMMITED_QUANTITY - ag.net_credit_quantity) "TOTAL SALES - CREDIT" 
from  agent_net_sales ag, branch_issues a, normal_issues b, titles c where
a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year

and b.niss_title_code = c.titl_code

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code
-----------------------
and b.niss_ean in (
977175662502144,
977175662502145,
977175662502146,
977175662597747,
977175662595349,
977175662502153

)
and a.bris_issue_year in (2015)
and a.bris_branch_code = 'BRA740'
group by c.titl_code, b.niss_issue_day,b.niss_issue_week,b.niss_issue_year,b.niss_ean,c.titl_long_name,a.bris_branch_code
order by year,week
