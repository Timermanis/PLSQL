977175662502153
select * from refmast.plant_issues_xref_base x where x.pix_ean = 977175662502153 and x.pix_branch_code = 'BRA740' and x.pix_orig_year in (2015,2016)--000000000269912304
select * from refmast.plant_issues_xref_base x where x.pix_ean = 977175662502101 and x.pix_branch_code = 'BRA740' and x.pix_orig_year in (2015,2016)

select * from archive.zpx_plnt_iss_stg_bak a where a.issue_id=269912304 and a.spoke_id = 740 and a.etl_run_num_seq = 
(select max(etl_run_num_seq) from archive.zpx_plnt_iss_stg_bak a where a.issue_id=000000000269912304 and a.spoke_id = 220) 

select * from archive.zpx_rtrn_stg_bak b where b.issue_id = '000000000269912304' and b.spoke_id = 740 

select sum(QUANTITY) from archive.zpx_rtrn_stg_bak b where b.issue_id = '000000000269912304' and b.spoke_id = 740 and b.document_type = 'JLF'
