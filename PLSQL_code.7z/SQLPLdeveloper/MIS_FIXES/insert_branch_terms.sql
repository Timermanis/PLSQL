--select * from branch_terms b where b.bran_title_code = '50295'
insert into branch_terms select 
BRAN_DATE_FROM,
BRAN_BRANCH_CODE,
50332,--50304,--50306,--50307,--47340,--50295,50328,50329,50330,50331,50332
BRAN_ADVANCE_INVOICE_INDICATOR,
BRAN_COST_DISCOUNT,
BRAN_DATE_TO,
BRAN_TRADE_DISCOUNT,
BRAN_COVERMOUNT_PRICE,
BRAN_COVER_PRICE,
BRAN_AGENT_HANDLING_ALLOWANCE,
BRAN_WHOLESALER_HANDLING_ALLOW,
BRAN_RETAIL_PRICE_EXCEPTION,
BRAN_RETAIL_PRICE_EXCEPT_DAY
from branch_terms where bran_title_code = 50306
-------------------------------
select * from branch_terms b where b.bran_title_code in (50280) for update

select * from branch_terms b where b.bran_title_code = 50306

50278
50280
