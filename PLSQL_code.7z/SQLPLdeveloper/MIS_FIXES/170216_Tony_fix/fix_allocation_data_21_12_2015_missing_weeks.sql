
select ag.net_agent_account_number,ag.net_branch_code,c.titl_code title,c.titl_long_name name,a.bris_on_sale_date,b.niss_issue_day "WEEK DAY",b.niss_issue_week WEEK,b.niss_issue_year YEAR,b.niss_ean,sum(ag.NET_COMMITED_QUANTITY) sales,sum(ag.net_credit_quantity) credits,sum(ag.NET_COMMITED_QUANTITY - ag.net_credit_quantity) "TOTAL (SALES - CREDITS)" 
from  agent_net_sales ag, branch_issues a, normal_issues b, titles c where
a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year

and b.niss_title_code = c.titl_code

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code
-----------------------
and a.bris_on_sale_date = '12-FEB-16'
and ag.net_agent_account_number = 502963039721700
and b.niss_title_code = 9029
and b.niss_issue_year in (2016)
--and b.niss_ean = 977174280705901
and a.bris_branch_code = 'BRA220'
group by ag.net_agent_account_number,c.titl_code, b.niss_issue_day,b.niss_issue_week,b.niss_issue_year,b.niss_ean,c.titl_long_name,ag.net_branch_code,a.bris_on_sale_date
order by b.niss_issue_year, b.niss_issue_week,b.niss_ean

ASHFORD
132943  sale in SAP 1,      sale in I-News 4  502963039721700,9029
132779  sale in SAP 1,      sale in I-News 4  502963084178900,9029


EASTBOURNE
132038  sale in SAP 2,      sale in I-news 9 502963040424300,9030
132064  sale in SAP 3,      sale in I-News 6 502963040219500,9030

select * from customer_x_ref h where h.ccr_bus_partner_id in (132943,132779,132038,132064)
select * from agent_net_sales s where s.net_agent_account_number = 502963039721700

502963039721700,
502963084178900,
502963040424300,
502963040219500

select * from agent_net_sales ag where ag.net_agent_account_number = 502963039721700 and ag.net_title_code = 9032
--------------------------------------------------------------------------


select c.titl_code title,b.niss_issue_day "WEEK DAY",b.niss_issue_week WEEK,b.niss_issue_year YEAR,b.niss_ean,sum(ag.NET_COMMITED_QUANTITY - ag.net_credit_quantity) "TOTAL SALES QUANTITY" 
from  agent_net_sales ag, branch_issues a, normal_issues b, titles c where
a.bris_link_ean = b.niss_ean
and a.bris_link_issue_year = b.niss_issue_year

and b.niss_title_code = c.titl_code

and ag.net_issue_ean = a.bris_ean
and ag.net_issue_year = a.bris_issue_year
and ag.net_branch_code = a.bris_branch_code

and c.titl_code = 39604
and b.niss_issue_year = 2015
group by c.titl_code, b.niss_issue_day,b.niss_issue_week,b.niss_issue_year,b.niss_ean
order by b.niss_ean
