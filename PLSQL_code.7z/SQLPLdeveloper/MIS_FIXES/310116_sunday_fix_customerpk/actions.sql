create table jt_310116_cus_pk_rec as
select 851385090227800 urn, CUS_FROM_DATE from customers c where c.cus_account_number=503103120601200 --
intersect
select CUS_ACCOUNT_NUMBER, CUS_FROM_DATE from customers c where c.cus_account_number=851385090227800

select * from agent_net_sales a where a.net_agent_account_number=503103120601200

select * from dc_ans d where d.net_agent_account_number=503103120601200

29.01.2016	WAKEFIELD	851385090227800	503103120601200	

create table jt_310116_bkp_del_cus as
select * from customers c where c.cus_account_number=503103120601200

--delete from customers c where c.cus_account_number=503103120601200
--851385090227800	503103120601200


select * from msg_files m where m.msg_counterparty = 'BRA740' order by m.msg_timestamp desc for update

create table jt_310116_bkp_del_ans2 as
select * from agent_net_sales a where a.net_agent_account_number=502963014081300
delete from agent_net_sales a where a.net_agent_account_number=502963014081300

create table jt_310116_bkp_del_cus2 as
select * from customers c where c.cus_account_number=502963014081300

delete from customers c where c.cus_account_number=502963014081300
----------------------------------------------------------------------------------------------------------------------------------------
insert into agent_net_sales  (select * from dc_ans where 1=1)

 


