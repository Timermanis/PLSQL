
--------------------------------------1---------------------------------------------------------------------------------------------------------------------    
--create table test01_1 as 
select b.* from archive.zpx_cus_dtls_stg_bak  b
    where (b.ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ)-4 from archive.archive_audit)) 
    and customer_id in (select customer_id from archive.zpx_cus_dtls_stg_bak a, lee_wak_customer_xref@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER 
    and xref.PRM_OLD_BRANCH = 'BRA790');
    --create table test01 as select b.* from archive.zpx_cus_dtls_stg_bak  b
----------------------------------------2
--create table test02_2 as 
select b.* from archive.zpx_cus_supi_stg_bak  b
    where (b.ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ)-4 from archive.archive_audit)) 
    and customer_id in (select customer_id from archive.zpx_cus_supi_stg_bak a, lee_wak_customer_xref@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER--); 
    and xref.PRM_OLD_BRANCH = 'BRA790');
    --create table test02 as select b.* from archive.zpx_cus_supi_stg_bak  b
----------------------------------------3
--create table test03_3 as 
select b.* from archive.zpx_cus_deli_stg_bak  b
    where (b.ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ)-4 from archive.archive_audit)) 
    and customer_id in (select customer_id from archive.zpx_cus_deli_stg_bak a, lee_wak_customer_xref@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER--); 
    and xref.PRM_OLD_BRANCH = 'BRA790');
    --create table test03 as select b.* from archive.zpx_cus_deli_stg_bak b
----------------------------------------4
--create table test04_4 as 
select b.* from archive.zpx_cus_hrs_stg_bak  b-- where--for update
    where (b.ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ)-4 from archive.archive_audit)) 
    and customer_id in (select customer_id from archive.zpx_cus_hrs_stg_bak a, lee_wak_customer_xref@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER--); 
    and xref.PRM_OLD_BRANCH = 'BRA790');
    --create table test04 as select b.* from archive.zpx_cus_hrs_stg_bak  b
----------------------------------------5
--create table test05_5 as 
select b.* from archive.zpx_cus_xrf_stg_bak  b
    where (b.ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ)-4 from archive.archive_audit)) 
    and customer_id in (select customer_id from archive.zpx_cus_xrf_stg_bak a, lee_wak_customer_xref@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER--) 
    and xref.PRM_OLD_BRANCH = 'BRA790');
    --create table test05 as select b.* from archive.zpx_cus_xrf_stg_bak  b
----------------------------------------
