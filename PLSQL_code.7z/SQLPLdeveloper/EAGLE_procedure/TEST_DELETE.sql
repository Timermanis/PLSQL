select * from archive.zpx_cus_dtls_stg_bak 
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))  
    and customer_id in (select customer_id from archive.zpx_cus_dtls_stg_bak a, She_wak_customer_xref@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER 
    and xref.PRM_OLD_BRANCH = 'BRA790');
    

select *  from archive.zpx_cus_supi_stg_bak 
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))   
    and customer_id in (select customer_id from archive.zpx_cus_supi_stg_bak a, She_wak_customer_xref@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER 
    and xref.PRM_OLD_BRANCH = 'BRA790');
    

select *  from archive.zpx_cus_deli_stg_bak 
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))  
    and customer_id in (select customer_id from archive.zpx_cus_deli_stg_bak a, She_wak_customer_xref@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER 
    and xref.PRM_OLD_BRANCH = 'BRA790');
    
    
select *  from archive.zpx_cus_hrs_stg_bak  
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit)) 
    and customer_id in (select customer_id from archive.zpx_cus_hrs_stg_bak a, She_wak_customer_xref@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER 
    and xref.PRM_OLD_BRANCH = 'BRA790');
    
    
select *  from archive.zpx_cus_xrf_stg_bak  
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))
    and customer_id in (select customer_id from archive.zpx_cus_xrf_stg_bak a, She_wak_customer_xref@live_mis.world xref
    where a.customer_id = xref.PRM_BP_NUMBER 
    and xref.PRM_OLD_BRANCH = 'BRA790');
    
    
    
branch:='BRA790';
      xref_table:='She_wak_customer_xref@live_mis.world xref';
