create or replace procedure Backup_Delete_740_ZPX (branch  IN varchar2)
is
l_sql_stmt varchar2(10000);
begin
 l_sql_stmt:='create table support.zpx_cus_dtls_stg_bak_'||branch||'_EAGLE as
select * from archive.zpx_cus_dtls_stg_bak where spoke_id = '||branch||'
and ETL_RUN_NUM_SEQ = (select max (ETL_RUN_NUM_SEQ) from archive.zpx_cus_dtls_stg_bak)';
 dbms_output.put_line( l_sql_stmt );
 EXECUTE IMMEDIATE (l_sql_stmt);

 l_sql_stmt:='create table support.zpx_cus_supi_stg_bak_'||branch||'_EAGLE as
select z.* from archive.zpx_cus_supi_stg_bak z,refmast.latest_customers_mv l
where z.CUSTOMER_ID = l.CD_CUSTOMER_NUM
and l.CD_SPOKE_NUM = '||branch||'
and z.ETL_RUN_NUM_SEQ = (select max (ETL_RUN_NUM_SEQ) from archive.zpx_cus_supi_stg_bak)';
 dbms_output.put_line( l_sql_stmt );
 EXECUTE IMMEDIATE (l_sql_stmt);

 l_sql_stmt:='create table support.zpx_cus_deli_stg_bak_'||branch||'_EAGLE as
select z.* from archive.zpx_cus_deli_stg_bak z,refmast.latest_customers_mv l
where z.CUSTOMER_ID = l.CD_CUSTOMER_NUM
 and CD_SPOKE_NUM = '||branch||'
 and ETL_RUN_NUM_SEQ = (select max (ETL_RUN_NUM_SEQ) from archive.zpx_cus_deli_stg_bak)';
 dbms_output.put_line( l_sql_stmt );
 EXECUTE IMMEDIATE (l_sql_stmt);
 
 l_sql_stmt := 'create table support.zpx_cus_hrs_stg_bak_'||branch||'_EAGLE as
select z.* from archive.zpx_cus_hrs_stg_bak z,refmast.latest_customers_mv l
where z.CUSTOMER_ID = l.CD_CUSTOMER_NUM
 and CD_SPOKE_NUM = '||branch||'
 and ETL_RUN_NUM_SEQ = (select max (ETL_RUN_NUM_SEQ) from archive.zpx_cus_hrs_stg_bak)';
 dbms_output.put_line( l_sql_stmt );
 EXECUTE IMMEDIATE (l_sql_stmt);
 
 l_sql_stmt := 'create table support.zpx_cus_xrf_stg_bak_'||branch||'_EAGLE as 
select *  from  archive.zpx_cus_xrf_stg_bak z where z.spoke_id = '||branch||'
and ETL_RUN_NUM_SEQ = (select max (ETL_RUN_NUM_SEQ) from archive.zpx_cus_xrf_stg_bak)';
 dbms_output.put_line( l_sql_stmt );
 EXECUTE IMMEDIATE (l_sql_stmt);
 
 

end Backup_Delete_740_ZPX;
