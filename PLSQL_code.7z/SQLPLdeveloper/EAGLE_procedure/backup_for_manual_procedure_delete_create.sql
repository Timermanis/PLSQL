create table support.zpx_cus_dtls_stg_bak_BRA790_1 as
select *  from archive.zpx_cus_dtls_stg_bak
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))
    and customer_id in (select customer_id from archive.zpx_cus_dtls_stg_bak a, lee_wak_customer_xref@MIS.WORLD xref 
    where a.customer_id = xref.PRM_BP_NUMBER
    and xref.PRM_OLD_BRANCH = 'BRA790');
    
create table support.zpx_cus_supi_stg_bak_BRA790_1 as
select *  from archive.zpx_cus_supi_stg_bak
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))
    and customer_id in (select customer_id from archive.zpx_cus_supi_stg_bak a, lee_wak_customer_xref@MIS.WORLD xref 
    where a.customer_id = xref.PRM_BP_NUMBER
    and xref.PRM_OLD_BRANCH = 'BRA790');
    
create table support.zpx_cus_deli_stg_bak_BRA790_1 as
select *  from archive.zpx_cus_deli_stg_bak
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))
    and customer_id in (select customer_id from archive.zpx_cus_deli_stg_bak a, lee_wak_customer_xref@MIS.WORLD xref 
    where a.customer_id = xref.PRM_BP_NUMBER
    and xref.PRM_OLD_BRANCH = 'BRA790');
    
create table support.zpx_cus_hrs_stg_bak_BRA790_1 as
select *  from archive.zpx_cus_hrs_stg_bak
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))
    and customer_id in (select customer_id from archive.zpx_cus_hrs_stg_bak a, lee_wak_customer_xref@MIS.WORLD xref 
    where a.customer_id = xref.PRM_BP_NUMBER
    and xref.PRM_OLD_BRANCH = 'BRA790');
    
create table support.zpx_cus_xrf_stg_bak_BRA790_1 as
select *  from archive.zpx_cus_xrf_stg_bak
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))
    and customer_id in (select customer_id from archive.zpx_cus_xrf_stg_bak a, lee_wak_customer_xref@MIS.WORLD xref 
    where a.customer_id = xref.PRM_BP_NUMBER
    and xref.PRM_OLD_BRANCH = 'BRA790');    
    ---------------------------------------------------------------------

delete  from archive.zpx_cus_dtls_stg_bak
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))
    and customer_id in (select customer_id from archive.zpx_cus_dtls_stg_bak a, lee_wak_customer_xref@MIS.WORLD xref 
    where a.customer_id = xref.PRM_BP_NUMBER
    and xref.PRM_OLD_BRANCH = 'BRA790');
    

delete  from archive.zpx_cus_supi_stg_bak
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))
    and customer_id in (select customer_id from archive.zpx_cus_supi_stg_bak a, lee_wak_customer_xref@MIS.WORLD xref 
    where a.customer_id = xref.PRM_BP_NUMBER
    and xref.PRM_OLD_BRANCH = 'BRA790');
    

delete  from archive.zpx_cus_deli_stg_bak
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))
    and customer_id in (select customer_id from archive.zpx_cus_deli_stg_bak a, lee_wak_customer_xref@MIS.WORLD xref 
    where a.customer_id = xref.PRM_BP_NUMBER
    and xref.PRM_OLD_BRANCH = 'BRA790');
    

delete  from archive.zpx_cus_hrs_stg_bak
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))
    and customer_id in (select customer_id from archive.zpx_cus_hrs_stg_bak a, lee_wak_customer_xref@MIS.WORLD xref 
    where a.customer_id = xref.PRM_BP_NUMBER
    and xref.PRM_OLD_BRANCH = 'BRA790');
    

delete  from archive.zpx_cus_xrf_stg_bak
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit))
    and customer_id in (select customer_id from archive.zpx_cus_xrf_stg_bak a, lee_wak_customer_xref@MIS.WORLD xref 
    where a.customer_id = xref.PRM_BP_NUMBER
    and xref.PRM_OLD_BRANCH = 'BRA790');   
 --------------------------------------test   
    
delete from archive.zpx_cus_dtls_stg_bak
    where (ETL_RUN_NUM_SEQ = (select max (aa_ETL_RUN_NUM_SEQ) from archive.archive_audit)
    and customer_id in (select customer_id from archive.zpx_cus_dtls_stg_bak a, lee_wak_customer_xref@MIS.WORLD xref
    where a.customer_id = xref.PRM_BP_NUMBER
    and xref.PRM_OLD_BRANCH = 'BRA790'));
   
    
