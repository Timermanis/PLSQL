select count(*) from archive.zpx_cus_dtls_stg_bak ;--121703
select count(*)  from test01_1;
select count(*)  from zpx_cdsbak_bra790_eagle;

select count(*) from archive.zpx_cus_supi_stg_bak ;--14737
select count(*)  from test02_2;
select count(*)  from zpx_cssbak_bra790_eagle;

select count(*) from archive.zpx_cus_deli_stg_bak ;--14839
select count(*)  from test03_3;
select count(*)  from zpx_cdstbak_bra790_eagle;

select count(*) from archive.zpx_cus_hrs_stg_bak ;--9364
select count(*)  from test04_4;
select count(*)  from zpx_chsbak_bra790_eagle;

select count(*) from archive.zpx_cus_xrf_stg_bak ;--20723
select count(*)  from test05_5;
select count(*)  from zpx_cxrfsbak_bra790_eagle;

