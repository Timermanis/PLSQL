create table jt_customers_210615 nologging
as
select *
from customers c --as of timestamp systimestamp - interval '1' day c
where c.cus_branch_code = 'BRA790'
and cus_to_date = '31-DEC-4000'
and cus_spoke_code = 2
and cus_account_number in (select cx.prm_old_urn from lee_wak_customer_xref cx)

insert into customers
select *
create table  jt_customers_220615_v1
 as
 select *
 from customers c--as of timestamp systimestamp - interval '1' hour c
where c.cus_branch_code = 'BRA790'
and ( cus_to_date = to_date('27/06/2015 23:59:59','dd/mm/yyyy hh24:mi:ss'))-- 23:59:59)
and cus_spoke_code = 2
and cus_account_number in (select cx.prm_old_urn from lee_wak_customer_xref cx)

select *
--create table  jt_customers_220615
 from customers c--as of timestamp systimestamp - interval '1' hour c
where c.cus_branch_code = 'BRA790'
and cus_from_date = '28-JUN-2015'
and cus_spoke_code = 2
and cus_account_number in (select cx.prm_old_urn from lee_wak_customer_xref cx)



insert into customers  select *
from jt_customers_210615;

select * from jt_customers_220615_leeds

select distinct c.cus_account_number, c.cus_branch_code, j.cus_branch_code , c.cus_from_date, j.cus_from_date, c.cus_to_date, j.cus_to_date
from customers c, jt_customers_210615 j
where c.cus_account_number=j.cus_account_number
and c.cus_from_date=j.cus_from_date


 
select c.*
from customers c ,jt_customers_210615 j where c.cus_account_number=j.cus_account_number
and  c.cus_to_date='31/dec/4000'

select c.*
from customers c ,jt_customers_210615 j where c.cus_account_number=j.cus_account_number
and  c.cus_to_date= (select max cus_to_date from customers)




create table jt_customers_210615_leeds
as
select *
from customers as of timestamp systimestamp - interval '1' day c
where cus_branch_code = 'BRA790'
and cus_spoke_code = 2
and cus_account_number in (select cx.prm_old_urn
                           from lee_wak_customer_xref cx)
select distinct j.cus_account_number
from   jt_customers_220615_leeds j    minus   
select distinct j.cus_account_number
from   jt_customers_210615_leeds j                 
                           
                           
create table jt_customers_220615_leeds
as
select *
from customers 
where cus_branch_code = 'BRA790'
and cus_spoke_code = 2
and cus_account_number in (select cx.prm_old_urn
                           from lee_wak_customer_xref cx)

delete from customers c where exists (select 1 from jt_customers_220615_leeds t where t.cus_account_number=c.cus_account_number and t.cus_from_date=c.cus_from_date)
insert into customers select * from jt_customers_210615_leeds
