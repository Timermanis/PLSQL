select * from user_tables t where t.table_name like '%SPOKE%' or t.table_name like '%BRANCH%'

create table backup_jm_organisation_units as select * from jm_organisation_units
delete from jm_organisation_units where ORGU_CODE='BRA780';
update jm_organisation_units set ORGU_DESCRIPTION = 'Wakefield',ORGU_STATUS='O' where ORGU_CODE='BRA740'

create table backup_branch_parents as select * from branch_parents
update branch_parents set BRANCH_NAME = 'Wakefield' where BRANCH_CODE = 'BRA740'

create table backup_SPOKE_BRANCHES_LOADS as select * from SPOKE_BRANCHES_LOADS
update SPOKE_BRANCHES_LOADS set SB_SPOKE_NAME = 'Wakefield',SB_ZONE=0 where SB_BRANCH_CODE = 'BRA740'

create table backup_SPOKE_BRANCHES as select * from SPOKE_BRANCHES
update SPOKE_BRANCHES set SB_BRANCH_CODE = 'BRA740',SB_SPOKE_NAME = 'Wakefield',SB_ZONE=0 where SB_SPOKE_CODE = 'BRA740'

