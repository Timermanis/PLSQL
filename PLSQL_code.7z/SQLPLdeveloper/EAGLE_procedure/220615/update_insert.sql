  create table jt_customers_orig_220614_740
  as select *
  from customers c
  where c.cus_branch_code in ('BRA790');
 -- and cus_spoke_code = 2
  
  create table jt_custom_xref_orig_220614_740
  as select *
  from customer_x_ref x
  where x.ccr_branch_code in ('BRA790');
  
  
--Step 2
--Close the old customer records

update customers c
   set c.cus_to_date = to_date('21/06/2015 23:59:59','dd/mm/yyyy hh24:mi:ss')
where c.cus_branch_code in ('BRA790')
   and c.cus_to_date = to_date('31/12/4000','dd/mm/yyyy')
   and c.cus_spoke_code = 2
   and c.cus_account_number in (select x.prm_old_urn from lee_wak_customer_xref x) -- moving to Wakefield
                              
commit;

u

-- Step 3
--copy them to the new hub branch
insert into customers c
select  CUS_BILL_SHOW,
        CUS_ACCOUNT_NUMBER,
       to_date('22/06/2015','dd/mm/yyyy') CUS_FROM_DATE,
        to_date('31/12/4000','dd/mm/yyyy')CUS_TO_DATE,
        CUS_ACCOUNT_STATUS,
        CUS_REALLOCATION_FLAG,
        CUS_ADDRESS_LINE_1,
        CUS_ADDRESS_LINE_2,
        CUS_ADDRESS_LINE_3,
        CUS_ADDRESS_LINE_4,
        x.prm_new_box_number CUS_BOX_NUMBER,
        CUS_DAILIES_HANDLED,
        CUS_EPOS_TILL_IN_USE,
        CUS_DAILIES_BOX_OUTS_HANDLED,
        CUS_SUNDAYS_BOX_OUTS_HANDLED,
        CUS_SUB_POST_OFFICE,
        CUS_POSTCODE_OUTER,
        CUS_POSTCODE_INNER,
        CUS_PERIODICALS_HANDLED,
        CUS_PERIODICALS_BOX_OUTS_HAND,
        CUS_NFRN_MEMBER,
        CUS_NEWSFORCE_MEMBER,
        CUS_MAGAZINES_HANDLED,
        'BRA740' CUS_BRANCH_CODE,  --- Leeds is 740
        CUS_TRADING_NAME,
       CUS_SUNDAYS_HANDLED,
        CUS_MAGAZINES_BOX_OUTS_HANDLE,
        CUS_FRIDAY_TIME_CLOSED,
        CUS_FRONTAGE,
        CUS_MONDAY_TIME_OPEN,
        CUS_MONDAY_TIME_CLOSED,
        CUS_WEDNESDAY_TIME_OPEN,
        CUS_WEDNESDAY_TIME_CLOSED,
        CUS_TURNOVER,
        CUS_TUESDAY_TIME_OPEN,
        CUS_TUESDAY_TIME_CLOSED,
        CUS_THURSDAY_TIME_OPEN,
        CUS_THURSDAY_TIME_CLOSED,
        CUS_TELEPHONE_NUMBER,
        CUS_SUNDAY_TIME_OPEN,
        CUS_SUNDAY_TIME_CLOSED,
        CUS_STATUS_DATE,
        CUS_SATURDAY_TIME_OPEN,
        CUS_SATURDAY_TIME_CLOSED,
        CUS_PROFIT,
        CUS_KNOWN_AS_NAME,
        CUS_GRANT_DATE,
        CUS_FRIDAY_TIME_OPEN,
        CUS_FAX_NUMBER,
        CUS_CONTACT_NAME,
        CUS_DEPOT_NUMBER,
        CUS_CLOSED_SINCE_DATE,
        CUS_SELECTED_AGENT_NET_SALES,
        CUS_ANMW_CODE,
        CUS_MULTIPLE_CODE,
        CUS_MULTIPLE_GRADE_CODE,
        CUS_POSTCODE,
        CUS_TYPE,
        CUS_TELEGRAPH_CODE,
        x.prm_new_spoke_number CUS_SPOKE_CODE,
        CUS_IPC,
        CUS_NATIONAL_LOTTERY,
        CUS_DELETE_FLAG,
        CUS_BUDGET_CENTRE,
        CUS_MULT_ACCOUNT_INDICATOR,
        CUS_PAYMENT_TYPE,
        CUS_BOARD_NUMBER_1,
        CUS_RUN_NUMBER_1,
        CUS_DROP_NUMBER_1,
        CUS_BOARD_NUMBER_2,
        CUS_RUN_NUMBER_2,
        CUS_DROP_NUMBER_2,
        CUS_BOARD_NUMBER_3,
        CUS_RUN_NUMBER_3,
        CUS_DROP_NUMBER_3,
        CUS_BOARD_NUMBER_4,
        CUS_RUN_NUMBER_4,
        CUS_DROP_NUMBER_4,
        CUS_REALLOCATION_PARAMETER,
        CUS_OUTLET_REFERENCE,
        CUS_MINIMUM_ENTRY_LEVEL,
        CUS_DEFERRED_INDICATOR,
        CUS_OWNER_TITLE,
        CUS_OWNER_FIRST_NAME,
        CUS_OWNER_SURNAME,
        CUS_MANAGER_TITLE,
        CUS_MANAGER_FIRST_NAME,
        CUS_MANAGER_SURNAME,
        CUS_PROMOTION,
        CUS_HOME_DELIVERY,
        CUS_SHOP_SAVES,
        CUS_NIGHT_SALES,
        CUS_COLLECTION_DAY_MON,
        CUS_COLLECTION_DAY_TUE,
        CUS_COLLECTION_DAY_WED,
        CUS_COLLECTION_DAY_THU,
        CUS_COLLECTION_DAY_FRI,
        CUS_COLLECTION_DAY_SAT,
        CUS_COLLECTION_DAY_SUN,
        CUS_SL_ACCOUNT_TYPE,
        CUS_SL_ACCOUNT_STATUS,
        CUS_PAYMENT_TERMS,
        CUS_PAYMENT_METHOD,
        CUS_STMNT_INTERVAL,
        CUS_RACK_ONLY,
        CUS_INVOICE_SEQ,
        CUS_INVOICE_FORMAT,
        CUS_PRINT_FLAG,
        CUS_MAG_DEFERRED_IND,
        CUS_MAGS_START_DATE,
        CUS_PERIOS_START_DATE,
        CUS_MAGS_STOP_DATE,
        CUS_PERIOS_STOP_DATE
   from customers c
   join  lee_wak_customer_xref x
     on c.cus_account_number = x.prm_new_urn
  where cus_to_date = to_date('21/06/2015 23:59:59','dd/mm/yyyy hh24:mi:ss')
    and cus_branch_code in ('BRA790')
    and cus_spoke_code = 2;
    
select * from customers c where CUS_BRANCH_CODE = 'BRA740' and c.cus_to_date='31-dec-4000'



--Step 4
--update the customer x ref to pick up the new details
update customer_x_ref x
   set (x.ccr_branch_code, x.ccr_legacy_box_no) = (select icx.prm_new_branch, icx.prm_new_box_number
                                                     from lee_wak_customer_xref icx
                                                    where icx.prm_bp_number = x.ccr_bus_partner_id )
                                                    
where exists (select 1
                 from lee_wak_customer_xref icx
                 where icx.prm_bp_number = x.ccr_bus_partner_id);
                 
                 
 
  
select *
  from jt_customers_orig_220614 c
  where c.cus_branch_code in ('BRA790') minus
select *
  from customers c
  where c.cus_branch_code in ('BRA790')
  
  
  select * from customer_x_ref x where x.ccr_branch_code='BRA740'
