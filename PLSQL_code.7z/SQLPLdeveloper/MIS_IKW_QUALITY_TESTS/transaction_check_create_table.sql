000000000493830003
000000000003264191

create table MIS_IKW_489080012_120117 as
select  'IKW' DB ,a.issue_id issue_id, a.customer_id customer_id,a.spoke_id spoke_id,a.transaction_date transaction_date,a.document_type document_type,a.item_type item_type,
a.quantity quantity from archive.zpx_rtrn_cdn_stg_bak a where a.issue_id = '000000000489080012'
union all
select  'MIS'  ,b.issue_id, b.customer_id,b.spoke_id,b.transaction_date,b.document_type,b.item_type,b.quantity from archive.zpx_rtrn_stg_bak b where b.issue_id = '000000000489080012'




select db,t.document_type,t.item_type,sum(t.quantity) from MIS_IKW_23192078_N t group by db,t.document_type,t.item_type


select * from archive.zpx_rtrn_cdn_stg_bak a,archive.zpx_rtrn_stg_bak b  where 
a.issue_id = b.issue_id and 
a.customer_id = b.customer_id and
b.issue_id = '000000000003264191' 



union all
select 'MIS',c.* from archive.zpx_rtrn_stg_bak c where c.issue_id = '000000000003264191' 

select c.* from archive.zpx_rtrn_cdn_stg_bak c where c.issue_id = '000000000003264191' 



--'000000000023192078'
--'000000000057082361'
--'000000000480630012'
'000000000480630012'
'000000000004262081'
'000000000489080012'
28932081
