select db,t.document_type,t.item_type,sum(t.quantity) from MIS_IKW_23192078_N t group by db,t.document_type,t.item_type
-------------------
select db,t.document_type,t.item_type,sum(abs(t.quantity)) from MIS_IKW_57082361_n t group by db,t.document_type,t.item_type 

select db,t.document_type,t.item_type,sum(abs(t.quantity)) qua from MIS_IKW_480630012_n t where db = 'MIS' 
and t.document_type in ('CLM','JLF','ZAD1','ZCLC','ZRE','ZRE1','ZOV','ZAD2','ZNDT') or db = 'IKW' 
group by db,t.document_type,t.item_type order by db, qua
--1729
--'JLF' - 

select db,t.document_type,t.item_type,sum(t.quantity) from mis_ikw_4262081_120117 t group by db,t.document_type,t.item_type


select db,t.document_type,t.item_type,sum(abs(t.quantity)) qua from MIS_IKW_489080012_120117 t where db = 'MIS' 
and t.document_type in ('CLM','JLF','ZAD1','ZCLC','ZRE','ZRE1','ZOV','ZAD2','ZNDT') or db = 'IKW' 
group by db,t.document_type,t.item_type order by db, qua
