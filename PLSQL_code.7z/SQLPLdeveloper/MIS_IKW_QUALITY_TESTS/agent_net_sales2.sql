     PIX_SAP_ID  PIX_BRANCH_CODE  PIX_LEGACY_EAN  PIX_LEGACY_TITLE
1  000000000385270078  BRA740  977204500910278  35405
   	PIX_SAP_ID	PIX_BRANCH_CODE	PIX_LEGACY_EAN	PIX_LEGACY_TITLE
1	000000000416720114	BRA740	977204721305714	38271


select distinct p.pix_sap_id,p.pix_branch_code,p.pix_legacy_ean,p.pix_legacy_title from branch_issues@mis.world b, refmast.plant_issues_xref_base p
where BRIS_BRANCH_CODE = p.pix_branch_code and
 BRIS_ISSUE_YEAR = p.pix_year and
 BRIS_EAN = p.pix_ean and
 p.pix_ean = p.pix_legacy_ean and
 p.pix_year = to_char(sysdate, 'YYYY') and
 p.PIX_LEGACY_TITLE IS NOT NULL  and
 p.pix_plant_on_sale_date IS NOT NULL and
 p.pix_issue_type not in  ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
p.pix_spoke_code != '745' and
p.pix_week = 43


select * from agent_net_sales@mis.world b where NET_ISSUE_EAN = 977204890903410
select * from branch_issues@mis.world b where BRIS_EAN = 977204890903410

select * from dw.plant_cust_iss_rtrn_sum_a p where p.plis_issue_num = 410090059
select * from refmast.plant_issues l where l.plis_issue_num = 410090059
select * from refmast.plant_issues_xref_base where PIX_SAP_ID = 212992065

select * from titles@mis.world where TITL_CODE = 37202

