select TYP_LOC_FROM_CODE, TYP_LOC_TO_CODE, TYP_MOVEMENT_CODE, TYP_CREDIT_DEBIT_FLAG, TYP_INTERBRANCH_FLAG
from  dw.stock_trn_report_type r where r.typ_loc_from_code = '####' and r.typ_loc_to_code = '####' and r.typ_credit_debit_flag = 'S' 

select count(*) from customers@mis.world where cus_to_date  > '31-DEC-3999' and cus_from_date  < '01-DEC-2016'--56383

select * from customer_x_ref@mis.world--54727

select * from dw.retailer f where f.out_id is not null

select * from refmast.latest_customers_mv c where c.cd_closed_date = '31-DEC-4000'   and c.cd_customer_num  in 
(select customer_id from orbital_customers_v@mis.world);

select count(*) from refmast.latest_customers_mv c where c.cd_closed_date = '31-DEC-4000' and c.cd_open_date < '31-DEC-3999'  and c.cd_customer_num not in 
(select customer_id from orbital_customers_v@mis.world);--30226

select CCR_CUST_URN from customer_x_ref@mis.world a
minus
select c.cd_urn from refmast.latest_customers_mv c--10 rec less

select c.cd_urn from refmast.latest_customers_mv c
minus
select CCR_CUST_URN from customer_x_ref@mis.world a--6438 

select * from customers@mis.world 

create table test_test as
select c.cd_urn from refmast.latest_customers_mv c where c.cd_closed_date = '31-DEC-4000' and c.cd_status_num in (0,1)  and c.cd_customer_num not in 
(select customer_id from orbital_customers_v@mis.world) and c.cd_customer_num between 100000 and 199999
minus
select CCR_CUST_URN from customer_x_ref@mis.world a --29 FINAL QUERY

select * from customer_x_ref@mis.world a


select * from refmast.latest_customers_mv c where c.cd_urn = 150084001110200

select * from refmast.latest_customers_mv where cd_customer_num  in 
(select customer_id from orbital_customers_v@mis.world);--30226
