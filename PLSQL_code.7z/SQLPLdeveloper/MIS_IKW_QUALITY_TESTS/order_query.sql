select * from JT_MIS_IKW_CHECKS_TEST t where  (DELIV_DIFF_P > 3 or RETURN_DIFF_P > 3 )
order by case when abs(t.deliv_diff_p) > abs(t.return_diff_p) then t.deliv_diff_p else t.return_diff_p end desc

select * from JT_MIS_IKW_CHECKS_TEST t

delete from JT_MIS_IKW_CHECKS_TEST t
