select * from agent_net_sales@mis.world b,refmast.plant_issues_xref_base x 
where b.net_issue_ean = x.pix_legacy_ean 
and b.net_issue_year = x.PIX_YEAR
and b.net_branch_code = x.PIX_BRANCH_CODE
and x.pix_sap_id = 446920008

select * from refmast.plant_issues_xref_base x where x.pix_sap_id = 446920008

select * from sap_ids_temp

select * from dw.plant_cust_iss_rtrn_sum_a p where p.partitioning_date > sysdate -10 and p.partitioning_date < sysdate -8

select distinct p.pix_sap_id from refmast.plant_issues_xref_base p 
where 
 p.pix_ean = p.pix_legacy_ean and
 p.pix_orig_year = to_char(sysdate, 'YYYY') and
 p.PIX_LEGACY_TITLE IS NOT NULL  and
 p.pix_plant_on_sale_date IS NOT NULL and
 p.pix_issue_type not in  ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
 p.pix_spoke_code != '745' and
 p.pix_week = 47 and
 --p.pix_sap_id = 27972080;
 rownum < 200

create table sap_ids_temp as
select distinct p.pix_sap_id from refmast.plant_issues_xref_base p 
where 
 p.pix_ean = p.pix_legacy_ean and
 p.pix_orig_year = to_char(sysdate, 'YYYY') and
 p.PIX_LEGACY_TITLE IS NOT NULL  and
 p.pix_plant_on_sale_date IS NOT NULL and
 p.pix_issue_type not in  ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
 p.pix_spoke_code != '745' and
 p.pix_week = 47 and
 p.pix_sap_id = 27972080
 rownum < 100

select sysdate -2 from dual
PIX_BRANCH_CODE, PIX_EAN, PIX_ORIG_YEAR
PIX_BRANCH_CODE, PIX_LEGACY_EAN, PIX_YEAR

select OUT_NUM,PLIS_ISSUE_NUM,MAIN_SUPPLY_QTY,	EXTRA_SUPPLY_QTY,	RETURN_QTY
 from dw.plant_cust_iss_rtrn_sum_a p where p.plis_issue_num = 27972080

minus
select c.CCR_BUS_PARTNER_ID,to_number(x.pix_sap_id),NET_COMMITED_QUANTITY,NET_OTHER_SALES_QUANTITY,NET_RETURN_QUANTITY
 from agent_net_sales@mis.world b,customer_x_ref@mis.world c,refmast.plant_issues_xref_base x 
where b.NET_AGENT_ACCOUNT_NUMBER = c.CCR_CUST_URN
and b.net_issue_ean = x.pix_legacy_ean 
and b.net_issue_year = x.PIX_YEAR
and b.net_branch_code = x.PIX_BRANCH_CODE
and x.pix_sap_id = 27972080


create table jt_MIS_IKW_CHECKS as
with c as
(select max(to_number(p.plis_issue_num)) sap_id ,sum(MAIN_SUPPLY_QTY)+	sum(EXTRA_SUPPLY_QTY) delivery,	sum(RETURN_QTY) return
 from dw.plant_cust_iss_rtrn_sum_a p where p.plis_issue_num in (1)
union all
select  max(to_number(x.pix_sap_id)) sap_id ,-sum(NET_COMMITED_QUANTITY) - sum(NET_OTHER_SALES_QUANTITY),-sum(NET_RETURN_QUANTITY)
 from agent_net_sales@mis.world b,customer_x_ref@mis.world c,refmast.plant_issues_xref_base x 
where b.NET_AGENT_ACCOUNT_NUMBER = c.CCR_CUST_URN
and b.net_issue_ean = x.pix_legacy_ean 
and b.net_issue_year = x.PIX_YEAR
and b.net_branch_code = x.PIX_BRANCH_CODE
and x.pix_sap_id in (1))
select max(sap_id) sap_id,max(delivery) delivery,sum(delivery) delivery_diff,sum(return) return_diff,abs(sum(delivery))/max(delivery)*100 DELIV_DIFF_P,abs(sum(return))/max(delivery)*100 RETURN_DIFF_P from c

---------- :)

select * from refmast.plant_issues_xref_base x where x.pix_sap_id in (select unique pix_sap_id from refmast.plant_issues_xref_base where x.pix_sap_id = pix_sap_id)
and x.pix_sap_id = 212992065

select unique x.pix_sap_id,pix_legacy_ean,PIX_YEAR,PIX_BRANCH_CODE  from refmast.plant_issues_xref_base x,jt_MIS_IKW_CHECKS j 
where x.pix_sap_id = j.sap_id

with c as
(select max(to_number(p.plis_issue_num)) sap_id ,sum(MAIN_SUPPLY_QTY)+	sum(EXTRA_SUPPLY_QTY) delivery,	sum(RETURN_QTY) return
 from dw.plant_cust_iss_rtrn_sum_a p where p.plis_issue_num in (1)
union all
select  max(to_number(x.pix_sap_id)) sap_id ,-sum(NET_COMMITED_QUANTITY) - sum(NET_OTHER_SALES_QUANTITY),-sum(NET_RETURN_QUANTITY)
 from agent_net_sales@mis.world b,customer_x_ref@mis.world c,(select unique pix_sap_id,pix_legacy_ean,PIX_YEAR,PIX_BRANCH_CODE  from refmast.plant_issues_xref_base) x
where b.NET_AGENT_ACCOUNT_NUMBER = c.CCR_CUST_URN
and b.net_issue_ean = x.pix_legacy_ean 
and b.net_issue_year = x.PIX_YEAR
and b.net_branch_code = x.PIX_BRANCH_CODE
and x.pix_sap_id in (1))
select max(sap_id) sap_id,max(delivery) delivery,sum(delivery) delivery_diff,sum(return) return_diff,abs(sum(delivery))/max(delivery)*100 DELIV_DIFF_P,abs(sum(return))/max(delivery)*100 RETURN_DIFF_P from c
