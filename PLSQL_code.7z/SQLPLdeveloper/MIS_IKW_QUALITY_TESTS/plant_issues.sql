select p.pix_sap_id,p.pix_branch_code from refmast.plant_issues l,refmast.plant_issues_xref_base p  where 
l.plis_issue_num = p.pix_sap_id and
'BRA'||l.plis_branch_num = p.pix_spoke_code and
p.pix_year = to_char(sysdate, 'YYYY') and
 p.PIX_LEGACY_TITLE IS NOT NULL  and
 p.pix_plant_on_sale_date IS NOT NULL and
 p.pix_issue_type not in ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
p.pix_spoke_code != '745' and
p.pix_week = 23

minus

select p.pix_sap_id,p.pix_branch_code from branch_issues@mis.world, refmast.plant_issues_xref_base p
where BRIS_BRANCH_CODE = p.pix_branch_code and
 BRIS_ISSUE_YEAR = p.pix_year and
 BRIS_EAN = p.pix_ean and
 p.pix_year = to_char(sysdate, 'YYYY') and
 p.PIX_LEGACY_TITLE IS NOT NULL  and
 p.pix_plant_on_sale_date IS NOT NULL and
 p.pix_issue_type not in  ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
p.pix_spoke_code != '745' and
p.pix_week = 23


select to_char(sysdate, 'YYYY')  from dual

select *  from refmast.plant_issues r where r.plis_issue_num = 000000000385270078
select *  from refmast.plant_issues_xref_base x where x.pix_sap_id = 000000000458650003--z2
select *  from refmast.plant_issues_xref_base x where x.pix_sap_id = 000000000048772329--wz

select p.pix_sap_id,p.pix_branch_code from refmast.plant_issues l,refmast.plant_issues_xref_base p  where 
l.plis_issue_num = p.pix_sap_id and
'BRA'||l.plis_branch_num = p.pix_spoke_code and
p.pix_year = to_char(sysdate, 'YYYY') and
 --p.PIX_LEGACY_TITLE IS NOT NULL  and
 --p.pix_plant_on_sale_date IS NOT NULL and
 --p.pix_issue_type not in  ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
--p.pix_spoke_code != '745' and
p.pix_sap_id = 000000000048772329

minus

select p.pix_sap_id,p.pix_branch_code from branch_issues@mis.world, refmast.plant_issues_xref_base p
where BRIS_BRANCH_CODE = p.pix_branch_code and
 BRIS_ISSUE_YEAR = p.pix_year and
 --BRIS_EAN = p.pix_ean and
  BRIS_EAN = p.pix_legacy_ean and
 p.pix_year = to_char(sysdate, 'YYYY') and
 --p.PIX_LEGACY_TITLE IS NOT NULL  and
 --p.pix_plant_on_sale_date IS NOT NULL and
 --p.pix_issue_type not in  ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
--p.pix_spoke_code != '745' and
p.pix_sap_id = 000000000048772329

--p.pix_ean = p.pix_legacy_ean 
select distinct p.pix_sap_id,p.pix_branch_code,p.pix_legacy_ean,p.pix_legacy_title from refmast.plant_issues l,refmast.plant_issues_xref_base p 
 where 
l.plis_issue_num = p.pix_sap_id and--
p.pix_ean = p.pix_legacy_ean and
'BRA'||l.plis_branch_num = p.pix_spoke_code and--
p.pix_year = to_char(sysdate, 'YYYY') and
 p.PIX_LEGACY_TITLE IS NOT NULL  and
 p.pix_plant_on_sale_date IS NOT NULL and
 p.pix_issue_type not in  ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
p.pix_spoke_code != '745' and
p.pix_week = 24--43--and
--p.pix_sap_id = 000000000048772329

minus

select distinct p.pix_sap_id,p.pix_branch_code,p.pix_legacy_ean,p.pix_legacy_title from branch_issues@mis.world b, refmast.plant_issues_xref_base p
where BRIS_BRANCH_CODE = p.pix_branch_code and
 BRIS_ISSUE_YEAR = p.pix_year and
 BRIS_EAN = p.pix_ean and
 p.pix_ean = p.pix_legacy_ean and
 -- BRIS_EAN = p.pix_legacy_ean and
 p.pix_year = to_char(sysdate, 'YYYY') and
 p.PIX_LEGACY_TITLE IS NOT NULL  and
 p.pix_plant_on_sale_date IS NOT NULL and
 p.pix_issue_type not in  ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
p.pix_spoke_code != '745' and
p.pix_week = 24--43--and

   	PIX_SAP_ID	PIX_BRANCH_CODE	PIX_LEGACY_EAN	PIX_LEGACY_TITLE
1	000000000385270078	BRA740	977204500910278	35405

   	PIX_SAP_ID	PIX_BRANCH_CODE	PIX_LEGACY_EAN	PIX_LEGACY_TITLE
1	000000000416720114	BRA740	977204721305714	38271
---CHANGED to PIX original year
select distinct p.pix_sap_id,p.pix_branch_code,p.pix_legacy_ean,p.pix_legacy_title from refmast.plant_issues l,refmast.plant_issues_xref_base p 
where 
 l.plis_issue_num = p.pix_sap_id and--
 p.pix_ean = p.pix_legacy_ean and
 'BRA'||l.plis_branch_num = p.pix_spoke_code and--
 p.pix_orig_year = to_char(sysdate, 'YYYY') and
 p.PIX_LEGACY_TITLE IS NOT NULL  and
 p.pix_plant_on_sale_date IS NOT NULL and
 p.pix_issue_type not in  ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
 p.pix_spoke_code != '745' and
 --p.pix_week in (TO_CHAR(sysdate, 'WW')-1, TO_CHAR(sysdate, 'WW'))
 p.pix_week > 10
minus

select distinct p.pix_sap_id,p.pix_branch_code,p.pix_legacy_ean,p.pix_legacy_title from branch_issues@mis.world b, refmast.plant_issues_xref_base p
where BRIS_BRANCH_CODE = p.pix_branch_code and
 BRIS_ISSUE_YEAR = p.pix_year and
 BRIS_EAN = p.pix_ean and
 p.pix_ean = p.pix_legacy_ean and
 p.pix_orig_year  = to_char(sysdate, 'YYYY') and
 p.PIX_LEGACY_TITLE IS NOT NULL  and
 p.pix_plant_on_sale_date IS NOT NULL and
 p.pix_issue_type not in  ( 'XX','Z3','Z4','Z5','Z6','Z7','Z8','ZS','ZZ' ) and
 p.pix_spoke_code != '745' and
 --p.pix_week in (TO_CHAR(sysdate, 'WW'),TO_CHAR(sysdate, 'WW')-1)
  p.pix_week > 10

   	PIX_SAP_ID	PIX_BRANCH_CODE	PIX_LEGACY_EAN	PIX_LEGACY_TITLE
1	000000000033902070	BRA740	977193698398928	3390
