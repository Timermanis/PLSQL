select * from branch_issues b where b.bris_issue_year = 2016 and b.bris_issue_week = 53

select unique b.* from branch_issues b, agent_net_sales a 
where b.bris_issue_year = a.net_issue_year
and b.bris_ean = a.net_issue_ean
and b.bris_branch_code = a.net_branch_code
and b.bris_issue_year = 2016 and b.bris_issue_week = 53

create table jt_2016_w53_problem as
select unique b.* from branch_issues b, agent_net_sales a 
where b.bris_issue_year = a.net_issue_year
and b.bris_ean = a.net_issue_ean
and b.bris_branch_code = a.net_branch_code
and b.bris_issue_year = 2016 and b.bris_issue_week in (52,53)

select b.* from jt_2016_w53_problem j, branch_issues b
where j.bris_branch_code = b.bris_branch_code
and j.bris_ean = b.bris_ean
and b.bris_issue_year = 2015
and b.bris_issue_week in (52,53)

select unique j.*  from branch_mult_summaries s, jt_2016_w53_problem j--all records have releated record
where s.bms_branch_code = j.bris_branch_code
and s.bms_ean = j.bris_ean


select unique j.*  from branch_summaries br, jt_2016_w53_problem j----all records have releated record
where br.br_branch_code = j.bris_branch_code
and br.br_ean = j.bris_ean

select unique j.*  from cas_agent_net_sales c, jt_2016_w53_problem j----0 records
where c.net_branch_code = j.bris_branch_code
and c.net_issue_ean = j.bris_ean

select unique j.*  from cas_branch_issues ca, jt_2016_w53_problem j----0 records
where ca.bris_branch_code = j.bris_branch_code
and ca.bris_ean = j.bris_ean

select unique j.*  from normal_issues n, jt_2016_w53_problem j-----all records have releated record
where n.niss_issue_year = j.bris_issue_year
and n.niss_ean = j.bris_ean

select unique j.*  from all_issues al, jt_2016_w53_problem j-----all records have releated record
where al.issu_issue_year = j.bris_issue_year
and al.issu_ean = j.bris_ean

select unique j.*  from anmw_sellouts an, jt_2016_w53_problem j-----0 records
where an.anmw_htot_issue_ean = j.bris_ean

select unique j.*  from anmw_summaries am, jt_2016_w53_problem j-----0 records
where am.anmw_issue_ean = j.bris_ean

select unique j.*  from Anmw_Summary_Open om, jt_2016_w53_problem j-----0 records
where om.asr_ean = j.bris_ean

select unique j.*  from branch_sas_summary sas, jt_2016_w53_problem j-----0 records
where sas. = j.bris_ean

select unique j.*  from branch_summary_open op, jt_2016_w53_problem j-----0 records
where op.bso_ean = j.bris_ean

select unique j.*  from cas_branch_summaries cb, jt_2016_w53_problem j-----0 records
where cb.br_ean = j.bris_ean

select unique j.*  from cas_normal_issues cn, jt_2016_w53_problem j-----0 records
where cn.niss_ean = j.bris_ean

select unique j.*  from ctb_summaries ctb, jt_2016_w53_problem j-----0 records
where ctb.cs_ean = j.bris_ean

select * from dailies_by_day days--, jt_2016_w53_problem j-----0 records
where days.dbd_year = 2016
and days.dbd_week = 53

select unique j.*  from homis_branch_issues hom, jt_2016_w53_problem j-----0 records
where hom.bris_ean = j.bris_ean

select unique j.*  from issues_receiving_ssids ssids, jt_2016_w53_problem j-----0 records
where ssids.irs_ean = j.bris_ean

select unique j.*  from issues_to_normalise ise, jt_2016_w53_problem j-----0 records
where ise.itn_ean = j.bris_ean

select unique j.*  from issues_xref xref, jt_2016_w53_problem j-----0 records
where xref.isx_ean = j.bris_ean

select *  from mult_sas_summary mary--, jt_2016_w53_problem j-----0 records
where mary.msas_year_number = 2016

select unique j.*  from mult_summaries mult, jt_2016_w53_problem j-----0 records
where mult.msum_issue_ean = j.bris_ean

select * from multiple_financial_histories his--, jt_2016_w53_problem j-----0 records
where his.mfh_year_number = 2016 and his.mfh_week_number = 53

select unique j.*  from outer_postcode_summaries outers, jt_2016_w53_problem j-----0 records
where outers.opos_issue_ean = j.bris_ean
and outers.opos_issue_issue_year = j.bris_issue_year

select unique j.*  from outer_postcode_summary_open opens, jt_2016_w53_problem j-----0 records
where opens.opso_ean = j.bris_ean
and opens.opso_issue_year = j.bris_issue_year

SELECT ROW_NUMBER()  OVER (PARTITION BY pl.spoke_id, pl.issue_id ORDER BY pl.etl_run_num_seq DESC) a FROM   zpx_plnt_iss_stg_bak pl where a>2
