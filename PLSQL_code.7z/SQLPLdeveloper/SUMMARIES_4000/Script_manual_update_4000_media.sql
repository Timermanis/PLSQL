create table media_4000_bkp_021115 as  
select w.*
         from dw.MEDIA w,refmast.issues t
         where  (
                (w.iss_type_code in ('Z7','Z8') )
                or 
                (w.iss_type_code = 'Z5'  and trim(t.iss_parent_prod_num) is not null))
         and t.iss_num = w.iss_num
         and w.iss_partitioning_date != to_date('31/12/4000','dd/mm/yyyy');
         
ALTER TABLE dw.MEDIA ENABLE ROW MOVEMENT;         
update dw.MEDIA p set p.iss_partitioning_date = '31-DEC-4000' where p.dimension_key in (select dimension_key from media_4000_bkp_021115);
ALTER TABLE dw.MEDIA DISABLE ROW MOVEMENT;
         


dw.plant_mult_iss_rtrn_summaries
dw.plant_cust_iss_rtrn_summaries
dw.retailer_transaction
refmast.issues
refmast.plant_issues

select * from dw.plant_mult_iss_rtrn_summaries p,dw.MEDIA w,termsprd.latest_media_issue t
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.parent_prod_id) is not null)
         and  t.id = w.iss_num
         and p.plant_issue_id = w.dimension_key
         and  p.partitioning_date <> '31-DEC-4000';
         
create table plant_mult_4000_bkp_021115 as         
select p.* from dw.plant_mult_iss_rtrn_summaries p,dw.MEDIA w,refmast.issues t--extra 15
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.iss_parent_prod_num) is not null)
         and  t.iss_num = w.iss_num
         and p.plant_issue_id = w.dimension_key
         and  p.partitioning_date <> '31-DEC-4000';
ALTER TABLE dw.plant_mult_iss_rtrn_summaries ENABLE ROW MOVEMENT;         
update dw.plant_mult_iss_rtrn_summaries p set p.partitioning_date = '31-DEC-4000' where p.plant_issue_id in (select plant_issue_id from plant_mult_4000_bkp_021115);
ALTER TABLE dw.plant_mult_iss_rtrn_summaries DISABLE ROW MOVEMENT;

-------------------------------------         
select p.* from dw.plant_cust_iss_rtrn_summaries p,dw.MEDIA w,termsprd.latest_media_issue t
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.parent_prod_id) is not null)
         and  t.id = w.iss_num
         and p.plant_issue_id = w.dimension_key
         and  p.partitioning_date <> '31-DEC-4000';
         
create table plant_cust_4000_bkp_021115 as            
select p.* from dw.plant_cust_iss_rtrn_summaries p,dw.MEDIA w,refmast.issues t--141 extra
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.iss_parent_prod_num) is not null)
         and  t.iss_num = w.iss_num
         and p.plant_issue_id = w.dimension_key
         and  p.partitioning_date <> '31-DEC-4000';
ALTER TABLE dw.plant_cust_iss_rtrn_summaries ENABLE ROW MOVEMENT;         
update dw.plant_cust_iss_rtrn_summaries p set p.partitioning_date = '31-DEC-4000' where p.plant_issue_id in (select plant_issue_id from plant_cust_4000_bkp_021115);
ALTER TABLE dw.plant_cust_iss_rtrn_summaries DISABLE ROW MOVEMENT;         
------------------------------------------         
select * from dw.retailer_transaction p,dw.MEDIA w,termsprd.latest_media_issue t
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.parent_prod_id) is not null)
         and  t.id = w.iss_num
         and p.plant_issue_id = w.dimension_key
         and  p.partitioning_date <> '31-DEC-4000';

create table RT_4000_bkp_021115 as            
select p.* from dw.retailer_transaction p,dw.MEDIA w,refmast.issues t--extra 278
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.iss_parent_prod_num) is not null)
         and  t.iss_num = w.iss_num
         and p.plant_issue_id = w.dimension_key
         and  p.partitioning_date <> '31-DEC-4000'; 
ALTER TABLE dw.retailer_transaction ENABLE ROW MOVEMENT;         
update dw.retailer_transaction p set p.partitioning_date = '31-DEC-4000' where p.plant_issue_id in (select plant_issue_id from RT_4000_bkp_021115);
ALTER TABLE dw.retailer_transaction DISABLE ROW MOVEMENT;                 
------------------------------------------   
create table ref_issues_4000_bkp_021115 as       
select p.* from refmast.issues p,dw.MEDIA w--extra 2(1)
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(p.iss_parent_prod_num) is not null)
         and p.iss_num = w.iss_num
         and  p.iss_partitioning_date <> '31-DEC-4000';
ALTER TABLE refmast.issues ENABLE ROW MOVEMENT;         
update refmast.issues p set p.iss_partitioning_date = '31-DEC-4000' where p.iss_num in (select iss_num from ref_issues_4000_bkp_021115);
ALTER TABLE refmast.issues DISABLE ROW MOVEMENT;  
---------------There were issue records with no media records so updated seperateley
ALTER TABLE refmast.issues ENABLE ROW MOVEMENT;   
update  refmast.issues i set i.iss_partitioning_date = '31-DEC-4000'
where  
((i.iss_type_code in ('Z5') and trim(i.iss_parent_prod_num) is not null)
or i.iss_type_code in ('Z7','Z8'))
and i.iss_partitioning_date <> '31-DEC-4000' 
ALTER TABLE refmast.issues DISABLE ROW MOVEMENT;        
-------------------------------------------         
select * from refmast.plant_issues p,dw.MEDIA w,termsprd.latest_media_issue t--havent updated due to Philip's information
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.parent_prod_id) is not null)
         and  t.id = w.iss_num
         and p.plis_issue_num = w.plis_issue_num
         and p.plis_plant_num = w.plis_plant_num
         and  p.plis_partitioning_date <> '31-DEC-4000' 
