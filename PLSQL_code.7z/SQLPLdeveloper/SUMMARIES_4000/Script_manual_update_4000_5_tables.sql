dw.plant_mult_iss_rtrn_summaries
dw.plant_cust_iss_rtrn_summaries
dw.retailer_transaction
refmast.issues
refmast.plant_issues

select * from dw.plant_mult_iss_rtrn_summaries p,dw.MEDIA w,termsprd.latest_media_issue t
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.parent_prod_id) is not null)
         and  t.id = w.iss_num
         and p.plant_issue_id = w.dimension_key
         and  p.partitioning_date <> '31-DEC-4000';
         
select * from dw.plant_mult_iss_rtrn_summaries p,dw.MEDIA w,refmast.issues t--extra 15
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.iss_parent_prod_num) is not null)
         and  t.iss_num = w.iss_num
         and p.plant_issue_id = w.dimension_key
         and  p.partitioning_date <> '31-DEC-4000';
-------------------------------------         
select * from dw.plant_cust_iss_rtrn_summaries p,dw.MEDIA w,termsprd.latest_media_issue t
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.parent_prod_id) is not null)
         and  t.id = w.iss_num
         and p.plant_issue_id = w.dimension_key
         and  p.partitioning_date <> '31-DEC-4000';
         
select * from dw.plant_cust_iss_rtrn_summaries p,dw.MEDIA w,refmast.issues t--141 extra
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.iss_parent_prod_num) is not null)
         and  t.iss_num = w.iss_num
         and p.plant_issue_id = w.dimension_key
         and  p.partitioning_date <> '31-DEC-4000';
------------------------------------------         
select * from dw.retailer_transaction p,dw.MEDIA w,termsprd.latest_media_issue t
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.parent_prod_id) is not null)
         and  t.id = w.iss_num
         and p.plant_issue_id = w.dimension_key
         and  p.partitioning_date <> '31-DEC-4000';
         
select * from dw.retailer_transaction p,dw.MEDIA w,refmast.issues t--extra 278
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.iss_parent_prod_num) is not null)
         and  t.iss_num = w.iss_num
         and p.plant_issue_id = w.dimension_key
         and  p.partitioning_date <> '31-DEC-4000';         
------------------------------------------         
select * from refmast.issues p,dw.MEDIA w--extra 2
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(p.iss_parent_prod_num) is not null)
         and p.iss_num = w.iss_num
         and  p.iss_partitioning_date <> '31-DEC-4000';
-------------------------------------------         
select * from refmast.plant_issues p,dw.MEDIA w,termsprd.latest_media_issue t
         where  (w.iss_type_code in ('Z7','Z8') or (w.iss_type_code = 'Z5' )and trim(t.parent_prod_id) is not null)
         and  t.id = w.iss_num
         and p.plis_issue_num = w.plis_issue_num
         and p.plis_plant_num = w.plis_plant_num
         and  p.plis_partitioning_date <> '31-DEC-4000' 
