select * from SUPPORT.MD_LOG t order by LOGGING_TIMESTAMP desc

--test
-- Created on 29/06/2016 by JTIMERMANIS 
declare 
  -- Local variables here
  i integer;
begin
  -- Test statements here
  -- Full rebuild of 2016 can be done
/*update summary_rebuild_audit a
set a.date_cus_level_completed = NULL, a.DATE_MUL_LEVEL_COMPLETED = NULL, a.DATE_ISS_LEVEL_COMPLETED = NULL
, latest_pf_run_num_loaded = NULL, date_catch_up_last_ran = NULL;

nsummary_utils.rebuild_issue_summaries(pi_summaires_to_rebuild => 7,  -- i.e all
                                        pi_source_from_live => FALSE, ---i. not from the live (_A  table)
                                        pi_restart => 0);*/

--- To keep up-to-date each day can run below
nsummary_utils.rebuild_issue_summaries(pi_summaires_to_rebuild => 7,  -- i.e all
                                        pi_source_from_live => FALSE, ---i. not from the live (_A  table)
                                        pi_restart => 0,
                                        pi_loading_in_chunks => TRUE);

-- can see progress in support.md_log
end;
