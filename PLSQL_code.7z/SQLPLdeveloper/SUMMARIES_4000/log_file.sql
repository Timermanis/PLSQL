create table LOG_4000 
(
backup_table varchar2(35),
backup_created date DEFAULT (sysdate)
)

insert into LOG_4000 (backup_table)values (123)

insert into LOG_4000 (backup_table)values ('JT_BACKUP_MEDIA_') ;

truncate table LOG_4000 ;

select q'[ insert into LOG_4000 (backup_table) values ('JT_BACKUP_MEDIA_'||PI_YEAR||'_UPD)]' from dual

select q'[ this isn't my string, is it? ]' from dual
