select * from customer_mult_changes f where f.cmc_account_number in
(select g.cmc_account_number
from  cust_mult_changes_upd_240216 g
where f.cmc_account_number = g.cmc_account_number)
and f.cmc_date_to = to_date('31-DEC-4000','DD-MON-YYYY')

update customer_mult_changes f set CMC_DATE_from = to_date('12-MAR-2016','DD-MON-YYYY')
where f.cmc_account_number in
(select g.cmc_account_number
from  cust_mult_changes_upd_240216 g
where f.cmc_account_number = g.cmc_account_number)
and f.cmc_date_to = to_date('31-DEC-4000','DD-MON-YYYY')
------------------------------------

select * from customer_mult_changes f where f.cmc_account_number in
(select g.cmc_account_number
from  cust_mult_changes_upd_240216 g
where f.cmc_account_number = g.cmc_account_number)
--and f.cmc_date_to = to_date('24-FEB-2016','DD-MON-YYYY')
and f.CMC_DATE_to = to_date('11-MAR-2016','DD-MON-YYYY')

update customer_mult_changes f set CMC_DATE_to = to_date('11-MAR-2016','DD-MON-YYYY')
where f.cmc_account_number in
(select g.cmc_account_number
from  cust_mult_changes_upd_240216 g
where f.cmc_account_number = g.cmc_account_number)
and f.cmc_date_to = to_date('24-FEB-2016','DD-MON-YYYY')
-------------test-----
select * from customer_mult_changes f where f.cmc_account_number=502963050837800
