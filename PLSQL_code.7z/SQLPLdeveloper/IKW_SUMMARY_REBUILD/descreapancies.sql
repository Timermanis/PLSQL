
select * from  jt_cs_ms_compare_cs
minus
select * from  jt_cs_ms_compare_ms

union all

select * from jt_cs_ms_compare_ms
minus
select * from  jt_cs_ms_compare_cs

27142085
353850043
353850043
27142085
181982058
84752040
-----------
select * from jt_cs_ms_compare_ms t where PLIS_ISSUE_NUM = 84752040 and mult_num = 952 and t.PF_RUN_NUM = 2406
union all
select * from  jt_cs_ms_compare_cs t where PLIS_ISSUE_NUM = 84752040 and mult_num = 952 and t.PF_RUN_NUM = 2406


select * from jt_cs_ms_compare_ms t where PLIS_ISSUE_NUM = 181982058 and mult_num = 0 and t.PF_RUN_NUM = 2388
union all
select * from  jt_cs_ms_compare_cs t where PLIS_ISSUE_NUM = 181982058 and mult_num = 0 and t.PF_RUN_NUM = 2388

select 'ms',t.* from jt_cs_ms_compare_ms t where PLIS_ISSUE_NUM = 27142085 and mult_num = 0 and t.PF_RUN_NUM = 2403 and t.PUBLISHER_ID = 1000456087 and t.CUS_PLANT_NUM = 390
minus --union all
select 'cs',t.* from  jt_cs_ms_compare_cs t where PLIS_ISSUE_NUM = 27142085 and mult_num = 0 and t.PF_RUN_NUM = 2403 and t.PUBLISHER_ID = 1000456087 and t.CUS_PLANT_NUM = 390

select 'ms',t.* from jt_cs_ms_compare_ms t where PLIS_ISSUE_NUM = 27142085 and mult_num = 0 and t.PF_RUN_NUM = 2410  and t.CUS_PLANT_NUM = 220
union all
select 'cs',t.* from  jt_cs_ms_compare_cs t where PLIS_ISSUE_NUM = 27142085 and mult_num = 0 and t.PF_RUN_NUM = 2410 and t.CUS_PLANT_NUM = 220


select 'ms',t.* from jt_cs_ms_compare_ms t where PLIS_ISSUE_NUM = 353850043 and mult_num = 0 and t.PF_RUN_NUM = 2391  and t.CUS_PLANT_NUM = 220
union all
select 'cs',t.* from  jt_cs_ms_compare_cs t where PLIS_ISSUE_NUM = 353850043 and mult_num = 0 and t.PF_RUN_NUM = 2391 and t.CUS_PLANT_NUM = 220

select 'ms',t.* from jt_cs_ms_compare_ms t where PLIS_ISSUE_NUM = 353850043 and mult_num = 5 and t.PF_RUN_NUM = 2392  and t.CUS_PLANT_NUM = 340
union all
select 'cs',t.* from  jt_cs_ms_compare_cs t where PLIS_ISSUE_NUM = 353850043 and mult_num = 5 and t.PF_RUN_NUM = 2392 and t.CUS_PLANT_NUM = 340
-----------
select * from  jt_cs_ms_compare_cs t where PLIS_ISSUE_NUM = 84752040 and mult_num = 952 and t.PF_RUN_NUM = 2406
minus
select * from jt_cs_ms_compare_ms t where PLIS_ISSUE_NUM = 84752040 and mult_num = 952 and t.PF_RUN_NUM = 2406

select * from  jt_cs_ms_compare_cs t where PLIS_ISSUE_NUM = 181982058 and mult_num = 0 and t.PF_RUN_NUM = 2388
minus
select * from jt_cs_ms_compare_ms t where PLIS_ISSUE_NUM = 181982058 and mult_num = 0 and t.PF_RUN_NUM = 2388

select t.* from  jt_cs_ms_compare_cs t where PLIS_ISSUE_NUM = 27142085 and mult_num = 0 --and t.PF_RUN_NUM = 2403 and t.PUBLISHER_ID = 1000456087 and t.CUS_PLANT_NUM = 390
minus --union all
select t.* from jt_cs_ms_compare_ms t where PLIS_ISSUE_NUM = 27142085 and mult_num = 0 --and t.PF_RUN_NUM = 2403 and t.PUBLISHER_ID = 1000456087 and t.CUS_PLANT_NUM = 390

select t.* from  jt_cs_ms_compare_cs t where PLIS_ISSUE_NUM = 27142085 and mult_num = 0 and t.PF_RUN_NUM = 2410 and t.CUS_PLANT_NUM = 220
union all--minus
select t.* from jt_cs_ms_compare_ms t where PLIS_ISSUE_NUM = 27142085 and mult_num = 0 and t.PF_RUN_NUM = 2410  and t.CUS_PLANT_NUM = 220

select t.* from  jt_cs_ms_compare_cs t where PLIS_ISSUE_NUM = 353850043 and mult_num = 0 and t.PF_RUN_NUM = 2391 and t.CUS_PLANT_NUM = 220
union all--minus
select t.* from jt_cs_ms_compare_ms t where PLIS_ISSUE_NUM = 353850043 and mult_num = 0 and t.PF_RUN_NUM = 2391  and t.CUS_PLANT_NUM = 220

select t.* from  jt_cs_ms_compare_cs t where PLIS_ISSUE_NUM = 353850043 and mult_num = 5 and t.PF_RUN_NUM = 2392 and t.CUS_PLANT_NUM = 340
union all--minus
select t.* from jt_cs_ms_compare_ms t where PLIS_ISSUE_NUM = 353850043 and mult_num = 5 and t.PF_RUN_NUM = 2392  and t.CUS_PLANT_NUM = 340

