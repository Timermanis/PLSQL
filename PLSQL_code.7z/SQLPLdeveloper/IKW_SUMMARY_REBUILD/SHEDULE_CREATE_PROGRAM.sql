

-- create a program with two arguments and define both
begin
dbms_scheduler.create_program
(
program_name=>'jm.summaries_run',
program_action=>'nsummary_utils.rebuild_issue_summaries();',
program_type=>'STORED_PROCEDURE',
number_of_arguments=>4, enabled=>FALSE) ;

dbms_scheduler.DEFINE_PROGRAM_ARGUMENT(
program_name=>'summaries_run',
argument_position=>1,
argument_type=>NUMBER,
DEFAULT_VALUE=> 7);

dbms_scheduler.DEFINE_PROGRAM_ARGUMENT(
program_name=>'summaries_run',
argument_position=>2,
argument_type=>BOOLEAN,
DEFAULT_VALUE=>FALSE);

dbms_scheduler.DEFINE_PROGRAM_ARGUMENT(
program_name=>'summaries_run',
argument_position=>3,
argument_type=>NUMBER,
DEFAULT_VALUE=>7);

dbms_scheduler.DEFINE_PROGRAM_ARGUMENT(
program_name=>'summaries_run',
argument_position=>4,
argument_type=>BOOLEAN,
DEFAULT_VALUE=>TRUE);

dbms_scheduler.enable('summaries_run');
end;


-- create a job pointing to a program and set both argument values
begin
dbms_scheduler.create_job('job_summaries_run',program_name=>'summaries_run');
dbms_scheduler.set_job_argument_value('job_summaries_run',1,7);
dbms_scheduler.set_job_argument_value('job_summaries_run',2,FALSE);
dbms_scheduler.set_job_argument_value('job_summaries_run',3,7);
dbms_scheduler.set_job_argument_value('job_summaries_run',2,TRUE);
dbms_scheduler.enable('job_summaries_run');
end;

--------------------------------------BEGIN my_proc(); END;
