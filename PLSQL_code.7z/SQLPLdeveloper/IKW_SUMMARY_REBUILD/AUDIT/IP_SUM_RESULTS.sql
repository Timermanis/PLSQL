select * from IP_SUM_RESULTS t order by runtest for update
