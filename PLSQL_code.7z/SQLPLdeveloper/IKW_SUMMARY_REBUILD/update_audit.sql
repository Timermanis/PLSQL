select * from support.POR_SUMMARY_REBUILD_AUDIT_2017
