select 
'PS' SOURCE_TAB,
CUS_PLANT_NUM,
PLIS_ISSUE_NUM,
CURRENCY_CODE,
CUS_PLANT_ID,
PLANT_ISSUE_ID,
CURRENCY_ID,
SAS_ID,
PUBLISHER_ID,
DISTRIBUTOR_ID,
FIRST_DELIVERY_DAY_NUM,
INTERBRANCH_TRANS_IN,
INTERBRANCH_TRANS_OUT,
MAIN_DELIVERIES,
ADDITIONAL_DELIVERIES,
ACTUAL_OVERS_AFTER_MAKEUP,
FINAL_OVERS,
MAIN_SUPPLY_QTY,
ADDITIONAL_SUPPLY_QTY,
ADVISED_QTY,
INVOICED_QTY,
CREDIT_QTY,
NUM_CUSTS_SUPPLIED,
NUM_CUSTS_RETURNING,
NUM_CUSTS_RETURNING_EARLY,
NUM_CUSTS_CREDITED,
NUM_CUSTS_SOLDOUT,
NUM_CUSTS_POTENTIAL_SOLDOUT,
RETURN_QTY,
INITIAL_CUST_SUPPLY,
EXTRA_SUPPLY_QTY,
POTENTIAL_SELL_OUTS,
RETAIL_INV_VAL_EXCL_VAT,
RETAIL_CRD_VAL_EXCL_VAT,
RETAIL_RET_VAL_EXCL_VAT,
RETAIL_INV_VAL_VAT,
RETAIL_CRD_VAL_VAT,
RETAIL_RET_VAL_VAT,
COST_INV_VAL_EXCL_VAT,
COST_CRD_VAL_EXCL_VAT,
COST_RET_VAL_EXCL_VAT,
COST_INV_VAL_VAT,
COST_CRD_VAL_VAT,
COST_RET_VAL_VAT,
TRADE_INV_VAL_EXCL_VAT,
TRADE_CRD_VAL_EXCL_VAT,
TRADE_RET_VAL_EXCL_VAT,
TRADE_INV_VAL_VAT,
TRADE_CRD_VAL_VAT,
TRADE_RET_VAL_VAT,
SBR_REDUCED_QTY,
MGRS_CRD_QTY,
PF_RUN_NUM,
CURRENCY_CONVERTOR_ID,
NUM_CUSTS_COULD_SUPPLY,
GR_DATE,
CLAIMABLE_FINAL_OVERS,
EARLY_RETURN_QTY

 from PLANT_ISS_SUM_A h where h.plant_issue_id = 54421259;
 
  SELECT   
        'MS' SOURCE_TAB,
                  NVL(i.cus_plant_num, sts.spo_num)             cus_plant_num,
                  NVL(i.plis_issue_num, sts.plis_issue_num)     plis_issue_num, -- AMT 15.0
                  NVL(i.currency_code, sts.currency_code)       currency_code,
                  NVL(i.cus_plant_id, plant_id)                 cus_plant_id,
                  NVL(i.plant_issue_id, sts.plant_issue_id)     plant_issue_id,
                  NVL(i.currency_id, sts.currency_id)           currency_id,
                  NVL(i.sas_id, sts.sas_id)                     sas_id,
                  NVL(i.publisher_id, sts.publisher_id)         publisher_id,
                  NVL(i.distributor_id, sts.distributer_id)     distributor_id,
                  NVL(i.main_supply_qty, 0)                     main_supply_qty,
                  NVL(i.additional_supply_qty, 0)               additional_supply_qty,
                  NVL(i.invoiced_qty, 0)                        invoiced_qty, -- AMT 15.0
                  NVL(i.credit_qty, 0)                          credit_qty,
                  NVL(i.num_custs_supplied, 0)                  num_custs_supplied, -- AMT 15.0
                  NVL(i.num_custs_returning, 0)                 num_custs_returning, -- AMT 15.0
                  NVL(i.num_custs_returning_early, 0)           num_custs_returning_early, -- AMT 15.0
                  NVL(i.num_custs_credited, 0)                  num_custs_credited, -- AMT 15.0
                  NVL(i.num_custs_soldout, 0)                   num_custs_soldout, -- AMT 15.0
                  NVL(i.num_custs_potential_soldout , 0)        num_custs_potential_soldout, -- AMT 15.0
                  NVL(i.return_qty, 0)                          return_qty,
                  NVL(i.initial_cust_supply, 0)                 initial_cust_supply,
                  NVL(i.extra_supply_qty, 0)                    extra_supply_qty, -- AMT 15.0
                  NVL(i.potential_sell_outs, 0)                 potential_sell_outs,
                  NVL(i.retail_inv_val_excl_vat, 0)             retail_inv_val_excl_vat,
                  NVL(i.retail_crd_val_excl_vat, 0)             retail_crd_val_excl_vat, -- AMT 15.0
                  NVL(i.retail_ret_val_excl_vat, 0)             retail_ret_val_excl_vat, -- AMT 15.0
                  NVL(i.retail_inv_val_vat, 0)                  retail_inv_val_vat, -- AMT 15.0
                  NVL(i.retail_crd_val_vat, 0)                  retail_crd_val_vat, -- AMT 15.0
                  NVL(i.retail_ret_val_vat, 0)                  retail_ret_val_vat,  --AMT 15.0
                  NVL(i.cost_inv_val_excl_vat, 0)               cost_inv_val_excl_vat, -- AMT 15.0
                  NVL(i.cost_crd_val_excl_vat, 0)               cost_crd_val_excl_vat, -- AMT 15.0
                  NVL(i.cost_ret_val_excl_vat, 0)               cost_ret_val_excl_vat, -- AMT 15.0
                  NVL(i.cost_inv_val_vat, 0)                    cost_inv_val_vat, -- AMT 15.0
                  NVL(i.cost_crd_val_vat, 0)                    cost_crd_val_vat, -- AMT 15.0
                  NVL(i.cost_ret_val_vat, 0)                    cost_ret_val_vat, -- AMT 15.0
                  NVL(i.trade_inv_val_excl_vat, 0)              trade_inv_val_excl_vat, -- AMT 15.0
                  NVL(i.trade_crd_val_excl_vat, 0)              trade_crd_val_excl_vat, -- AMT 15.0
                  NVL(i.trade_ret_val_excl_vat, 0)              trade_ret_val_excl_vat, -- AMT 15.0
                  NVL(i.trade_inv_val_vat, 0)                   trade_inv_val_vat, -- AMT 15.0
                  NVL(i.trade_crd_val_vat, 0)                   trade_crd_val_vat, -- AMT 15.0
                  NVL(i.trade_ret_val_vat, 0)                   trade_ret_val_vat,  -- AMT 15.0
                  NVL(i.sbr_reduced_qty, 0)                     sbr_reduced_qty,
                  NVL(i.mgrs_crd_qty, 0)                        mgrs_crd_qty, -- AMT 15.0
                  NVL(i.pf_run_num, 0)                          pf_run_num,
                  NVL(i.currency_convertor_id, 0)               currency_convertor_id,
                  NVL(i.num_custs_could_supply, 0)              num_custs_could_supply, -- AMT 15.0
                  NVL(sts.interbranch_in,0)                     interbranch_trans_in,
                  NVL(sts.interbranch_out,0)                    interbranch_trans_out,
                  NVL(sts.pub_supply_main,0)                    main_deliveries,
                  NVL(sts.pub_supply_additional,0)              additional_deliveries,
                  NVL(sts.advised_qty,0)                        advised_qty,
                  NVL(sts.overs_after_makeup,0)                 actual_overs_after_makeup,
                  NVL(sts.final_overs,0)                        final_overs,
                  sts.first_delivery_day_num                    first_delivery_day_num, -- AMT 15.1
                  sts.gr_date                                   gr_date,
                  sts.claimable_final_overs                     claimable_final_overs,
                  NVL(i.early_return_qty, 0)                    early_return_qty
        FROM      (SELECT    rs.cus_plant_num                                 cus_plant_num,
                             rs.plis_issue_num                                plis_issue_num, -- AMT 15.0
                             STATS_MODE(m.plis_currency_code)                 currency_code,
                             STATS_MODE(rs.cus_plant_id)                      cus_plant_id,
                             STATS_MODE(rs.plant_issue_id)                    plant_issue_id,
                             STATS_MODE(rs.currency_id)                       currency_id,
                             STATS_MODE(rs.sas_id)                            sas_id,
                             STATS_MODE(rs.publisher_id)                      publisher_id,
                             STATS_MODE(rs.distributor_id)                    distributor_id,
                             NVL(SUM(rs.main_supply_qty),0)                   main_supply_qty, -- AMT 15.0
                             NVL(SUM(rs.additional_supply_qty),0)             additional_supply_qty, -- AMT 15.0
                             NVL(SUM(rs.invoiced_qty),0)                      invoiced_qty, -- AMT 15.0
                             NVL(SUM(rs.credit_qty),0)                        credit_qty, -- AMT 15.0
                             NVL(SUM(rs.num_custs_supplied),0)                num_custs_supplied, --AMT 15.0
                             NVL(SUM(rs.num_custs_returning),0)               num_custs_returning, -- AMT 15.0
                             NVL(SUM(rs.num_custs_returning_early),0)         num_custs_returning_early, -- AMT 15.0
                             NVL(SUM(rs.num_custs_credited),0)                num_custs_credited, -- AMT 15.0
                             NVL(SUM(rs.num_custs_soldout),0)                 num_custs_soldout, -- AMT 15.0
                             NVL(SUM(rs.num_custs_potential_soldout ),0)      num_custs_potential_soldout , -- AMT 15.0
                             NVL(SUM(rs.return_qty),0)                        return_qty, -- AMT 15.0
                             NVL(SUM(rs.early_return_qty),0)                  early_return_qty, -- AMT 15.0
                             NVL(SUM(rs.main_supply_qty),0)                   initial_cust_supply, -- AMT 15.0
                             NVL(SUM(rs.extra_supply_qty),0)                  extra_supply_qty, -- AMT 15.0
                             NVL(SUM(rs.num_custs_potential_soldout),0)       potential_sell_outs, -- AMT 15.0
                             NVL(SUM(rs.retail_inv_val_excl_vat),0)           retail_inv_val_excl_vat,
                             NVL(SUM(rs.retail_crd_val_excl_vat),0)           retail_crd_val_excl_vat, --AMT 15.0
                             NVL(SUM(rs.retail_ret_val_excl_vat),0)           retail_ret_val_excl_vat, --AMT 15.0
                             NVL(SUM(rs.retail_inv_val_vat),0)                retail_inv_val_vat, -- AMT 15.0
                             NVL(SUM(rs.retail_crd_val_vat),0)                retail_crd_val_vat, -- AMT 15.0
                             NVL(SUM(rs.retail_ret_val_vat),0)                retail_ret_val_vat, -- AMT 15.0
                             NVL(SUM(rs.cost_inv_val_excl_vat),0)             cost_inv_val_excl_vat, -- AMT 15.0
                             NVL(SUM(rs.cost_crd_val_excl_vat),0)             cost_crd_val_excl_vat, -- AMT 15.0
                             NVL(SUM(rs.cost_ret_val_excl_vat),0)             cost_ret_val_excl_vat, -- AMT 15.0
                             NVL(SUM(rs.cost_inv_val_vat),0)                  cost_inv_val_vat, -- AMT 15.0
                             NVL(SUM(rs.cost_crd_val_vat),0)                  cost_crd_val_vat, -- AMT 15.0
                             NVL(SUM(rs.cost_ret_val_vat),0)                  cost_ret_val_vat, -- AMT 15.0
                             NVL(SUM(rs.trade_inv_val_excl_vat),0)            trade_inv_val_excl_vat, -- AMT 15.0
                             NVL(SUM(rs.trade_crd_val_excl_vat),0)            trade_crd_val_excl_vat, -- AMT 15.0
                             NVL(SUM(rs.trade_ret_val_excl_vat),0)            trade_ret_val_excl_vat, -- AMT 15.0
                             NVL(SUM(rs.trade_inv_val_vat),0)                 trade_inv_val_vat, -- AMT 15.0
                             NVL(SUM(rs.trade_crd_val_vat),0)                 trade_crd_val_vat, -- AMT 15.0
                             NVL(SUM(rs.trade_ret_val_vat),0)                 trade_ret_val_vat, -- AMT 15.0
                             NVL(SUM(rs.sbr_reduced_qty),0)                   sbr_reduced_qty,
                             NVL(SUM(rs.mgrs_crd_qty),0)                      mgrs_crd_qty, --AMT 15.0
                             MAX(rs.pf_run_num)                               pf_run_num,
                             STATS_MODE(rs.currency_convertor_id)             currency_convertor_id,
                             SUM(rs.num_custs_could_supply)            num_custs_could_supply -- AMT 15.0
                   FROM      plant_mult_iss_rtrn_summaries rs
                             JOIN  media m
                             ON    m.dimension_key = rs.plant_issue_id
                             where m.plis_id = 54421259
                   GROUP BY  rs.cus_plant_num, rs.plis_issue_num) i -- AMT 15.0
                  FULL OUTER JOIN  (SELECT    w.spo_num,
                                              m.plis_issue_num,
                                              STATS_MODE(sts.plant_id)                 plant_id,
                                              STATS_MODE(sts.plant_issue_id)           plant_issue_id,
                                              SUM(sts.interbranch_in)                  interbranch_in,
                                              SUM(sts.interbranch_out)                 interbranch_out,
                                              SUM(sts.pub_supply_main)                 pub_supply_main,
                                              SUM(sts.pub_supply_additional)           pub_supply_additional,
                                              SUM(sts.advised_qty)                     advised_qty,
                                              SUM(sts.overs_after_makeup)              overs_after_makeup,
                                              SUM(sts.final_overs)                     final_overs,
                                              STATS_MODE(sts.first_delivery_day_num)    first_delivery_day_num, -- AMT 15.1
                                              STATS_MODE(sts.gr_date)                  gr_date,
                                              STATS_MODE(sc.dimension_key)             sas_id,
                                              STATS_MODE(sts.currency_id)              currency_id,
                                              STATS_MODE(vp.dimension_key)             publisher_id,
                                              STATS_MODE(vd.dimension_key)             distributer_id,
                                              STATS_MODE(c.cur_code)                   currency_code,
                                              STATS_MODE(sts.claimable_final_overs)    claimable_final_overs
                                    FROM      stock_transaction_summary sts
                                              JOIN  media m
                                              ON    m.plis_id = sts.plant_issue_id
                                              JOIN  wholesaler w
                                              ON    w.dimension_key = sts.plant_id
                                              AND   NVL(m.plis_actual_on_sale_date, m.plis_planned_on_sale_date) BETWEEN w.gro_eff_date AND w.gro_exp_date
                                              JOIN  sas sc
                                              ON    sc.sas_code = m.plis_sois_sas_code
                                              JOIN  vendor vp
                                              ON    vp.ven_num = m.plis_publisher_num
                                              AND   NVL(m.plis_actual_on_sale_date, m.plis_planned_on_sale_date) BETWEEN vp.ven_eff_date AND vp.ven_exp_date
                                              JOIN  vendor vd
                                              ON    vd.ven_num = m.plis_distributor_num
                                              AND   NVL(m.plis_actual_on_sale_date, m.plis_planned_on_sale_date) BETWEEN vd.ven_eff_date AND vd.ven_exp_date
                                              JOIN  currency c
                                              ON    c.dimension_key = sts.currency_id
                                              where m.plis_id = 54421259
                                    GROUP BY  w.spo_num, m.plis_issue_num) sts
                                    
                  ON    sts.spo_num = i.cus_plant_num
                  AND   sts.plis_issue_num = i.plis_issue_num 
                  
