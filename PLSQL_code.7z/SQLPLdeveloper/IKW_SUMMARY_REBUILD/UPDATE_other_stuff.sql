truncate table plant_cust_iss_rtrn_sum_driver
create table plant_cust_iss_rtrn_sum_dr_bkp as
select * from plant_cust_iss_rtrn_sum_driver

update dw.summary_rebuild_audit a
set a.date_cus_level_completed = NULL, a.date_mul_level_completed = NULL, a.date_iss_level_completed = NULL
, latest_pf_run_num_loaded = NULL, date_catch_up_last_ran = NULL;



select * from dw.summary_rebuild_audit for update


select * from dw.plant_iss_sum_b

select * from dw.plant_iss_sum_b
select max(GR_DATE) from dw.plant_iss_sum_a
