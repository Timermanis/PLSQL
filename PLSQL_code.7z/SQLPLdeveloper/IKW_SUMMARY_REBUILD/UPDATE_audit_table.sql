create table dw.summar_rebuil_audit_BKP_130217 as select * from dw.summary_rebuild_audit 

truncate table dw.summary_rebuild_audit 

insert into dw.summary_rebuild_audit 
select * from 
support.POR_SUMMARY_REBUILD_AUDIT_2017


update summary_rebuild_audit a
set a.date_cus_level_completed = NULL, a.date_mul_level_completed = NULL, a.date_iss_level_completed = NULL
, latest_pf_run_num_loaded = NULL, date_catch_up_last_ran = NULL;

Ti
select * from dw.summary_rebuild_audit for update
