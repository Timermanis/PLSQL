CREATE OR REPLACE TYPE my_tab_t AS TABLE OF VARCHAR2(30);
/
CREATE TABLE nested_table (id NUMBER, col1 my_tab_t)
       NESTED TABLE col1 STORE AS col1_tab;
       
       
INSERT INTO nested_table VALUES (4, my_tab_t('A',' ' ,1));
INSERT INTO nested_table VALUES (2, my_tab_t('B', 'C'));
INSERT INTO nested_table VALUES (3, my_tab_t('D', 'E', 'F'));
COMMIT;

SELECT * FROM nested_table;

delete 
from sap_extract_log
where log_time < sysdate-31
