create table jt_ZG2_missing_ZCLC as

(select a.spoke_id,a.customer_id,a.issue_id,a.ETL_RUN_DATE_NUM,a.etl_run_num_seq,abs(a.trade_net_value) value,a.document_type from archive.zpx_rtrn_stg_bak a where a.document_type = 'ZG2'
minus
select a.spoke_id,a.customer_id,a.issue_id,a.ETL_RUN_DATE_NUM,a.etl_run_num_seq,abs(a.trade_net_value),'ZG2' from archive.zpx_rtrn_stg_bak a where a.document_type = 'ZCLC')

select * from jt_ZG2_missing_ZCLC c where c.issue_id = 000000000090224070
