select * from archive.zpx_rtrn_stg_bak a,archive.zpx_rtrn_stg_bak b where 
a.spoke_id = b.spoke_id
and a.customer_id = b.customer_id
and a.issue_id = b.issue_id
and a.ETL_RUN_DATE_NUM = b.ETL_RUN_DATE_NUM
and a.etl_run_num_seq = b.etl_run_num_seq
and a.item_type = b.item_type
--and a.document_id = b.document_id
and a.item_type = 'ZRUC'
and a.customer_id = 0000122324
and a.issue_id = 000000000010912316


select a.spoke_id,a.customer_id,a.issue_id,a.spoke_id,a.ETL_RUN_DATE_NUM,a.etl_run_num_seq,count(*) from archive.zpx_rtrn_stg_bak a,archive.zpx_rtrn_stg_bak b where 
a.spoke_id = b.spoke_id
and a.customer_id = b.customer_id
and a.issue_id = b.issue_id
and a.ETL_RUN_DATE_NUM = b.ETL_RUN_DATE_NUM
and a.etl_run_num_seq = b.etl_run_num_seq
and a.item_type = b.item_type
and a.item_type = 'ZRUC'
--and a.customer_id = 0000114908
group by a.spoke_id,a.customer_id,a.issue_id,a.spoke_id,a.ETL_RUN_DATE_NUM,a.etl_run_num_seq
having count(*) != 4
order by count(*) desc


select count(*) from archive.zpx_rtrn_stg_bak  where item_type = 'ZRUC' and DOCUMENT_TYPE = 'ZCLC'--484651
select count(*) from archive.zpx_rtrn_stg_bak  where item_type = 'ZRUC' and DOCUMENT_TYPE = 'ZG2' --517597
select 517597 - 484651 from dual --32946 records no ZCLC in 6 months
--SAMPLE---------------------------------
select * from archive.zpx_rtrn_stg_bak  a where 
a.customer_id = 0000103473
and a.issue_id = 000000000088252312
--MINUS "dirty" set 36278 rec-------------------------------------
select a.spoke_id,a.customer_id,a.issue_id,a.spoke_id,a.ETL_RUN_DATE_NUM,a.etl_run_num_seq,abs(a.trade_net_value),a.document_type from archive.zpx_rtrn_stg_bak a where a.document_type = 'ZG2'
minus
select a.spoke_id,a.customer_id,a.issue_id,a.spoke_id,a.ETL_RUN_DATE_NUM,a.etl_run_num_seq,abs(a.trade_net_value),'ZG2' from archive.zpx_rtrn_stg_bak a where a.document_type = 'ZCLC'
-----ANOTHER SAMPLE-------------------------------------------
select * from archive.zpx_rtrn_stg_bak  a where 
a.customer_id = '0000124694'
and a.issue_id = '000000000380250070'

