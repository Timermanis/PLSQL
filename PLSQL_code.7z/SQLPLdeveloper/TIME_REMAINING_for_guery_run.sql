select "SID","SERIAL#","OPNAME","TARGET","SOFAR","TOTALWORK",round("SOFAR"/"TOTALWORK"*100,2) done,round(v.TIME_REMAINING/3600,2) "REMAINING HOURS","START_TIME","LAST_UPDATE_TIME","TIME_REMAINING","ELAPSED_SECONDS","MESSAGE" 
from v$session_longops v where v.TIME_REMAINING!=0-- and START_TIME > sysdate - 8/24
order by start_time;

 

SELECT s.sid,
       s.serial#,
       s.machine,
       sl.totalwork,
       sl.sofar,
       sl.totalwork - sl.sofar work_left,
       ROUND(sl.elapsed_seconds/60) || ':' || MOD(sl.elapsed_seconds,60) elapsed,
       ROUND(sl.time_remaining/60) || ':' || MOD(sl.time_remaining,60) remaining,
       s.OSUSER
FROM   v$session s,
       v$session_longops sl
WHERE  s.sid     = sl.sid
AND    s.serial# = sl.serial#
--and osuser = 'jtimermanis'
and sl.sofar <> sl.totalwork;
------------------------------------------

SELECT s.osuser,s.module,
      
       t.message,
       t.username,
       t.sofar,
       t.totalwork,
       t.sid,
       t.sql_id,
       s.LOGON_TIME,
       s.username     
FROM   v$session_longops t
       LEFT OUTER JOIN  v$session s
       ON    s.sid = t.sid
        where sofar != TOTALWORK
order by logon_time desc nulls last;

--select OSUSER,STATUS,PROGRAM,ACTION,PREV_EXEC_START,BLOCKING_SESSION_STATUS  from v$session-- 
/*select STATUS,PREV_EXEC_START,t.*  from v$session t-- 
where --logon_time > sysdate - 1 and 
osuser = 'jtimermanis'order by t.status, t.PREV_EXEC_START desc;
---------------------------------------------
select sid, opname, target, sofar, totalwork,
units, to_char(start_time,'HH24:MI:SS') StartTime,
to_char(time_remaining,'HH:MI:SS') "minutes remaining", message, username
from v$session_longops
where sofar != totalwork
order by start_time


