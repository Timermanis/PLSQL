select * from msg_files order by MSG_TIMESTAMP desc
select * from ctl_files
select * from MSG_PROCESSES
