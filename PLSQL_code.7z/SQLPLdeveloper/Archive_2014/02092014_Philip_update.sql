select c.cus_mags_start_date, c.cus_mags_stop_date,c.cus_perios_start_date,c.cus_perios_stop_date,c.cus_account_number,c.cus_to_date,c.cus_box_number from customers c where c.cus_box_number in (10011,10012) 
and c.cus_to_date=to_date('31/12/4000','dd/mm/yyyy')
order by c.cus_to_date for update--503103139113800,503103139119000


select  c.cd_mags_start_date, c.cd_mags_stop_date,c.cd_perios_start_date,c.cd_perios_stop_date,c.cd_urn
 from refmast.customer_details c where c.cd_urn in (503103139113800,503103139119000) 
 and c.CD_EXPIRATION_DATE = to_date('31/12/4000','dd/mm/yyyy') 

CD_MAGS_START_DATE	CD_MAGS_STOP_DATE	CD_PERIOS_START_DATE	CD_PERIOS_STOP_DATE	CD_URN
31/12/4000	31/12/4000	31/12/4000	31/12/4000	503103139119000
26/08/2014	31/12/4000	28/08/2014	31/12/4000	503103139113800
