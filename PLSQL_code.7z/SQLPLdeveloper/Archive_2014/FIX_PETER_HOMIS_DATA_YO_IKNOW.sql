select NET_BRANCH_CODE,sum (NET_COMMITED_QUANTITY) from agent_net_sales a
where (a.net_issue_ean = 977990382900101 and a.net_issue_year = 2014 ) group by NET_BRANCH_CODE

for update

select NET_AGENT_ACCOUNT_NUMBER, NET_COMMITED_QUANTITY from agent_net_sales a
where (a.net_issue_ean = 977990382900101 and a.net_issue_year = 2014) 
and
(net_agent_account_number in (502963006925100,
502963066140000,
503103113796500,
560077560000300


)) for update

2	120	1367
1	560	3554
