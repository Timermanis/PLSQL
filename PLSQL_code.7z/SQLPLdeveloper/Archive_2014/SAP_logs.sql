select *
  from sap_extract_log l
 where l.branch_id = 'BRA350'
  -- and l.log_time >= (select max(log_time) from sap_extract_log where task = 'Started SAP transaction extract' 
  -- and branch_id = '&<name="Branch ID (From drop down list)">')
 order by l.log_time desc;
 
 select * from TWSD_350_20141114113551180366
 
 
