select * from all_cons_columns where column_name like '%VEND%' and owner = 'DW';
