select sum(t.MAIN_DELIVERIES+t.additional_deliveries) --Frontline Total Publisher Supply 2014 week 1-26  '87881670' vs '90448411'
 from plant_iss_summaries t,media m,latest_product_mv l 
where t.plant_issue_id = m.plis_id
and m.PROD_NUM=l.PROD_NUM
and l.PLIS_distributor_NUM =203840
and ISS_HANDLED_YEAR_WEEK_M <=201426 and ISS_HANDLED_YEAR_WEEK_M >=201401
and m.iss_segment_name not in ('MISCELLANEOUS','NEWSPAPERS','SPECIALS','VOUCHERS')
and m.ISS_TYPE_CODE NOT IN ('Z3','Z4');
-------------------------------------
select sum(t.MAIN_DELIVERIES+t.additional_deliveries) --Frontline Total Publisher Supply 2013 week 1-26 '95018994' vs '96646391'
 from plant_iss_summaries t,media m,latest_product_mv l 
where t.plant_issue_id = m.plis_id
and m.PROD_NUM=l.PROD_NUM
and l.PLIS_distributor_NUM =203840
and ISS_HANDLED_YEAR_WEEK_M <=201326 and ISS_HANDLED_YEAR_WEEK_M >=201301
and m.iss_segment_name not in ('MISCELLANEOUS','NEWSPAPERS','SPECIALS','VOUCHERS')
and m.ISS_TYPE_CODE NOT IN ('Z3','Z4');
---------------------------------------------------
select 87881670 / 95018994 from dual --0.924885291881747
select 90448411 / 96646391 from dual --0.935869514258427
