create table jt_check_PIX081214
as
(select *
from zpx_rtrn_stg_bak b
where b.etl_run_num_seq  between  1594 and 1601
and b.spoke_id = 220 --and b.issue_type is not null
and b.issue_type = 'Z5'
)

select *
from jt_check_PIX081214
where  not exists
              (select 1
               from plant_issues_xref x
               where x.PIX_BRANCH_CODE = 'BRA220'
               and x.PIX_SAP_ID = jt_check_PIX081214.issue_id
               )

