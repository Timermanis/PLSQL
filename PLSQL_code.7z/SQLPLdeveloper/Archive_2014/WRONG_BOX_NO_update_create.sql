--create table jt_280814_wr_box_ans_whole as
select c.cus_box_number,n.net_box_number, n.net_issue_ean,n.net_agent_account_number,n.net_issue_year, n.rowid as the_rowid from agent_net_sales n , customers c, branch_issues b
where  b.bris_issue_year = 2014
--and b.bris_issue_week =33
and n.net_issue_year = 2013                                         --this year branch_issues
and c.cus_account_number = n.net_agent_account_number               --join sales-customer 
and b.bris_branch_code=c.cus_branch_code                            --join extra           
and n.net_issue_ean = b.bris_ean                                    --join sales-branch_issues
and n.net_issue_year = b.bris_issue_year                            --join sales-branch_issues
and n.net_branch_code = b.bris_branch_code                          --join sales-branch_issues
and c.cus_branch_code=n.net_branch_code                             --join extra
and b.bris_on_sale_date between c.cus_from_date and c.cus_to_date   --branch sales date between, from - to date in Customers 
and n.net_box_number != c.cus_box_number                            --restrictions box numbers are different sales-customers
                                      
--UPDATE    agent_net_sales ans
SET       ans.net_box_number = (SELECT    d.cus_box_number
                                FROM      jt_280814_wr_box_ans_whole d
                                where     d.the_rowid = ans.rowid )                                         
where     ans.ROWID in (select THE_ROWID from jt_280814_wr_box_ans_whole)
