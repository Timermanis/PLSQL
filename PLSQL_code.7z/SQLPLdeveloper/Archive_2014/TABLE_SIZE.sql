select owner, table_name,   NUM_ROWS--round((num_rows*avg_row_len)/(1024*1024)) MB,
from all_tables 
where owner ='DW'  -- Exclude system tables.
and num_rows > 0  -- Ignore empty Tables.
order by NUM_ROWS desc; -- Biggest first.

select * from all_tables
where owner ='DW'  -- Exclude system tables.
and num_rows > 0  -- Ignore empty Tables.
 
