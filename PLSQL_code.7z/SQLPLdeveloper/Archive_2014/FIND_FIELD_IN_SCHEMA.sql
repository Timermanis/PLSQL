select table_name,c.* from dba_tab_columns c where column_name like'%SPOKE%' and owner = 'JM';
select * from SPOKE_BRANCHES
select * from ICSD_220_20140713030132841613
