select * from latest_product_mv p where p.prod_name like'%XMAS TV TIME%'--PROD_NUM 5974
select * from media where PROD_NUM = 5974 and plis_plant_num = 850 and plis_id = 50739080
select sum(ISS_RETAIL_PRICE_M) from plant_iss_summaries p, media m where m.plis_issue_num=p.issue_num and m.prod_num=5974 and p.cus_plant_num = 850
select * from plant_iss_summaries p where p.issue_num = 59742004 and cus_plant_num in (740,790,910)
