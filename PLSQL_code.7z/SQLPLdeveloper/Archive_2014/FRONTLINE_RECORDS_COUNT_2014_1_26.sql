select count(*) from (select distinct t.OUT_num,t.plis_issue_num
from PLANT_CUST_ISS_RTRN_SUMMARIES t,media m,latest_product_mv l 
where t.plant_issue_id = m.plis_id
and m.PROD_NUM=l.PROD_NUM
and l.PLIS_distributor_NUM =203840
and m.ISS_HANDLED_YEAR_WEEK_M  >=  201401
AND m.ISS_HANDLED_YEAR_WEEK_M  <=  201426
and m.iss_segment_name not in ('MISCELLANEOUS','NEWSPAPERS','SPECIALS','VOUCHERS')--13572468 (13572479 in 061014)
and m.iss_partitioning_date = t.partitioning_date))

select sum(t.copies_invoiced-t.credits)
from PLANT_CUST_ISS_RTRN_SUMMARIES t,media m,latest_product_mv l 
where t.plant_issue_id = m.plis_id
and m.PROD_NUM=l.PROD_NUM
and l.PLIS_distributor_NUM =203840
and m.ISS_HANDLED_YEAR_WEEK_M  >=  201401
AND m.ISS_HANDLED_YEAR_WEEK_M  <=  201426
and m.iss_segment_name not in ('MISCELLANEOUS','NEWSPAPERS','SPECIALS','VOUCHERS')
and m.iss_partitioning_date = t.partitioning_date;  --56 132 118

select * from PLANT_CUST_ISS_RTRN_SUMMARIES
-------------------------------------------------Fix problem Peter Sloan---------------
select PLIS_PLANT_NUM, sum(COPIES_INVOICED), m.iss_type_code
from PLANT_CUST_ISS_RTRN_SUMMARIES t,media m,latest_product_mv l 
where t.plant_issue_id = m.plis_id
and m.PROD_NUM=l.PROD_NUM
and m.ISS_HANDLED_YEAR_WEEK_M  >=  201439
and l.prod_name like '%DRAW THE MARVEL WAY%'
and m.iss_partitioning_date = t.partitioning_date
group by PLIS_PLANT_NUM, m.iss_type_code;  

BRA120	2727
BRA560	7123

select m.iss_type_code,t.*,m.*,l.*
from PLANT_CUST_ISS_RTRN_SUMMARIES t,media m,latest_product_mv l 
where t.plant_issue_id = m.plis_id
and m.PROD_NUM=l.PROD_NUM
and m.ISS_HANDLED_YEAR_WEEK_M  >=  201439
and l.prod_name like '%DRAW THE MARVEL WAY%'
and m.iss_partitioning_date = t.partitioning_date
and m.iss_type_code = 'Z4'
--group by PLIS_PLANT_NUM, m.iss_type_code;  

select * from plant_cust_iss_rtrn_summaries;
--create table jt_data_fix.jm@hodev
select m.plis_plant_num,sum(COPIES_INVOICED)
from plant_cust_iss_rtrn_summaries t,media m,latest_product_mv l 
where t.plant_issue_id = m.plis_id
and m.PROD_NUM=l.PROD_NUM
and m.ISS_HANDLED_YEAR_WEEK_M  >=  201439
and l.prod_name like '%DRAW THE MARVEL WAY%'
and m.iss_partitioning_date = t.partitioning_date
and m.iss_type_code = 'Z4'
--and m.plis_plant_num = 560
group by PLIS_PLANT_NUM





select m.iss_type_code, m.plis_plant_num ,m.plis_issue_num, t.* 
from PLANT_CUST_ISS_RTRN_SUMMARIES t,media m,latest_product_mv l 
where t.plant_issue_id = m.dimension_key --m.plis_id
and m.PROD_NUM=l.PROD_NUM
and m.iss_original_year_week  =  201436
and t.out_num = 132512
and m.iss_partitioning_date = t.partitioning_date
and m.prod_num = 39986
--group by PLIS_PLANT_NUM, m.iss_type_code;  
