select * from all_db_links
