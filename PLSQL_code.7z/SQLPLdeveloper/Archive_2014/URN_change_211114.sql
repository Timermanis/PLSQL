select *
  from agent_net_sales d
 where d.net_agent_account_number in (220154163000000)--(502963003836301,348223101004600,502963083260200,590219081204100)
   and not exists (SELECT 1
                     FROM title_history_2, titles, branch_issues, customers
                    WHERE cus_branch_code = bris_branch_code
                      AND bris_invoice_date BETWEEN cus_from_date AND cus_to_date
                      AND titl_code = bris_title_code
                      AND th_code(+) = bris_title_code
                      AND bris_invoice_date BETWEEN th_from_date(+) AND th_to_date(+)
                      AND bris_ean = d.net_issue_ean
                      AND bris_issue_year = d.net_issue_year
                      AND cus_account_number = d.net_agent_account_number);
                      
Maidstone � 146370 from 502963003836301 to 502963003836300
Maidstone � 135856 from 348223101004600 to 502963025172400
Maidstone � 102644 from 502963083260200 to 503103128784400
Maidstone � 120632 from 590219081204100 to 503103139551800

                      
                      
                      
truncate table dc_ans;

insert into dc_ans
select *
  from agent_net_sales d
 where d.net_agent_account_number in (502963003836301,348223101004600,502963083260200,590219081204100)
   and not exists (SELECT 1
                     FROM title_history_2, titles, branch_issues, customers
                    WHERE cus_branch_code = bris_branch_code
                      AND bris_invoice_date BETWEEN cus_from_date AND cus_to_date
                      AND titl_code = bris_title_code
                      AND th_code(+) = bris_title_code
                      AND bris_invoice_date BETWEEN th_from_date(+) AND th_to_date(+)
                      AND bris_ean = d.net_issue_ean
                      AND bris_issue_year = d.net_issue_year
                      AND cus_account_number = d.net_agent_account_number);


delete from agent_net_sales s
 where (s.net_agent_account_number, s.net_issue_ean, s.net_issue_year) in (select s1.net_agent_account_number, s1.net_issue_ean, s1.net_issue_year
                                                                             from dc_ans s1);

commit;
