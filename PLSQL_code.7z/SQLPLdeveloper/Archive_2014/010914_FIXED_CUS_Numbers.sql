select * from customers c where --c.CUS_BOX_NUMBER =10018
c.cus_account_number =503103139113800 for update;--303103139113800  changed first to 3

select * from customers c where --c.CUS_BOX_NUMBER =10018
c.cus_account_number =503103139119000  for update--303103139119000 changed first to 3

-delete from customers where cus_account_number =503103139113800 and cus_to_date = to_date ('31/12/4000','dd/mm/yyyy')
select * from customers c
where 
c.cus_box_number = 10011--like '22014902500070%'  for update

select * from multiple 

-create table jt_010914_cust_1 as
select * from customers c where 
c.cus_account_number=503103139119000

select *
from customers c
where c.cus_account_number = 503103139113800

select *
from customer_x_ref x
where x.ccr_cust_urn = 503103139113800
